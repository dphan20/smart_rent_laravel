<?php
/**
 * Measure just the Laravel bootstrap time
 */
$startTotal = microtime(true);

// Bootstrap Laravel
$startLaravel = microtime(true);
require_once __DIR__ . '/bootstrap/app.php';
$laravelTime = (microtime(true) - $startLaravel) * 1000;

// Create and handle app
$startKernel = microtime(true);
$app = require_once __DIR__ . '/bootstrap/app.php';
$kernel = $app->make(\Illuminate\Contracts\Http\Kernel::class);
$kernelTime = (microtime(true) - $startKernel) * 1000;

echo "Laravel Bootstrap Timing\n";
echo "========================\n";
echo "Bootstrap app.php: " . number_format($laravelTime, 2) . "ms\n";
echo "Kernel creation: " . number_format($kernelTime, 2) . "ms\n";
echo "\n";
echo "This represents the overhead added by Laravel before\n";
echo "our backend script even gets invoked.\n";
