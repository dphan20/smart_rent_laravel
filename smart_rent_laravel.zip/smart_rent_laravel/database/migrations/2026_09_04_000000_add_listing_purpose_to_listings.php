<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Lets a landlord (via the "Upload Property" form) or an admin (via the
 * "Add New Room" form) mark a listing as for long-term Rental or for
 * short-term Holiday/vacation stays. Defaults to 'rental' so every
 * existing listing keeps behaving exactly as it does today.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('properties', function (Blueprint $table) {
            if (!Schema::hasColumn('properties', 'listing_purpose')) {
                $table->enum('listing_purpose', ['rental', 'holiday'])
                    ->default('rental')
                    ->after('type');
            }
        });

        Schema::table('rooms', function (Blueprint $table) {
            if (!Schema::hasColumn('rooms', 'listing_purpose')) {
                $table->enum('listing_purpose', ['rental', 'holiday'])
                    ->default('rental')
                    ->after('type');
            }
        });
    }

    public function down(): void
    {
        Schema::table('properties', function (Blueprint $table) {
            if (Schema::hasColumn('properties', 'listing_purpose')) {
                $table->dropColumn('listing_purpose');
            }
        });

        Schema::table('rooms', function (Blueprint $table) {
            if (Schema::hasColumn('rooms', 'listing_purpose')) {
                $table->dropColumn('listing_purpose');
            }
        });
    }
};
