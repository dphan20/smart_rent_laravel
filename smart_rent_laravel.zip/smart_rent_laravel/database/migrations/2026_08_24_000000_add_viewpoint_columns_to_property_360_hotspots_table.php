<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

/**
 * Adds support for "same-panorama viewpoint" hotspots: a hotspot that,
 * instead of navigating to another uploaded panorama, just re-orients the
 * viewer to a different part of the SAME panorama (e.g. "Kitchen" pin in
 * the Living Room scene that spins the viewer to face the kitchen area).
 *
 * Like the 2026_08_21 migration this only declares the schema for
 * `php artisan migrate` - the actual reads/writes are raw PDO in
 * public/backend/models/Tour360.php, matching the rest of this table.
 *
 * Purely additive: existing 'navigation' and 'info' hotspots are
 * unaffected, target_tour_id / yaw / pitch keep meaning exactly what they
 * meant before. No data is dropped or altered.
 */
return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('property_360_hotspots')) {
            return;
        }

        if (!Schema::hasColumn('property_360_hotspots', 'target_yaw')) {
            DB::statement('ALTER TABLE property_360_hotspots ADD COLUMN target_yaw FLOAT NULL AFTER target_tour_id');
        }
        if (!Schema::hasColumn('property_360_hotspots', 'target_pitch')) {
            DB::statement('ALTER TABLE property_360_hotspots ADD COLUMN target_pitch FLOAT NULL AFTER target_yaw');
        }
        if (!Schema::hasColumn('property_360_hotspots', 'target_hfov')) {
            DB::statement('ALTER TABLE property_360_hotspots ADD COLUMN target_hfov FLOAT NULL AFTER target_pitch');
        }

        // Widen the type enum to add 'viewpoint' alongside the existing
        // 'navigation' and 'info' values. Re-declaring the full enum list
        // (rather than just appending) is required by MySQL's MODIFY
        // COLUMN syntax, but every existing value is preserved so no row
        // changes meaning.
        DB::statement("ALTER TABLE property_360_hotspots MODIFY COLUMN type ENUM('navigation','info','viewpoint') NOT NULL DEFAULT 'info'");
    }

    public function down(): void
    {
        if (!Schema::hasTable('property_360_hotspots')) {
            return;
        }

        // Degrade any existing 'viewpoint' hotspots to 'info' first so the
        // narrower enum below can't reject them.
        DB::statement("UPDATE property_360_hotspots SET type = 'info' WHERE type = 'viewpoint'");
        DB::statement("ALTER TABLE property_360_hotspots MODIFY COLUMN type ENUM('navigation','info') NOT NULL DEFAULT 'info'");

        foreach (['target_hfov', 'target_pitch', 'target_yaw'] as $col) {
            if (Schema::hasColumn('property_360_hotspots', $col)) {
                DB::statement("ALTER TABLE property_360_hotspots DROP COLUMN {$col}");
            }
        }
    }
};
