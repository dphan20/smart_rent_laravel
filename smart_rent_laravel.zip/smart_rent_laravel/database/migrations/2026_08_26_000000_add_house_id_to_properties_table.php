<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Adds the permanent, automatically-generated public "House ID" to
     * existing properties. Nullable + unique: existing rows keep working
     * (Part 6/50/51 - no data loss, no forced re-save), and a follow-up
     * backfill (public/backend/backfill_house_ids.php) fills in an ID for
     * every row that doesn't have one yet.
     */
    public function up(): void
    {
        if (!Schema::hasColumn('properties', 'house_id')) {
            Schema::table('properties', function (Blueprint $table) {
                $table->string('house_id', 40)->nullable()->unique()->after('id');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('properties', 'house_id')) {
            Schema::table('properties', function (Blueprint $table) {
                $table->dropUnique(['house_id']);
                $table->dropColumn('house_id');
            });
        }
    }
};
