﻿<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('properties', function (Blueprint $table) {
            if (!Schema::hasColumn('properties', 'construction_status')) {
                $table->enum('construction_status', ['finished', 'semi_finished', 'unfinished'])
                    ->default('finished')
                    ->after('type');
            }
            if (!Schema::hasColumn('properties', 'nearby_landmarks')) {
                $table->text('nearby_landmarks')->nullable()->after('coords');
            }
            if (!Schema::hasColumn('properties', 'sri')) {
                $table->string('sri', 32)->nullable()->after('id');
            }
            if (!Schema::hasColumn('properties', 'rental_mode')) {
                $table->string('rental_mode', 20)->default('rent')->after('type');
            }
        });

        Schema::table('rooms', function (Blueprint $table) {
            if (!Schema::hasColumn('rooms', 'construction_status')) {
                $table->enum('construction_status', ['finished', 'semi_finished', 'unfinished'])
                    ->default('finished')
                    ->after('type');
            }
            if (!Schema::hasColumn('rooms', 'nearby_landmarks')) {
                $table->text('nearby_landmarks')->nullable()->after('area');
            }
            if (!Schema::hasColumn('rooms', 'rental_mode')) {
                $table->string('rental_mode', 20)->default('rent')->after('type');
            }
        });

        DB::statement("UPDATE properties SET sri = CONCAT('TZ-', UPPER(COALESCE(region, 'DAR')), '-', LPAD(CAST((RAND() * 99999999) AS UNSIGNED), 8, '0')) WHERE sri IS NULL OR sri = ''");

        Schema::table('properties', function (Blueprint $table) {
            $table->unique('sri');
            $table->index('sri');
        });
    }

    public function down(): void
    {
        Schema::table('properties', function (Blueprint $table) {
            if (Schema::hasColumn('properties', 'nearby_landmarks')) {
                $table->dropColumn('nearby_landmarks');
            }
            if (Schema::hasColumn('properties', 'construction_status')) {
                $table->dropColumn('construction_status');
            }
            if (Schema::hasColumn('properties', 'sri')) {
                $table->dropUnique(['sri']);
                $table->dropIndex(['sri']);
                $table->dropColumn('sri');
            }
        });

        Schema::table('rooms', function (Blueprint $table) {
            if (Schema::hasColumn('rooms', 'nearby_landmarks')) {
                $table->dropColumn('nearby_landmarks');
            }
            if (Schema::hasColumn('rooms', 'construction_status')) {
                $table->dropColumn('construction_status');
            }
        });
    }
};
