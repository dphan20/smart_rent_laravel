<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * NOTE: like the rest of Smart Rent's property/room data, these tables
     * are actually read and written by the legacy PHP backend
     * (public/backend/models/Tour360.php) using raw PDO, not Eloquent.
     * They're declared here only so `php artisan migrate` can create them
     * in the shared `smartrent` MySQL database, matching how the existing
     * `users`/`rooms`/`properties` tables are handled in this project.
     *
     * A listing can be either a `room` or a `property` (they are two
     * separate tables with different schemas - see GroqService's
     * normalizeListing()), so tours are linked polymorphically via
     * (listing_type, listing_id) rather than a single foreign key.
     */
    public function up(): void
    {
        if (!Schema::hasTable('property_360_tours')) {
            Schema::create('property_360_tours', function (Blueprint $table) {
                $table->id();
                $table->enum('listing_type', ['room', 'property']);
                $table->unsignedBigInteger('listing_id');
                $table->string('name');
                $table->string('image'); // stored path to the panorama image
                $table->text('description')->nullable();
                $table->boolean('is_primary')->default(false);
                $table->unsignedBigInteger('created_by')->nullable();
                $table->timestamps();

                $table->index(['listing_type', 'listing_id']);
            });
        }

        if (!Schema::hasTable('property_360_hotspots')) {
            Schema::create('property_360_hotspots', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('tour_id');
                $table->unsignedBigInteger('target_tour_id')->nullable();
                $table->enum('type', ['navigation', 'info'])->default('info');
                $table->float('yaw');
                $table->float('pitch');
                $table->string('title')->nullable();
                $table->text('description')->nullable();
                $table->timestamps();

                $table->foreign('tour_id')->references('id')->on('property_360_tours')->onDelete('cascade');
                // Deliberately no FK constraint on target_tour_id: if the target
                // scene is deleted we want the hotspot to degrade gracefully
                // (see Tour360::deleteTour(), which nulls references instead of
                // cascading), not silently vanish along with an unrelated scene.
                $table->index('target_tour_id');
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('property_360_hotspots');
        Schema::dropIfExists('property_360_tours');
    }
};
