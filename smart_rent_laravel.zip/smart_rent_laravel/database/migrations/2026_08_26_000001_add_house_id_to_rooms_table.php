<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Rooms are this app's actual bookable/searchable listing entity (see
     * bookings.room_id), so each room also gets its own permanent House ID
     * - identical to its parent property's House ID when the room was
     * created together with a property (PropertyController::create), or
     * freshly generated from the room's own location/area when the room
     * was created standalone (RoomController::create, no parent property).
     */
    public function up(): void
    {
        if (!Schema::hasColumn('rooms', 'house_id')) {
            Schema::table('rooms', function (Blueprint $table) {
                $table->string('house_id', 40)->nullable()->unique()->after('id');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('rooms', 'house_id')) {
            Schema::table('rooms', function (Blueprint $table) {
                $table->dropUnique(['house_id']);
                $table->dropColumn('house_id');
            });
        }
    }
};
