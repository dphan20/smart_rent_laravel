# Smart Rent — Laravel backend patch (media/CORS fix)

## What changed
`public/backend/api.php` gained one new resource: `media`. It re-serves
files from `public/uploads/` through this script (which already sets
CORS headers from `SMART_RENT_ALLOWED_ORIGINS`) instead of letting the
PHP dev server hand them out directly as static files with no CORS
header at all.

This is required for:
- Images to reliably display in the Flutter **web** build (Chrome).
- The **360° virtual tour** to work in the Flutter web build at all —
  the panorama viewer needs real pixel bytes to map onto its sphere,
  which browsers withhold cross-origin without a CORS header, regardless
  of Flutter's renderer choice.

Android and iOS native builds are unaffected either way (native HTTP
clients aren't subject to browser CORS), but they benefit too since it's
one consistent code path for every platform.

## How to apply
Replace your existing `public/backend/api.php` with the one in this
folder — it's the same file, with one new `case 'media':` block added
right before the final `default:` in the dispatch switch, plus a doc
comment above it. Nothing else in your Laravel project needs to change.
The matching Flutter app already points its image URLs at
`/api/media/...` instead of `/uploads/...`.

## What it does NOT change
- No new routes/web.php or routes/api.php changes needed — the existing
  catch-all in routes/api.php already forwards `/api/media/...` into
  this script like every other resource.
- No database changes.
- No changes to how/where files are uploaded — only how they're served
  back out.
- Directory traversal is blocked (`realpath()` + prefix check) before
  any file is read.
