<?php
$email = 'cookie_test_' . bin2hex(random_bytes(4)) . '@example.com';
$pass = 'Pass123!';
$jar = tempnam(sys_get_temp_dir(), 'sm');

echo "Cookie jar: $jar\n";

// SIGNUP
$ch = curl_init('http://127.0.0.1:8000/api/auth/signup');
curl_setopt_array($ch, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_COOKIEJAR => $jar,
  CURLOPT_COOKIEFILE => $jar,
  CURLOPT_POST => true,
  CURLOPT_POSTFIELDS => json_encode(['name' => 'Test User', 'email' => $email, 'phone' => '0770000000', 'password' => $pass, 'type' => 'Customer']),
  CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Accept: application/json'],
  CURLOPT_VERBOSE => true
]);
$signup = curl_exec($ch);
$signupCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
echo "SIGNUP ($signupCode)\n";
curl_close($ch);

echo "\nCookie jar after signup:\n";
echo file_get_contents($jar) . "\n";

// LOGIN
$ch2 = curl_init('http://127.0.0.1:8000/api/auth/login');
curl_setopt_array($ch2, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_COOKIEJAR => $jar,
  CURLOPT_COOKIEFILE => $jar,
  CURLOPT_POST => true,
  CURLOPT_POSTFIELDS => json_encode(['email' => $email, 'password' => $pass]),
  CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Accept: application/json']
]);
$login = curl_exec($ch2);
$loginCode = curl_getinfo($ch2, CURLINFO_HTTP_CODE);
echo "\nLOGIN ($loginCode)\n";
curl_close($ch2);

echo "\nCookie jar after login:\n";
echo file_get_contents($jar) . "\n";

// CHECK
$ch3 = curl_init('http://127.0.0.1:8000/api/auth/check');
curl_setopt_array($ch3, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_COOKIEJAR => $jar,
  CURLOPT_COOKIEFILE => $jar
]);
$check = curl_exec($ch3);
$checkCode = curl_getinfo($ch3, CURLINFO_HTTP_CODE);
echo "\nCHECK ($checkCode): $check\n";
curl_close($ch3);

@unlink($jar);
