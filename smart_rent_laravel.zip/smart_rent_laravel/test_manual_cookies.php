<?php
$email = 'manual_cookie_test_' . bin2hex(random_bytes(4)) . '@example.com';
$pass = 'Pass123!';

// SIGNUP
$ch = curl_init('http://127.0.0.1:8000/api/auth/signup');
curl_setopt_array($ch, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_POST => true,
  CURLOPT_POSTFIELDS => json_encode(['name' => 'Test User', 'email' => $email, 'phone' => '0770000000', 'password' => $pass, 'type' => 'Customer']),
  CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Accept: application/json']
]);
$signup = curl_exec($ch);
$signupCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$headers = [];
curl_setopt($ch, CURLOPT_HEADERFUNCTION, function($curl, $header) use (&$headers) {
    $len = strlen($header);
    $header = explode(':', $header, 2);
    if (count($header) < 2) return $len;
    $name = strtolower(trim($header[0]));
    $value = trim($header[1]);
    if ($name === 'set-cookie') {
        $headers[] = $value;
    }
    return $len;
});
curl_exec($ch);
curl_close($ch);
echo "SIGNUP ($signupCode)\n";

// Extract session cookie from Set-Cookie header
$sessionCookie = '';
foreach ($headers as $cookie) {
    if (strpos($cookie, 'SMART_RENT_SESSID=') === 0) {
        $parts = explode(';', $cookie);
        $sessionCookie = trim($parts[0]);
        break;
    }
}
echo "Session cookie: $sessionCookie\n";

if (!$sessionCookie) {
    echo "No session cookie received!\n";
    exit(1);
}

// LOGIN - with the session cookie
$ch2 = curl_init('http://127.0.0.1:8000/api/auth/login');
curl_setopt_array($ch2, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_POST => true,
  CURLOPT_POSTFIELDS => json_encode(['email' => $email, 'password' => $pass]),
  CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Accept: application/json', 'Cookie: ' . $sessionCookie]
]);
$login = curl_exec($ch2);
$loginCode = curl_getinfo($ch2, CURLINFO_HTTP_CODE);
echo "\nLOGIN ($loginCode): " . json_decode($login, true)['success'] . "\n";
curl_close($ch2);

// CHECK - with the same session cookie
$ch3 = curl_init('http://127.0.0.1:8000/api/auth/check');
curl_setopt_array($ch3, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_HTTPHEADER => ['Cookie: ' . $sessionCookie]
]);
$check = curl_exec($ch3);
$checkCode = curl_getinfo($ch3, CURLINFO_HTTP_CODE);
$checkData = json_decode($check, true);
echo "\nCHECK ($checkCode): loggedIn=" . ($checkData['loggedIn'] ? 'true' : 'false') . "\n";
if ($checkData['loggedIn']) {
    echo "Session is working!\n";
} else {
    echo "Session is NOT working - user still not logged in!\n";
}
curl_close($ch3);
