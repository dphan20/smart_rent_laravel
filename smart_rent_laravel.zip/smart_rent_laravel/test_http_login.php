<?php
/**
 * Test HTTP Login Flow
 * Tests the complete login process via HTTP API
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "=== HTTP LOGIN FLOW TEST ===\n\n";

// Test data
$baseUrl = 'http://127.0.0.1:8000';
$loginUrl = $baseUrl . '/api/auth/login';
$checkUrl = $baseUrl . '/api/auth/check';

$credentials = [
    'email' => 'admin@smartrent.test',
    'password' => 'Admin123!Test',
    'remember' => false
];

echo "[1] Testing login endpoint...\n";
echo "    URL: $loginUrl\n";
echo "    Credentials: Email=" . $credentials['email'] . ", Password=***\n\n";

// Make login request
$curl = curl_init($loginUrl);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($credentials));
curl_setopt($curl, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($curl, CURLOPT_COOKIEJAR, '/tmp/cookies.txt'); // Save cookies
curl_setopt($curl, CURLOPT_COOKIEFILE, '/tmp/cookies.txt'); // Use saved cookies
curl_setopt($curl, CURLOPT_HEADER, true); // Get headers
curl_setopt($curl, CURLOPT_TIMEOUT, 10);

$response = curl_exec($curl);
$httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
$headerSize = curl_getinfo($curl, CURLINFO_HEADER_SIZE);
$header = substr($response, 0, $headerSize);
$body = substr($response, $headerSize);

curl_close($curl);

echo "[2] Login Response...\n";
echo "    HTTP Status: $httpCode\n";
echo "    Headers:\n";
foreach (explode("\n", $header) as $line) {
    if (trim($line)) {
        echo "        " . trim($line) . "\n";
    }
}

$loginData = json_decode($body, true);
echo "    Body:\n";
echo "        " . json_encode($loginData, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n";

if ($httpCode === 200 && $loginData['success']) {
    echo "\n    [+] LOGIN SUCCESSFUL\n";
    $user = $loginData['user'] ?? [];
    echo "        User ID: " . ($user['id'] ?? 'N/A') . "\n";
    echo "        Name: " . ($user['name'] ?? 'N/A') . "\n";
    echo "        Email: " . ($user['email'] ?? 'N/A') . "\n";
    echo "        Type: " . ($user['type'] ?? 'N/A') . "\n";
} else {
    echo "\n    [-] LOGIN FAILED\n";
    echo "        Error: " . ($loginData['message'] ?? 'Unknown error') . "\n";
}

// Test check-session
echo "\n[3] Testing session check endpoint...\n";
$curl = curl_init($checkUrl);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_COOKIEJAR, '/tmp/cookies.txt'); // Save cookies
curl_setopt($curl, CURLOPT_COOKIEFILE, '/tmp/cookies.txt'); // Use saved cookies
curl_setopt($curl, CURLOPT_TIMEOUT, 10);

$response = curl_exec($curl);
$httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
$checkData = json_decode($response, true);

curl_close($curl);

echo "    HTTP Status: $httpCode\n";
echo "    Response: " . json_encode($checkData, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n";

if ($checkData['loggedIn'] ?? false) {
    echo "\n    [+] SESSION CHECK SUCCESSFUL - User is logged in\n";
    $user = $checkData['user'] ?? [];
    echo "        User ID: " . ($user['id'] ?? 'N/A') . "\n";
    echo "        Name: " . ($user['name'] ?? 'N/A') . "\n";
    echo "        Email: " . ($user['email'] ?? 'N/A') . "\n";
} else {
    echo "\n    [-] SESSION CHECK FAILED - User is not logged in\n";
}

echo "\n=== TEST COMPLETE ===\n";
