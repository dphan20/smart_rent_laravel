<?php
$pdo = new PDO("mysql:host=127.0.0.1;port=3306;dbname=smartrent;charset=utf8mb4", "root", "");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Clean slate: drop and recreate auth tables to ensure clean state
$tables = ['login_attempts', 'password_resets', 'remember_tokens', 'email_verifications'];
foreach ($tables as $table) {
    try {
        $pdo->exec("DROP TABLE IF EXISTS `$table`");
        echo "Dropped $table\n";
    } catch (Exception $e) {
        echo "Drop $table failed: " . $e->getMessage() . "\n";
    }
}

// Now recreate them cleanly
try {
    $pdo->exec("CREATE TABLE `login_attempts` (
        id INT AUTO_INCREMENT PRIMARY KEY,
        email VARCHAR(191) NOT NULL,
        ip_address VARCHAR(45) NOT NULL,
        success TINYINT(1) NOT NULL DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_login_attempts_ip_time (ip_address, created_at),
        INDEX idx_login_attempts_email_time (email, created_at)
    ) ENGINE=InnoDB");
    echo "Created login_attempts\n";
    
    $pdo->exec("CREATE TABLE `password_resets` (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        token_hash CHAR(64) NOT NULL,
        expires_at DATETIME NOT NULL,
        used_at DATETIME NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_password_resets_token_hash (token_hash),
        INDEX idx_password_resets_user (user_id),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB");
    echo "Created password_resets\n";
    
    $pdo->exec("CREATE TABLE `remember_tokens` (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        selector CHAR(24) NOT NULL,
        token_hash CHAR(64) NOT NULL,
        expires_at DATETIME NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_remember_tokens_selector (selector),
        INDEX idx_remember_tokens_user (user_id),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB");
    echo "Created remember_tokens\n";
    
    $pdo->exec("CREATE TABLE `email_verifications` (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        token_hash CHAR(64) NOT NULL,
        expires_at DATETIME NOT NULL,
        verified_at DATETIME NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_email_verifications_token_hash (token_hash),
        INDEX idx_email_verifications_user (user_id),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB");
    echo "Created email_verifications\n";
    
    echo "\nAll auth tables recreated successfully!\n";
} catch (Exception $e) {
    echo "Error creating tables: " . $e->getMessage() . "\n";
}
