<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ChatController;

// AI Chat endpoints - publicly accessible (no login required)
Route::post('/chat', [ChatController::class, 'sendMessage']);
Route::post('/ai/chat', [ChatController::class, 'sendMessage']);
Route::post('/ai/match', [ChatController::class, 'match']);
Route::post('/ai/search', [ChatController::class, 'search']);
Route::post('/ai/ask-property', [ChatController::class, 'askProperty']);
Route::get('/ai/similar', [ChatController::class, 'similar']);
Route::post('/ai/compare', [ChatController::class, 'compare']);
// NOTE: not ->middleware('auth') — Laravel's own auth guard is never
// populated because login happens entirely through the legacy PHP backend's
// session. ChatController checks the logged-in user itself by asking the
// legacy backend's /auth/check endpoint (see currentLegacyUserId()).
Route::get('/chat/history', [ChatController::class, 'getHistory']);
Route::delete('/chat/history', [ChatController::class, 'clearHistory']);

// Dispatch directly into the legacy PHP backend in-process instead of
// re-entering Laravel via HTTP. This avoids the circular
// Laravel -> Laravel / PHP dev-server loop that caused slow requests,
// stale sessions, and failed auth. The legacy backend is the authoritative
// auth/session layer and it already uses the SMART_RENT_SESSID cookie.
Route::any('/{any?}', function (Request $request, $any = null) {
    $path = trim((string) $any, '/');
    $backendScript = base_path('public/backend/api.php');
    if (!is_file($backendScript)) {
        abort(500, 'Legacy backend script not found.');
    }

    $queryString = $request->getQueryString();
    $relativePath = $path !== '' ? '/' . $path : '/';
    $_SERVER['SCRIPT_NAME'] = '/backend/api.php';
    $_SERVER['PHP_SELF'] = '/backend/api.php';
    $_SERVER['SCRIPT_FILENAME'] = $backendScript;
    $_SERVER['DOCUMENT_ROOT'] = dirname($backendScript, 2);
    $_SERVER['REQUEST_URI'] = '/backend/api.php' . $relativePath . ($queryString ? '?' . $queryString : '');
    $_SERVER['PATH_INFO'] = $relativePath;
    $_SERVER['QUERY_STRING'] = $queryString ?? '';
    $_SERVER['REQUEST_METHOD'] = strtoupper($request->method());
    if ($request->header('content-type')) {
        $_SERVER['CONTENT_TYPE'] = $request->header('content-type');
    }
    $_GET = $request->query->all();
    if (strtoupper($request->method()) !== 'GET') {
        $_POST = $request->request->all();
        if (empty($_POST)) {
            $_POST = $request->all();
        }
        // $request->files->all() returns a tree of Symfony UploadedFile
        // OBJECTS, not the classic $_FILES array shape the legacy backend
        // (RoomController, PropertyController, UploadSecurity, ...) does
        // plain array access on ($_FILES['image']['error'], etc). Assigning
        // the objects straight into $_FILES made every upload throw
        // "Cannot use object of type ...UploadedFile as array" the instant
        // a file was attached - see App\Support\LegacyBackend::normalizeFilesArray()
        // for the full explanation.
        $_FILES = \App\Support\LegacyBackend::normalizeFilesArray($request->files->all());
    }

    // The legacy backend relies on global $pdo and $_SESSION state, and when
    // it is required from inside this route closure those variables are scoped
    // to the closure itself unless we expose them as globals here. Without
    // this, the included backend reaches RoomController::getAll() with $pdo = null
    // and fails with "Call to a member function prepare() on null".
    global $pdo;
    $_SESSION = $_SESSION ?? [];

    require $backendScript;
    exit;
})->where('any', '.*');