<?php

use Illuminate\Support\Facades\Route;

// Landing/marketing page is the first thing shown when the site opens.
Route::get('/', function () {
    return view('welcome');
});

// The main app (dashboard, browse, booking, etc.) - reached by navigating
// in from the landing page.
Route::get('/app', function () {
    return view('app');
});

// Optional standalone chat page kept available for direct access if needed.
Route::get('/chat', function () {
    return view('chat');
});

// Keep unknown routes on the app rather than redirecting to the legacy app,
// except the landing page itself, which is handled above.
Route::get('/{any}', function () {
    return view('app');
})->where('any', '.*');
