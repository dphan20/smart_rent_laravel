<?php
/**
 * PaymentService - currently just the webhook trust boundary.
 *
 * This does NOT call out to any payment gateway - there are no real
 * provider credentials anywhere in this codebase, and none should be
 * invented here. What this DOES do is verify that an inbound webhook
 * request actually came from whoever holds the configured shared secret,
 * so PaymentController::webhook() never has to trust an unsigned request
 * body.
 *
 * Secret resolution order (first one set wins):
 *   1. A provider-specific secret, e.g. MPESA_WEBHOOK_SECRET, for the
 *      payment_method on the payment being confirmed.
 *   2. PAYMENT_WEBHOOK_SECRET as a generic fallback.
 * If neither is set, verification fails closed (returns false) - a
 * misconfigured/unconfigured webhook must never silently accept requests.
 */
class PaymentService
{
    private static function providerEnvKey(string $paymentMethod): string
    {
        $normalized = strtolower(trim($paymentMethod));
        $map = [
            'mpesa' => 'MPESA_WEBHOOK_SECRET',
            'm-pesa' => 'MPESA_WEBHOOK_SECRET',
            'airtel' => 'AIRTEL_WEBHOOK_SECRET',
            'airtel money' => 'AIRTEL_WEBHOOK_SECRET',
            'mixx' => 'MIXX_WEBHOOK_SECRET',
            'mixx by yas' => 'MIXX_WEBHOOK_SECRET',
            'halopesa' => 'HALOPESA_WEBHOOK_SECRET',
            'halo pesa' => 'HALOPESA_WEBHOOK_SECRET',
            'card' => 'CARD_WEBHOOK_SECRET',
        ];
        return $map[$normalized] ?? 'PAYMENT_WEBHOOK_SECRET';
    }

    private static function resolveSecret(string $paymentMethod): ?string
    {
        $specific = getenv(self::providerEnvKey($paymentMethod));
        if ($specific !== false && $specific !== '') {
            return $specific;
        }
        $generic = getenv('PAYMENT_WEBHOOK_SECRET');
        return ($generic !== false && $generic !== '') ? $generic : null;
    }

    /**
     * @param string $rawBody   The exact, unmodified request body bytes.
     * @param array  $headers   Request headers (as from getallheaders()).
     * @param string $paymentMethod  payment_method of the payment being confirmed.
     */
    public static function verifyWebhookSignature(string $rawBody, array $headers, string $paymentMethod): bool
    {
        $secret = self::resolveSecret($paymentMethod);
        if ($secret === null) {
            return false; // fail closed: no secret configured = nothing is trusted
        }

        // Header lookup is case-insensitive - PHP's getallheaders() preserves
        // whatever casing the client sent.
        $signature = null;
        foreach ($headers as $name => $value) {
            if (strcasecmp($name, 'X-Signature') === 0) {
                $signature = $value;
                break;
            }
        }
        if (!$signature) {
            return false;
        }

        $expected = hash_hmac('sha256', $rawBody, $secret);
        return hash_equals($expected, (string) $signature);
    }
}
