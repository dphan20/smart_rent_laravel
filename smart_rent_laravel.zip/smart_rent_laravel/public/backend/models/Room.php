<?php
require_once __DIR__ . '/../config/database.php';

class Room {
    public static function getAll($filters = []) {
        global $pdo;
        $sql = "SELECT * FROM rooms WHERE 1=1";
        $params = [];
        if (!empty($filters['house_id'])) {
            // Exact-match lookup by the permanent public House ID - an
            // additional way to find a listing, alongside (not instead
            // of) the existing search filters below.
            $sql .= " AND house_id = ?";
            $params[] = trim($filters['house_id']);
        }
        if (!empty($filters['search'])) {
            $sql .= " AND (title LIKE ? OR location LIKE ? OR area LIKE ? OR house_id LIKE ?)";
            $like = '%' . $filters['search'] . '%';
            $params = array_merge($params, [$like, $like, $like, $like]);
        }
        if (!empty($filters['location'])) {
            $sql .= " AND location LIKE ?";
            $params[] = '%' . $filters['location'] . '%';
        }
        if (!empty($filters['area'])) {
            $sql .= " AND area = ?";
            $params[] = $filters['area'];
        }
        if (!empty($filters['max_price'])) {
            $sql .= " AND price <= ?";
            $params[] = (float)$filters['max_price'];
        }
        if (!empty($filters['min_size'])) {
            $sql .= " AND size >= ?";
            $params[] = (int)$filters['min_size'];
        }
        if (!empty($filters['type'])) {
            $sql .= " AND type = ?";
            $params[] = $filters['type'];
        }
        if (!empty($filters['sort'])) {
            switch ($filters['sort']) {
                case 'price-low': $sql .= " ORDER BY price ASC"; break;
                case 'price-high': $sql .= " ORDER BY price DESC"; break;
                case 'size-low': $sql .= " ORDER BY size ASC"; break;
                case 'size-high': $sql .= " ORDER BY size DESC"; break;
                default: $sql .= " ORDER BY id DESC";
            }
        } else {
            $sql .= " ORDER BY id DESC";
        }
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public static function find($id) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT * FROM rooms WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    /** Exact lookup by the permanent public House ID. */
    public static function findByHouseId($houseId) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT * FROM rooms WHERE house_id = ?");
        $stmt->execute([trim($houseId)]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function create($data) {
        global $pdo;
        // Permanent, automatically-generated public identifier. If the
        // caller (PropertyController) already generated one - because this
        // room is being created together with a parent property - reuse
        // that exact value so both records share one identity. Otherwise
        // (a standalone room created directly by Admin/Landlord) generate
        // a fresh one from this room's own location/area.
        require_once __DIR__ . '/../helpers/ListingIdGenerator.php';
        $houseId = $data['house_id'] ?? ListingIdGenerator::generate($pdo, 'rooms', $data['location'] ?? '', $data['area'] ?? '');

        // construction_status: finished / semi_finished / unfinished (defaults
        // to 'finished', matching the column default, if not supplied).
        // nearby_landmarks: optional JSON object of nearby social services
        // (hospital, police_station, bus_stand, beach, airport, school,
        // university) - stored as-is if the caller already sent a JSON
        // string, otherwise encoded from an array/object.
        $nearbyLandmarks = $data['nearby_landmarks'] ?? null;
        if (is_array($nearbyLandmarks)) {
            $nearbyLandmarks = json_encode($nearbyLandmarks);
        }

        $stmt = $pdo->prepare("INSERT INTO rooms (house_id, title, location, area, price, size, type, rental_mode, listing_purpose, construction_status, nearby_landmarks, beds, badge, status, image, landlord_id, virtual_tour, contract_terms) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $houseId,
            $data['title'],
            $data['location'],
            $data['area'],
            $data['price'],
            $data['size'],
            $data['type'],
            strtolower((string) ($data['rental_mode'] ?? 'rent')),
            $data['listing_purpose'] ?? 'rental',
            $data['construction_status'] ?? 'finished',
            $nearbyLandmarks,
            $data['beds'],
            $data['badge'] ?? null,
            $data['status'] ?? 'available',
            $data['image'] ?? null,
            $data['landlord_id'] ?? null,
            $data['virtual_tour'] ?? null,
            $data['contract_terms'] ?? null
        ]);
        return $pdo->lastInsertId();
    }

    /**
     * Parses whatever is currently in rooms.image into a plain list of
     * relative paths, regardless of whether it's a legacy single path
     * string, a JSON array (new multi-image gallery format), or empty.
     * Mirrors the frontend's parsePropertyImages() so both sides agree on
     * the same accepted shapes.
     */
    public static function parseImageList($rawImage): array {
        if ($rawImage === null || $rawImage === '') {
            return [];
        }
        $decoded = json_decode($rawImage, true);
        if (is_array($decoded)) {
            return array_values(array_filter(array_map('strval', $decoded), function ($v) {
                return trim($v) !== '';
            }));
        }
        return [$rawImage];
    }

    /** Persists a gallery (list of relative upload paths) back onto a room. */
    public static function saveImageList($id, array $images) {
        global $pdo;
        $stmt = $pdo->prepare("UPDATE rooms SET image = ? WHERE id = ?");
        return $stmt->execute([json_encode(array_values($images)), $id]);
    }

    private static array $updatableColumns = [
        'title', 'location', 'area', 'nearby_landmarks', 'price', 'size', 'type',
        'listing_purpose', 'rental_mode', 'construction_status', 'beds', 'badge',
        'status', 'image', 'virtual_tour', 'contract_terms',
    ];

    public static function update($id, $data) {
        global $pdo;
        $fields = [];
        $params = [];
        foreach ($data as $key => $value) {
            if (!in_array($key, self::$updatableColumns, true)) continue;
            $fields[] = "$key = ?";
            $params[] = $value;
        }
        if (empty($fields)) {
            return false;
        }
        $params[] = $id;
        $sql = "UPDATE rooms SET " . implode(', ', $fields) . " WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        return $stmt->execute($params);
    }

    public static function delete($id) {
        global $pdo;
        $stmt = $pdo->prepare("DELETE FROM rooms WHERE id = ?");
        return $stmt->execute([$id]);
    }
}