<?php
require_once __DIR__ . '/../config/database.php';

class Order {
    public static function getAll() {
        global $pdo;
        $stmt = $pdo->query("SELECT o.*, r.title AS room_title, r.location AS room_location, r.price AS room_price FROM orders o LEFT JOIN rooms r ON o.room_id = r.id ORDER BY o.created_at DESC");
        return $stmt->fetchAll();
    }

    public static function create($data) {
        global $pdo;
        $stmt = $pdo->prepare("INSERT INTO orders (room_id, user_id, landlord_id, customer_name, customer_email, customer_phone, arrival_date, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $data['room_id'],
            $data['user_id'] ?? null,
            $data['landlord_id'] ?? null,
            $data['customer_name'],
            $data['customer_email'],
            $data['customer_phone'],
            $data['arrival_date'] ?? null,
            $data['status'] ?? 'ordered'
        ]);
        return $pdo->lastInsertId();
    }

    private static array $updatableColumns = [
        'customer_name', 'customer_email', 'customer_phone', 'arrival_date', 'status',
    ];

    public static function update($id, $data) {
        global $pdo;
        $fields = [];
        $params = [];
        foreach ($data as $key => $value) {
            if (!in_array($key, self::$updatableColumns, true)) continue;
            $fields[] = "$key = ?";
            $params[] = $value;
        }
        if (empty($fields)) {
            return false;
        }
        $params[] = $id;
        $sql = "UPDATE orders SET " . implode(', ', $fields) . " WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        return $stmt->execute($params);
    }

    public static function delete($id) {
        global $pdo;
        $stmt = $pdo->prepare("DELETE FROM orders WHERE id = ?");
        return $stmt->execute([$id]);
    }
}