<?php
require_once __DIR__ . '/../config/database.php';

class Property {
    public static function getAll($landlordId = null, $houseId = null) {
        global $pdo;
        $sql = "SELECT * FROM properties";
        $where = [];
        $params = [];
        if ($landlordId) {
            $where[] = "landlord_id = ?";
            $params[] = $landlordId;
        }
        if ($houseId) {
            $where[] = "house_id = ?";
            $params[] = trim($houseId);
        }
        if ($where) {
            $sql .= " WHERE " . implode(' AND ', $where);
        }
        $sql .= " ORDER BY created_at DESC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /** Exact lookup by the permanent public House ID. */
    public static function findByHouseId($houseId) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT * FROM properties WHERE house_id = ?");
        $stmt->execute([trim($houseId)]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function find($id) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT * FROM properties WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public static function create($data) {
        global $pdo;
        // Permanent, automatically-generated public identifier - never
        // supplied by the caller/Landlord, generated once here and kept
        // unchanged for the life of the listing (see ListingIdGenerator).
        require_once __DIR__ . '/../helpers/ListingIdGenerator.php';
        $houseId = $data['house_id'] ?? ListingIdGenerator::generate($pdo, 'properties', $data['region'] ?? '', $data['district'] ?? '');

        // See Room::create() for the same construction_status /
        // nearby_landmarks handling.
        $nearbyLandmarks = $data['nearby_landmarks'] ?? null;
        if (is_array($nearbyLandmarks)) {
            $nearbyLandmarks = json_encode($nearbyLandmarks);
        }

        $stmt = $pdo->prepare("INSERT INTO properties (house_id, landlord_id, name, type, rental_mode, listing_purpose, construction_status, apartment, house_no, region, district, ward, street, location, coords, nearby_landmarks, description, bedrooms, bathrooms, amenities, furnished, room_size, monthly_rent, deposit, service_charge, availability, images, video, virtual_tour) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $houseId,
            $data['landlord_id'],
            $data['name'],
            $data['type'],
            strtolower((string) ($data['rental_mode'] ?? 'rent')),
            $data['listing_purpose'] ?? 'rental',
            $data['construction_status'] ?? 'finished',
            $data['apartment'] ?? null,
            $data['houseNo'] ?? null,
            $data['region'],
            $data['district'],
            $data['ward'] ?? null,
            $data['street'],
            $data['location'],
            $data['coords'] ?? null,
            $nearbyLandmarks,
            $data['description'] ?? null,
            $data['bedrooms'] ?? 0,
            $data['bathrooms'] ?? 0,
            $data['amenities'] ?? null,
            $data['furnished'] ?? 'Unfurnished',
            $data['roomSize'],
            $data['monthlyRent'],
            $data['deposit'] ?? 0,
            $data['serviceCharge'] ?? 0,
            $data['availability'] ?? 'available',
            $data['images'] ?? null,
            $data['video'] ?? null,
            $data['virtualTour'] ?? null
        ]);
        return $pdo->lastInsertId();
    }

    public static function delete($id) {
        global $pdo;
        $stmt = $pdo->prepare("DELETE FROM properties WHERE id = ?");
        return $stmt->execute([$id]);
    }

    /**
     * Parses whatever is currently in properties.images into a plain list
     * of relative paths, regardless of whether it's a legacy single path
     * string, a JSON array, or empty. Mirrors Room::parseImageList() so
     * both sides agree on the same accepted shapes.
     */
    public static function parseImageList($rawImages): array {
        if ($rawImages === null || $rawImages === '') {
            return [];
        }
        $decoded = json_decode($rawImages, true);
        if (is_array($decoded)) {
            return array_values(array_filter(array_map('strval', $decoded), function ($v) {
                return trim($v) !== '';
            }));
        }
        return [$rawImages];
    }

    /** Persists a gallery (list of relative upload paths) back onto a property. */
    public static function saveImageList($id, array $images) {
        global $pdo;
        $stmt = $pdo->prepare("UPDATE properties SET images = ? WHERE id = ?");
        return $stmt->execute([json_encode(array_values($images)), $id]);
    }
}
?>