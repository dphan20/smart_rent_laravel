<?php
require_once __DIR__ . '/../config/database.php';

class User {
    public static function findByEmail($email) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT id, full_name AS name, email, phone, password_hash, role AS type, failed_login_attempts, locked_until, email_verified_at FROM users WHERE email = ?");
        $stmt->execute([$email]);
        return $stmt->fetch();
    }

    public static function findById($id) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT id, full_name AS name, email, phone, password_hash, role AS type, failed_login_attempts, locked_until, email_verified_at FROM users WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public static function create($name, $email, $phone, $password, $role = 'Customer') {
        global $pdo;
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (full_name, email, phone, password_hash, role) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$name, $email, $phone, $hash, $role]);
        return $pdo->lastInsertId();
    }

    public static function updateProfile($id, $name, $email, $phone) {
        global $pdo;
        $stmt = $pdo->prepare("UPDATE users SET full_name = ?, email = ?, phone = ? WHERE id = ?");
        return $stmt->execute([$name, $email, $phone, $id]);
    }
}
?>