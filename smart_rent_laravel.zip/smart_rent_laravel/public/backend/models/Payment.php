<?php
require_once __DIR__ . '/../config/database.php';

class Payment {
    public static function getAll($filters = []) {
        global $pdo;
        $sql = "SELECT p.*, 
                       COALESCE(b.landlord_id, o.landlord_id) AS landlord_id,
                       COALESCE(r.title, '') AS room_name,
                       COALESCE(r.location, '') AS location
                FROM payments p
                LEFT JOIN bookings b ON p.booking_id = b.id
                LEFT JOIN orders o ON p.order_id = o.id
                LEFT JOIN rooms r ON (r.id = b.room_id OR r.id = o.room_id)
                WHERE 1=1";
        $params = [];

        if (!empty($filters['user_id'])) {
            $sql .= " AND p.user_id = ?";
            $params[] = $filters['user_id'];
        }
        if (!empty($filters['landlord_id'])) {
            $sql .= " AND (b.landlord_id = ? OR o.landlord_id = ?)";
            $params[] = $filters['landlord_id'];
            $params[] = $filters['landlord_id'];
        }

        $sql .= " ORDER BY p.created_at DESC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    // NEW: Create payment
    public static function create($data) {
        global $pdo;
        $stmt = $pdo->prepare("INSERT INTO payments (room_id, user_id, landlord_id, booking_id, order_id, amount, commission_rate, commission_amount, landlord_amount, payment_method, reference, status, recipient_number, customer_name, customer_email, customer_phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $data['room_id'] ?? null,
            $data['user_id'] ?? null,
            $data['landlord_id'] ?? null,
            $data['booking_id'] ?? null,
            $data['order_id'] ?? null,
            $data['amount'],
            $data['commission_rate'] ?? null,
            $data['commission_amount'] ?? null,
            $data['landlord_amount'] ?? null,
            $data['payment_method'],
            $data['reference'],
            $data['status'] ?? 'pending',
            $data['recipient_number'] ?? null,
            $data['customer_name'] ?? null,
            $data['customer_email'] ?? null,
            $data['customer_phone'] ?? null
        ]);
        return $pdo->lastInsertId();
    }

    public static function findById($id) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT p.*,
                       COALESCE(b.landlord_id, o.landlord_id) AS landlord_id
                FROM payments p
                LEFT JOIN bookings b ON p.booking_id = b.id
                LEFT JOIN orders o ON p.order_id = o.id
                WHERE p.id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public static function findByReference(string $reference) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT p.*,
                       COALESCE(b.landlord_id, o.landlord_id) AS landlord_id
                FROM payments p
                LEFT JOIN bookings b ON p.booking_id = b.id
                LEFT JOIN orders o ON p.order_id = o.id
                WHERE p.reference = ?
                ORDER BY p.id DESC LIMIT 1");
        $stmt->execute([$reference]);
        return $stmt->fetch();
    }

    public static function delete($id) {
        global $pdo;
        $stmt = $pdo->prepare("DELETE FROM payments WHERE id = ?");
        return $stmt->execute([$id]);
    }

    const VALID_STATUSES = ['pending', 'processing', 'successful', 'failed', 'cancelled', 'refunded'];

    public static function updateStatus($id, string $status) {
        global $pdo;
        $stmt = $pdo->prepare("UPDATE payments SET status = ? WHERE id = ?");
        return $stmt->execute([$status, $id]);
    }
}