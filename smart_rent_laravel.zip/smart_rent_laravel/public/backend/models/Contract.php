<?php
require_once __DIR__ . '/../config/database.php';

class Contract {
    // Format: SR-{year}-{sequence within that year, zero-padded to 4}.
    // Generated inside the same transaction as the INSERT so two
    // concurrent contract creations can't collide; on a duplicate-key
    // retry once with the next sequence number.
    private static function nextContractNumber(PDO $pdo, $year) {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM contracts WHERE contract_number LIKE ?");
        $stmt->execute(["SR-$year-%"]);
        $count = (int) $stmt->fetchColumn();
        return sprintf('SR-%s-%04d', $year, $count + 1);
    }

    public static function create($data) {
        global $pdo;
        $year = date('Y');

        for ($attempt = 0; $attempt < 3; $attempt++) {
            $contractNumber = self::nextContractNumber($pdo, $year);
            try {
                $stmt = $pdo->prepare("INSERT INTO contracts
                    (contract_number, booking_id, property_id, room_id, landlord_id, customer_id,
                     monthly_rent, deposit, start_date, end_date, payment_terms, responsibilities,
                     termination_conditions, other_terms, status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([
                    $contractNumber,
                    $data['booking_id'] ?? null,
                    $data['property_id'] ?? null,
                    $data['room_id'] ?? null,
                    $data['landlord_id'],
                    $data['customer_id'],
                    $data['monthly_rent'],
                    $data['deposit'] ?? 0,
                    $data['start_date'] ?? null,
                    $data['end_date'] ?? null,
                    $data['payment_terms'] ?? null,
                    $data['responsibilities'] ?? null,
                    $data['termination_conditions'] ?? null,
                    $data['other_terms'] ?? null,
                    $data['status'] ?? 'PENDING_CUSTOMER'
                ]);
                return $pdo->lastInsertId();
            } catch (PDOException $e) {
                // 23000 = integrity constraint violation (duplicate contract_number
                // under a race). Retry with a freshly counted number; any other
                // error is real and should propagate.
                if ($e->getCode() !== '23000' || $attempt === 2) {
                    throw $e;
                }
            }
        }
        throw new RuntimeException('Could not generate a unique contract number');
    }

    public static function find($id) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT c.*, u1.full_name AS landlord_name, u2.full_name AS customer_name, u2.email AS customer_email
            FROM contracts c
            JOIN users u1 ON u1.id = c.landlord_id
            JOIN users u2 ON u2.id = c.customer_id
            WHERE c.id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public static function findByOrder($orderId) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT * FROM contracts WHERE booking_id = ? LIMIT 1");
        $stmt->execute([$orderId]);
        return $stmt->fetch();
    }

    public static function findByBooking($bookingId) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT * FROM contracts WHERE booking_id = ? LIMIT 1");
        $stmt->execute([$bookingId]);
        return $stmt->fetch();
    }

    // Role-scoped listing: Admin sees all, Landlord sees their own,
    // Customer sees their own. Enforced here (not just in the controller)
    // so any future caller of this model gets the same guarantee.
    public static function getAllForUser($userId, $role) {
        global $pdo;
        $sql = "SELECT c.*, u1.full_name AS landlord_name, u2.full_name AS customer_name
                FROM contracts c
                JOIN users u1 ON u1.id = c.landlord_id
                JOIN users u2 ON u2.id = c.customer_id";
        $params = [];
        if ($role === 'Landlord') {
            $sql .= " WHERE c.landlord_id = ?";
            $params[] = $userId;
        } elseif ($role === 'Customer') {
            $sql .= " WHERE c.customer_id = ?";
            $params[] = $userId;
        }
        // Admin: no WHERE clause — sees everything.
        $sql .= " ORDER BY c.created_at DESC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    // Records an acceptance event and advances contract status. Only the
    // customer named on the contract may accept as 'Customer', and only
    // the landlord named on the contract may accept as 'Landlord' — the
    // caller (ContractController) is responsible for that ownership check
    // before calling this; this method still re-validates status
    // transitions so it can't be called out of order.
    public static function accept($contractId, $userId, $role, $ipAddress) {
        global $pdo;
        $contract = self::find($contractId);
        if (!$contract) return ['success' => false, 'message' => 'Contract not found'];

        $status = $contract['status'];
        if (!in_array($status, ['PENDING_CUSTOMER', 'PENDING_LANDLORD'], true)) {
            return ['success' => false, 'message' => 'This contract is not awaiting acceptance'];
        }
        if ($role === 'Customer' && $status !== 'PENDING_CUSTOMER') {
            return ['success' => false, 'message' => 'Waiting on the landlord, not the customer'];
        }
        if ($role === 'Landlord' && $status !== 'PENDING_LANDLORD') {
            return ['success' => false, 'message' => 'Waiting on the customer, not the landlord'];
        }

        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare("INSERT INTO contract_acceptances (contract_id, user_id, role, ip_address) VALUES (?, ?, ?, ?)");
            $stmt->execute([$contractId, $userId, $role, $ipAddress]);

            if ($role === 'Customer') {
                $pdo->prepare("UPDATE contracts SET status = 'PENDING_LANDLORD', customer_accepted_at = NOW() WHERE id = ?")
                    ->execute([$contractId]);
            } else {
                $pdo->prepare("UPDATE contracts SET status = 'ACTIVE', landlord_accepted_at = NOW() WHERE id = ?")
                    ->execute([$contractId]);
            }

            $pdo->commit();
            return ['success' => true];
        } catch (Throwable $e) {
            $pdo->rollBack();
            error_log('Contract::accept failed: ' . $e->getMessage());
            return ['success' => false, 'message' => 'Could not record acceptance'];
        }
    }
}
