<?php
require_once __DIR__ . '/../config/database.php';

class ChatMessage {
    public static function send($senderId, $receiverId, $body, $listingType = null, $listingId = null) {
        global $pdo;
        $stmt = $pdo->prepare(
            "INSERT INTO chat_messages (sender_id, receiver_id, body, listing_type, listing_id, created_at)
             VALUES (?, ?, ?, ?, ?, NOW())"
        );
        $stmt->execute([$senderId, $receiverId, $body, $listingType, $listingId]);
        return $pdo->lastInsertId();
    }

    public static function conversationsFor($userId) {
        global $pdo;
        $stmt = $pdo->prepare(
            "SELECT
                CASE WHEN sender_id = ? THEN receiver_id ELSE sender_id END AS other_id,
                MAX(id) AS last_message_id
             FROM chat_messages
             WHERE sender_id = ? OR receiver_id = ?
             GROUP BY other_id"
        );
        $stmt->execute([$userId, $userId, $userId]);
        $pairs = $stmt->fetchAll();

        $result = [];
        foreach ($pairs as $pair) {
            $otherId = (int) $pair['other_id'];

            $userStmt = $pdo->prepare("SELECT id, full_name AS name, role FROM users WHERE id = ?");
            $userStmt->execute([$otherId]);
            $other = $userStmt->fetch();
            if (!$other) continue;

            $lastStmt = $pdo->prepare("SELECT body, sender_id, created_at FROM chat_messages WHERE id = ?");
            $lastStmt->execute([$pair['last_message_id']]);
            $last = $lastStmt->fetch();

            $unreadStmt = $pdo->prepare(
                "SELECT COUNT(*) FROM chat_messages WHERE sender_id = ? AND receiver_id = ? AND read_at IS NULL"
            );
            $unreadStmt->execute([$otherId, $userId]);
            $unread = (int) $unreadStmt->fetchColumn();

            $result[] = [
                'other_id' => $otherId,
                'other_name' => $other['name'],
                'other_role' => $other['role'],
                'last_message' => $last['body'] ?? '',
                'last_message_at' => $last['created_at'] ?? null,
                'last_message_is_mine' => $last && (int) $last['sender_id'] === (int) $userId,
                'unread_count' => $unread,
            ];
        }

        usort($result, fn($a, $b) => strcmp($b['last_message_at'] ?? '', $a['last_message_at'] ?? ''));
        return $result;
    }

    public static function threadBetween($userId, $otherId, $limit = 200) {
        global $pdo;
        $stmt = $pdo->prepare(
            "SELECT * FROM chat_messages
             WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)
             ORDER BY id ASC
             LIMIT ?"
        );
        $stmt->bindValue(1, $userId, PDO::PARAM_INT);
        $stmt->bindValue(2, $otherId, PDO::PARAM_INT);
        $stmt->bindValue(3, $otherId, PDO::PARAM_INT);
        $stmt->bindValue(4, $userId, PDO::PARAM_INT);
        $stmt->bindValue(5, $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public static function markRead($userId, $otherId) {
        global $pdo;
        $stmt = $pdo->prepare(
            "UPDATE chat_messages SET read_at = NOW()
             WHERE sender_id = ? AND receiver_id = ? AND read_at IS NULL"
        );
        return $stmt->execute([$otherId, $userId]);
    }

    public static function allowedContactsFor($userId, $role) {
        global $pdo;
        $role = strtolower($role);

        if ($role === 'admin') {
            $stmt = $pdo->prepare("SELECT id, full_name AS name, role FROM users WHERE id != ? ORDER BY full_name");
            $stmt->execute([$userId]);
            return $stmt->fetchAll();
        }

        $stmt = $pdo->prepare("SELECT id, full_name AS name, role FROM users WHERE role = 'Admin' ORDER BY full_name");
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public static function canMessage($senderId, $senderRole, $receiverId) {
        global $pdo;
        $senderRole = strtolower($senderRole);
        if ($senderRole === 'admin') return true;

        $stmt = $pdo->prepare("SELECT role FROM users WHERE id = ?");
        $stmt->execute([$receiverId]);
        $receiverRole = strtolower((string) $stmt->fetchColumn());
        return $receiverRole === 'admin';
    }
}
