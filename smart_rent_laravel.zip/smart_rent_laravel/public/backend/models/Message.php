<?php
require_once __DIR__ . '/../config/database.php';

class Message {
    public static function getAll() {
        global $pdo;
        $stmt = $pdo->query("SELECT * FROM messages ORDER BY created_at DESC");
        return $stmt->fetchAll();
    }

    public static function find($id) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT * FROM messages WHERE id = ?");
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    // All messages a given customer has sent, matched by the email they
    // used when submitting the contact form - the messages table has no
    // user_id, so email is the only link back to "their" messages. Used
    // by the customer-facing "My Messages" section.
    public static function findByEmail($email) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT * FROM messages WHERE email = ? ORDER BY created_at DESC");
        $stmt->execute([$email]);
        return $stmt->fetchAll();
    }

    public static function create($data) {
        global $pdo;
        $stmt = $pdo->prepare("INSERT INTO messages (name, email, phone, message) VALUES (?, ?, ?, ?)");
        $stmt->execute([$data['name'], $data['email'], $data['phone'], $data['message']]);
        return $pdo->lastInsertId();
    }

    // Saves the admin's reply. Actual email delivery to the sender is
    // attempted separately in MessageController::reply() via mail() -
    // that requires a real SMTP/sendmail setup to actually leave the
    // server, same boundary AuthController's password-reset/SMS flows
    // already flag as out of scope. The reply is always saved and
    // visible in the admin panel regardless of whether delivery succeeds.
    public static function reply($id, $replyText) {
        global $pdo;
        $stmt = $pdo->prepare("UPDATE messages SET admin_reply = ?, replied_at = NOW() WHERE id = ?");
        $stmt->execute([$replyText, $id]);
        return $stmt->rowCount() > 0;
    }
}
?>