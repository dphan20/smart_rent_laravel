<?php
require_once __DIR__ . '/../config/database.php';

class Payout
{
    const VALID_STATUSES = ['PENDING', 'PROCESSING', 'PAID', 'FAILED', 'CANCELLED'];

    public static function create(array $data)
    {
        global $pdo;
        $stmt = $pdo->prepare(
            "INSERT INTO payouts (landlord_id, payment_id, amount, status, payout_method, payout_reference, notes)
             VALUES (?, ?, ?, ?, ?, ?, ?)"
        );
        $stmt->execute([
            $data['landlord_id'],
            $data['payment_id'] ?? null,
            $data['amount'],
            $data['status'] ?? 'PENDING',
            $data['payout_method'] ?? null,
            $data['payout_reference'] ?? null,
            $data['notes'] ?? null,
        ]);
        return $pdo->lastInsertId();
    }

    public static function getAll(array $filters = [])
    {
        global $pdo;
        $sql = "SELECT po.*, u.full_name AS landlord_name, u.email AS landlord_email,
                       p.reference AS payment_reference, p.amount AS gross_amount
                FROM payouts po
                LEFT JOIN users u ON po.landlord_id = u.id
                LEFT JOIN payments p ON po.payment_id = p.id
                WHERE 1=1";
        $params = [];
        if (!empty($filters['landlord_id'])) {
            $sql .= " AND po.landlord_id = ?";
            $params[] = $filters['landlord_id'];
        }
        $sql .= " ORDER BY po.created_at DESC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public static function findById($id)
    {
        global $pdo;
        $stmt = $pdo->prepare("SELECT * FROM payouts WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public static function updateStatus($id, string $status, ?string $method, ?string $reference, ?string $notes)
    {
        if (!in_array($status, self::VALID_STATUSES, true)) {
            throw new InvalidArgumentException('Invalid payout status');
        }
        global $pdo;
        $stmt = $pdo->prepare(
            "UPDATE payouts SET status = ?, payout_method = COALESCE(?, payout_method),
             payout_reference = COALESCE(?, payout_reference), notes = COALESCE(?, notes)
             WHERE id = ?"
        );
        return $stmt->execute([$status, $method, $reference, $notes, $id]);
    }
}
