<?php
require_once __DIR__ . '/../config/database.php';

class Booking {
    public static function getAll() {
        global $pdo;
        $stmt = $pdo->query("SELECT b.*, r.title AS room_title, r.location AS room_location, r.price AS room_price FROM bookings b LEFT JOIN rooms r ON b.room_id = r.id ORDER BY b.created_at DESC");
        return $stmt->fetchAll();
    }

    public static function create($data) {
        global $pdo;
        $stmt = $pdo->prepare("INSERT INTO bookings (room_id, user_id, landlord_id, customer_name, customer_email, customer_phone, amount, arrival_date, rental_mode, status, payment_ref) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $data['room_id'],
            $data['user_id'] ?? null,
            $data['landlord_id'] ?? null,
            $data['customer_name'],
            $data['customer_email'],
            $data['customer_phone'],
            $data['amount'] ?? null,
            $data['arrival_date'] ?? null,
            $data['rental_mode'] ?? 'holiday',
            $data['status'] ?? 'confirmed',
            $data['payment_ref'] ?? null
        ]);
        return $pdo->lastInsertId();
    }

    private static array $updatableColumns = [
        'customer_name', 'customer_email', 'customer_phone', 'amount',
        'arrival_date', 'rental_mode', 'status', 'payment_ref',
    ];

    public static function update($id, $data) {
        global $pdo;
        $fields = [];
        $params = [];
        foreach ($data as $key => $value) {
            if (!in_array($key, self::$updatableColumns, true)) continue;
            $fields[] = "$key = ?";
            $params[] = $value;
        }
        if (empty($fields)) {
            return false;
        }
        $params[] = $id;
        $sql = "UPDATE bookings SET " . implode(', ', $fields) . " WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        return $stmt->execute($params);
    }

    public static function delete($id) {
        global $pdo;
        $stmt = $pdo->prepare("DELETE FROM bookings WHERE id = ?");
        return $stmt->execute([$id]);
    }

    /**
     * Moves a booking (and the room it holds) forward once its payment has
     * actually been verified - called from PaymentController::verify() and
     * PaymentController::webhook() ONLY, i.e. only after genuine server-side
     * confirmation, never from the Pay Now request itself. This is what
     * finally turns a 'pending' booking into 'confirmed'/room 'taken', or
     * releases the room back to 'available' if the payment failed.
     */
    public static function syncFromPaymentStatus($bookingId, string $paymentStatus) {
        global $pdo;
        if (!$bookingId) {
            return;
        }
        $stmt = $pdo->prepare("SELECT * FROM bookings WHERE id = ?");
        $stmt->execute([$bookingId]);
        $booking = $stmt->fetch();
        if (!$booking) {
            return;
        }

        if ($paymentStatus === 'successful') {
            $pdo->prepare("UPDATE bookings SET status = 'confirmed' WHERE id = ?")->execute([$bookingId]);
            $pdo->prepare("UPDATE rooms SET status = 'taken' WHERE id = ? AND status = 'booked'")->execute([$booking['room_id']]);
        } elseif (in_array($paymentStatus, ['failed', 'cancelled'], true)) {
            $pdo->prepare("UPDATE bookings SET status = 'cancelled' WHERE id = ?")->execute([$bookingId]);
            // Only release the hold this booking itself placed - never
            // touch a room that has since moved on (e.g. already taken by
            // a different, since-verified booking).
            $pdo->prepare("UPDATE rooms SET status = 'available' WHERE id = ? AND status = 'booked'")->execute([$booking['room_id']]);
        }

        // Keep the customer's receipt showing the same true status as the
        // payment it documents, instead of whatever it said at issue time.
        $pdo->prepare("UPDATE receipts SET payment_status = ? WHERE booking_id = ?")
            ->execute([$paymentStatus === 'successful' ? 'successful' : $paymentStatus, $bookingId]);
    }
}