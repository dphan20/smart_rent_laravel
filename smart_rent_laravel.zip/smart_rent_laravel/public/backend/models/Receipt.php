<?php
require_once __DIR__ . '/../config/database.php';

class Receipt {
    public static function getAll($filters = []) {
        global $pdo;
        $sql = "SELECT * FROM receipts WHERE 1=1";
        $params = [];

        if (!empty($filters['user_id'])) {
            $sql .= " AND user_id = ?";
            $params[] = $filters['user_id'];
        }
        if (!empty($filters['landlord_id'])) {
            $sql .= " AND landlord_id = ?";
            $params[] = $filters['landlord_id'];
        }

        $sql .= " ORDER BY created_at DESC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public static function create($data) {
        global $pdo;
        $stmt = $pdo->prepare("INSERT INTO receipts (booking_id, payment_id, room_id, user_id, landlord_id, receipt_number, amount, payment_method, reference, customer_name, customer_email, customer_phone, recipient_number, status, payment_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $data['booking_id'] ?? null,
            $data['payment_id'] ?? null,
            $data['room_id'] ?? null,
            $data['user_id'] ?? null,
            $data['landlord_id'] ?? null,
            $data['receipt_number'] ?? self::generateNumber(),
            $data['amount'] ?? null,
            $data['payment_method'] ?? null,
            $data['reference'] ?? null,
            $data['customer_name'] ?? null,
            $data['customer_email'] ?? null,
            $data['customer_phone'] ?? null,
            $data['recipient_number'] ?? null,
            $data['status'] ?? 'issued',
            $data['payment_status'] ?? 'successful'
        ]);
        return $pdo->lastInsertId();
    }

    private static function generateNumber() {
        return 'RCP-' . date('Ymd') . '-' . substr(strtoupper(bin2hex(random_bytes(3))), 0, 6);
    }
}
