<?php
require_once __DIR__ . '/../config/database.php';

class AuthSecurity
{
    // --- Login throttling / brute-force protection ---------------------

    const MAX_ACCOUNT_FAILURES = 5;     // failures before an account locks
    const ACCOUNT_LOCK_MINUTES = 15;
    const MAX_IP_FAILURES = 20;         // failures from one IP (any email) before it's throttled
    const IP_WINDOW_MINUTES = 15;

    public static function recordAttempt(string $email, string $ip, bool $success): void
    {
        global $pdo;
        $stmt = $pdo->prepare("INSERT INTO login_attempts (email, ip_address, success) VALUES (?, ?, ?)");
        $stmt->execute([$email, $ip, $success ? 1 : 0]);
    }

    public static function isIpThrottled(string $ip): bool
    {
        global $pdo;
        $stmt = $pdo->prepare(
            "SELECT COUNT(*) FROM login_attempts
             WHERE ip_address = ? AND success = 0 AND created_at > (NOW() - INTERVAL ? MINUTE)"
        );
        $stmt->execute([$ip, self::IP_WINDOW_MINUTES]);
        return ((int) $stmt->fetchColumn()) >= self::MAX_IP_FAILURES;
    }

    public static function isAccountLocked(array $user): bool
    {
        return !empty($user['locked_until']) && strtotime($user['locked_until']) > time();
    }

    public static function registerFailure(int $userId): void
    {
        global $pdo;
        $stmt = $pdo->prepare("UPDATE users SET failed_login_attempts = failed_login_attempts + 1 WHERE id = ?");
        $stmt->execute([$userId]);

        $stmt = $pdo->prepare("SELECT failed_login_attempts FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $attempts = (int) $stmt->fetchColumn();

        if ($attempts >= self::MAX_ACCOUNT_FAILURES) {
            $lockUntil = date('Y-m-d H:i:s', time() + self::ACCOUNT_LOCK_MINUTES * 60);
            $pdo->prepare("UPDATE users SET locked_until = ? WHERE id = ?")->execute([$lockUntil, $userId]);
        }
    }

    public static function registerSuccess(int $userId): void
    {
        global $pdo;
        $pdo->prepare("UPDATE users SET failed_login_attempts = 0, locked_until = NULL WHERE id = ?")->execute([$userId]);
    }

    // --- Remember-me tokens ----------------------------------------------
    // Selector/validator split (like a lookup key + secret) so the DB never
    // stores anything the raw cookie value could be reconstructed from, and
    // a leaked DB dump alone can't be replayed as a login.

    const REMEMBER_DAYS = 30;

    public static function createRememberToken(int $userId): string
    {
        global $pdo;
        $selector = bin2hex(random_bytes(12));
        $validator = bin2hex(random_bytes(32));
        $hash = hash('sha256', $validator);
        $expires = date('Y-m-d H:i:s', time() + self::REMEMBER_DAYS * 86400);

        $stmt = $pdo->prepare("INSERT INTO remember_tokens (user_id, selector, token_hash, expires_at) VALUES (?, ?, ?, ?)");
        $stmt->execute([$userId, $selector, $hash, $expires]);

        return $selector . ':' . $validator;
    }

    /** Returns the user_id if the cookie is valid, else null. Rotates the token on success. */
    public static function verifyAndRotateRememberToken(string $cookieValue): ?int
    {
        global $pdo;
        if (!str_contains($cookieValue, ':')) return null;
        [$selector, $validator] = explode(':', $cookieValue, 2);

        $stmt = $pdo->prepare("SELECT * FROM remember_tokens WHERE selector = ? LIMIT 1");
        $stmt->execute([$selector]);
        $row = $stmt->fetch();
        if (!$row) return null;

        if (strtotime($row['expires_at']) < time()) {
            $pdo->prepare("DELETE FROM remember_tokens WHERE id = ?")->execute([$row['id']]);
            return null;
        }

        if (!hash_equals($row['token_hash'], hash('sha256', $validator))) {
            // Mismatched validator for a real selector strongly suggests the
            // token was stolen/guessed. Revoke it rather than let more
            // attempts happen against it.
            $pdo->prepare("DELETE FROM remember_tokens WHERE id = ?")->execute([$row['id']]);
            return null;
        }

        // Rotate: delete the used token, issue a fresh one for next time.
        $pdo->prepare("DELETE FROM remember_tokens WHERE id = ?")->execute([$row['id']]);
        return (int) $row['user_id'];
    }

    public static function revokeRememberToken(string $cookieValue): void
    {
        global $pdo;
        if (!str_contains($cookieValue, ':')) return;
        [$selector] = explode(':', $cookieValue, 2);
        $pdo->prepare("DELETE FROM remember_tokens WHERE selector = ?")->execute([$selector]);
    }

    public static function revokeAllRememberTokensForUser(int $userId): void
    {
        global $pdo;
        $pdo->prepare("DELETE FROM remember_tokens WHERE user_id = ?")->execute([$userId]);
    }

    // --- Password reset ----------------------------------------------------

    const RESET_TOKEN_TTL_MINUTES = 60;

    public static function createPasswordResetToken(int $userId): string
    {
        global $pdo;
        $token = bin2hex(random_bytes(32));
        $hash = hash('sha256', $token);
        $expires = date('Y-m-d H:i:s', time() + self::RESET_TOKEN_TTL_MINUTES * 60);

        $pdo->prepare("INSERT INTO password_resets (user_id, token_hash, expires_at) VALUES (?, ?, ?)")
            ->execute([$userId, $hash, $expires]);

        return $token;
    }

    /** Returns the user_id for a valid, unused, unexpired token, else null. */
    public static function consumePasswordResetToken(string $token): ?int
    {
        global $pdo;
        $hash = hash('sha256', $token);
        $stmt = $pdo->prepare("SELECT * FROM password_resets WHERE token_hash = ? AND used_at IS NULL LIMIT 1");
        $stmt->execute([$hash]);
        $row = $stmt->fetch();
        if (!$row || strtotime($row['expires_at']) < time()) {
            return null;
        }
        $pdo->prepare("UPDATE password_resets SET used_at = NOW() WHERE id = ?")->execute([$row['id']]);
        return (int) $row['user_id'];
    }

    // --- Email verification -------------------------------------------------

    const VERIFY_TOKEN_TTL_HOURS = 24;

    public static function createEmailVerificationToken(int $userId): string
    {
        global $pdo;
        $token = bin2hex(random_bytes(32));
        $hash = hash('sha256', $token);
        $expires = date('Y-m-d H:i:s', time() + self::VERIFY_TOKEN_TTL_HOURS * 3600);

        $pdo->prepare("INSERT INTO email_verifications (user_id, token_hash, expires_at) VALUES (?, ?, ?)")
            ->execute([$userId, $hash, $expires]);

        return $token;
    }

    public static function consumeEmailVerificationToken(string $token): ?int
    {
        global $pdo;
        $hash = hash('sha256', $token);
        $stmt = $pdo->prepare("SELECT * FROM email_verifications WHERE token_hash = ? AND verified_at IS NULL LIMIT 1");
        $stmt->execute([$hash]);
        $row = $stmt->fetch();
        if (!$row || strtotime($row['expires_at']) < time()) {
            return null;
        }
        $pdo->prepare("UPDATE email_verifications SET verified_at = NOW() WHERE id = ?")->execute([$row['id']]);
        $pdo->prepare("UPDATE users SET email_verified_at = NOW() WHERE id = ?")->execute([(int) $row['user_id']]);
        return (int) $row['user_id'];
    }
}
