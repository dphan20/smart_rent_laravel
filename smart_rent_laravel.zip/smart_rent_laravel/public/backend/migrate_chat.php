<?php
require_once __DIR__ . '/config/env.php';
loadEnvFile(__DIR__ . '/../../.env');

$host = getenv('SMART_RENT_DB_HOST') ?: 'localhost';
$dbname = getenv('SMART_RENT_DB_NAME') ?: 'smartrent';
$username = getenv('SMART_RENT_DB_USER') ?: 'root';
$password = getenv('SMART_RENT_DB_PASS') ?: '';

$pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
]);

function tableExists(PDO $pdo, string $table): bool {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?");
    $stmt->execute([$table]);
    return (int) $stmt->fetchColumn() > 0;
}

echo "-> chat_messages table ... ";
if (tableExists($pdo, 'chat_messages')) {
    echo "skipped (already exists)\n";
} else {
    $pdo->exec("CREATE TABLE chat_messages (
        id INT AUTO_INCREMENT PRIMARY KEY,
        sender_id INT NOT NULL,
        receiver_id INT NOT NULL,
        body TEXT NOT NULL,
        listing_type VARCHAR(20) NULL,
        listing_id INT NULL,
        read_at TIMESTAMP NULL DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_chat_sender (sender_id),
        INDEX idx_chat_receiver (receiver_id),
        INDEX idx_chat_pair (sender_id, receiver_id),
        CONSTRAINT fk_chat_sender FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
        CONSTRAINT fk_chat_receiver FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB");
    echo "done\n";
}
echo "\nChat migration complete.\n";
