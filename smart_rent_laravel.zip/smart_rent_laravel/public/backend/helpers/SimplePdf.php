<?php
/**
 * Minimal, dependency-free PDF writer for simple single-column text
 * documents. No Composer package needed (this project intentionally has no
 * Composer dependency at runtime - matches how the rest of the backend is
 * built). Good enough for a contract document: a title, some paragraphs,
 * automatic word-wrap and pagination. Not a general-purpose PDF library -
 * no images, no tables, no custom fonts.
 */
class SimplePdf
{
    private array $lines = []; // each entry: ['text' => string, 'bold' => bool, 'size' => int, 'gap' => int]
    private const PAGE_WIDTH = 595;  // A4 in points
    private const PAGE_HEIGHT = 842;
    private const MARGIN = 56;

    public function addHeading(string $text): void
    {
        $this->lines[] = ['text' => $text, 'bold' => true, 'size' => 16, 'gap' => 22];
    }

    public function addSubheading(string $text): void
    {
        $this->lines[] = ['text' => $text, 'bold' => true, 'size' => 12, 'gap' => 16];
    }

    public function addLine(string $text = '', bool $bold = false): void
    {
        $this->lines[] = ['text' => $text, 'bold' => $bold, 'size' => 10, 'gap' => 14];
    }

    public function addSpacer(): void
    {
        $this->lines[] = ['text' => '', 'bold' => false, 'size' => 10, 'gap' => 10];
    }

    private function escape(string $s): string
    {
        return str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $s);
    }

    /** Naive word-wrap by estimated character width - good enough for A4 contract text, not pixel-perfect. */
    private function wrap(string $text, int $size): array
    {
        $maxChars = max(20, (int) floor((self::PAGE_WIDTH - 2 * self::MARGIN) / ($size * 0.52)));
        if ($text === '') return [''];
        $words = explode(' ', $text);
        $out = [];
        $current = '';
        foreach ($words as $word) {
            $candidate = $current === '' ? $word : $current . ' ' . $word;
            if (mb_strlen($candidate) > $maxChars && $current !== '') {
                $out[] = $current;
                $current = $word;
            } else {
                $current = $candidate;
            }
        }
        if ($current !== '') $out[] = $current;
        return $out ?: [''];
    }

    /** Renders all queued lines into one or more pages and returns raw PDF bytes. */
    public function render(): string
    {
        $usableHeight = self::PAGE_HEIGHT - 2 * self::MARGIN;
        $pages = [[]];
        $y = 0;
        $pageIndex = 0;

        foreach ($this->lines as $entry) {
            foreach ($this->wrap($entry['text'], $entry['size']) as $wrapped) {
                if ($y + $entry['gap'] > $usableHeight) {
                    $pageIndex++;
                    $pages[$pageIndex] = [];
                    $y = 0;
                }
                $pages[$pageIndex][] = ['text' => $wrapped, 'bold' => $entry['bold'], 'size' => $entry['size'], 'gap' => $entry['gap']];
                $y += $entry['gap'];
            }
        }

        // --- Build PDF objects ---
        $objects = [];
        $fontRegularId = 1;
        $fontBoldId = 2;
        $objects[$fontRegularId] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>";
        $objects[$fontBoldId] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>";

        $pageObjIds = [];
        $contentObjIds = [];
        $nextId = 3;
        $pagesObjId = $nextId++;

        foreach ($pages as $pageLines) {
            $contentId = $nextId++;
            $pageId = $nextId++;

            $stream = "BT\n";
            $cursorY = self::PAGE_HEIGHT - self::MARGIN;
            foreach ($pageLines as $line) {
                $font = $line['bold'] ? '/F2' : '/F1';
                $stream .= "$font {$line['size']} Tf\n";
                $stream .= "1 0 0 1 " . self::MARGIN . " $cursorY Tm\n";
                $stream .= "(" . $this->escape($line['text']) . ") Tj\n";
                $cursorY -= $line['gap'];
            }
            $stream .= "ET";

            $objects[$contentId] = "<< /Length " . strlen($stream) . " >>\nstream\n$stream\nendstream";
            $objects[$pageId] = "<< /Type /Page /Parent $pagesObjId 0 R /Resources << /Font << /F1 $fontRegularId 0 R /F2 $fontBoldId 0 R >> >> /MediaBox [0 0 " . self::PAGE_WIDTH . " " . self::PAGE_HEIGHT . "] /Contents $contentId 0 R >>";

            $pageObjIds[] = $pageId;
            $contentObjIds[] = $contentId;
        }

        $kids = implode(' ', array_map(fn($id) => "$id 0 R", $pageObjIds));
        $objects[$pagesObjId] = "<< /Type /Pages /Kids [$kids] /Count " . count($pageObjIds) . " >>";

        $catalogId = $nextId++;
        $objects[$catalogId] = "<< /Type /Catalog /Pages $pagesObjId 0 R >>";

        ksort($objects);

        $pdf = "%PDF-1.4\n";
        $offsets = [0 => 0];
        foreach ($objects as $id => $body) {
            $offsets[$id] = strlen($pdf);
            $pdf .= "$id 0 obj\n$body\nendobj\n";
        }

        $xrefStart = strlen($pdf);
        $maxId = max(array_keys($objects));
        $pdf .= "xref\n0 " . ($maxId + 1) . "\n";
        $pdf .= "0000000000 65535 f \n";
        for ($i = 1; $i <= $maxId; $i++) {
            if (isset($offsets[$i])) {
                $pdf .= sprintf("%010d 00000 n \n", $offsets[$i]);
            } else {
                $pdf .= "0000000000 00000 f \n";
            }
        }
        $pdf .= "trailer\n<< /Size " . ($maxId + 1) . " /Root $catalogId 0 R >>\nstartxref\n$xrefStart\n%%EOF";

        return $pdf;
    }
}
