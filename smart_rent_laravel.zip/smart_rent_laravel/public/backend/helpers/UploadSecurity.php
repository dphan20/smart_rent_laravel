<?php
/**
 * Centralized validation for user-uploaded image files (property photos,
 * room photos, and - once enabled - 360 virtual tour panoramas).
 *
 * Every upload path in the app must go through validateImageUpload() before
 * calling move_uploaded_file(). This is the one place that decides what
 * counts as "a safe image" so every controller enforces the same rules:
 *   - real MIME type sniffed from file content (not the client-supplied
 *     Content-Type header, which is trivially spoofable)
 *   - extension whitelist, independent of the original filename
 *   - hard size cap
 *   - a fresh, random, non-guessable filename (never the original name)
 *
 * This does not make PHP execution of an uploaded file impossible on every
 * possible server configuration - the uploads/ directory should also be
 * configured to never execute PHP (see deploy/ notes) - but it stops the
 * simple "rename shell.php to shell.jpg" bypass and rejects anything that
 * isn't actually image data.
 */

class UploadSecurity
{
    // MIME type => allowed extension. Sniffed MIME must be in this map;
    // the stored extension always comes from this map, never from the
    // client's original filename.
    private const ALLOWED_MIME_TO_EXT = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/gif'  => 'gif',
        'image/webp' => 'webp',
        // .jfif files are JPEG data with a different container extension -
        // the existing uploads/ folder already has several of these from
        // before this validation existed.
    ];

    private const MAX_BYTES = 8 * 1024 * 1024; // 8 MB per file

    /**
     * Validates a single entry from $_FILES and, if valid, moves it into
     * $uploadsDir under a fresh random name.
     *
     * @param array  $fileEntry  One element of $_FILES (must already have
     *                           passed the UPLOAD_ERR_OK check by the caller,
     *                           since $_FILES structures differ for single
     *                           vs. multi-file inputs).
     * @param string $uploadsDir Absolute path to the destination directory.
     * @param string $prefix     Filename prefix, e.g. 'room', 'property'.
     *
     * @return array{ok: bool, path?: string, error?: string} 'path' is the
     *         relative "uploads/xxx.ext" string to store in the database.
     */
    public static function validateAndStore(array $fileEntry, string $uploadsDir, string $prefix): array
    {
        $errCode = $fileEntry['error'] ?? UPLOAD_ERR_NO_FILE;
        if ($errCode !== UPLOAD_ERR_OK) {
            $messages = [
                UPLOAD_ERR_INI_SIZE => 'File exceeds the server\'s upload_max_filesize limit (see public/.user.ini).',
                UPLOAD_ERR_FORM_SIZE => 'File exceeds the form\'s allowed size.',
                UPLOAD_ERR_PARTIAL => 'File was only partially uploaded - try again.',
                UPLOAD_ERR_NO_FILE => 'No file was uploaded.',
                UPLOAD_ERR_NO_TMP_DIR => 'Server has no temporary folder configured for uploads.',
                UPLOAD_ERR_CANT_WRITE => 'Server failed to write the uploaded file to disk (check folder permissions).',
                UPLOAD_ERR_EXTENSION => 'A server extension stopped the upload.',
            ];
            return ['ok' => false, 'error' => $messages[$errCode] ?? ('Upload failed (error code ' . $errCode . ')')];
        }

        $tmpPath = $fileEntry['tmp_name'] ?? '';
        if ($tmpPath === '' || !is_uploaded_file($tmpPath)) {
            return ['ok' => false, 'error' => 'Invalid upload'];
        }

        $size = (int) ($fileEntry['size'] ?? 0);
        if ($size <= 0 || $size > self::MAX_BYTES) {
            return ['ok' => false, 'error' => 'File is too large (max ' . (self::MAX_BYTES / 1024 / 1024) . ' MB)'];
        }

        // Sniff the real content type from the file's bytes, not the
        // client-supplied header - a renamed .php file claiming to be
        // image/jpeg in its Content-Type header is caught here.
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime = $finfo->file($tmpPath) ?: '';

        // .jfif/.jpe files sniff as image/jpeg, which is already covered.
        if (!isset(self::ALLOWED_MIME_TO_EXT[$mime])) {
            return ['ok' => false, 'error' => 'Unsupported file type. Allowed: JPG, PNG, GIF, WEBP.'];
        }

        // Belt-and-suspenders: confirm getimagesize() also agrees this is a
        // real image (catches a few polyglot tricks finfo alone can miss).
        if (@getimagesize($tmpPath) === false) {
            return ['ok' => false, 'error' => 'File is not a valid image.'];
        }

        $ext = self::ALLOWED_MIME_TO_EXT[$mime];
        $safePrefix = preg_replace('/[^a-zA-Z0-9_-]/', '', $prefix) ?: 'file';
        $filename = $safePrefix . '_' . time() . '_' . bin2hex(random_bytes(6)) . '.' . $ext;
        $destination = rtrim($uploadsDir, '/') . '/' . $filename;

        if (!move_uploaded_file($tmpPath, $destination)) {
            return ['ok' => false, 'error' => 'Failed to save uploaded file.'];
        }

        // Uploaded files never need to be executable.
        @chmod($destination, 0644);

        return ['ok' => true, 'path' => 'uploads/' . $filename];
    }
}
