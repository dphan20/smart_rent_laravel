<?php
/**
 * ListingIdGenerator - generates the permanent, human-readable public
 * identifier ("House ID") for a property or room listing.
 *
 * Format:  TZ-{CITY}-{AREA}-{XXXX}-{XXXX}
 * Example: TZ-DAR-KIN-8F42-7291
 *
 * - TZ is fixed (Tanzania).
 * - CITY / AREA are short uppercase codes derived from whatever
 *   region/district (or location/area) text already exists on the row
 *   being created - nothing is ever typed in manually by an Admin or
 *   Landlord, and no new location tables are introduced.
 * - The last two 4-character groups are a cryptographically random
 *   unique code (not a sequential counter), rechecked against the
 *   database before use so collisions are structurally prevented.
 *
 * This ID is generated exactly once, at creation time, by the callers
 * below (PropertyController::create / RoomController::create) and is
 * never regenerated when a listing is later edited.
 */
class ListingIdGenerator
{
    /** Known Tanzanian region/city name -> short code. Extend freely. */
    private static function cityCodeMap(): array
    {
        return [
            'dar es salaam' => 'DAR', 'dar-es-salaam' => 'DAR', 'dar' => 'DAR',
            'dodoma' => 'DOD',
            'arusha' => 'ARU',
            'mwanza' => 'MWZ',
            'mbeya' => 'MBE',
            'morogoro' => 'MOR',
            'tanga' => 'TAN',
            'kigoma' => 'KIG',
            'tabora' => 'TAB',
            'iringa' => 'IRI',
            'shinyanga' => 'SHY',
            'singida' => 'SIN',
            'kagera' => 'KAG',
            'mtwara' => 'MTW',
            'lindi' => 'LIN',
            'ruvuma' => 'RUV',
            'rukwa' => 'RUK',
            'katavi' => 'KAT',
            'njombe' => 'NJO',
            'geita' => 'GEI',
            'simiyu' => 'SIM',
            'manyara' => 'MAN',
            'pwani' => 'PWA', 'coast' => 'PWA',
            'zanzibar' => 'ZNZ', 'unguja' => 'ZNZ', 'pemba' => 'PEM',
        ];
    }

    /** Known district/area name -> short code. Extend freely. */
    private static function areaCodeMap(): array
    {
        return [
            'kinondoni' => 'KIN',
            'ilala' => 'ILA',
            'temeke' => 'TEM',
            'kigamboni' => 'KIG',
            'ubungo' => 'UBU',
            'kibaha' => 'KBH',
            'bagamoyo' => 'BAG',
        ];
    }

    /**
     * Turns free-text location data into a stable short uppercase code.
     * Falls back to the first letters of the text (never a manual/blank
     * value) so every listing always gets a deterministic-looking code
     * even for a region/district not in the known lists above.
     */
    private static function codeFor(string $text, array $knownMap, int $fallbackLength = 3): string
    {
        $normalized = strtolower(trim($text));
        // Strip anything after a comma - callers sometimes pass a combined
        // "Dar es Salaam, Kinondoni" style string into a single field.
        $normalized = trim(explode(',', $normalized)[0]);
        if ($normalized === '') {
            return str_pad('', $fallbackLength, 'X');
        }
        if (isset($knownMap[$normalized])) {
            return $knownMap[$normalized];
        }
        foreach ($knownMap as $name => $code) {
            if (strpos($normalized, $name) !== false) {
                return $code;
            }
        }
        $letters = preg_replace('/[^A-Za-z]/', '', $normalized);
        if ($letters === '') {
            return str_pad('', $fallbackLength, 'X');
        }
        return strtoupper(substr(str_pad($letters, $fallbackLength, $letters), 0, $fallbackLength));
    }

    public static function cityCode(?string $region): string
    {
        return self::codeFor((string) $region, self::cityCodeMap());
    }

    public static function areaCode(?string $district): string
    {
        return self::codeFor((string) $district, self::areaCodeMap());
    }

    /**
     * Generates a Smart Rental Identifier in the required format:
     * TZ-[CITY]-[8 DIGIT NUMBER]
     * Example: TZ-DAR-00084721
     */
    public static function generateSri(PDO $pdo, ?string $region, ?string $district = null): string
    {
        $city = self::cityCode($region ?? $district ?? '');
        $city = strtoupper(trim($city ?: 'DAR'));

        for ($attempt = 0; $attempt < 50; $attempt++) {
            $number = str_pad((string) random_int(0, 99999999), 8, '0', STR_PAD_LEFT);
            $candidate = sprintf('TZ-%s-%s', $city, $number);
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM properties WHERE sri = ?");
            $stmt->execute([$candidate]);
            if ((int) $stmt->fetchColumn() === 0) {
                return $candidate;
            }
        }

        $timestamp = (int) (microtime(true) * 1000) % 100000000;
        return sprintf('TZ-%s-%08d', $city, $timestamp);
    }

    private static function randomGroup(): string
    {
        // 4 uppercase hex chars, e.g. "8F42" - short, unique-looking, and
        // cheap to regenerate on the rare collision without leaking any
        // sequential/guessable pattern.
        return strtoupper(bin2hex(random_bytes(2)));
    }

    /**
     * Builds a brand-new, DB-verified-unique House ID.
     *
     * @param string $table  'properties' or 'rooms' - whichever table's
     *                       house_id column must not collide.
     */
    public static function generate(PDO $pdo, string $table, ?string $region, ?string $district): string
    {
        $city = self::cityCode($region);
        $area = self::areaCode($district);

        for ($attempt = 0; $attempt < 20; $attempt++) {
            $candidate = sprintf('TZ-%s-%s-%s-%s', $city, $area, self::randomGroup(), self::randomGroup());
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM `$table` WHERE house_id = ?");
            $stmt->execute([$candidate]);
            if ((int) $stmt->fetchColumn() === 0) {
                return $candidate;
            }
        }
        // Astronomically unlikely to be reached (20 collisions in a row),
        // but never loop forever - fall back to a longer random suffix.
        return sprintf('TZ-%s-%s-%s', $city, $area, strtoupper(bin2hex(random_bytes(6))));
    }
}
