<?php
function normalizeRentalMode(array $data): array {
    $mode = isset($data['rental_mode']) ? strtolower(trim((string) $data['rental_mode'])) : '';
    $purpose = isset($data['listing_purpose']) ? strtolower(trim((string) $data['listing_purpose'])) : '';
    if ($mode === '' && $purpose !== '') {
        $mode = $purpose === 'holiday' ? 'holiday' : 'rent';
    } elseif ($mode === '') {
        $mode = 'rent';
    }
    if ($purpose === '') {
        $purpose = $mode === 'holiday' ? 'holiday' : 'rental';
    }
    $data['rental_mode'] = $mode;
    $data['listing_purpose'] = $purpose;
    return $data;
}

function sendJSON($data, $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json');
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    echo json_encode($data);
    exit;
}

function sanitizeString($value) {
    return trim(strip_tags((string) $value));
}

function validateEmail($value) {
    return filter_var($value, FILTER_VALIDATE_EMAIL) !== false;
}

function validatePasswordStrength($password) {
    // Only a minimum length is enforced now - no required uppercase letter
    // or digit, so signup/reset no longer reject passwords on those rules.
    return strlen((string) $password) >= 6;
}

function readRequestData() {
    $raw = trim((string) file_get_contents('php://input'));
    if ($raw !== '') {
        $data = json_decode($raw, true);
        if (is_array($data)) {
            return $data;
        }

        $parsed = [];
        parse_str($raw, $parsed);
        if (is_array($parsed)) {
            return $parsed;
        }
    }

    if (!empty($_POST)) {
        return $_POST;
    }

    if (!empty($_GET)) {
        return $_GET;
    }

    return [];
}

function normalizeRole($value) {
    if ($value === null) return 'Customer';
    $role = trim((string) $value);
    if ($role === '') return 'Customer';

    // Smart Rent's frontend only has dedicated dashboards for Admin,
    // Landlord, and Customer - but the `smartrent.users` table's role
    // column is a genuine enum('Admin','Landlord','Customer','Agent') and
    // real Agent accounts already exist in it. Silently remapping Agent to
    // Customer (the previous behavior) let Agent accounts log in, but
    // misreported their identity/role to the rest of the app on every
    // request - not a cosmetic issue, since anything that ever branches on
    // role (permissions, reporting, future features) would see the wrong
    // value. Agent is preserved as its own role here; requireRole()/
    // requireAnyRole() checks elsewhere already only allow-list 'Admin'
    // and/or 'Landlord' explicitly, so this does not grant Agent accounts
    // any Admin/Landlord permissions they didn't already have. The
    // frontend has no Agent-specific dashboard (see resources/views/
    // app.blade.php), so an Agent who logs in lands on the same general
    // Browse Rooms view a Customer would - it just now does so as
    // "Agent", not under a false "Customer" identity.
    $map = [
        'customer' => 'Customer',
        'customers' => 'Customer',
        'landlord' => 'Landlord',
        'landlords' => 'Landlord',
        'admin' => 'Admin',
        'admins' => 'Admin',
        'agent' => 'Agent',
        'agents' => 'Agent',
    ];

    return $map[strtolower($role)] ?? 'Customer';
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function getCurrentUser() {
    global $pdo;
    if (!isLoggedIn()) return null;
    $stmt = $pdo->prepare("SELECT id, full_name AS name, email, phone, role AS type FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    if ($user) {
        $user['type'] = normalizeRole($user['type']);
    }
    return $user;
}

function requireAuth() {
    if (!isLoggedIn()) sendJSON(['error' => 'Unauthorized'], 401);
}

function requireRole($role) {
    $user = getCurrentUser();
    if (!$user || normalizeRole($user['type']) !== normalizeRole($role)) sendJSON(['error' => 'Forbidden'], 403);
}

function requireAnyRole(array $roles) {
    $user = getCurrentUser();
    if (!$user) sendJSON(['error' => 'Unauthorized'], 401);
    $currentRole = normalizeRole($user['type']);
    foreach ($roles as $role) {
        if ($currentRole === normalizeRole($role)) {
            return;
        }
    }
    sendJSON(['error' => 'Forbidden'], 403);
}
?>