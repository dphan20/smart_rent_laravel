<?php
require_once __DIR__ . '/../config/database.php';

/**
 * Computes platform commission and landlord payout amounts. This is the
 * ONLY place commission math happens - callers must never accept a
 * commission_rate, commission_amount, or landlord_amount from client input
 * and pass it through. Every payment's commission is (re)computed here from
 * the admin-configured platform_settings.platform_commission_rate.
 */
class CommissionService
{
    private const DEFAULT_RATE = 10.0; // percent, used only if the setting row is somehow missing

    public static function getCommissionRate(): float
    {
        global $pdo;
        $stmt = $pdo->prepare("SELECT setting_value FROM platform_settings WHERE setting_key = 'platform_commission_rate'");
        $stmt->execute();
        $value = $stmt->fetchColumn();
        if ($value === false || !is_numeric($value)) {
            return self::DEFAULT_RATE;
        }
        $rate = (float) $value;
        // Defensive clamp - a corrupted or mistyped setting (e.g. "1000")
        // should never be able to zero out or exceed 100% of a payment.
        return max(0.0, min(100.0, $rate));
    }

    public static function setCommissionRate(float $rate): void
    {
        $rate = max(0.0, min(100.0, $rate));
        global $pdo;
        $stmt = $pdo->prepare(
            "INSERT INTO platform_settings (setting_key, setting_value) VALUES ('platform_commission_rate', ?)
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)"
        );
        $stmt->execute([(string) $rate]);
    }

    /**
     * @return array{rate: float, commission: float, landlord_amount: float}
     */
    public static function calculate(float $grossAmount): array
    {
        $rate = self::getCommissionRate();
        $commission = round($grossAmount * ($rate / 100), 2);
        $landlordAmount = round($grossAmount - $commission, 2);
        return [
            'rate' => $rate,
            'commission' => $commission,
            'landlord_amount' => $landlordAmount,
        ];
    }
}
