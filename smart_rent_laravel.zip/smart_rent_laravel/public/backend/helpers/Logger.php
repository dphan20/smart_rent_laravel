<?php
/**
 * Minimal structured logger, no external dependencies (fits XAMPP/no-Composer
 * constraint). Writes one line of JSON per event to backend/logs/{category}.log.
 *
 * Every line includes: timestamp, request_id (stable per HTTP request, so
 * you can grep one request across multiple log files), user_id (if logged
 * in), ip address, and whatever context the caller passes in.
 *
 * Categories used elsewhere in the app: app, auth, api, error, booking.
 * (sms/payment logging is intentionally NOT wired in here - those layers
 * are out of scope for this pass and were left untouched.)
 */
class Logger
{
    private static ?string $requestId = null;

    private static function requestId(): string
    {
        if (self::$requestId === null) {
            self::$requestId = bin2hex(random_bytes(8));
        }
        return self::$requestId;
    }

    private static function clientIp(): string
    {
        // Trust X-Forwarded-For only if you control the proxy in front of
        // this app; otherwise REMOTE_ADDR is the only value that can't be
        // spoofed by the client.
        return $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    }

    private static function logDir(): string
    {
        $dir = __DIR__ . '/../logs';
        if (!is_dir($dir)) {
            @mkdir($dir, 0750, true);
        }
        return $dir;
    }

    public static function log(string $category, string $message, array $context = []): void
    {
        $category = preg_replace('/[^a-z0-9_-]/i', '', $category) ?: 'app';
        $line = [
            'ts' => date('c'),
            'request_id' => self::requestId(),
            'user_id' => $_SESSION['user_id'] ?? null,
            'ip' => self::clientIp(),
            'method' => $_SERVER['REQUEST_METHOD'] ?? null,
            'path' => $_SERVER['PATH_INFO'] ?? ($_SERVER['REQUEST_URI'] ?? null),
            'message' => $message,
        ] + $context;

        $file = self::logDir() . '/' . $category . '.log';
        @file_put_contents($file, json_encode($line, JSON_UNESCAPED_SLASHES) . "\n", FILE_APPEND | LOCK_EX);
    }

    public static function auth(string $message, array $context = []): void { self::log('auth', $message, $context); }
    public static function api(string $message, array $context = []): void { self::log('api', $message, $context); }
    public static function booking(string $message, array $context = []): void { self::log('booking', $message, $context); }
    public static function error(string $message, array $context = []): void { self::log('error', $message, $context); }
    public static function app(string $message, array $context = []): void { self::log('app', $message, $context); }
}
