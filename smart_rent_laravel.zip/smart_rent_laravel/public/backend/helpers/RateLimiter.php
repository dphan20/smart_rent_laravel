<?php
/**
 * Minimal file-based rate limiter. No Redis/Memcached dependency, so it
 * works out of the box on XAMPP. Good enough for a single-server deployment;
 * if you ever run multiple app servers behind a load balancer, swap the
 * storage in allow() for a shared store (Redis, Memcached, or a DB table) -
 * the interface here doesn't need to change.
 */
class RateLimiter
{
    private static function dir(): string
    {
        $dir = sys_get_temp_dir() . '/smart_rent_ratelimit';
        if (!is_dir($dir)) {
            @mkdir($dir, 0700, true);
        }
        return $dir;
    }

    /**
     * @param string $key Unique bucket key, e.g. "auth:1.2.3.4"
     * @param int $maxRequests Max requests allowed within the window
     * @param int $windowSeconds Window length in seconds
     * @return bool true if this request is allowed, false if the limit was hit
     */
    public static function allow(string $key, int $maxRequests, int $windowSeconds): bool
    {
        $file = self::dir() . '/' . preg_replace('/[^a-z0-9_:.-]/i', '_', $key) . '.json';
        $now = time();

        $fp = @fopen($file, 'c+');
        if (!$fp) {
            // Fail open rather than break the whole API if /tmp is somehow
            // unwritable - availability wins over a rate-limit edge case.
            return true;
        }
        flock($fp, LOCK_EX);
        $contents = stream_get_contents($fp);
        $timestamps = $contents ? (json_decode($contents, true) ?: []) : [];

        // Drop anything outside the current window.
        $timestamps = array_values(array_filter($timestamps, fn($t) => $t > $now - $windowSeconds));

        $allowed = count($timestamps) < $maxRequests;
        if ($allowed) {
            $timestamps[] = $now;
        }

        ftruncate($fp, 0);
        rewind($fp);
        fwrite($fp, json_encode($timestamps));
        fflush($fp);
        flock($fp, LOCK_UN);
        fclose($fp);

        return $allowed;
    }
}
