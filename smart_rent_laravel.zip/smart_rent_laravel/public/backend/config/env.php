<?php
/**
 * Minimal, dependency-free .env loader.
 *
 * XAMPP doesn't ship Composer/vlucas-phpdotenv by default, so this reads a
 * KEY=VALUE .env file at the project root and exposes it via getenv()/$_ENV,
 * without ever overwriting a real OS-level environment variable that was
 * already set (e.g. by Apache's SetEnv, or a real production host).
 *
 * Usage: require this once, early, before any getenv() calls.
 */
function loadEnvFile(string $path): void
{
    if (!is_file($path) || !is_readable($path)) {
        return;
    }

    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if ($lines === false) {
        return;
    }

    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || $line[0] === '#') {
            continue;
        }
        if (!str_contains($line, '=')) {
            continue;
        }

        [$key, $value] = array_map('trim', explode('=', $line, 2));
        if ($key === '') {
            continue;
        }

        // Strip matching surrounding quotes, e.g. KEY="some value"
        if (strlen($value) >= 2 &&
            (($value[0] === '"' && $value[-1] === '"') || ($value[0] === "'" && $value[-1] === "'"))) {
            $value = substr($value, 1, -1);
        }

        // A real environment variable always wins over the .env file.
        if (getenv($key) !== false) {
            continue;
        }

        putenv("$key=$value");
        $_ENV[$key] = $value;
    }
}

// backend/ now lives inside public/, so the project's .env (which stays
// at the project root, alongside artisan/composer.json) is 3 levels up
// from here: config -> backend -> public -> project root.
loadEnvFile(__DIR__ . '/../../../.env');
