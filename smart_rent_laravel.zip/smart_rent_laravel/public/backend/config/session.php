<?php
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.use_strict_mode', 1);
    ini_set('session.use_only_cookies', 1);
    $host = $_SERVER['SERVER_NAME'] ?? ($_SERVER['HTTP_HOST'] ?? '');
    $hostNoPort = preg_replace('/:\d+$/', '', $host);
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    $originHost = $origin !== '' ? preg_replace('/:\d+$/', '', (string) parse_url($origin, PHP_URL_HOST)) : '';
    $isCrossOrigin = $origin !== '' && $originHost !== '' && $originHost !== $hostNoPort;
    $isLocalhost = in_array($hostNoPort, ['localhost', '127.0.0.1'], true);
    $isHttps = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    if ($isCrossOrigin) {
        ini_set('session.cookie_secure', ($isHttps || $isLocalhost) ? 1 : 0);
        ini_set('session.cookie_samesite', 'None');
    } else {
        ini_set('session.cookie_secure', $isHttps ? 1 : 0);
        ini_set('session.cookie_samesite', 'Lax');
    }
    ini_set('session.cookie_httponly', 1);
    ini_set('session.gc_maxlifetime', 3600);
    ini_set('session.cookie_lifetime', 0);
    ini_set('session.name', 'SMART_RENT_SESSID');
    session_start();
}
$_SESSION['last_activity'] = time();
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
function getCsrfToken() {
    return trim((string) ($_SESSION['csrf_token'] ?? ''));
}
function verifyCsrfToken($token) {
    $sessionToken = getCsrfToken();
    $providedToken = is_string($token) ? trim($token) : '';
    if ($sessionToken === '' || $providedToken === '') {
        return false;
    }
    return hash_equals($sessionToken, $providedToken);
}
?>