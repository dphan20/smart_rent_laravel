<?php
require_once __DIR__ . '/env.php';

$appEnv = getenv('APP_ENV') ?: 'development';

if ($appEnv === 'production') {
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
} else {
    ini_set('display_errors', '1');
}
error_reporting(E_ALL);

$host = getenv('SMART_RENT_DB_HOST') ?: 'localhost';
$port = getenv('SMART_RENT_DB_PORT') ?: '3306';
$dbname = getenv('SMART_RENT_DB_NAME') ?: 'smartrent';

if ($appEnv === 'production') {
    $username = getenv('SMART_RENT_DB_USER');
    $password = getenv('SMART_RENT_DB_PASS');
    if (!$username) {
        http_response_code(500);
        error_log('FATAL: SMART_RENT_DB_USER is not set while APP_ENV=production. Refusing to start.');
        die(json_encode(['error' => 'Server misconfigured. Contact the administrator.']));
    }
} else {
    $username = getenv('SMART_RENT_DB_USER') ?: 'root';
    $password = getenv('SMART_RENT_DB_PASS') ?: '';
}

$pdoOptions = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
    PDO::ATTR_TIMEOUT => 5  // Connection timeout
];

try {
    $pdo = new PDO("mysql:host=$host;port=$port;dbname=$dbname;charset=utf8mb4", $username, $password, $pdoOptions);
    
    // Schema self-healing only runs if a marker file doesn't exist,
    // which prevents this expensive operation from running on every request.
    // When the marker file is deleted (via a deployment script or manual reset),
    // the next request will rebuild the schema.
    $markerFile = __DIR__ . '/../../.schema_initialized';
    $schemaInitialized = is_file($markerFile) && (time() - filemtime($markerFile)) < 3600; // Valid for 1 hour
    
    if (!$schemaInitialized) {
        // Run schema initialization only once per hour
        initializeSchema($pdo);
        @touch($markerFile);
    }
    
} catch (PDOException $e) {
    http_response_code(500);
    die(json_encode(['error' => 'Database connection failed', 'details' => $e->getMessage()]));
}

/**
 * Initialize or repair the database schema.
 * Runs once per 24 hours to minimize performance impact.
 */
function initializeSchema($pdo) {
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        full_name VARCHAR(100) NOT NULL,
        email VARCHAR(191) NOT NULL UNIQUE,
        phone VARCHAR(30) DEFAULT '',
        password_hash VARCHAR(255) NOT NULL,
        role VARCHAR(30) DEFAULT 'Customer',
        email_verified_at DATETIME NULL,
        failed_login_attempts INT NOT NULL DEFAULT 0,
        locked_until DATETIME NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB");

    $requiredUserColumns = [
        ['email_verified_at', 'DATETIME NULL', 'AFTER role'],
        ['failed_login_attempts', 'INT NOT NULL DEFAULT 0', 'AFTER email_verified_at'],
        ['locked_until', 'DATETIME NULL', 'AFTER failed_login_attempts'],
    ];
    foreach ($requiredUserColumns as [$column, $definition, $after]) {
        $missing = $pdo->query(
            "SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'users' AND column_name = '$column'"
        )->fetchColumn();
        if ((int) $missing === 0) {
            $pdo->exec("ALTER TABLE users ADD COLUMN `$column` $definition $after");
        }
    }

    $pdo->exec("CREATE TABLE IF NOT EXISTS rooms (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(150) NOT NULL,
        location VARCHAR(255) NOT NULL,
        area VARCHAR(100) NOT NULL,
        price DECIMAL(10,2) NOT NULL,
        size INT NOT NULL,
        type VARCHAR(50) NOT NULL,
        rental_mode VARCHAR(20) NOT NULL DEFAULT 'rent',
        beds INT NOT NULL,
        badge VARCHAR(100) DEFAULT '',
        status VARCHAR(30) DEFAULT 'available',
        image VARCHAR(255) DEFAULT NULL,
        landlord_id INT DEFAULT NULL,
        virtual_tour VARCHAR(255) DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB");

    $pdo->exec("CREATE TABLE IF NOT EXISTS bookings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        room_id INT DEFAULT NULL,
        user_id INT DEFAULT NULL,
        landlord_id INT DEFAULT NULL,
        customer_name VARCHAR(100) NOT NULL,
        customer_email VARCHAR(191) NOT NULL,
        customer_phone VARCHAR(30) NOT NULL,
        amount DECIMAL(10,2) DEFAULT NULL,
        arrival_date DATE DEFAULT NULL,
        rental_mode VARCHAR(20) NOT NULL DEFAULT 'holiday',
        status VARCHAR(30) DEFAULT 'confirmed',
        payment_ref VARCHAR(100) DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB");

    $pdo->exec("CREATE TABLE IF NOT EXISTS orders (
        id INT AUTO_INCREMENT PRIMARY KEY,
        room_id INT DEFAULT NULL,
        user_id INT DEFAULT NULL,
        landlord_id INT DEFAULT NULL,
        customer_name VARCHAR(100) NOT NULL,
        customer_email VARCHAR(191) NOT NULL,
        customer_phone VARCHAR(30) NOT NULL,
        arrival_date DATE DEFAULT NULL,
        status VARCHAR(30) DEFAULT 'ordered',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB");

    $pdo->exec("CREATE TABLE IF NOT EXISTS payments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        room_id INT DEFAULT NULL,
        user_id INT DEFAULT NULL,
        landlord_id INT DEFAULT NULL,
        booking_id INT DEFAULT NULL,
        order_id INT DEFAULT NULL,
        amount DECIMAL(10,2) NOT NULL,
        commission_rate DECIMAL(5,2) NULL,
        commission_amount DECIMAL(10,2) NULL,
        landlord_amount DECIMAL(10,2) NULL,
        payment_method VARCHAR(50) NOT NULL,
        reference VARCHAR(100) NOT NULL,
        status VARCHAR(30) DEFAULT 'successful',
        recipient_number VARCHAR(30) DEFAULT NULL,
        customer_name VARCHAR(100) DEFAULT NULL,
        customer_email VARCHAR(191) DEFAULT NULL,
        customer_phone VARCHAR(30) DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB");

    $pdo->exec("CREATE TABLE IF NOT EXISTS receipts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        booking_id INT DEFAULT NULL,
        payment_id INT DEFAULT NULL,
        room_id INT DEFAULT NULL,
        user_id INT DEFAULT NULL,
        landlord_id INT DEFAULT NULL,
        receipt_number VARCHAR(100) NOT NULL,
        amount DECIMAL(10,2) DEFAULT NULL,
        payment_method VARCHAR(50) DEFAULT NULL,
        reference VARCHAR(100) DEFAULT NULL,
        customer_name VARCHAR(100) DEFAULT NULL,
        customer_email VARCHAR(191) DEFAULT NULL,
        customer_phone VARCHAR(30) DEFAULT NULL,
        recipient_number VARCHAR(30) DEFAULT NULL,
        status VARCHAR(30) DEFAULT 'issued',
        payment_status VARCHAR(30) DEFAULT 'successful',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB");

    $pdo->exec("CREATE TABLE IF NOT EXISTS messages (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(191) NOT NULL,
        phone VARCHAR(30) NOT NULL,
        message TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB");

    $pdo->exec("CREATE TABLE IF NOT EXISTS properties (
        id INT AUTO_INCREMENT PRIMARY KEY,
        landlord_id INT NOT NULL,
        name VARCHAR(150) NOT NULL,
        type VARCHAR(50) DEFAULT 'House',
        rental_mode VARCHAR(20) NOT NULL DEFAULT 'rent',
        apartment VARCHAR(100) DEFAULT NULL,
        house_no VARCHAR(50) DEFAULT NULL,
        region VARCHAR(100) NOT NULL,
        district VARCHAR(100) NOT NULL,
        ward VARCHAR(100) DEFAULT NULL,
        street VARCHAR(100) DEFAULT NULL,
        location VARCHAR(255) NOT NULL,
        coords VARCHAR(100) DEFAULT NULL,
        description TEXT DEFAULT NULL,
        bedrooms INT DEFAULT 0,
        bathrooms INT DEFAULT 0,
        amenities TEXT DEFAULT NULL,
        furnished VARCHAR(50) DEFAULT 'Unfurnished',
        room_size DECIMAL(8,2) DEFAULT 0,
        monthly_rent DECIMAL(10,2) DEFAULT 0,
        deposit DECIMAL(10,2) DEFAULT 0,
        service_charge DECIMAL(10,2) DEFAULT 0,
        availability VARCHAR(30) DEFAULT 'available',
        images TEXT DEFAULT NULL,
        video VARCHAR(255) DEFAULT NULL,
        virtual_tour VARCHAR(255) DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB");

    $userCount = (int) $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $adminEmail = getenv('SMART_RENT_ADMIN_EMAIL') ?: 'admin@smartrent.co.tz';
    $adminPassword = getenv('SMART_RENT_ADMIN_PASSWORD');
    if ($userCount === 0 && $adminPassword) {
        $adminHash = password_hash($adminPassword, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (full_name, email, phone, password_hash, role) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute(['System Admin', $adminEmail, '+255700000000', $adminHash, 'Admin']);
    } elseif ($userCount > 0) {
        $adminCheck = $pdo->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
        $adminCheck->execute([$adminEmail]);
        $adminUser = $adminCheck->fetch();
        if (!$adminUser) {
            $adminCheck = $pdo->prepare("SELECT id FROM users WHERE role = ? LIMIT 1");
            $adminCheck->execute(['Admin']);
            $adminUser = $adminCheck->fetch();
        }
        if ($adminUser && $adminPassword) {
            $pdo->prepare("UPDATE users SET email = ?, password_hash = ?, role = ? WHERE id = ?")
                ->execute([$adminEmail, password_hash($adminPassword, PASSWORD_DEFAULT), 'Admin', $adminUser['id']]);
        }
    }

    $pdo->exec("CREATE TABLE IF NOT EXISTS platform_settings (
        setting_key VARCHAR(100) NOT NULL PRIMARY KEY,
        setting_value VARCHAR(255) NOT NULL,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB");

    $pdo->exec("CREATE TABLE IF NOT EXISTS contracts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        contract_number VARCHAR(50) NOT NULL UNIQUE,
        booking_id INT DEFAULT NULL,
        property_id INT DEFAULT NULL,
        room_id INT DEFAULT NULL,
        landlord_id INT NOT NULL,
        customer_id INT NOT NULL,
        monthly_rent DECIMAL(10,2) NOT NULL,
        deposit DECIMAL(10,2) DEFAULT 0,
        start_date DATE DEFAULT NULL,
        end_date DATE DEFAULT NULL,
        payment_terms TEXT DEFAULT NULL,
        responsibilities TEXT DEFAULT NULL,
        termination_conditions TEXT DEFAULT NULL,
        other_terms TEXT DEFAULT NULL,
        status VARCHAR(30) NOT NULL DEFAULT 'DRAFT',
        customer_accepted_at TIMESTAMP NULL DEFAULT NULL,
        landlord_accepted_at TIMESTAMP NULL DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_contracts_landlord (landlord_id),
        INDEX idx_contracts_customer (customer_id),
        INDEX idx_contracts_booking (booking_id),
        INDEX idx_contracts_status (status)
    ) ENGINE=InnoDB");

    // One row per acceptance event (customer accept, landlord accept) -
    // kept separate from contracts.*_accepted_at so we retain a full,
    // append-only audit trail (who, when, from where) even if a contract
    // is later re-issued.
    $pdo->exec("CREATE TABLE IF NOT EXISTS contract_acceptances (
        id INT AUTO_INCREMENT PRIMARY KEY,
        contract_id INT NOT NULL,
        user_id INT NOT NULL,
        role VARCHAR(30) NOT NULL,
        accepted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        ip_address VARCHAR(45) DEFAULT NULL,
        INDEX idx_acceptances_contract (contract_id),
        FOREIGN KEY (contract_id) REFERENCES contracts(id) ON DELETE CASCADE
    ) ENGINE=InnoDB");

    $pdo->exec("CREATE TABLE IF NOT EXISTS payouts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        landlord_id INT NOT NULL,
        payment_id INT DEFAULT NULL,
        amount DECIMAL(10,2) NOT NULL,
        status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
        payout_method VARCHAR(50) DEFAULT NULL,
        payout_reference VARCHAR(100) DEFAULT NULL,
        notes TEXT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_payouts_landlord (landlord_id),
        INDEX idx_payouts_status (status)
    ) ENGINE=InnoDB");

    $pdo->exec("CREATE TABLE IF NOT EXISTS ai_conversations (
        id INT AUTO_INCREMENT PRIMARY KEY,
        customer_id INT DEFAULT NULL,
        session_id VARCHAR(100) NOT NULL,
        message TEXT NOT NULL,
        response TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_ai_conv_session (session_id),
        INDEX idx_ai_conv_customer (customer_id)
    ) ENGINE=InnoDB");

    // --- Auth-support tables ------------------------------------------------
    // These four were missing from auto-creation (they only existed in the
    // standalone smartrent_auth_fix.sql patch, which was never actually run).
    // AuthController::login()/signup() write to login_attempts on EVERY
    // attempt (success or failure) via AuthSecurity::recordAttempt(), so
    // without this table every login/signup throws an uncaught PDOException
    // and the API returns a generic 500 "unexpected error occurred" - which
    // is exactly the "can't login" symptom this was causing. Creating them
    // here makes the schema fully self-healing on first request, same as
    // every other table above.
    $normalizeAuthTable = function (string $table, string $createSql, array $indexesToAdd = [], array $uniqueKeysToAdd = [], array $fkToAdd = []) use ($pdo) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS `$table` ($createSql) ENGINE=InnoDB");

        // Only adjust AUTO_INCREMENT if there are existing rows
        $maxId = (int) $pdo->query("SELECT COALESCE(MAX(id), 0) FROM `$table`")->fetchColumn();
        if ($maxId > 0) {
            // Set AUTO_INCREMENT to next safe value, but don't MODIFY the column
            // (which would trigger MySQL to rebuild the index and cause PK collisions)
            try {
                $pdo->exec("ALTER TABLE `$table` AUTO_INCREMENT = " . ($maxId + 1));
            } catch (PDOException $e) {
                // Ignore failures here; the table will self-heal eventually
            }
        }

        foreach ($indexesToAdd as $indexSql) {
            try {
                $pdo->exec("ALTER TABLE `$table` ADD $indexSql");
            } catch (PDOException $e) {
                // Existing index; ignore for idempotent self-healing.
            }
        }

        foreach ($uniqueKeysToAdd as $uniqueSql) {
            try {
                $pdo->exec("ALTER TABLE `$table` ADD UNIQUE KEY $uniqueSql");
            } catch (PDOException $e) {
                // Existing unique key; ignore for idempotent self-healing.
            }
        }

        foreach ($fkToAdd as $fkSql) {
            try {
                $pdo->exec("ALTER TABLE `$table` ADD $fkSql");
            } catch (PDOException $e) {
                // Existing FK; ignore for idempotent self-healing.
            }
        }
    };

    $normalizeAuthTable(
        'login_attempts',
        "id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, email VARCHAR(191) NOT NULL, ip_address VARCHAR(45) NOT NULL, success TINYINT(1) NOT NULL DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP",
        ['INDEX idx_login_attempts_ip_time (ip_address, created_at)', 'INDEX idx_login_attempts_email_time (email, created_at)']
    );

    $normalizeAuthTable(
        'password_resets',
        "id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, token_hash CHAR(64) NOT NULL, expires_at DATETIME NOT NULL, used_at DATETIME NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP",
        ['INDEX idx_password_resets_user (user_id)'],
        ['uq_password_resets_token_hash (token_hash)'],
        ['CONSTRAINT fk_password_resets_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE']
    );

    $normalizeAuthTable(
        'remember_tokens',
        "id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, selector CHAR(24) NOT NULL, token_hash CHAR(64) NOT NULL, expires_at DATETIME NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP",
        ['INDEX idx_remember_tokens_user (user_id)'],
        ['uq_remember_tokens_selector (selector)'],
        ['CONSTRAINT fk_remember_tokens_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE']
    );

    $normalizeAuthTable(
        'email_verifications',
        "id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, token_hash CHAR(64) NOT NULL, expires_at DATETIME NOT NULL, verified_at DATETIME NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP",
        ['INDEX idx_email_verifications_user (user_id)'],
        ['uq_email_verifications_token_hash (token_hash)'],
        ['CONSTRAINT fk_email_verifications_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE']
    );

    // Default platform commission rate (percent). Admin-configurable;
    // every commission calculation must read this value server-side and
    // never trust a rate sent from the client.
    $pdo->prepare("INSERT IGNORE INTO platform_settings (setting_key, setting_value) VALUES ('platform_commission_rate', '10')")->execute();

    $roomCount = (int) $pdo->query("SELECT COUNT(*) FROM rooms")->fetchColumn();
    if ($roomCount === 0) {
        $stmt = $pdo->prepare("INSERT INTO rooms (title, location, area, price, size, type, beds, badge, status, image, landlord_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            'Modern Studio Apartment',
            'Dar es Salaam, Kinondoni',
            'Kinondoni',
            450000,
            120,
            'Studio',
            1,
            'Featured',
            'available',
            'uploads/room_1783719075_2992.PNG',
            1
        ]);
    }
}
?>