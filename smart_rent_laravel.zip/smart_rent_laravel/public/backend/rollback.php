<?php
/**
 * SMART RENT - rollback for backend/migrate.php.
 * Run with: php backend/rollback.php
 * Safe to run multiple times (checks existence before dropping).
 */

require_once __DIR__ . '/config/env.php';
// backend/ now lives inside public/ - project root is 2 levels up.
loadEnvFile(__DIR__ . '/../../.env');

$host = getenv('SMART_RENT_DB_HOST') ?: 'localhost';
$dbname = getenv('SMART_RENT_DB_NAME') ?: 'smartrent';
$username = getenv('SMART_RENT_DB_USER') ?: 'root';
$password = getenv('SMART_RENT_DB_PASS') ?: '';

$pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
]);

function step2(string $label, callable $fn): void {
    echo "-> $label ... ";
    try {
        $fn();
        echo "done\n";
    } catch (Throwable $e) {
        echo "skipped: " . $e->getMessage() . "\n";
    }
}

$fks = [
    ['bookings', 'fk_bookings_room'], ['bookings', 'fk_bookings_user'], ['bookings', 'fk_bookings_landlord'],
    ['orders', 'fk_orders_room'], ['orders', 'fk_orders_user'], ['orders', 'fk_orders_landlord'],
    ['payments', 'fk_payments_room'], ['payments', 'fk_payments_user'], ['payments', 'fk_payments_landlord'],
    ['receipts', 'fk_receipts_booking'], ['receipts', 'fk_receipts_payment'],
    ['properties', 'fk_properties_landlord'],
];
foreach ($fks as [$table, $name]) {
    step2("drop FK $name", fn() => $pdo->exec("ALTER TABLE `$table` DROP FOREIGN KEY `$name`"));
}

$indexes = [
    ['rooms', 'idx_rooms_status'], ['rooms', 'idx_rooms_landlord'],
    ['bookings', 'idx_bookings_room'], ['bookings', 'idx_bookings_user'], ['bookings', 'idx_bookings_status'],
    ['orders', 'idx_orders_room'], ['orders', 'idx_orders_user'], ['orders', 'idx_orders_status'],
    ['payments', 'idx_payments_user'], ['payments', 'idx_payments_status'], ['payments', 'uq_payments_reference'],
];
foreach ($indexes as [$table, $name]) {
    step2("drop index $name", fn() => $pdo->exec("ALTER TABLE `$table` DROP INDEX `$name`"));
}

foreach (['login_attempts', 'password_resets', 'remember_tokens', 'email_verifications'] as $table) {
    step2("drop table $table", fn() => $pdo->exec("DROP TABLE IF EXISTS `$table`"));
}

step2('drop users auth-hardening columns', function () use ($pdo) {
    $pdo->exec("ALTER TABLE users DROP COLUMN email_verified_at");
    $pdo->exec("ALTER TABLE users DROP COLUMN failed_login_attempts");
    $pdo->exec("ALTER TABLE users DROP COLUMN locked_until");
});

step2('drop payments commission columns', function () use ($pdo) {
    $pdo->exec("ALTER TABLE payments DROP COLUMN commission_rate");
    $pdo->exec("ALTER TABLE payments DROP COLUMN commission_amount");
    $pdo->exec("ALTER TABLE payments DROP COLUMN landlord_amount");
});

echo "\nRollback complete.\n";
