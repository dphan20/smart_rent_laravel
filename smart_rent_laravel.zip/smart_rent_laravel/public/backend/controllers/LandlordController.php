<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../helpers/functions.php';

/**
 * Landlord-only dashboard data: the SAME KPI-card style as
 * AdminController::dashboard(), but every query is scoped to just the
 * signed-in landlord's own rows via landlord_id — never the platform-wide
 * totals (those stay Admin-only). Added because the Flutter landlord
 * dashboard was previously calling /admin/dashboard directly, which is
 * intentionally Admin-only and always returned "Forbidden - admin only".
 */
class LandlordController
{
    private static function guard(): int
    {
        requireAuth();
        $user = getCurrentUser();
        if (!$user || normalizeRole($user['type']) !== 'Landlord') {
            sendJSON(['error' => 'Forbidden - landlord only'], 403);
        }
        return (int) $user['id'];
    }

    /** GET /landlord/dashboard */
    public static function dashboard(): void
    {
        $landlordId = self::guard();
        global $pdo;

        $propertiesStmt = $pdo->prepare('SELECT COUNT(*) FROM properties WHERE landlord_id = ?');
        $propertiesStmt->execute([$landlordId]);

        $roomsStmt = $pdo->prepare('SELECT COUNT(*) FROM rooms WHERE landlord_id = ?');
        $roomsStmt->execute([$landlordId]);

        $bookingsStmt = $pdo->prepare('SELECT COUNT(*) FROM bookings WHERE landlord_id = ?');
        $bookingsStmt->execute([$landlordId]);

        // "Earnings" = the landlord's own share (landlord_amount) of
        // successful payments only — never pending/failed, and never the
        // platform's commission cut.
        $earningsStmt = $pdo->prepare(
            "SELECT COALESCE(SUM(landlord_amount), 0) FROM payments WHERE landlord_id = ? AND status = 'successful'"
        );
        $earningsStmt->execute([$landlordId]);

        $pendingPayoutsStmt = $pdo->prepare(
            "SELECT COALESCE(SUM(amount), 0) FROM payouts WHERE landlord_id = ? AND status = 'PENDING'"
        );
        $pendingPayoutsStmt->execute([$landlordId]);

        $months = self::lastNMonths(6);
        $earnByMonthStmt = $pdo->prepare(
            "SELECT DATE_FORMAT(created_at, '%Y-%m') ym, COALESCE(SUM(landlord_amount),0) total
             FROM payments
             WHERE landlord_id = ? AND status = 'successful' AND created_at >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
             GROUP BY ym"
        );
        $earnByMonthStmt->execute([$landlordId]);
        $earnByMonth = [];
        foreach ($earnByMonthStmt->fetchAll() as $row) {
            $earnByMonth[$row['ym']] = $row['total'];
        }
        $monthlyEarnings = array_map(function ($m) use ($earnByMonth) {
            return ['month' => $m, 'total' => (float) ($earnByMonth[$m] ?? 0)];
        }, $months);

        $bookingsByStatusStmt = $pdo->prepare('SELECT status, COUNT(*) AS count FROM bookings WHERE landlord_id = ? GROUP BY status');
        $bookingsByStatusStmt->execute([$landlordId]);

        sendJSON([
            'properties_count' => (int) $propertiesStmt->fetchColumn(),
            'rooms_count' => (int) $roomsStmt->fetchColumn(),
            'bookings_count' => (int) $bookingsStmt->fetchColumn(),
            'landlord_earnings' => (float) $earningsStmt->fetchColumn(),
            'pending_payouts' => (float) $pendingPayoutsStmt->fetchColumn(),
            'charts' => [
                'monthly_earnings' => $monthlyEarnings,
                'bookings_by_status' => $bookingsByStatusStmt->fetchAll(),
            ],
        ]);
    }

    /** @return string[] e.g. ['2026-03', '2026-04', ..., '2026-08'] */
    private static function lastNMonths(int $n): array
    {
        $months = [];
        for ($i = $n - 1; $i >= 0; $i--) {
            $months[] = date('Y-m', strtotime("-$i months"));
        }
        return $months;
    }
}
