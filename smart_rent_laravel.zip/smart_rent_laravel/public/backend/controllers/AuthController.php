<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../helpers/functions.php';
require_once __DIR__ . '/../helpers/Logger.php';
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/AuthSecurity.php';

class AuthController {
    const REMEMBER_COOKIE = 'smart_rent_remember';

    private static function clientIp(): string {
        return $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    }

    private static function setRememberCookie(int $userId): void {
        $value = AuthSecurity::createRememberToken($userId);
        setcookie(self::REMEMBER_COOKIE, $value, [
            'expires' => time() + AuthSecurity::REMEMBER_DAYS * 86400,
            'path' => '/',
            'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
    }

    private static function clearRememberCookie(): void {
        if (isset($_COOKIE[self::REMEMBER_COOKIE])) {
            AuthSecurity::revokeRememberToken($_COOKIE[self::REMEMBER_COOKIE]);
        }
        setcookie(self::REMEMBER_COOKIE, '', [
            'expires' => time() - 42000,
            'path' => '/',
            'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
    }

    /**
     * Called once per request (from api.php) before routing, for requests
     * that arrive with no active session. If a valid remember-me cookie is
     * present, transparently logs the user back in and rotates the token.
     */
    public static function attemptRememberMeLogin(): void {
        if (isLoggedIn() || !isset($_COOKIE[self::REMEMBER_COOKIE])) {
            return;
        }
        $userId = AuthSecurity::verifyAndRotateRememberToken($_COOKIE[self::REMEMBER_COOKIE]);
        if ($userId === null) {
            self::clearRememberCookie();
            return;
        }
        $user = User::findById($userId);
        if (!$user) {
            self::clearRememberCookie();
            return;
        }
        session_regenerate_id(true);
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_type'] = normalizeRole($user['type']);
        self::setRememberCookie($userId); // rotated token
        Logger::auth('remember-me login', ['email' => $user['email']]);
    }

    public static function login() {
        $data = readRequestData();
        if (!is_array($data)) {
            $data = [];
        }
        if (empty($data['email']) || empty($data['password'])) {
            sendJSON(['success' => false, 'message' => 'Email and password required'], 400);
        }
        $email = sanitizeString($data['email'] ?? '');
        $password = (string) ($data['password'] ?? '');
        $remember = !empty($data['remember']);
        $ip = self::clientIp();

        if ($email === '' || !validateEmail($email) || $password === '') {
            sendJSON(['success' => false, 'message' => 'Invalid credentials'], 401);
        }

        if (AuthSecurity::isIpThrottled($ip)) {
            Logger::auth('login blocked: IP throttled', ['email' => $email]);
            sendJSON(['success' => false, 'message' => 'Too many login attempts from this network. Please try again later.'], 429);
        }

        $user = User::findByEmail($email);

        if ($user && AuthSecurity::isAccountLocked($user)) {
            AuthSecurity::recordAttempt($email, $ip, false);
            Logger::auth('login blocked: account locked', ['email' => $email]);
            sendJSON(['success' => false, 'message' => 'This account is temporarily locked due to repeated failed logins. Please try again later or reset your password.'], 423);
        }

        if (!$user || !password_verify($password, $user['password_hash'])) {
            AuthSecurity::recordAttempt($email, $ip, false);
            if ($user) {
                AuthSecurity::registerFailure((int) $user['id']);
            }
            Logger::auth('login failed', ['email' => $email]);
            sendJSON(['success' => false, 'message' => 'Invalid credentials'], 401);
        }

        AuthSecurity::recordAttempt($email, $ip, true);
        AuthSecurity::registerSuccess((int) $user['id']);

        $user['type'] = normalizeRole($user['type']);
        
        // Set session data. Note: session_regenerate_id() cannot be called here
        // because CORS headers have already been sent by api.php, so regeneration
        // will fail. Instead, rely on session_start() in session.php using
        // session.use_strict_mode=1 to prevent session fixation attacks.
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_type'] = $user['type'];

        if ($remember) {
            self::setRememberCookie((int) $user['id']);
        }

        unset($user['password_hash'], $user['failed_login_attempts'], $user['locked_until']);
        Logger::auth('login success', ['email' => $email]);
        sendJSON(['success' => true, 'user' => $user]);
    }

    public static function signup() {
        $data = readRequestData();
        if (!is_array($data)) {
            $data = [];
        }
        if (empty($data['name']) || empty($data['email']) || empty($data['password'])) {
            sendJSON(['success' => false, 'message' => 'Name, email and password required'], 400);
        }
        $name = sanitizeString($data['name'] ?? '');
        $email = sanitizeString($data['email'] ?? '');
        $password = (string) ($data['password'] ?? '');

        $fieldErrors = [];
        if ($name === '') {
            $fieldErrors['name'] = 'Name is required';
        }
        if ($email === '' || !validateEmail($email)) {
            $fieldErrors['email'] = 'A valid email address is required';
        }
        if (!validatePasswordStrength($password)) {
            $fieldErrors['password'] = 'Password must be at least 6 characters';
        }
        if (!empty($fieldErrors)) {
            sendJSON([
                'success' => false,
                'message' => implode(' ', $fieldErrors),
                'errors' => $fieldErrors,
            ], 400);
        }
        $existingUser = User::findByEmail($email);
        if ($existingUser) {
            $role = normalizeRole($existingUser['type']);
            sendJSON(['success' => false, 'message' => 'This email is already registered as ' . $role . '. Please sign in instead.'], 409);
        }

        // Public self-signup may only create a Customer or Landlord account.
        // 'admin' is deliberately excluded here - allowing a client to pass
        // type=admin to this endpoint would let anyone self-register as an
        // administrator, which is a privilege-escalation bug, not a
        // feature. Admin accounts are only created via the seeded
        // SMART_RENT_ADMIN_* environment variables (see config/database.php)
        // or by an existing admin managing users directly.
        // 'agent' is excluded because Smart Rent has exactly three roles:
        // Admin, Landlord, Customer - there is no Agent role.
        $typeMap = [
            'customer' => 'Customer',
            'landlord' => 'Landlord',
        ];
        $requestedType = strtolower(trim((string) ($data['type'] ?? 'customer')));
        $type = $typeMap[$requestedType] ?? 'Customer';
        $id = User::create($name, $email, $data['phone'] ?? '', $password, $type);
        $user = User::findByEmail($email);
        $user['type'] = normalizeRole($user['type']);
        unset($user['password_hash'], $user['failed_login_attempts'], $user['locked_until']);
        
        // Set session data (without regeneration - see login() for details)
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_type'] = $user['type'];

        // A freshly-registered account is logged in immediately, and per the
        // "stay logged in until manual logout" requirement that login must
        // survive a browser refresh the same way a normal login does.
        self::setRememberCookie((int) $id);

        $verificationToken = AuthSecurity::createEmailVerificationToken((int) $id);
        Logger::auth('signup', ['email' => $email]);

        $response = ['success' => true, 'user' => $user];
        // Real delivery requires SMTP, which is out of scope for this pass
        // (same boundary as the SMS layer). The token is always logged to
        // auth.log; in non-production it's also returned directly so the
        // verify-email flow is testable end to end without a mail server.
        if ((getenv('APP_ENV') ?: 'development') !== 'production') {
            $response['dev_email_verification_token'] = $verificationToken;
        }
        sendJSON($response);
    }

    public static function logout() {
        $email = null;
        if (isLoggedIn()) {
            $user = getCurrentUser();
            $email = $user['email'] ?? null;
            unset($_SESSION['user_id']);
            session_regenerate_id(true);
        }
        self::clearRememberCookie();
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_destroy();
        }
        Logger::auth('logout', ['email' => $email]);
        sendJSON(['success' => true, 'message' => 'Logged out successfully']);
    }

    public static function check() {
        if (isLoggedIn()) {
            $user = getCurrentUser();
            sendJSON(['loggedIn' => true, 'user' => $user]);
        } else {
            sendJSON(['loggedIn' => false]);
        }
    }

    // --- Password reset ---------------------------------------------------

    public static function requestPasswordReset() {
        $data = readRequestData();
        $email = sanitizeString($data['email'] ?? '');
        // Always return the same generic response whether or not the email
        // exists, so this endpoint can't be used to enumerate registered
        // accounts.
        $generic = ['success' => true, 'message' => 'If that email is registered, a password reset link has been sent.'];

        if ($email === '' || !validateEmail($email)) {
            sendJSON($generic);
        }
        $user = User::findByEmail($email);
        if (!$user) {
            Logger::auth('password reset requested for unknown email', ['email' => $email]);
            sendJSON($generic);
        }

        $token = AuthSecurity::createPasswordResetToken((int) $user['id']);
        Logger::auth('password reset requested', ['email' => $email]);

        // Real delivery requires SMTP (out of scope, same boundary as SMS).
        // Token is always logged; only exposed directly in the API response
        // outside production so the flow is testable without a mail server.
        if ((getenv('APP_ENV') ?: 'development') !== 'production') {
            $generic['dev_reset_token'] = $token;
        }
        sendJSON($generic);
    }

    public static function resetPassword() {
        $data = readRequestData();
        $token = (string) ($data['token'] ?? '');
        $newPassword = (string) ($data['newPassword'] ?? '');

        if ($token === '' || !validatePasswordStrength($newPassword)) {
            sendJSON(['success' => false, 'message' => 'A valid token and a password with at least 6 characters are required'], 400);
        }

        $userId = AuthSecurity::consumePasswordResetToken($token);
        if ($userId === null) {
            sendJSON(['success' => false, 'message' => 'This reset link is invalid or has expired'], 400);
        }

        global $pdo;
        $hash = password_hash($newPassword, PASSWORD_DEFAULT);
        $pdo->prepare("UPDATE users SET password_hash = ?, failed_login_attempts = 0, locked_until = NULL WHERE id = ?")
            ->execute([$hash, $userId]);

        // A password reset should invalidate any "remember me" sessions that
        // might exist on other devices - if the account was compromised,
        // this is what actually cuts the attacker off.
        AuthSecurity::revokeAllRememberTokensForUser($userId);

        Logger::auth('password reset completed', ['user_id' => $userId]);
        sendJSON(['success' => true, 'message' => 'Password has been reset. Please log in with your new password.']);
    }

    // --- Email verification -------------------------------------------------

    public static function verifyEmail() {
        $data = readRequestData();
        $token = (string) ($data['token'] ?? ($_GET['token'] ?? ''));
        if ($token === '') {
            sendJSON(['success' => false, 'message' => 'Verification token required'], 400);
        }
        $userId = AuthSecurity::consumeEmailVerificationToken($token);
        if ($userId === null) {
            sendJSON(['success' => false, 'message' => 'This verification link is invalid or has expired'], 400);
        }
        Logger::auth('email verified', ['user_id' => $userId]);
        sendJSON(['success' => true, 'message' => 'Email verified successfully']);
    }

    public static function resendVerification() {
        requireAuth();
        $user = getCurrentUser();
        if (!$user) {
            sendJSON(['success' => false, 'message' => 'Not authenticated'], 401);
        }
        $token = AuthSecurity::createEmailVerificationToken((int) $user['id']);
        Logger::auth('resent verification email', ['email' => $user['email']]);
        $response = ['success' => true, 'message' => 'Verification email sent'];
        if ((getenv('APP_ENV') ?: 'development') !== 'production') {
            $response['dev_email_verification_token'] = $token;
        }
        sendJSON($response);
    }

    // NEW: Change password
    public static function changePassword() {
        requireAuth();
        $data = readRequestData();
        if (empty($data['currentPassword']) || empty($data['newPassword'])) {
            sendJSON(['success' => false, 'message' => 'Current and new password required'], 400);
        }
        if (!validatePasswordStrength($data['newPassword'])) {
            sendJSON(['success' => false, 'message' => 'New password must be at least 6 characters'], 400);
        }
        $user = getCurrentUser();
        if (!$user) {
            sendJSON(['success' => false, 'message' => 'User not found'], 401);
        }
        global $pdo;
        $stmt = $pdo->prepare("SELECT password_hash FROM users WHERE id = ?");
        $stmt->execute([$user['id']]);
        $row = $stmt->fetch();
        if (!$row || !password_verify($data['currentPassword'], $row['password_hash'])) {
            sendJSON(['success' => false, 'message' => 'Current password is incorrect'], 401);
        }
        $hash = password_hash($data['newPassword'], PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ?");
        if ($stmt->execute([$hash, $user['id']])) {
            AuthSecurity::revokeAllRememberTokensForUser((int) $user['id']);
            Logger::auth('password changed', ['email' => $user['email']]);
            sendJSON(['success' => true, 'message' => 'Password updated']);
        } else {
            sendJSON(['success' => false, 'message' => 'Update failed'], 500);
        }
    }

    public static function updateProfile() {
        requireAuth();
        $data = readRequestData();
        if (empty($data)) {
            sendJSON(['success' => false, 'message' => 'No data provided'], 400);
        }

        $name = trim((string) ($data['name'] ?? ''));
        $email = trim((string) ($data['email'] ?? ''));
        $phone = trim((string) ($data['phone'] ?? ''));
        if ($name === '' || $email === '') {
            sendJSON(['success' => false, 'message' => 'Name and email are required'], 400);
        }

        $user = getCurrentUser();
        if (!$user) {
            sendJSON(['success' => false, 'message' => 'User not found'], 401);
        }

        $existing = User::findByEmail($email);
        if ($existing && (int) $existing['id'] !== (int) $user['id']) {
            sendJSON(['success' => false, 'message' => 'That email is already in use'], 409);
        }

        if (!User::updateProfile($user['id'], $name, $email, $phone)) {
            sendJSON(['success' => false, 'message' => 'Profile update failed'], 500);
        }

        $updatedUser = User::findById($user['id']);
        if ($updatedUser) {
            $updatedUser['type'] = normalizeRole($updatedUser['type']);
            unset($updatedUser['password_hash']);
        }

        sendJSON(['success' => true, 'user' => $updatedUser]);
    }
}