<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../helpers/functions.php';

/**
 * Admin-only dashboard data: KPI cards + chart series, all computed
 * server-side from real MySQL rows (never hard-coded, never client-supplied).
 * Every value here comes from a query the admin is authorized to see in
 * full - no per-landlord/per-customer scoping needed since only Admin can
 * reach this controller.
 */
class AdminController
{
    private static function guard(): void
    {
        requireAuth();
        $user = getCurrentUser();
        if (!$user || normalizeRole($user['type']) !== 'Admin') {
            sendJSON(['error' => 'Forbidden - admin only'], 403);
        }
    }

    public static function dashboard(): void
    {
        self::guard();
        global $pdo;

        // --- KPI cards -------------------------------------------------
        $kpis = [
            'total_properties'   => (int) $pdo->query("SELECT COUNT(*) FROM properties")->fetchColumn(),
            'total_customers'    => (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'Customer'")->fetchColumn(),
            'total_landlords'    => (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'Landlord'")->fetchColumn(),
            'total_bookings'     => (int) $pdo->query("SELECT COUNT(*) FROM bookings")->fetchColumn(),
            'active_contracts'   => (int) $pdo->query("SELECT COUNT(*) FROM contracts WHERE status = 'ACTIVE'")->fetchColumn(),
            'total_transactions' => (int) $pdo->query("SELECT COUNT(*) FROM payments")->fetchColumn(),
            'platform_revenue'   => (float) ($pdo->query("SELECT COALESCE(SUM(commission_amount), 0) FROM payments WHERE status = 'successful'")->fetchColumn() ?: 0),
            'pending_payouts'    => (float) ($pdo->query("SELECT COALESCE(SUM(amount), 0) FROM payouts WHERE status = 'PENDING'")->fetchColumn() ?: 0),
            'pending_payouts_count' => (int) $pdo->query("SELECT COUNT(*) FROM payouts WHERE status = 'PENDING'")->fetchColumn(),
        ];

        // --- Charts ------------------------------------------------------

        // Monthly transactions (count + gross amount) for the last 6 months,
        // including months with zero activity so the chart axis is continuous.
        $months = self::lastNMonths(6);
        $txByMonth = self::indexByMonth($pdo->query(
            "SELECT DATE_FORMAT(created_at, '%Y-%m') ym, COUNT(*) cnt, COALESCE(SUM(amount),0) total
             FROM payments
             WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
             GROUP BY ym"
        )->fetchAll());
        $monthlyTransactions = array_map(function ($m) use ($txByMonth) {
            return [
                'month' => $m,
                'count' => (int) ($txByMonth[$m]['cnt'] ?? 0),
                'total' => (float) ($txByMonth[$m]['total'] ?? 0),
            ];
        }, $months);

        // Monthly platform commission (successful payments only).
        $commByMonth = self::indexByMonth($pdo->query(
            "SELECT DATE_FORMAT(created_at, '%Y-%m') ym, COALESCE(SUM(commission_amount),0) total
             FROM payments
             WHERE status = 'successful' AND created_at >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
             GROUP BY ym"
        )->fetchAll());
        $monthlyCommission = array_map(function ($m) use ($commByMonth) {
            return ['month' => $m, 'total' => (float) ($commByMonth[$m]['total'] ?? 0)];
        }, $months);

        // Monthly gross revenue (successful payments) - same grouping,
        // separate series so the frontend can chart commission vs. gross.
        $revByMonth = self::indexByMonth($pdo->query(
            "SELECT DATE_FORMAT(created_at, '%Y-%m') ym, COALESCE(SUM(amount),0) total
             FROM payments
             WHERE status = 'successful' AND created_at >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
             GROUP BY ym"
        )->fetchAll());
        $monthlyRevenue = array_map(function ($m) use ($revByMonth) {
            return ['month' => $m, 'total' => (float) ($revByMonth[$m]['total'] ?? 0)];
        }, $months);

        // Property listings by availability status.
        $propertyListings = $pdo->query(
            "SELECT availability AS status, COUNT(*) AS count FROM properties GROUP BY availability"
        )->fetchAll();

        // Bookings by status.
        $bookingsByStatus = $pdo->query(
            "SELECT status, COUNT(*) AS count FROM bookings GROUP BY status"
        )->fetchAll();

        // Payments by status (used for both the "Payment Status" chart and
        // ties directly into platform_revenue/pending_payouts above).
        $paymentsByStatus = $pdo->query(
            "SELECT status, COUNT(*) AS count, COALESCE(SUM(amount),0) AS total FROM payments GROUP BY status"
        )->fetchAll();

        // Contracts by status (covers the "Active Contracts" chart with
        // full context - active vs. draft vs. expired etc., not just a
        // single number).
        $contractsByStatus = $pdo->query(
            "SELECT status, COUNT(*) AS count FROM contracts GROUP BY status"
        )->fetchAll();

        sendJSON([
            'kpis' => $kpis,
            'charts' => [
                'monthly_transactions' => $monthlyTransactions,
                'monthly_commission'   => $monthlyCommission,
                'monthly_revenue'      => $monthlyRevenue,
                'property_listings'    => $propertyListings,
                'bookings_by_status'   => $bookingsByStatus,
                'payments_by_status'   => $paymentsByStatus,
                'contracts_by_status'  => $contractsByStatus,
            ],
        ]);
    }

    /** @return string[] e.g. ['2026-03', '2026-04', ..., '2026-08'] */
    private static function lastNMonths(int $n): array
    {
        $months = [];
        for ($i = $n - 1; $i >= 0; $i--) {
            $months[] = date('Y-m', strtotime("-$i months"));
        }
        return $months;
    }

    private static function indexByMonth(array $rows): array
    {
        $out = [];
        foreach ($rows as $row) {
            $out[$row['ym']] = $row;
        }
        return $out;
    }

    /**
     * GET admin/commission-report?range=today|week|month|year|custom&from=YYYY-MM-DD&to=YYYY-MM-DD&export=csv
     *
     * Platform Revenue Report: transaction volume, commission, landlord
     * payouts, and payment success/failure counts for a date range, plus a
     * monthly breakdown. All figures computed live from `payments`/`payouts`
     * - nothing here is cached or hard-coded.
     */
    public static function commissionReport(): void
    {
        self::guard();
        global $pdo;

        [$from, $to] = self::resolveRange(
            $_GET['range'] ?? 'month',
            $_GET['from'] ?? null,
            $_GET['to'] ?? null
        );

        $summaryStmt = $pdo->prepare(
            "SELECT
                COALESCE(SUM(amount), 0) AS total_volume,
                COALESCE(SUM(commission_amount), 0) AS total_commission,
                COALESCE(SUM(landlord_amount), 0) AS total_landlord_payable,
                SUM(CASE WHEN status = 'successful' THEN 1 ELSE 0 END) AS successful_count,
                SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) AS failed_count
             FROM payments
             WHERE status = 'successful' AND created_at BETWEEN ? AND ?"
        );
        $summaryStmt->execute([$from, $to]);
        $summary = $summaryStmt->fetch() ?: [];

        // Failed-payment count is independent of the 'successful'-only WHERE
        // above, so it needs its own query rather than reusing $summary.
        $failedStmt = $pdo->prepare("SELECT COUNT(*) FROM payments WHERE status = 'failed' AND created_at BETWEEN ? AND ?");
        $failedStmt->execute([$from, $to]);
        $failedCount = (int) $failedStmt->fetchColumn();

        $pendingPayoutsStmt = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) FROM payouts WHERE status = 'PENDING' AND created_at BETWEEN ? AND ?");
        $pendingPayoutsStmt->execute([$from, $to]);
        $pendingPayouts = (float) $pendingPayoutsStmt->fetchColumn();

        $monthlyStmt = $pdo->prepare(
            "SELECT DATE_FORMAT(created_at, '%Y-%m') AS month,
                    COALESCE(SUM(amount), 0) AS volume,
                    COALESCE(SUM(commission_amount), 0) AS commission
             FROM payments
             WHERE status = 'successful' AND created_at BETWEEN ? AND ?
             GROUP BY month ORDER BY month ASC"
        );
        $monthlyStmt->execute([$from, $to]);
        $monthlyTotals = $monthlyStmt->fetchAll();

        if (($_GET['export'] ?? '') === 'csv') {
            self::exportCommissionCsv($monthlyTotals, $from, $to);
            return;
        }

        sendJSON([
            'range' => ['from' => $from, 'to' => $to],
            'total_transaction_volume' => (float) ($summary['total_volume'] ?? 0),
            'total_platform_commission' => (float) ($summary['total_commission'] ?? 0),
            'total_landlord_payouts' => (float) ($summary['total_landlord_payable'] ?? 0),
            'pending_payouts' => $pendingPayouts,
            'successful_payments' => (int) ($summary['successful_count'] ?? 0),
            'failed_payments' => $failedCount,
            'monthly_totals' => $monthlyTotals,
        ]);
    }

    /** @return array{0: string, 1: string} [from, to] as 'Y-m-d H:i:s' bounds */
    private static function resolveRange($range, $customFrom, $customTo): array
    {
        $now = new DateTime();
        switch ($range) {
            case 'today':
                return [$now->format('Y-m-d 00:00:00'), $now->format('Y-m-d 23:59:59')];
            case 'week':
                $start = (clone $now)->modify('-6 days');
                return [$start->format('Y-m-d 00:00:00'), $now->format('Y-m-d 23:59:59')];
            case 'year':
                return [$now->format('Y-01-01 00:00:00'), $now->format('Y-12-31 23:59:59')];
            case 'custom':
                try {
                    $from = $customFrom ? (new DateTime($customFrom))->format('Y-m-d 00:00:00') : $now->format('Y-m-01 00:00:00');
                    $to = $customTo ? (new DateTime($customTo))->format('Y-m-d 23:59:59') : $now->format('Y-m-d 23:59:59');
                } catch (Exception $e) {
                    // Invalid custom date input - fall back to this month
                    // rather than letting a bad date string reach the query.
                    return [$now->format('Y-m-01 00:00:00'), $now->format('Y-m-d 23:59:59')];
                }
                return [$from, $to];
            case 'month':
            default:
                return [$now->format('Y-m-01 00:00:00'), $now->format('Y-m-d 23:59:59')];
        }
    }

    private static function exportCommissionCsv(array $rows, string $from, string $to): void
    {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="smart-rent-commission-report.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['Smart Rent Platform Revenue Report']);
        fputcsv($out, ['Range', "$from to $to"]);
        fputcsv($out, []);
        fputcsv($out, ['Month', 'Transaction Volume (TZS)', 'Platform Commission (TZS)']);
        foreach ($rows as $row) {
            fputcsv($out, [$row['month'], $row['volume'], $row['commission']]);
        }
        fclose($out);
        exit;
    }
}
