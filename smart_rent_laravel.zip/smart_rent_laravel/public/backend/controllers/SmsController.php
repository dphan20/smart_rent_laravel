<?php
require_once __DIR__ . '/../helpers/functions.php';

class SmsController {
    public static function send() {
        requireAuth();

        $data = json_decode(file_get_contents('php://input'), true) ?: [];
        $to = trim((string) ($data['to'] ?? ''));
        $message = trim((string) ($data['message'] ?? ''));
        $provider = strtolower((string) ($data['provider'] ?? 'twilio'));
        $to = self::normalizePhoneNumber($to);

        if ($to === '' || $message === '') {
            sendJSON(['error' => 'Phone number and message are required'], 400);
        }

        $result = self::dispatch($provider, $to, $message);
        if ($result['success']) {
            sendJSON([
                'success' => true,
                'provider' => $result['provider'],
                'message_id' => $result['message_id'] ?? null,
                'details' => $result['details'] ?? null,
            ]);
        }

        sendJSON(['error' => $result['error'] ?? 'Unable to send SMS'], 500);
    }

    private static function dispatch($provider, $to, $message) {
        if ($provider === 'africastalking') {
            return self::sendAfricaTalking($to, $message);
        }

        return self::sendTwilio($to, $message);
    }

    private static function normalizePhoneNumber($value) {
        $value = trim((string) $value);
        if ($value === '') return '';
        $digits = preg_replace('/[^0-9+]/', '', $value);
        if ($digits === '') return '';
        if (strpos($digits, '+') === 0) {
            return $digits;
        }
        if (strpos($digits, '255') === 0) {
            return '+' . $digits;
        }
        if (strpos($digits, '0') === 0) {
            return '+255' . substr($digits, 1);
        }
        return '+' . $digits;
    }

    private static function sendTwilio($to, $message) {
        $sid = getenv('TWILIO_ACCOUNT_SID') ?: ($_ENV['TWILIO_ACCOUNT_SID'] ?? '');
        $token = getenv('TWILIO_AUTH_TOKEN') ?: ($_ENV['TWILIO_AUTH_TOKEN'] ?? '');
        $from = getenv('TWILIO_FROM') ?: ($_ENV['TWILIO_FROM'] ?? '');

        if (!$sid || !$token || !$from) {
            return [
                'success' => false,
                'error' => 'Twilio credentials are not configured. Set TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, and TWILIO_FROM to enable real SMS delivery.',
            ];
        }

        if (!function_exists('curl_init')) {
            return [
                'success' => false,
                'error' => 'cURL is not available on this server.',
            ];
        }

        $url = "https://api.twilio.com/2010-04-01/Accounts/{$sid}/Messages.json";
        $payload = http_build_query([
            'To' => $to,
            'From' => $from,
            'Body' => $message,
        ], '', '&');

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_USERPWD, $sid . ':' . $token);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/x-www-form-urlencoded']);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($curlError) {
            return ['success' => false, 'error' => 'Twilio request failed: ' . $curlError];
        }

        $decoded = json_decode($response, true);
        if ($httpCode >= 200 && $httpCode < 300 && isset($decoded['sid'])) {
            return [
                'success' => true,
                'provider' => 'twilio',
                'message_id' => $decoded['sid'],
                'details' => $decoded,
            ];
        }

        return [
            'success' => false,
            'error' => 'Twilio rejected the SMS request: ' . ($decoded['message'] ?? $response),
        ];
    }

    private static function sendAfricaTalking($to, $message) {
        $username = getenv('AT_USERNAME') ?: ($_ENV['AT_USERNAME'] ?? '');
        $apiKey = getenv('AT_API_KEY') ?: ($_ENV['AT_API_KEY'] ?? '');
        $from = getenv('AT_FROM') ?: ($_ENV['AT_FROM'] ?? '');

        if (!$username || !$apiKey || !$from) {
            return [
                'success' => false,
                'error' => 'Africa’s Talking credentials are not configured. Set AT_USERNAME, AT_API_KEY, and AT_FROM to enable real SMS delivery.',
            ];
        }

        if (!function_exists('curl_init')) {
            return [
                'success' => false,
                'error' => 'cURL is not available on this server.',
            ];
        }

        $url = 'https://api.africastalking.com/version1/messaging';
        $payload = json_encode([
            'username' => $username,
            'to' => $to,
            'message' => $message,
            'from' => $from,
        ]);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Accept: application/json',
            'apiKey: ' . $apiKey,
        ]);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($curlError) {
            return ['success' => false, 'error' => 'Africa’s Talking request failed: ' . $curlError];
        }

        $decoded = json_decode($response, true);
        if ($httpCode >= 200 && $httpCode < 300) {
            return [
                'success' => true,
                'provider' => 'africastalking',
                'message_id' => $decoded['SMSMessageData']['Recipients'][0]['messageId'] ?? null,
                'details' => $decoded,
            ];
        }

        return [
            'success' => false,
            'error' => 'Africa’s Talking rejected the SMS request: ' . ($decoded['errorMessage'] ?? $response),
        ];
    }
}
