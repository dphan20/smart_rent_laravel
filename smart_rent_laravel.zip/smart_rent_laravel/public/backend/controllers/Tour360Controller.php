<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../helpers/functions.php';
require_once __DIR__ . '/../helpers/UploadSecurity.php';
require_once __DIR__ . '/../models/Tour360.php';

class Tour360Controller
{
    /**
     * GET /tours?listing_type=room&listing_id=5
     * Public — customers viewing a property need this with no login,
     * same as RoomController::getAll()/getOne(). Returns every scene for
     * the listing with its hotspots embedded, ready for the frontend's
     * Pannellum multi-scene config.
     */
    public static function listForListing()
    {
        $listingType = $_GET['listing_type'] ?? '';
        $listingId = $_GET['listing_id'] ?? '';
        if (!in_array($listingType, ['room', 'property'], true) || !$listingId) {
            sendJSON(['error' => 'listing_type (room|property) and listing_id are required'], 400);
        }
        $scenes = Tour360::fullTourForListing($listingType, (int) $listingId);
        sendJSON(['scenes' => $scenes]);
    }

    /**
     * GET /tours/{id} — one scene with its hotspots. Public.
     */
    public static function getOne($id)
    {
        $tour = Tour360::find($id);
        if (!$tour) {
            sendJSON(['error' => 'Not found'], 404);
        }
        $tour['hotspots'] = Tour360::hotspotsForTour($id);
        sendJSON($tour);
    }

    /**
     * POST /tours — multipart form: listing_type, listing_id, name,
     * description?, image (file). Admin or the owning Landlord only.
     */
    public static function createScene()
    {
        requireAuth();
        $user = getCurrentUser();

        $listingType = $_POST['listing_type'] ?? '';
        $listingId = $_POST['listing_id'] ?? '';
        $name = trim((string) ($_POST['name'] ?? ''));

        if (!in_array($listingType, ['room', 'property'], true) || !$listingId || $name === '') {
            sendJSON(['error' => 'listing_type, listing_id and name are required'], 400);
        }

        if (!Tour360::userCanManageListing($user, $listingType, (int) $listingId)) {
            sendJSON(['error' => 'Forbidden — you do not manage this listing'], 403);
        }

        $imageFile = $_FILES['image'] ?? null;
        if (!$imageFile || ($imageFile['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            sendJSON(['error' => 'A panorama image is required'], 400);
        }

        $uploadsDir = getenv('SMART_RENT_UPLOADS_DIR') ?: (__DIR__ . '/../../uploads');
        if (!is_dir($uploadsDir)) {
            mkdir($uploadsDir, 0755, true);
        }
        $result = UploadSecurity::validateAndStore($imageFile, $uploadsDir, 'tour360');
        if (!$result['ok']) {
            sendJSON(['error' => $result['error']], 400);
        }

        $id = Tour360::createScene([
            'listing_type' => $listingType,
            'listing_id' => (int) $listingId,
            'name' => $name,
            'image' => $result['path'],
            'description' => $_POST['description'] ?? null,
            'is_primary' => !empty($_POST['is_primary']),
            'created_by' => $user['id'],
        ]);

        sendJSON(['success' => true, 'id' => $id]);
    }

    /**
     * PUT /tours/{id} — update name/description/is_primary. Does not
     * replace the image (re-upload as a new scene instead, to avoid
     * silently invalidating an editor session mid-edit).
     */
    public static function updateScene($id)
    {
        requireAuth();
        $user = getCurrentUser();
        $tour = Tour360::find($id);
        if (!$tour) {
            sendJSON(['error' => 'Not found'], 404);
        }
        if (!Tour360::userCanManageListing($user, $tour['listing_type'], $tour['listing_id'])) {
            sendJSON(['error' => 'Forbidden'], 403);
        }

        $data = readRequestData();
        Tour360::updateScene($id, $data);
        sendJSON(['success' => true]);
    }

    /**
     * DELETE /tours/{id}
     */
    public static function deleteScene($id)
    {
        requireAuth();
        $user = getCurrentUser();
        $tour = Tour360::find($id);
        if (!$tour) {
            sendJSON(['error' => 'Not found'], 404);
        }
        if (!Tour360::userCanManageListing($user, $tour['listing_type'], $tour['listing_id'])) {
            sendJSON(['error' => 'Forbidden'], 403);
        }

        Tour360::deleteScene($id);

        // If the deleted scene was primary, promote whatever scene is left
        // so the listing still has a sensible starting point.
        $remaining = Tour360::scenesForListing($tour['listing_type'], $tour['listing_id']);
        if (!empty($remaining) && !array_filter($remaining, fn ($s) => $s['is_primary']) ) {
            Tour360::updateScene($remaining[0]['id'], ['is_primary' => true]);
        }

        sendJSON(['success' => true]);
    }

    /**
     * POST /tours/{tourId}/hotspots — body: type, yaw, pitch, title?,
     * description?, target_tour_id? (required if type=navigation).
     */
    public static function createHotspot($tourId)
    {
        requireAuth();
        $user = getCurrentUser();
        $tour = Tour360::find($tourId);
        if (!$tour) {
            sendJSON(['error' => 'Scene not found'], 404);
        }
        if (!Tour360::userCanManageListing($user, $tour['listing_type'], $tour['listing_id'])) {
            sendJSON(['error' => 'Forbidden'], 403);
        }

        $data = readRequestData();
        if (!isset($data['yaw']) || !isset($data['pitch'])) {
            sendJSON(['error' => 'yaw and pitch are required'], 400);
        }
        $rawType = $data['type'] ?? 'info';
        $type = in_array($rawType, ['navigation', 'viewpoint'], true) ? $rawType : 'info';

        if ($type === 'navigation') {
            if (empty($data['target_tour_id'])) {
                sendJSON(['error' => 'target_tour_id is required for navigation hotspots'], 400);
            }
            $target = Tour360::find($data['target_tour_id']);
            if (!$target || $target['listing_type'] !== $tour['listing_type'] || (int) $target['listing_id'] !== (int) $tour['listing_id']) {
                sendJSON(['error' => 'target_tour_id must be another scene of the same listing'], 400);
            }
        } elseif ($type === 'viewpoint') {
            // A viewpoint hotspot re-orients the viewer within THIS SAME
            // panorama - it needs its own target yaw/pitch (where the
            // viewer should look), not a target_tour_id.
            if (!isset($data['target_yaw']) || !isset($data['target_pitch']) || $data['target_yaw'] === '' || $data['target_pitch'] === '') {
                sendJSON(['error' => 'target_yaw and target_pitch are required for viewpoint hotspots'], 400);
            }
        }

        $id = Tour360::createHotspot([
            'tour_id' => $tourId,
            'target_tour_id' => $data['target_tour_id'] ?? null,
            'target_yaw' => $data['target_yaw'] ?? null,
            'target_pitch' => $data['target_pitch'] ?? null,
            'target_hfov' => $data['target_hfov'] ?? null,
            'type' => $type,
            'yaw' => $data['yaw'],
            'pitch' => $data['pitch'],
            'title' => $data['title'] ?? null,
            'description' => $data['description'] ?? null,
        ]);

        sendJSON(['success' => true, 'id' => $id]);
    }

    /**
     * PUT /tours/hotspot/{hotspotId}
     */
    public static function updateHotspot($hotspotId)
    {
        requireAuth();
        $user = getCurrentUser();
        $hotspot = Tour360::findHotspot($hotspotId);
        if (!$hotspot) {
            sendJSON(['error' => 'Not found'], 404);
        }
        $tour = Tour360::find($hotspot['tour_id']);
        if (!$tour || !Tour360::userCanManageListing($user, $tour['listing_type'], $tour['listing_id'])) {
            sendJSON(['error' => 'Forbidden'], 403);
        }

        $data = readRequestData();

        // Same server-side rules as createHotspot(): a navigation hotspot
        // must target another scene of the same listing, a viewpoint
        // hotspot must carry its own target yaw/pitch. Only enforced when
        // the caller is actually changing to that type, so partial updates
        // (e.g. just editing the title) aren't blocked by unrelated fields.
        if (($data['type'] ?? null) === 'navigation') {
            if (empty($data['target_tour_id'])) {
                sendJSON(['error' => 'target_tour_id is required for navigation hotspots'], 400);
            }
            $target = Tour360::find($data['target_tour_id']);
            if (!$target || $target['listing_type'] !== $tour['listing_type'] || (int) $target['listing_id'] !== (int) $tour['listing_id']) {
                sendJSON(['error' => 'target_tour_id must be another scene of the same listing'], 400);
            }
        } elseif (($data['type'] ?? null) === 'viewpoint') {
            if (!isset($data['target_yaw']) || !isset($data['target_pitch']) || $data['target_yaw'] === '' || $data['target_pitch'] === '') {
                sendJSON(['error' => 'target_yaw and target_pitch are required for viewpoint hotspots'], 400);
            }
        }

        Tour360::updateHotspot($hotspotId, $data);
        sendJSON(['success' => true]);
    }

    /**
     * DELETE /tours/hotspot/{hotspotId}
     */
    public static function deleteHotspot($hotspotId)
    {
        requireAuth();
        $user = getCurrentUser();
        $hotspot = Tour360::findHotspot($hotspotId);
        if (!$hotspot) {
            sendJSON(['error' => 'Not found'], 404);
        }
        $tour = Tour360::find($hotspot['tour_id']);
        if (!$tour || !Tour360::userCanManageListing($user, $tour['listing_type'], $tour['listing_id'])) {
            sendJSON(['error' => 'Forbidden'], 403);
        }

        Tour360::deleteHotspot($hotspotId);
        sendJSON(['success' => true]);
    }
}
