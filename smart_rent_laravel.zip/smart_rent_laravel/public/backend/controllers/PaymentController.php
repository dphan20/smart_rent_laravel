<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../helpers/functions.php';
require_once __DIR__ . '/../helpers/CommissionService.php';
require_once __DIR__ . '/../helpers/Logger.php';
require_once __DIR__ . '/../models/Payment.php';

class PaymentController {
    public static function getAll() {
        $user = getCurrentUser();
        $payments = [];
        if (!$user) {
            sendJSON([]);
            return;
        }
        $filters = [];
        if (normalizeRole($user['type']) === 'Admin') {
            // no filters
        } elseif (normalizeRole($user['type']) === 'Landlord') {
            $filters['landlord_id'] = $user['id'];
        } else {
            $filters['user_id'] = $user['id'];
        }
        $payments = Payment::getAll($filters);
        sendJSON($payments);
    }

    public static function create() {
        requireAuth();
        $data = json_decode(file_get_contents('php://input'), true);
        if (empty($data['amount']) || empty($data['payment_method']) || empty($data['reference'])) {
            sendJSON(['error' => 'Missing required fields'], 400);
        }
        $user = getCurrentUser();
        if ($user) {
            $data['user_id'] = $user['id'];
            if (empty($data['customer_name'])) $data['customer_name'] = $user['name'];
            if (empty($data['customer_email'])) $data['customer_email'] = $user['email'];
            if (empty($data['customer_phone'])) $data['customer_phone'] = $user['phone'];
        }
        if (!empty($data['booking_id'])) {
            global $pdo;
            $bookingStmt = $pdo->prepare("SELECT b.user_id, b.rental_mode, c.status AS contract_status FROM bookings b LEFT JOIN contracts c ON c.booking_id = b.id WHERE b.id = ? LIMIT 1");
            $bookingStmt->execute([$data['booking_id']]);
            $booking = $bookingStmt->fetch();
            if (!$booking || (int) $booking['user_id'] !== (int) ($user['id'] ?? 0)) {
                sendJSON(['error' => 'Booking not found'], 404);
            }
            if (($booking['rental_mode'] ?? 'holiday') === 'rent' && $booking['contract_status'] !== 'ACTIVE') {
                sendJSON(['error' => 'Payment is locked until both customer and landlord approve the rental contract'], 409);
            }
        } elseif (!empty($data['room_id'])) {
            global $pdo;
            $modeStmt = $pdo->prepare("SELECT rental_mode FROM rooms WHERE id = ? LIMIT 1");
            $modeStmt->execute([$data['room_id']]);
            if (($modeStmt->fetchColumn() ?: 'holiday') === 'rent') {
                sendJSON(['error' => 'Rent payments must use a booking with an approved contract'], 409);
            }
        }
        if (empty($data['landlord_id']) && !empty($data['room_id'])) {
            global $pdo;
            $stmt = $pdo->prepare("SELECT landlord_id FROM rooms WHERE id = ?");
            $stmt->execute([$data['room_id']]);
            $room = $stmt->fetch();
            if ($room) {
                $data['landlord_id'] = $room['landlord_id'];
            }
        }

        // Commission is ALWAYS computed here from the admin-configured rate.
        // Any commission_rate/commission_amount/landlord_amount the client
        // sent in the request body is discarded and ignored below - a
        // client must never be able to set its own commission split.
        $commission = CommissionService::calculate((float) $data['amount']);
        $data['commission_rate'] = $commission['rate'];
        $data['commission_amount'] = $commission['commission'];
        $data['landlord_amount'] = $commission['landlord_amount'];

        // This endpoint has no real payment-gateway verification behind it
        // yet (see backend/controllers/ — no webhook handler exists). A
        // client submitting a reference number is not proof a payment
        // actually happened, so we never trust a client-supplied "status"
        // here and always record it as pending. Only the internal,
        // server-driven booking flow (BookingController::create) is allowed
        // to record a payment as already successful, because it computes
        // and stores that status itself server-side rather than accepting
        // it from this endpoint.
        $data['status'] = 'pending';

        $id = Payment::create($data);
        Logger::api('payment recorded as pending (awaiting verification)', [
            'payment_id' => $id,
            'amount' => $data['amount'],
            'reference' => $data['reference'],
        ]);
        sendJSON(['success' => true, 'id' => $id, 'status' => 'pending', 'message' => 'Payment recorded and is pending verification.']);
    }

    public static function delete($id) {
        requireAuth();
        $user = getCurrentUser();
        $payment = Payment::findById($id);
        if (!$payment) {
            sendJSON(['error' => 'Payment not found'], 404);
            return;
        }
        $role = normalizeRole($user['type'] ?? '');
        $isOwner = (int) ($payment['user_id'] ?? 0) === (int) $user['id'];
        $isLandlordOfBooking = $role === 'Landlord' && (int) ($payment['landlord_id'] ?? 0) === (int) $user['id'];
        if ($role !== 'Admin' && !$isOwner && !$isLandlordOfBooking) {
            sendJSON(['error' => 'You can only delete your own payment records'], 403);
            return;
        }
        if (Payment::delete($id)) {
            sendJSON(['success' => true]);
        } else {
            sendJSON(['error' => 'Delete failed'], 500);
        }
    }

    /**
     * Admin-only: confirm or reject a pending payment that was recorded
     * through the public /payments endpoint (which never trusts a client's
     * own "successful" claim - see create() above). This is a manual
     * stand-in for real payment-gateway verification: an admin checks the
     * reference against the actual mobile money / bank statement and
     * confirms it here. Moving a payment to 'successful' creates the
     * matching landlord payout, exactly like the automated booking flow
     * does, so both paths end up in the same consistent state.
     */
    public static function verify($id) {
        requireAuth();
        $user = getCurrentUser();
        if (normalizeRole($user['type'] ?? '') !== 'Admin') {
            sendJSON(['error' => 'Only an admin can verify a payment'], 403);
            return;
        }

        $payment = Payment::findById($id);
        if (!$payment) {
            sendJSON(['error' => 'Payment not found'], 404);
            return;
        }
        if ($payment['status'] !== 'pending') {
            sendJSON(['error' => 'Only a pending payment can be verified'], 409);
            return;
        }

        $data = readRequestData();
        $status = strtolower(trim((string) ($data['status'] ?? '')));
        if (!in_array($status, ['successful', 'failed'], true)) {
            sendJSON(['error' => 'status must be "successful" or "failed"'], 400);
            return;
        }

        if (!Payment::updateStatus($id, $status)) {
            sendJSON(['error' => 'Failed to update payment status'], 500);
            return;
        }

        // Move the associated booking/room forward now that payment has
        // genuinely been confirmed (or rejected) - never before this point.
        require_once __DIR__ . '/../models/Booking.php';
        Booking::syncFromPaymentStatus($payment['booking_id'] ?? null, $status);

        if ($status === 'successful' && !empty($payment['landlord_id'])) {
            require_once __DIR__ . '/../models/Payout.php';
            Payout::create([
                'landlord_id' => $payment['landlord_id'],
                'payment_id' => $id,
                'amount' => $payment['landlord_amount'] ?? 0,
                'status' => 'PENDING',
            ]);
        }

        Logger::api('payment verified', ['payment_id' => $id, 'status' => $status, 'by' => $user['email']]);
        sendJSON(['success' => true, 'status' => $status]);
    }

    /**
     * Payment-provider webhook. No requireAuth()/CSRF - the caller here is
     * a payment gateway's server, not a logged-in browser session, so trust
     * is established entirely by PaymentService::verifyWebhookSignature()
     * instead. This intentionally mirrors verify()'s status-transition and
     * payout-creation logic rather than calling into verify() directly, so
     * that method (already covered by tests/Integration/PaymentOwnershipTest.php)
     * is left completely untouched.
     *
     * A customer cannot use this to mark their own payment successful:
     * nothing here trusts the request body until the signature check
     * passes, and the signature check fails closed when unconfigured.
     */
    public static function webhook() {
        $rawBody = file_get_contents('php://input');
        $data = json_decode($rawBody, true);
        if (!is_array($data) || empty($data['reference']) || empty($data['status'])) {
            Logger::api('webhook rejected: malformed payload', []);
            sendJSON(['error' => 'Malformed webhook payload'], 400);
            return;
        }

        $payment = Payment::findByReference((string) $data['reference']);
        if (!$payment) {
            Logger::api('webhook rejected: unknown reference', ['reference' => $data['reference']]);
            sendJSON(['error' => 'Unknown payment reference'], 404);
            return;
        }

        require_once __DIR__ . '/../services/PaymentService.php';
        $headers = function_exists('getallheaders') ? (getallheaders() ?: []) : [];
        if (!PaymentService::verifyWebhookSignature($rawBody, $headers, (string) $payment['payment_method'])) {
            Logger::api('webhook rejected: invalid signature', ['payment_id' => $payment['id']]);
            sendJSON(['error' => 'Invalid or missing webhook signature'], 401);
            return;
        }

        // Only a still-pending payment can be moved by a webhook - same
        // rule as the admin verify() path, and it makes a replayed/duplicate
        // webhook call a safe no-op instead of double-processing a payout.
        if ($payment['status'] !== 'pending') {
            sendJSON(['success' => true, 'message' => 'Payment already in a final state; no action taken.']);
            return;
        }

        $status = strtolower(trim((string) $data['status']));
        if (!in_array($status, ['successful', 'failed'], true)) {
            sendJSON(['error' => 'status must be "successful" or "failed"'], 400);
            return;
        }

        if (!Payment::updateStatus($payment['id'], $status)) {
            sendJSON(['error' => 'Failed to update payment status'], 500);
            return;
        }

        require_once __DIR__ . '/../models/Booking.php';
        Booking::syncFromPaymentStatus($payment['booking_id'] ?? null, $status);

        if ($status === 'successful' && !empty($payment['landlord_id'])) {
            require_once __DIR__ . '/../models/Payout.php';
            Payout::create([
                'landlord_id' => $payment['landlord_id'],
                'payment_id' => $payment['id'],
                'amount' => $payment['landlord_amount'] ?? 0,
                'status' => 'PENDING',
            ]);
        }

        Logger::api('payment confirmed via webhook', [
            'payment_id' => $payment['id'],
            'status' => $status,
            'payment_method' => $payment['payment_method'],
        ]);
        sendJSON(['success' => true, 'status' => $status]);
    }
}