<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../helpers/functions.php';
require_once __DIR__ . '/../models/Message.php';

class MessageController {
    public static function getAll() {
        requireAuth();
        requireRole('Admin');
        $messages = Message::getAll();
        sendJSON($messages);
    }

    // The logged-in customer's own messages + any admin replies. The
    // email comes from the authenticated session (getCurrentUser), never
    // from client input, so a customer can only ever see their own
    // messages regardless of what they pass in the request.
    public static function mine() {
        requireAuth();
        $user = getCurrentUser();
        $messages = Message::findByEmail($user['email']);
        sendJSON($messages);
    }

    public static function create() {
        $data = json_decode(file_get_contents('php://input'), true);
        if (empty($data['name']) || empty($data['email']) || empty($data['phone']) || empty($data['message'])) {
            sendJSON(['error' => 'All fields required'], 400);
        }
        $id = Message::create($data);
        sendJSON(['success' => true, 'id' => $id]);
    }

    public static function reply($id) {
        requireAuth();
        requireRole('Admin');

        $data = json_decode(file_get_contents('php://input'), true);
        $replyText = trim($data['reply'] ?? '');
        if ($replyText === '') {
            sendJSON(['error' => 'Reply text is required'], 400);
        }

        $message = Message::find($id);
        if (!$message) {
            sendJSON(['error' => 'Message not found'], 404);
        }

        Message::reply($id, $replyText);

        // Best-effort email to the sender. On a default XAMPP install with
        // no sendmail_path/SMTP configured this returns false and the
        // sender will NOT actually receive it - the reply is still saved
        // and visible in the admin panel either way.
        $subject = 'Reply from Smart Rent';
        $body = "Hello {$message['name']},\n\nYou messaged us:\n\"{$message['message']}\"\n\nOur reply:\n{$replyText}\n\n- Smart Rent Team";
        $headers = "From: no-reply@smartrent.local\r\nContent-Type: text/plain; charset=UTF-8";
        $emailSent = @mail($message['email'], $subject, $body, $headers);

        sendJSON(['success' => true, 'email_sent' => $emailSent]);
    }
}
?>