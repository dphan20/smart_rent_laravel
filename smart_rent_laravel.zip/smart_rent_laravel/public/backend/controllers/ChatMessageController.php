<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../helpers/functions.php';
require_once __DIR__ . '/../models/ChatMessage.php';

class ChatMessageController {
    public static function conversations() {
        requireAuth();
        $user = getCurrentUser();
        sendJSON(ChatMessage::conversationsFor($user['id']));
    }

    public static function contacts() {
        requireAuth();
        $user = getCurrentUser();
        sendJSON(ChatMessage::allowedContactsFor($user['id'], $user['type']));
    }

    public static function thread($otherId) {
        requireAuth();
        $user = getCurrentUser();
        $otherId = (int) $otherId;
        if ($otherId <= 0) sendJSON(['error' => 'Invalid conversation'], 400);
        $messages = ChatMessage::threadBetween($user['id'], $otherId);
        ChatMessage::markRead($user['id'], $otherId);
        sendJSON($messages);
    }

    public static function send() {
        requireAuth();
        $user = getCurrentUser();
        $data = json_decode(file_get_contents('php://input'), true);

        $receiverId = (int) ($data['receiver_id'] ?? 0);
        $body = trim((string) ($data['message'] ?? ''));
        $listingType = $data['listing_type'] ?? null;
        $listingId = isset($data['listing_id']) ? (int) $data['listing_id'] : null;

        if ($receiverId <= 0 || $body === '') {
            sendJSON(['error' => 'receiver_id and message are required'], 400);
        }
        if ($receiverId === (int) $user['id']) {
            sendJSON(['error' => 'Cannot message yourself'], 400);
        }
        if (!ChatMessage::canMessage($user['id'], $user['type'], $receiverId)) {
            sendJSON(['error' => 'Customers and landlords can only message Admin'], 403);
        }

        $id = ChatMessage::send($user['id'], $receiverId, $body, $listingType, $listingId);
        sendJSON(['success' => true, 'id' => $id]);
    }
}
?>
