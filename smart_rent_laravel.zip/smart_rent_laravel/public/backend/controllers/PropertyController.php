<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../helpers/functions.php';
require_once __DIR__ . '/../helpers/UploadSecurity.php';
require_once __DIR__ . '/../models/Property.php';
require_once __DIR__ . '/../models/Room.php';
require_once __DIR__ . '/../helpers/ListingIdGenerator.php';

class PropertyController {
    public static function getAll() {
        $user = getCurrentUser();
        $landlordId = $_GET['landlord_id'] ?? null;
        if ($user && normalizeRole($user['type']) === 'Landlord') {
            $landlordId = $user['id'];
        }
        $houseId = $_GET['house_id'] ?? null;
        $sri = $_GET['sri'] ?? null;
        $props = Property::getAll($landlordId, $houseId, $sri);
        sendJSON($props);
    }

    public static function getBySri($sri) {
        $property = Property::findBySri($sri);
        if (!$property) {
            sendJSON(['error' => 'Not found'], 404);
        }
        $user = getCurrentUser();
        if ($user && normalizeRole($user['type']) === 'Landlord' && (int) $property['landlord_id'] !== (int) $user['id']) {
            sendJSON(['error' => 'Forbidden'], 403);
        }
        sendJSON($property);
    }

    /**
     * GET /properties/{id} — a single property by its row id. This was
     * missing entirely, so the router fell back to calling getAll() for
     * every GET on this resource regardless of whether an id was present
     * in the URL — meaning "get property #15" silently returned the full
     * property list instead. The app expected one JSON object back and
     * crashed trying to cast that list to a map the moment anyone opened
     * a property's details (landlord or customer, tapping any property's
     * photo/card) with: "type 'List<dynamic>' is not a subtype of type
     * 'Map<dynamic, dynamic>'".
     */
    public static function getOne($id) {
        $property = Property::find($id);
        if (!$property) {
            sendJSON(['error' => 'Not found'], 404);
        }
        $user = getCurrentUser();
        if ($user && normalizeRole($user['type']) === 'Landlord' && (int) $property['landlord_id'] !== (int) $user['id']) {
            sendJSON(['error' => 'Forbidden'], 403);
        }
        sendJSON($property);
    }

    public static function create() {
        requireAuth();
        requireRole('Landlord');

        // --- 1. Get form data ---
        $data = $_POST;
        $data['landlord_id'] = $_SESSION['user_id'];

        // --- 2. Handle image uploads ---
        // backend/ and public/ are siblings under the same project root -
        // see RoomController::create() for the full explanation.
        $uploadsDir = getenv('SMART_RENT_UPLOADS_DIR') ?: (__DIR__ . '/../../uploads');
        // Ensure the directory exists and is writable
        if (!is_dir($uploadsDir)) {
            if (!mkdir($uploadsDir, 0755, true)) {
                sendJSON(['error' => 'Failed to create uploads directory.'], 500);
            }
        }
        if (!is_writable($uploadsDir)) {
            sendJSON(['error' => 'Uploads directory is not writable. Please chmod 755 on "' . $uploadsDir . '".'], 500);
        }

        // Check if any files were uploaded
        if (!isset($_FILES['images']) || empty($_FILES['images']['tmp_name'][0])) {
            sendJSON(['error' => 'No images were uploaded.'], 400);
        }

        $imageFilenames = [];
        foreach ($_FILES['images']['tmp_name'] as $index => $tmp) {
            $fileEntry = [
                'tmp_name' => $tmp,
                'error'    => $_FILES['images']['error'][$index] ?? UPLOAD_ERR_NO_FILE,
                'size'     => $_FILES['images']['size'][$index] ?? 0,
            ];
            $result = UploadSecurity::validateAndStore($fileEntry, $uploadsDir, 'property');
            if (!$result['ok']) {
                // Roll back anything already saved earlier in this same
                // request before rejecting, so a bad file later in the
                // batch doesn't leave earlier ones orphaned on disk.
                foreach ($imageFilenames as $rel) {
                    $abs = __DIR__ . '/../../' . $rel;
                    if (is_file($abs)) @unlink($abs);
                }
                sendJSON(['error' => $result['error']], 400);
            }
            $imageFilenames[] = $result['path'];
        }

        if (empty($imageFilenames)) {
            sendJSON(['error' => 'No images were successfully saved.'], 500);
        }

        // --- 3. Save property ---
        $data['images'] = json_encode($imageFilenames);

        // Automatic, permanent identifiers - generated once here so the same
        // values can be shared with the room this property spawns below.
        // Never accepted from the request.
        global $pdo;
        $houseId = ListingIdGenerator::generate($pdo, 'properties', $data['region'] ?? '', $data['district'] ?? '');
        $sri = ListingIdGenerator::generateSri($pdo, $data['region'] ?? '', $data['district'] ?? '');
        $data['house_id'] = $houseId;
        $data['sri'] = $sri;
        $data = normalizeRentalMode($data);
        if (!in_array($data['rental_mode'], ['rent', 'holiday'], true)) {
            sendJSON(['error' => 'rental_mode must be rent or holiday'], 400);
        }

        // Optional 360° virtual tour: either an uploaded panorama image
        // (preferred - validated exactly like property photos) or a pasted
        // external tour URL (e.g. a Matterport/Kuula link) typed into the
        // virtualTour text field. An uploaded file always takes priority
        // over a pasted URL if both are somehow provided.
        if (isset($_FILES['virtualTourImage']) && ($_FILES['virtualTourImage']['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_OK) {
            $tourResult = UploadSecurity::validateAndStore($_FILES['virtualTourImage'], $uploadsDir, 'tour');
            if (!$tourResult['ok']) {
                foreach ($imageFilenames as $rel) {
                    $abs = __DIR__ . '/../../' . $rel;
                    if (is_file($abs)) @unlink($abs);
                }
                sendJSON(['error' => '360° tour image: ' . $tourResult['error']], 400);
            }
            $data['virtualTour'] = $tourResult['path'];
        } elseif (!empty($data['virtualTour'])) {
            $url = trim((string) $data['virtualTour']);
            // A pasted URL must actually be an absolute http(s) URL - reject
            // anything else rather than silently storing garbage that would
            // later render as a broken tour button.
            $data['virtualTour'] = (filter_var($url, FILTER_VALIDATE_URL) && preg_match('/^https?:\/\//i', $url)) ? $url : null;
        }
        // NOTE: 'amenities' arrives from the frontend as a JSON string
        // (fd.append('amenities', JSON.stringify({...}))) and the DB column
        // is TEXT, so it must stay a string. Do NOT json_decode it here —
        // binding a PHP array as a single PDO parameter throws an uncaught
        // PDOException (PDO::ATTR_ERRMODE = ERRMODE_EXCEPTION), which used
        // to kill the request AFTER the image was already saved to disk but
        // BEFORE the property/room rows were inserted. That's why images
        // showed up in the uploads/ folder but never in the DB or frontend.
        if (!isset($data['amenities']) || $data['amenities'] === '') {
            $data['amenities'] = json_encode([]);
        }

        try {
            $propertyId = Property::create($data);
        } catch (Throwable $e) {
            // Roll back the files we just saved so we don't leave orphaned
            // uploads behind when the DB insert fails.
            foreach ($imageFilenames as $rel) {
                $abs = __DIR__ . '/../../' . $rel;
                if (is_file($abs)) {
                    @unlink($abs);
                }
            }
            error_log('Property::create failed: ' . $e->getMessage());
            sendJSON(['error' => 'Failed to save property: ' . $e->getMessage()], 500);
        }

        // --- 4. Create corresponding room ---
        $roomData = [
            'title'       => $data['name'],
            'location'    => $data['region'] . ', ' . $data['district'] . (isset($data['ward']) ? ', ' . $data['ward'] : '') . (isset($data['street']) ? ', ' . $data['street'] : ''),
            'area'        => $data['district'],
            'price'       => $data['monthlyRent'],
            'size'        => $data['roomSize'],
            'type'        => $data['type'] ?? 'Apartment',
            'rental_mode' => $data['rental_mode'],
            'listing_purpose' => $data['listing_purpose'],
            'beds'        => $data['bedrooms'] ?? 1,
            'badge'       => '',
            'status'      => $data['availability'] ?? 'available',
            // Full gallery, not just the first image - so the room (the
            // entity customers actually browse/book) carries every photo,
            // not only a single cover shot. Stored as a JSON array, same
            // convention properties.images already uses.
            'image'       => json_encode($imageFilenames),
            'landlord_id' => $_SESSION['user_id'],
            'virtual_tour' => $data['virtualTour'] ?? null,
            // Same House ID as the parent property, so the gallery/tour/
            // booking/payment for this listing all resolve to one identity.
            'house_id'    => $houseId,
        ];

        // Log the image paths for debugging
        error_log("Saving room images: " . $roomData['image']);

        try {
            $roomId = Room::create($roomData);
        } catch (Throwable $e) {
            // The property row was already saved successfully at this point,
            // so we don't roll back the files/property — just report the
            // room-creation failure clearly instead of a blank 500.
            error_log('Room::create failed: ' . $e->getMessage());
            sendJSON(['error' => 'Property saved, but failed to create the room listing: ' . $e->getMessage()], 500);
        }

        sendJSON(['success' => true, 'property_id' => $propertyId, 'room_id' => $roomId, 'house_id' => $houseId, 'sri' => $sri, 'image' => $roomData['image']]);
    }

    public static function delete($id) {
        requireAuth();
        requireRole('Landlord');
        $user = getCurrentUser();
        $property = Property::find($id);
        if (!$property || (int)$property['landlord_id'] !== (int)$user['id']) {
            sendJSON(['error' => 'You can only delete your own properties'], 403);
        }
        if (Property::delete($id)) {
            sendJSON(['success' => true]);
        } else {
            sendJSON(['error' => 'Delete failed'], 500);
        }
    }

    /** Admin, or the Landlord who owns this property - never anyone else. */
    private static function authorizePropertyManagement($id) {
        requireAuth();
        $user = getCurrentUser();
        $property = Property::find($id);
        if (!$property) {
            sendJSON(['error' => 'Not found'], 404);
        }
        $role = normalizeRole($user['type'] ?? '');
        if ($role === 'Admin') {
            return $property;
        }
        if ($role === 'Landlord' && (int) $property['landlord_id'] === (int) $user['id']) {
            return $property;
        }
        sendJSON(['error' => 'Forbidden - only Admin or the owning Landlord can manage this property\'s images'], 403);
    }

    /**
     * POST /properties/{id}/images (multipart, field name "images[]" or
     * "images") - appends one or more new photos to this property's
     * existing gallery without disturbing the images already there. This
     * is the direct, property-native equivalent of RoomController::addImages()
     * - it needs no house_id/room matching at all, since it works straight
     * off the property's own id.
     */
    public static function addImages($id) {
        $property = self::authorizePropertyManagement($id);

        $files = $_FILES['images'] ?? null;
        if (!$files || empty($files['tmp_name'][0])) {
            // Also accept a single-file field name for convenience.
            $files = isset($_FILES['image']) ? [
                'tmp_name' => [$_FILES['image']['tmp_name'] ?? null],
                'error'    => [$_FILES['image']['error'] ?? UPLOAD_ERR_NO_FILE],
                'size'     => [$_FILES['image']['size'] ?? 0],
            ] : null;
        }
        if (!$files || empty($files['tmp_name'][0])) {
            sendJSON(['error' => 'No images were uploaded.'], 400);
        }

        $uploadsDir = getenv('SMART_RENT_UPLOADS_DIR') ?: (__DIR__ . '/../../uploads');
        if (!is_dir($uploadsDir)) {
            mkdir($uploadsDir, 0755, true);
        }

        $newPaths = [];
        foreach ($files['tmp_name'] as $index => $tmp) {
            $fileEntry = [
                'tmp_name' => $tmp,
                'error'    => $files['error'][$index] ?? UPLOAD_ERR_NO_FILE,
                'size'     => $files['size'][$index] ?? 0,
            ];
            $result = UploadSecurity::validateAndStore($fileEntry, $uploadsDir, 'property');
            if (!$result['ok']) {
                foreach ($newPaths as $rel) {
                    $abs = __DIR__ . '/../../' . $rel;
                    if (is_file($abs)) @unlink($abs);
                }
                sendJSON(['error' => $result['error']], 400);
            }
            $newPaths[] = $result['path'];
        }

        $existing = Property::parseImageList($property['images']);
        $merged = array_merge($existing, $newPaths);
        Property::saveImageList($id, $merged);

        // Keep the paired room's gallery (used by customer browse/booking)
        // in sync too, when one exists, so both views of this listing show
        // the same photos - same convention already used at creation time.
        if (!empty($property['house_id'])) {
            $room = Room::findByHouseId($property['house_id']) ?? null;
            if ($room) {
                Room::saveImageList($room['id'], $merged);
            }
        }

        sendJSON(['success' => true, 'images' => $merged]);
    }

    /**
     * DELETE /properties/{id}/images/{index} - removes exactly one image
     * (by its position in the gallery) from this property. Never deletes
     * the property itself, and always leaves at least one photo behind.
     */
    public static function deleteImage($id, $index) {
        $property = self::authorizePropertyManagement($id);
        $images = Property::parseImageList($property['images']);
        $index = (int) $index;

        if (count($images) <= 1) {
            sendJSON(['error' => 'A property must keep at least one image.'], 400);
        }
        if (!array_key_exists($index, $images)) {
            sendJSON(['error' => 'Image not found.'], 404);
        }

        $removedPath = $images[$index];
        array_splice($images, $index, 1);
        Property::saveImageList($id, $images);

        if (!empty($property['house_id'])) {
            $room = Room::findByHouseId($property['house_id']) ?? null;
            if ($room) {
                Room::saveImageList($room['id'], $images);
            }
        }

        $abs = __DIR__ . '/../../' . $removedPath;
        if (is_file($abs)) @unlink($abs);

        sendJSON(['success' => true, 'images' => $images]);
    }
}