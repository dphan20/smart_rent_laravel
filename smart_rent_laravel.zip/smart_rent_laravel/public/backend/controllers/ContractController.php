<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../helpers/functions.php';
require_once __DIR__ . '/../models/Contract.php';
require_once __DIR__ . '/../models/Order.php';

class ContractController {
    public static function getAll() {
        requireAuth();
        $user = getCurrentUser();
        $role = normalizeRole($user['type']);
        sendJSON(Contract::getAllForUser($user['id'], $role));
    }

    public static function getOne($id) {
        requireAuth();
        $user = getCurrentUser();
        $role = normalizeRole($user['type']);
        $contract = Contract::find($id);
        if (!$contract) sendJSON(['error' => 'Not found'], 404);
        self::assertCanView($contract, $user, $role);
        sendJSON($contract);
    }

    // Generates a contract from a confirmed order. Called both directly
    // (Landlord/Admin hitting POST contracts) and automatically from
    // OrderController::update() the moment a landlord confirms an order —
    // matching the spec's "Landlord approves booking -> contract generated"
    // flow without requiring a second manual step.
    public static function generateForOrder($orderId, $overrides = []) {
        global $pdo;
        $order = $pdo->prepare("SELECT o.*, r.price AS room_price FROM orders o LEFT JOIN rooms r ON o.room_id = r.id WHERE o.id = ?");
        $order->execute([$orderId]);
        $order = $order->fetch();
        if (!$order) return null;

        $existing = Contract::findByOrder($orderId);
        if ($existing) return $existing['id'];

        return Contract::create([
            'booking_id' => $orderId,
            'room_id' => $order['room_id'],
            'landlord_id' => $order['landlord_id'],
            'customer_id' => $order['user_id'],
            'monthly_rent' => $overrides['monthly_rent'] ?? $order['room_price'] ?? 0,
            'deposit' => $overrides['deposit'] ?? 0,
            'start_date' => $overrides['start_date'] ?? $order['arrival_date'] ?? null,
            'end_date' => $overrides['end_date'] ?? null,
            'payment_terms' => $overrides['payment_terms'] ?? 'Rent is due monthly in advance.',
            'responsibilities' => $overrides['responsibilities'] ?? null,
            'termination_conditions' => $overrides['termination_conditions'] ?? null,
            'other_terms' => $overrides['other_terms'] ?? null,
        ]);
    }

    // Manual creation endpoint — Admin/Landlord only, and a Landlord can
    // only generate a contract for their own order.
    public static function create() {
        requireAuth();
        requireAnyRole(['Admin', 'Landlord']);
        $data = json_decode(file_get_contents('php://input'), true);
        if (empty($data['order_id'])) {
            sendJSON(['error' => 'order_id is required'], 400);
        }

        global $pdo;
        $stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ?");
        $stmt->execute([$data['order_id']]);
        $order = $stmt->fetch();
        if (!$order) sendJSON(['error' => 'Order not found'], 404);

        $user = getCurrentUser();
        if (normalizeRole($user['type']) === 'Landlord' && (int) $order['landlord_id'] !== (int) $user['id']) {
            sendJSON(['error' => 'You can only generate contracts for your own orders'], 403);
        }
        if ($order['status'] !== 'confirmed') {
            sendJSON(['error' => 'The order must be confirmed by the landlord before a contract can be generated'], 409);
        }

        $contractId = self::generateForOrder($data['order_id'], $data);
        if (!$contractId) sendJSON(['error' => 'Could not generate contract'], 500);
        sendJSON(['success' => true, 'contract' => Contract::find($contractId)]);
    }

    // Digital acceptance. Authenticated user must be the exact customer or
    // landlord named on the contract — never anyone else, and never the
    // other party acting out of turn (enforced again inside Contract::accept).
    public static function accept($id) {
        requireAuth();
        $user = getCurrentUser();
        $role = normalizeRole($user['type']);
        $contract = Contract::find($id);
        if (!$contract) sendJSON(['error' => 'Not found'], 404);

        if ($role === 'Customer' && (int) $contract['customer_id'] !== (int) $user['id']) {
            sendJSON(['error' => 'This is not your contract'], 403);
        }
        if ($role === 'Landlord' && (int) $contract['landlord_id'] !== (int) $user['id']) {
            sendJSON(['error' => 'This is not your contract'], 403);
        }
        if (!in_array($role, ['Customer', 'Landlord'], true)) {
            sendJSON(['error' => 'Only the customer or landlord on this contract can accept it'], 403);
        }

        $data = json_decode(file_get_contents('php://input'), true) ?? [];
        if (empty($data['accept'])) {
            sendJSON(['error' => 'Explicit acceptance is required'], 400);
        }

        $ip = $_SERVER['REMOTE_ADDR'] ?? null;
        $result = Contract::accept($id, $user['id'], $role, $ip);
        if ($result['success']) {
            sendJSON(['success' => true, 'contract' => Contract::find($id)]);
        } else {
            sendJSON(['error' => $result['message']], 409);
        }
    }

    private static function assertCanView($contract, $user, $role) {
        if ($role === 'Admin') return;
        if ($role === 'Landlord' && (int) $contract['landlord_id'] === (int) $user['id']) return;
        if ($role === 'Customer' && (int) $contract['customer_id'] === (int) $user['id']) return;
        sendJSON(['error' => 'Forbidden'], 403);
    }

    public static function getPdf($id) {
        requireAuth();
        $user = getCurrentUser();
        $role = normalizeRole($user['type']);
        $contract = Contract::find($id);
        if (!$contract) sendJSON(['error' => 'Not found'], 404);
        self::assertCanView($contract, $user, $role);

        require_once __DIR__ . '/../helpers/SimplePdf.php';
        $pdf = new SimplePdf();

        $pdf->addHeading('SMART RENT — Rental Agreement');
        $pdf->addLine('Contract Number: ' . $contract['contract_number']);
        $pdf->addLine('Status: ' . $contract['status']);
        $pdf->addSpacer();

        $pdf->addSubheading('Parties');
        $pdf->addLine('Landlord: ' . $contract['landlord_name']);
        $pdf->addLine('Customer: ' . $contract['customer_name'] . ' (' . $contract['customer_email'] . ')');
        $pdf->addSpacer();

        $pdf->addSubheading('Rental Terms');
        $pdf->addLine('Monthly Rent: TZS ' . number_format((float) $contract['monthly_rent'], 2));
        $pdf->addLine('Deposit: TZS ' . number_format((float) $contract['deposit'], 2));
        $pdf->addLine('Start Date: ' . ($contract['start_date'] ?? 'Not set'));
        $pdf->addLine('End Date: ' . ($contract['end_date'] ?? 'Not set'));
        $pdf->addSpacer();

        if (!empty($contract['payment_terms'])) {
            $pdf->addSubheading('Payment Terms');
            $pdf->addLine($contract['payment_terms']);
            $pdf->addSpacer();
        }
        if (!empty($contract['responsibilities'])) {
            $pdf->addSubheading('Responsibilities');
            $pdf->addLine($contract['responsibilities']);
            $pdf->addSpacer();
        }
        if (!empty($contract['termination_conditions'])) {
            $pdf->addSubheading('Termination Conditions');
            $pdf->addLine($contract['termination_conditions']);
            $pdf->addSpacer();
        }
        if (!empty($contract['other_terms'])) {
            $pdf->addSubheading('Other Terms');
            $pdf->addLine($contract['other_terms']);
            $pdf->addSpacer();
        }

        $pdf->addSubheading('Acceptance');
        $pdf->addLine('Customer accepted: ' . ($contract['customer_accepted_at'] ?? 'Not yet accepted'));
        $pdf->addLine('Landlord accepted: ' . ($contract['landlord_accepted_at'] ?? 'Not yet accepted'));
        $pdf->addSpacer();
        $pdf->addLine('Generated: ' . date('Y-m-d H:i:s'), true);
        $pdf->addLine('This document reflects the rental terms recorded in the Smart Rent system at the time of generation.');

        $bytes = $pdf->render();
        $filename = 'contract-' . $contract['contract_number'] . '.pdf';

        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . strlen($bytes));
        header('X-Content-Type-Options: nosniff');
        echo $bytes;
        exit;
    }
}
