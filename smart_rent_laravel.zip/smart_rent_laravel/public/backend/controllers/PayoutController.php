<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../helpers/functions.php';
require_once __DIR__ . '/../helpers/Logger.php';
require_once __DIR__ . '/../helpers/CommissionService.php';
require_once __DIR__ . '/../models/Payout.php';

class PayoutController
{
    public static function getAll()
    {
        requireAuth();
        $user = getCurrentUser();
        $role = normalizeRole($user['type'] ?? '');

        if ($role === 'Admin') {
            sendJSON(Payout::getAll());
            return;
        }
        if ($role === 'Landlord') {
            sendJSON(Payout::getAll(['landlord_id' => $user['id']]));
            return;
        }
        // Customers have no payouts of their own.
        sendJSON([]);
    }

    public static function updateStatus($id)
    {
        requireAuth();
        $user = getCurrentUser();
        if (normalizeRole($user['type'] ?? '') !== 'Admin') {
            sendJSON(['error' => 'Only an admin can update payout status'], 403);
            return;
        }

        $payout = Payout::findById($id);
        if (!$payout) {
            sendJSON(['error' => 'Payout not found'], 404);
            return;
        }

        $data = readRequestData();
        $status = strtoupper(trim((string) ($data['status'] ?? '')));
        if (!in_array($status, Payout::VALID_STATUSES, true)) {
            sendJSON([
                'error' => 'Invalid status',
                'valid_statuses' => Payout::VALID_STATUSES,
            ], 400);
            return;
        }

        // This system does not itself move money. Marking PAID here records
        // that the admin has confirmed the payout happened through whatever
        // channel was actually used (bank transfer, mobile money, etc.) - it
        // is a ledger entry, not a claim that this software executed a
        // transfer.
        $method = isset($data['payout_method']) ? sanitizeString($data['payout_method']) : null;
        $reference = isset($data['payout_reference']) ? sanitizeString($data['payout_reference']) : null;
        $notes = isset($data['notes']) ? sanitizeString($data['notes']) : null;

        Payout::updateStatus($id, $status, $method ?: null, $reference ?: null, $notes ?: null);
        Logger::app('payout status updated', ['payout_id' => $id, 'status' => $status, 'admin_id' => $user['id']]);
        sendJSON(['success' => true]);
    }

    // --- Platform commission rate (admin-configurable) ---------------------

    public static function getSettings()
    {
        requireAuth();
        $user = getCurrentUser();
        if (normalizeRole($user['type'] ?? '') !== 'Admin') {
            sendJSON(['error' => 'Forbidden'], 403);
            return;
        }
        sendJSON(['platform_commission_rate' => CommissionService::getCommissionRate()]);
    }

    public static function updateSettings()
    {
        requireAuth();
        $user = getCurrentUser();
        if (normalizeRole($user['type'] ?? '') !== 'Admin') {
            sendJSON(['error' => 'Forbidden'], 403);
            return;
        }
        $data = readRequestData();
        if (!isset($data['platform_commission_rate']) || !is_numeric($data['platform_commission_rate'])) {
            sendJSON(['error' => 'platform_commission_rate must be a number between 0 and 100'], 400);
            return;
        }
        $rate = (float) $data['platform_commission_rate'];
        if ($rate < 0 || $rate > 100) {
            sendJSON(['error' => 'platform_commission_rate must be between 0 and 100'], 400);
            return;
        }
        CommissionService::setCommissionRate($rate);
        Logger::app('commission rate updated', ['new_rate' => $rate, 'admin_id' => $user['id']]);
        sendJSON(['success' => true, 'platform_commission_rate' => CommissionService::getCommissionRate()]);
    }
}
