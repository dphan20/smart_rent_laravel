<?php
// Optimize images served from /uploads by adding proper caching headers
// and handling image compression

$requestUri = $_SERVER['REQUEST_URI'] ?? '';

// Only handle upload requests
if (strpos($requestUri, '/uploads/') !== 0) {
    http_response_code(404);
    die('Not found');
}

// Extract filename
$filename = basename(parse_url($requestUri, PHP_URL_PATH));
$uploadsDir = __DIR__ . '/uploads';
$filepath = realpath($uploadsDir . '/' . $filename);

// Security: ensure the file is actually in the uploads directory
if (!$filepath || strpos($filepath, realpath($uploadsDir)) !== 0) {
    http_response_code(404);
    die('Not found');
}

if (!is_file($filepath)) {
    http_response_code(404);
    die('Not found');
}

// Get file info
$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mimeType = finfo_file($finfo, $filepath);
finfo_close($finfo);

// Set aggressive caching headers for images (30 days)
header('Cache-Control: public, max-age=2592000, immutable');
header('Expires: ' . gmdate('D, d M Y H:i:s', time() + 2592000) . ' GMT');
header('Pragma: public');

// Add ETag for cache validation
$etag = '"' . filemtime($filepath) . '-' . filesize($filepath) . '"';
header('ETag: ' . $etag);

// Handle If-None-Match (304 Not Modified)
$ifNoneMatch = $_SERVER['HTTP_IF_NONE_MATCH'] ?? '';
if ($ifNoneMatch === $etag) {
    http_response_code(304);
    exit;
}

// Serve with proper MIME type
header('Content-Type: ' . ($mimeType ?: 'application/octet-stream'));
header('Content-Length: ' . filesize($filepath));

// Allow byte range requests for better UX on large images
$size = filesize($filepath);
if (isset($_SERVER['HTTP_RANGE'])) {
    if (preg_match('/bytes=(\d+)-(\d*)/', $_SERVER['HTTP_RANGE'], $matches)) {
        $start = intval($matches[1]);
        $end = $matches[2] !== '' ? intval($matches[2]) : $size - 1;
        
        if ($start >= 0 && $end < $size && $start <= $end) {
            http_response_code(206);
            header('Content-Range: bytes ' . $start . '-' . $end . '/' . $size);
            header('Content-Length: ' . ($end - $start + 1));
            
            $fp = fopen($filepath, 'rb');
            fseek($fp, $start);
            echo fread($fp, $end - $start + 1);
            fclose($fp);
            exit;
        }
    }
}

// Serve the entire file
readfile($filepath);
