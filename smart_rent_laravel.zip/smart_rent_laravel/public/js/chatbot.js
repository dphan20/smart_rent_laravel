/**
 * Smart Rent AI Chatbot Widget
 * This chatbot integrates with the Groq AI API through a secure Laravel backend
 */

(function() {
    'use strict';

    // Configuration
    const config = {
        apiEndpoint: '/api/chat',
        historyEndpoint: '/api/chat/history',
        clearHistoryEndpoint: '/api/chat/history',
    };

    // Chatbot state
    let chatState = {
        isOpen: false,
        isLoading: false,
        sessionId: generateSessionId(),
        messages: [],
    };

    /**
     * Generate a unique session ID
     */
    function generateSessionId() {
        return 'session_' + Math.random().toString(36).substr(2, 9) + '_' + Date.now();
    }

    /**
     * Initialize the chatbot
     */
    function initChatbot() {
        // Create chat container
        const container = createChatContainer();
        document.body.appendChild(container);

        // Bind event listeners
        bindEventListeners();

        // Display welcome message
        addMessageToChat('assistant', 'Welcome to Smart Rent AI! 👋 I can help you find rental properties. What are you looking for?');
    }

    /**
     * Create the chat container HTML
     */
    function createChatContainer() {
        const wrapper = document.createElement('div');
        wrapper.className = 'smart-rent-chatbot-wrapper';
        wrapper.innerHTML = `
            <div class="smart-rent-chatbot">
                <!-- Chat Toggle Button -->
                <div class="chatbot-toggle">
                    <button id="chatbot-toggle-btn" class="toggle-btn" title="Open AI Assistant">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                        </svg>
                        <span class="badge" style="display:none;">1</span>
                    </button>
                </div>

                <!-- Chat Window -->
                <div class="chatbot-window" style="display:none;">
                    <div class="chatbot-header">
                        <div class="header-content">
                            <h3>Smart Rent AI Assistant</h3>
                            <p>Powered by Groq</p>
                        </div>
                        <div class="header-actions">
                            <button id="chatbot-close-btn" class="close-btn" title="Close">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <line x1="18" y1="6" x2="6" y2="18"></line>
                                    <line x1="6" y1="6" x2="18" y2="18"></line>
                                </svg>
                            </button>
                        </div>
                    </div>

                    <div class="chatbot-messages" id="chatbot-messages">
                        <!-- Messages will be added here -->
                    </div>

                    <div class="chatbot-footer">
                        <div class="input-container">
                            <input 
                                type="text" 
                                id="chatbot-input" 
                                class="message-input" 
                                placeholder="Ask me anything about properties..." 
                                maxlength="2000"
                                autocomplete="off"
                            />
                            <button id="chatbot-send-btn" class="send-btn" title="Send message">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M16.6915026,12.4744748 L3.50612381,13.2599618 C3.19218622,13.2599618 3.03521743,13.4170592 3.03521743,13.5741566 L1.15159189,20.0151496 C0.8376543,20.8006365 0.99,21.89 1.77946707,22.52 C2.41,22.99 3.50612381,23.1 4.13399899,22.8429026 L21.714504,14.0454487 C22.6563168,13.5741566 23.1272231,12.6315722 22.9702544,11.6889879 L4.13399899,1.16126654 C3.34915502,0.9041691 2.40734225,1.01538882 1.77946707,1.4866809 C0.994623095,2.11539624 0.837654326,3.0579806 1.15159189,3.84346742 L3.03521743,10.2844604 C3.03521743,10.4415577 3.19218622,10.5976551 3.50612381,10.5976551 L16.6915026,11.3831420 C16.6915026,11.3831420 17.1624089,11.3831420 17.1624089,10.9118499 L17.1624089,1.00636533 C17.1624089,0.9041691 17.1624089,0.370840783 17.1624089,0 C17.1624089,0.370840783 17.1624089,0 17.1624089,0.9041691 L17.1624089,10.9118499 C17.1624089,11.3831420 17.1624089,11.3831420 16.6915026,11.3831420 Z"></path>
                                </svg>
                            </button>
                        </div>
                        <div class="input-hint">Press Enter to send, Shift+Enter for new line</div>
                    </div>
                </div>
            </div>
        `;
        return wrapper;
    }

    /**
     * Bind event listeners
     */
    function bindEventListeners() {
        const toggleBtn = document.getElementById('chatbot-toggle-btn');
        const closeBtn = document.getElementById('chatbot-close-btn');
        const sendBtn = document.getElementById('chatbot-send-btn');
        const input = document.getElementById('chatbot-input');
        const window = document.querySelector('.chatbot-window');

        // Toggle chatbot
        toggleBtn.addEventListener('click', () => {
            chatState.isOpen = !chatState.isOpen;
            window.style.display = chatState.isOpen ? 'flex' : 'none';
            if (chatState.isOpen) {
                input.focus();
            }
        });

        // Close chatbot
        closeBtn.addEventListener('click', () => {
            chatState.isOpen = false;
            window.style.display = 'none';
        });

        // Send message
        sendBtn.addEventListener('click', sendMessage);

        // Handle Enter key in input
        input.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
            }
        });
    }

    /**
     * Send message to chatbot
     */
    async function sendMessage() {
        const input = document.getElementById('chatbot-input');
        const message = input.value.trim();

        if (!message || chatState.isLoading) {
            return;
        }

        // Add user message to chat
        addMessageToChat('user', message);
        input.value = '';

        // Show loading state
        chatState.isLoading = true;
        addLoadingIndicator();

        try {
            // Send message to backend
            const response = await fetch(config.apiEndpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                },
                body: JSON.stringify({
                    message: message,
                    session_id: chatState.sessionId,
                }),
            });

            if (!response.ok) {
                throw new Error('Failed to send message');
            }

            const data = await response.json();

            // Remove loading indicator
            removeLoadingIndicator();

            // Defense in depth: never render a blank/undefined bubble, even
            // if the backend response is missing a usable reply string.
            const replyText = (data && typeof data.reply === 'string' && data.reply.trim())
                ? data.reply
                : (data && data.message) || 'Sorry, I encountered an error. Please try again.';
            addMessageToChat('assistant', replyText);

            // Display properties if available
            if (data.properties && data.properties.length > 0) {
                displayProperties(data.properties);
            }
        } catch (error) {
            console.error('Chatbot error:', error);
            removeLoadingIndicator();
            addMessageToChat('assistant', 'Sorry, I encountered an error. Please try again later.');
        } finally {
            chatState.isLoading = false;
        }
    }

    /**
     * Add message to chat
     */
    function addMessageToChat(role, content) {
        const messagesContainer = document.getElementById('chatbot-messages');
        const messageEl = document.createElement('div');
        messageEl.className = `message message-${role}`;
        
        const contentEl = document.createElement('div');
        contentEl.className = 'message-content';
        contentEl.textContent = content;
        
        messageEl.appendChild(contentEl);
        messagesContainer.appendChild(messageEl);

        // Store message
        chatState.messages.push({ role, content, timestamp: new Date() });

        // Scroll to bottom
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    /**
     * Display property results
     */
    function displayProperties(properties) {
        const messagesContainer = document.getElementById('chatbot-messages');
        const propertiesEl = document.createElement('div');
        propertiesEl.className = 'message message-properties';
        
        let html = '<div class="properties-container"><div class="properties-title">📍 Available Properties:</div>';
        
        properties.forEach((prop, index) => {
            if (index >= 3) return; // Limit to 3 properties
            
            const price = new Intl.NumberFormat('en-US').format(Number(prop.monthly_rent || 0));
            const title = prop.name || prop.title || 'Property';
            const beds = prop.bedrooms;
            
            html += `
                <div class="property-item">
                    <div class="property-name">${escapeHtml(title)}</div>
                    <div class="property-details">
                        <span>📍 ${escapeHtml(prop.location || '')}</span>
                        <span>💰 TZS ${price}</span>
                        <span>🛏️ ${beds} bed${beds > 1 ? 's' : ''}</span>
                    </div>
                </div>
            `;
        });
        
        html += '</div>';
        propertiesEl.innerHTML = html;
        messagesContainer.appendChild(propertiesEl);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    /**
     * Add loading indicator
     */
    function addLoadingIndicator() {
        const messagesContainer = document.getElementById('chatbot-messages');
        const loadingEl = document.createElement('div');
        loadingEl.className = 'message message-loading';
        loadingEl.id = 'chatbot-loading';
        loadingEl.innerHTML = '<div class="typing-indicator"><span></span><span></span><span></span></div>';
        messagesContainer.appendChild(loadingEl);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    /**
     * Remove loading indicator
     */
    function removeLoadingIndicator() {
        const loading = document.getElementById('chatbot-loading');
        if (loading) {
            loading.remove();
        }
    }

    /**
     * Escape HTML to prevent XSS
     */
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    /**
     * Initialize when DOM is ready
     */
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initChatbot);
    } else {
        initChatbot();
    }

    // Expose API for manual control if needed
    window.SmartRentChatbot = {
        open: () => {
            document.getElementById('chatbot-toggle-btn').click();
        },
        close: () => {
            if (chatState.isOpen) {
                document.getElementById('chatbot-toggle-btn').click();
            }
        },
        sendMessage: (msg) => {
            document.getElementById('chatbot-input').value = msg;
            sendMessage();
        },
    };
})();
