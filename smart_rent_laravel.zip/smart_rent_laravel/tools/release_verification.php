<?php
require_once __DIR__ . '/../public/backend/config/env.php';
loadEnvFile(__DIR__ . '/../.env');

$host = getenv('SMART_RENT_DB_HOST') ?: '127.0.0.1';
$port = getenv('SMART_RENT_DB_PORT') ?: '3306';
$db = getenv('SMART_RENT_DB_NAME') ?: 'smartrent';
$user = getenv('SMART_RENT_DB_USER') ?: 'root';
$password = getenv('SMART_RENT_DB_PASS') ?: '';

$pdo = new PDO("mysql:host=$host;port=$port;dbname=$db;charset=utf8mb4", $user, $password, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
]);

$checks = [];
$check = function (string $label, bool $passed) use (&$checks): void {
    $checks[] = [$label, $passed];
    echo ($passed ? '[PASS] ' : '[FAIL] ') . $label . PHP_EOL;
};

$columnExists = function (string $table, string $column) use ($pdo): bool {
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ?');
    $stmt->execute([$table, $column]);
    return (bool) $stmt->fetchColumn();
};

$indexExists = function (string $table, string $index) use ($pdo): bool {
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema = DATABASE() AND table_name = ? AND index_name = ?');
    $stmt->execute([$table, $index]);
    return (bool) $stmt->fetchColumn();
};

$foreignKeyExists = function (string $name) use ($pdo): bool {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM information_schema.table_constraints WHERE table_schema = DATABASE() AND constraint_name = ? AND constraint_type = 'FOREIGN KEY'");
    $stmt->execute([$name]);
    return (bool) $stmt->fetchColumn();
};

foreach ([
    ['properties', 'sri'],
    ['properties', 'rental_mode'],
    ['rooms', 'rental_mode'],
    ['bookings', 'rental_mode'],
] as [$table, $column]) {
    $check("$table.$column exists", $columnExists($table, $column));
}

foreach ([
    ['properties', 'uq_properties_sri'],
    ['properties', 'idx_properties_sri'],
    ['bookings', 'idx_bookings_status'],
] as [$table, $index]) {
    $check("$table.$index exists", $indexExists($table, $index));
}

foreach (['fk_bookings_room', 'fk_orders_room', 'receipts_ibfk_1'] as $foreignKey) {
    $check("$foreignKey exists", $foreignKeyExists($foreignKey));
}

$missingSri = (int) $pdo->query("SELECT COUNT(*) FROM properties WHERE sri IS NULL OR sri = ''")->fetchColumn();
$invalidSri = (int) $pdo->query("SELECT COUNT(*) FROM properties WHERE sri IS NOT NULL AND sri <> '' AND sri NOT REGEXP '^TZ-[A-Z0-9]+-[0-9]{8}$'")->fetchColumn();
$duplicateSri = (int) $pdo->query("SELECT COUNT(*) FROM (SELECT sri FROM properties WHERE sri IS NOT NULL AND sri <> '' GROUP BY sri HAVING COUNT(*) > 1) duplicates")->fetchColumn();
$check('all properties have valid SRI values', $missingSri === 0 && $invalidSri === 0);
$check('property SRI values are unique', $duplicateSri === 0);

$failed = array_filter($checks, static fn (array $result): bool => !$result[1]);
echo PHP_EOL . (empty($failed) ? 'Release verification passed.' : count($failed) . ' release checks failed.') . PHP_EOL;
exit(empty($failed) ? 0 : 1);
