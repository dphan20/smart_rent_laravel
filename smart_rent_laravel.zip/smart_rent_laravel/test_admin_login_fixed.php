<?php
/**
 * Verify admin login works
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "Testing admin login with fixed credentials...\n\n";

$baseUrl = 'http://127.0.0.1:8000';
$loginUrl = $baseUrl . '/api/auth/login';

$credentials = [
    'email' => 'admin@smartrent.co.tz',
    'password' => 'admin123'
];

$curl = curl_init($loginUrl);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($credentials));
curl_setopt($curl, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($curl, CURLOPT_TIMEOUT, 10);

$response = curl_exec($curl);
$httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
$loginData = json_decode($response, true);

curl_close($curl);

echo "HTTP Status: $httpCode\n";
echo "Response:\n";
echo json_encode($loginData, JSON_PRETTY_PRINT) . "\n\n";

if ($httpCode === 200 && $loginData['success']) {
    echo "✅ LOGIN SUCCESSFUL!\n";
    echo "Admin: " . $loginData['user']['name'] . "\n";
    echo "Email: " . $loginData['user']['email'] . "\n";
    echo "Role: " . $loginData['user']['type'] . "\n";
} else {
    echo "❌ LOGIN FAILED\n";
    echo "Error: " . ($loginData['message'] ?? 'Unknown error') . "\n";
}
