<?php
$pdo = new PDO("mysql:host=127.0.0.1;port=3306;dbname=smartrent;charset=utf8mb4", "root", "");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$newPassword = 'Admin123!Test';
$hash = password_hash($newPassword, PASSWORD_DEFAULT);

$pdo->prepare("UPDATE users SET password_hash = ? WHERE role = 'Admin'")->execute([$hash]);

echo "Admin password reset to: $newPassword\n";
echo "Hash: $hash\n";

// Verify
if (password_verify($newPassword, $hash)) {
    echo "✓ Password verification works\n";
} else {
    echo "✗ Password verification failed\n";
}
