# 🤖 Smart Rent AI Chatbot - Quick Start Guide

## What's New?

Your Smart Rent application now has an **AI-powered chatbot** that helps users find properties using natural language. The chatbot is:

- ✅ **Public** - Anyone can use it without login
- ✅ **Secure** - API key is never exposed to users
- ✅ **Smart** - Understands English and Swahili
- ✅ **Fast** - Uses Groq's fast inference engine
- ✅ **Dynamic** - Automatically finds newly added properties

---

## 📦 What Was Added

### Files Created
```
app/Services/GroqService.php          → AI integration service
app/Http/Controllers/ChatController.php → Chat message handler
app/Models/Room.php                   → Room model
app/Models/Property.php               → Property model
app/Models/Booking.php                → Booking model
app/Models/AIConversation.php         → Conversation history
public/js/chatbot.js                  → Frontend chatbot widget
public/css/chatbot.css                → Chatbot styles
```

### Files Modified
```
.env                  → Added GROQ_API_KEY and GROQ_MODEL
config/services.php   → Added Groq service configuration
routes/web.php        → Added /api/chat endpoint
app/Models/User.php   → Added model relationships
smart_rent/app.html   → Added chatbot CSS and JS
```

### Database
No changes needed! The `ai_conversations` table already exists.

---

## 🚀 Get Started

### Step 1: Verify Configuration

Check that `.env` has:
```
GROQ_API_KEY=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
GROQ_MODEL=mixtral-8x7b-32768
```

### Step 2: Test the Chatbot

1. Open [http://localhost/smart_rent/app.html](http://localhost/smart_rent/app.html)
2. Look for the gold chat bubble in the bottom-right corner
3. Click it to open the chatbot
4. Try asking: **"Find me a room in Mbezi under 300,000"**
5. The AI should respond with available properties

### Step 3: Test Natural Language

Try these searches:
- "Show me apartments in Dar es Salaam"
- "I need a 2-bedroom house under 500,000"
- "Find me a furnished room with parking"
- "Nataka chumba Sinza" (Swahili)

---

## 🔐 Security Features

✅ **API Key Protection**
- API key stored in `.env` (server-side only)
- Never exposed to browser or JavaScript
- Only backend `GroqService` handles it

✅ **Input Validation**
- Message length limited to 2000 chars
- HTML tags stripped from input
- XSS prevention enabled

✅ **Rate Limiting**
- 20 requests/minute per IP
- 100 requests/hour per IP
- Prevents abuse and spam

✅ **No Login Required**
- Chatbot is public
- Anyone can use it
- Optional: Logged-in users can save history

---

## 📊 How It Works

```
User types: "Find me a room in Mbezi under 300,000"
                           ↓
           ChatController receives message
                           ↓
          GroqService extracts criteria:
          - Location: Mbezi
          - Max Price: 300,000
                           ↓
        Database queries Room & Property tables
                           ↓
        Returns matching properties to AI
                           ↓
        Groq generates natural response
                           ↓
    Response sent back to chatbot widget
                           ↓
User sees: "I found 3 rooms in Mbezi under 300,000 TZS..."
           + Property cards with details
```

---

## 🧪 Testing

### Browser Testing

1. Open DevTools (F12)
2. Go to **Network** tab
3. Send a message to chatbot
4. Find `/api/chat` request
5. Verify:
   - Request goes to **your server** (not Groq)
   - **No API key** in headers or body
   - Only user message is sent

### Command Line Testing

```bash
# Test the chat endpoint
curl -X POST http://localhost/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "Find a room in Dar", "session_id": "test-123"}'
```

### Expected Response

```json
{
  "success": true,
  "reply": "I found several rooms in Dar es Salaam...",
  "properties": [
    {
      "type": "room",
      "id": 1,
      "title": "Modern Room",
      "location": "Dar es Salaam",
      "price": 250000,
      "beds": 1,
      "size": 150
    }
  ]
}
```

---

## 🚨 Rate Limiting

If a user sends more than 20 messages per minute, they'll see:

> "Too many requests. Please wait a moment before trying again."

After 1 minute, they can continue. This prevents abuse.

---

## 📱 Mobile Support

The chatbot works on:
- ✅ Desktop (Chrome, Firefox, Safari, Edge)
- ✅ Tablet (iPad, Android tablets)
- ✅ Mobile (iPhone, Android phones)

The chat window automatically resizes for smaller screens.

---

## 🌙 Dark Mode

The chatbot automatically adapts to:
- Light mode (default)
- Dark mode (user's system preference)

No extra configuration needed!

---

## 💾 Conversation History

### For Logged-In Users

Users who are logged in can optionally:
- View their conversation history
- Clear their history

**Endpoints:**
```
GET  /api/chat/history         → Get last 50 conversations
DELETE /api/chat/history       → Delete all conversations
```

### For Guest Users

Guest (non-logged-in) users:
- Can use chatbot normally
- Conversations are NOT stored
- No user tracking

---

## 🛠️ Customization

### Change Rate Limits

Edit `app/Services/GroqService.php`:

```php
const RATE_LIMIT_PER_MINUTE = 20;  // Change this
const RATE_LIMIT_PER_HOUR = 100;   // Change this
```

### Change Welcome Message

Edit `public/js/chatbot.js`:

```javascript
addMessageToChat('assistant', 'Your custom welcome message here');
```

### Change Model

Edit `.env`:

```
GROQ_MODEL=mixtral-8x7b-32768    // Change to another model
GROQ_MODEL=llama-3.1-70b-versatile
GROQ_MODEL=llama-3.1-8b-instant
```

---

## 🐛 Troubleshooting

### Chatbot doesn't appear

- Check browser console (F12) for errors
- Verify chatbot CSS loaded: Check Network tab for `chatbot.css`
- Verify chatbot JS loaded: Check Network tab for `chatbot.js`

### Chat doesn't respond

- Check `.env` has valid `GROQ_API_KEY`
- Check Laravel logs: `storage/logs/laravel.log`
- Try: Send a simpler message like "hello"
- Try: Refresh browser

### Rate limit errors

- User sent too many messages
- Wait 1 minute and try again
- Check IP address in error (might be proxy issue)

### AI gives wrong answers

- AI might need more specific search criteria
- Try: "Find a 2-bedroom room in Mbezi under 300,000"
- Instead of: "Find a room"

### API key not working

- Get a new key from [https://console.groq.com/](https://console.groq.com/)
- Update `GROQ_API_KEY` in `.env`
- Make sure there are no extra spaces in the key
- Restart PHP/Laravel server

---

## 📚 Advanced Features

### Custom System Prompt

The AI is instructed to:
- Only use database information
- Never invent properties
- Support English and Swahili
- Ask clarifying questions when needed

You can customize this in `app/Services/GroqService.php`:

```php
private function prepareContext($propertyData, $criteria)
{
    $context = "Your custom system prompt here";
    // ...
}
```

### Add More Search Criteria

Currently searches by:
- Location, Price, Type, Bedrooms, Furnished status

To add more (e.g., amenities search):

Edit `extractSearchCriteria()` in `GroqService.php`

### Extend to Multi-Language Support

Currently supports: English, Swahili

To add more languages:

Edit language detection in `prepareContext()`

---

## 📞 Getting Help

### Check Logs

```bash
# Laravel logs
tail -f storage/logs/laravel.log

# Check for Groq API errors
grep -i "groq" storage/logs/laravel.log
```

### Test Database Connection

```bash
# Start Laravel tinker
php artisan tinker

# Check rooms
>>> App\Models\Room::count()
>>> App\Models\Room::first()

# Check properties
>>> App\Models\Property::count()
>>> App\Models\Property::first()
```

### Verify Configuration

```bash
# Check config
php artisan config:cache

# See all services
php artisan config:show services
```

---

## ✨ What's Possible

The AI can now help users:

- 🏘️ Find properties by location
- 💰 Filter by price range
- 🛏️ Search by number of bedrooms
- 🔒 Look for specific amenities
- 🌍 Search in multiple languages
- ❓ Ask questions about properties
- 📋 Get property recommendations

All using **natural language** - no complex search forms needed!

---

## 🎉 That's It!

Your Smart Rent chatbot is ready to use. Enjoy! 🚀

For more details, see `GROQ_INTEGRATION_GUIDE.md`
