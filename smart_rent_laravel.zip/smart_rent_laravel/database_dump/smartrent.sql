-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 15, 2026 at 09:30 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smartrent`
--

-- --------------------------------------------------------

--
-- Table structure for table `ai_conversations`
--

CREATE TABLE `ai_conversations` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `session_id` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `response` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ai_conversations`
--

INSERT INTO `ai_conversations` (`id`, `customer_id`, `session_id`, `message`, `response`, `created_at`) VALUES
(1, 12, 'match-eb22652b70c04553', 'which house resemble each other', 'Found 2 matching properties.', '2026-08-10 20:50:02'),
(2, 12, '7280463025e8919c5e165433fa49970b', 'what room as small cost', 'I found 2 available properties that might match:\n- western park lodge — TSh 700,000/month, 3 bed(s), kinodoni, Makongo, Dar es Salaam\n- Moonlight Park — TSh 600,000/month, 2 bed(s), Temeke, TEMEKE, Dar es Salaam\nTap a property below to see more, or ask me something more specific.', '2026-08-10 20:50:58'),
(3, 12, 'property-24-2c690254b2b12e0dfd120d717064ca18', 'where is it located', 'This property is located in Temeke, TEMEKE, Dar es Salaam.', '2026-08-10 20:52:10'),
(4, 12, 'property-24-056b3c03d66fd177772f696bb738d6f8', 'is it booked', 'I can tell you this property has 2 bedroom(s), 1 bathroom(s), rents for TSh 600,000/month in Temeke, TEMEKE, Dar es Salaam. Ask me something more specific, or contact the landlord for details not listed here.', '2026-08-10 20:52:31'),
(5, 12, 'property-24-488129eb2dd88daf39ed7a9cbf806d2a', 'can i book it', 'Yes, this property is currently available to book.', '2026-08-10 20:52:59'),
(6, 12, 'property-24-236ea437d9e93006996ab8cd20e527ac', 'thanks alot', 'I can tell you this property has 2 bedroom(s), 1 bathroom(s), rents for TSh 600,000/month in Temeke, TEMEKE, Dar es Salaam. Ask me something more specific, or contact the landlord for details not listed here.', '2026-08-10 20:53:16'),
(7, 12, '7280463025e8919c5e165433fa49970b', 'whi is booking not working', 'I found 2 available properties that might match:\n- western park lodge — TSh 700,000/month, 3 bed(s), kinodoni, Makongo, Dar es Salaam\n- Moonlight Park — TSh 600,000/month, 2 bed(s), Temeke, TEMEKE, Dar es Salaam\nTap a property below to see more, or ask me something more specific.', '2026-08-10 20:54:41'),
(8, 12, '7280463025e8919c5e165433fa49970b', 'big rooms', 'I found 2 available properties that might match:\n- western park lodge — TSh 700,000/month, 3 bed(s), kinodoni, Makongo, Dar es Salaam\n- Moonlight Park — TSh 600,000/month, 2 bed(s), Temeke, TEMEKE, Dar es Salaam\nTap a property below to see more, or ask me something more specific.', '2026-08-10 20:55:01'),
(9, 12, 'e8a76b12c25cab49515970045e92e082', 'show 3 big rooms with high cost', 'I found 2 available properties that might match:\n- western park lodge — TSh 700,000/month, 3 bed(s), kinodoni, Makongo, Dar es Salaam\n- Moonlight Park — TSh 600,000/month, 2 bed(s), Temeke, TEMEKE, Dar es Salaam\nTap a property below to see more, or ask me something more specific.', '2026-08-10 20:55:53'),
(10, NULL, 'match-fb66e2b6669425e0', 'hii', 'Found 1 matching properties.', '2026-08-10 20:58:49'),
(11, NULL, '5549f9adf256cb30b204f36e3c82b443', 'hii', 'I found 1 available property that might match:\n- Moonlight Park — TSh 600,000/month, 2 bed(s), Temeke, TEMEKE, Dar es Salaam\nTap a property below to see more, or ask me something more specific.', '2026-08-11 15:37:10'),
(12, NULL, '5549f9adf256cb30b204f36e3c82b443', 'hii', 'I found 1 available property that might match:\n- Moonlight Park — TSh 600,000/month, 2 bed(s), Temeke, TEMEKE, Dar es Salaam\nTap a property below to see more, or ask me something more specific.', '2026-08-11 15:37:22'),
(13, NULL, '3aeaa1b7eda2565c6ffb82e44f9d06b9', 'Show me available rooms in TestDistrictf0844e', 'I found 1 available property that might match:\n- Test Property 50fd26 — TSh 320,000/month, 2 bed(s), TestWard, TestDistrictf0844e, TestRegion\nTap a property below to see more, or ask me something more specific.', '2026-08-11 15:48:45'),
(14, NULL, '4bda74697a3e47e15164dab0da51af05', 'Show me available rooms in TestDistrictac2aaa', 'I found 1 available property that might match:\n- Test Property ca58e7 — TSh 320,000/month, 2 bed(s), TestWard, TestDistrictac2aaa, TestRegion\nTap a property below to see more, or ask me something more specific.', '2026-08-11 15:49:57'),
(15, NULL, '9c31094a6df641168446067b4560a00a', 'Show me available rooms in TestDistrict6332ee', 'I found 1 available property that might match:\n- Test Property c03374 — TSh 320,000/month, 2 bed(s), TestWard, TestDistrict6332ee, TestRegion\nTap a property below to see more, or ask me something more specific.', '2026-08-11 15:52:41'),
(16, NULL, 'b2bcbb1e72f8100a325f6bcc9dfdf951', 'Show me available rooms in TestDistrict16c28e', 'I found 1 available property that might match:\n- Test Property 885b69 — TSh 320,000/month, 2 bed(s), TestWard, TestDistrict16c28e, TestRegion\nTap a property below to see more, or ask me something more specific.', '2026-08-11 15:53:13'),
(17, NULL, 'a518c80d716bfdf31eb832c0a155bdf2', 'What is the current price for rooms in TestDistrict16c28e?', 'I found 1 available property that might match:\n- Test Property 885b69 — TSh 380,000/month, 2 bed(s), TestWard, TestDistrict16c28e, TestRegion\nTap a property below to see more, or ask me something more specific.', '2026-08-11 15:53:14'),
(18, NULL, '6abaff40fda7cb55e10d047d775afd30', 'Show me available rooms in TestDistrict16c28e', 'I couldn\'t find any available properties matching that yet. Try telling me a location, budget, and number of bedrooms - for example \"2 bedroom apartment in Mbezi under 600,000\".', '2026-08-11 15:53:14'),
(19, NULL, 'cbfb8d05e6b92bef71145a5e2bc8c394', 'Show me available rooms in TestDistrict16c28e', 'I found 4 available properties that might match:\n- Test Property c03374 — TSh 320,000/month, 2 bed(s), TestWard, TestDistrict6332ee, TestRegion\n- Test Property ca58e7 — TSh 320,000/month, 2 bed(s), TestWard, TestDistrictac2aaa, TestRegion\n- Test Property 50fd26 — TSh 320,000/month, 2 bed(s), TestWard, TestDistrictf0844e, TestRegion\n- Moonlight Park — TSh 600,000/month, 2 bed(s), Temeke, TEMEKE, Dar es Salaam\nTap a property below to see more, or ask me something more specific.', '2026-08-11 15:53:14'),
(20, NULL, '490bcd61b639ec9a4a2b341e0d9cd242', 'Show me available rooms in TestDistrict36db8f', 'I found 1 available property that might match:\n- Test Property f58fff — TSh 320,000/month, 2 bed(s), TestWard, TestDistrict36db8f, TestRegion\nTap a property below to see more, or ask me something more specific.', '2026-08-11 15:54:26'),
(21, NULL, '8395d77748fa4f0dbbee1a8e1194ca5f', 'What is the current price for rooms in TestDistrict36db8f?', 'I found 1 available property that might match:\n- Test Property f58fff — TSh 380,000/month, 2 bed(s), TestWard, TestDistrict36db8f, TestRegion\nTap a property below to see more, or ask me something more specific.', '2026-08-11 15:54:26'),
(22, NULL, '5b80ffb266851369e0ca4e1b8d479cfb', 'Show me available rooms in TestDistrict36db8f', 'I couldn\'t find any available properties matching that yet. Try telling me a location, budget, and number of bedrooms - for example \"2 bedroom apartment in Mbezi under 600,000\".', '2026-08-11 15:54:26'),
(23, NULL, '6e0a34bb88699feac125e21fea6ef926', 'Show me available rooms in TestDistrict36db8f', 'I found 4 available properties that might match:\n- Test Property c03374 — TSh 320,000/month, 2 bed(s), TestWard, TestDistrict6332ee, TestRegion\n- Test Property ca58e7 — TSh 320,000/month, 2 bed(s), TestWard, TestDistrictac2aaa, TestRegion\n- Test Property 50fd26 — TSh 320,000/month, 2 bed(s), TestWard, TestDistrictf0844e, TestRegion\n- Moonlight Park — TSh 600,000/month, 2 bed(s), Temeke, TEMEKE, Dar es Salaam\nTap a property below to see more, or ask me something more specific.', '2026-08-11 15:54:26'),
(24, NULL, '7c08f57ba948391e606b0385c270836a', 'Show me available rooms in TestDistrict35b507', 'I found 1 available property that might match:\n- Test Property b1cac7 — TSh 320,000/month, 2 bed(s), TestWard, TestDistrict35b507, TestRegion\nTap a property below to see more, or ask me something more specific.', '2026-08-11 15:55:22'),
(25, NULL, 'a28577a103b7c08ebe5f1011bbedebcd', 'What is the current price for rooms in TestDistrict35b507?', 'I found 1 available property that might match:\n- Test Property b1cac7 — TSh 380,000/month, 2 bed(s), TestWard, TestDistrict35b507, TestRegion\nTap a property below to see more, or ask me something more specific.', '2026-08-11 15:55:22'),
(26, NULL, '9e3a19c9b5b1763a527fa8b05d4682f1', 'Show me available rooms in TestDistrict35b507', 'I couldn\'t find any available properties matching that yet. Try telling me a location, budget, and number of bedrooms - for example \"2 bedroom apartment in Mbezi under 600,000\".', '2026-08-11 15:55:22'),
(27, NULL, '7228cd5168fabc7917fa476a06324c19', 'Show me available rooms in TestDistrict35b507', 'I found 4 available properties that might match:\n- Test Property c03374 — TSh 320,000/month, 2 bed(s), TestWard, TestDistrict6332ee, TestRegion\n- Test Property ca58e7 — TSh 320,000/month, 2 bed(s), TestWard, TestDistrictac2aaa, TestRegion\n- Test Property 50fd26 — TSh 320,000/month, 2 bed(s), TestWard, TestDistrictf0844e, TestRegion\n- Moonlight Park — TSh 600,000/month, 2 bed(s), Temeke, TEMEKE, Dar es Salaam\nTap a property below to see more, or ask me something more specific.', '2026-08-11 15:55:22'),
(28, NULL, 'b76b29feceb75e3afadf19b64bced0e8', 'hii', 'I found 4 available properties that might match:\n- Test Property c03374 — TSh 320,000/month, 2 bed(s), TestWard, TestDistrict6332ee, TestRegion\n- Test Property ca58e7 — TSh 320,000/month, 2 bed(s), TestWard, TestDistrictac2aaa, TestRegion\n- Test Property 50fd26 — TSh 320,000/month, 2 bed(s), TestWard, TestDistrictf0844e, TestRegion\n- Moonlight Park — TSh 600,000/month, 2 bed(s), Temeke, TEMEKE, Dar es Salaam\nTap a property below to see more, or ask me something more specific.', '2026-08-11 15:55:48'),
(29, NULL, 'match-615f0fae62bcbc7a', 'hii', 'Found 4 matching properties.', '2026-08-11 16:03:29'),
(30, NULL, '436b263e27964dcc3727a545f9806248', 'rooms in dodoma', 'I found 4 available properties that might match:\n- Test Property c03374 — TSh 320,000/month, 2 bed(s), TestWard, TestDistrict6332ee, TestRegion\n- Test Property ca58e7 — TSh 320,000/month, 2 bed(s), TestWard, TestDistrictac2aaa, TestRegion\n- Test Property 50fd26 — TSh 320,000/month, 2 bed(s), TestWard, TestDistrictf0844e, TestRegion\n- Moonlight Park — TSh 600,000/month, 2 bed(s), Temeke, TEMEKE, Dar es Salaam\nTap a property below to see more, or ask me something more specific.', '2026-08-11 16:05:00'),
(31, NULL, '52bbc286b3ebffee564e10a285643730', 'hii', 'I found 4 available properties that might match:\n- Test Property c03374 — TSh 320,000/month, 2 bed(s), TestWard, TestDistrict6332ee, TestRegion\n- Test Property ca58e7 — TSh 320,000/month, 2 bed(s), TestWard, TestDistrictac2aaa, TestRegion\n- Test Property 50fd26 — TSh 320,000/month, 2 bed(s), TestWard, TestDistrictf0844e, TestRegion\n- Moonlight Park — TSh 600,000/month, 2 bed(s), Temeke, TEMEKE, Dar es Salaam\nTap a property below to see more, or ask me something more specific.', '2026-08-11 16:06:32'),
(32, 11, '52bbc286b3ebffee564e10a285643730', 'rooms in dodoma', 'I found 4 available properties that might match:\n- Test Property c03374 — TSh 320,000/month, 2 bed(s), TestWard, TestDistrict6332ee, TestRegion\n- Test Property ca58e7 — TSh 320,000/month, 2 bed(s), TestWard, TestDistrictac2aaa, TestRegion\n- Test Property 50fd26 — TSh 320,000/month, 2 bed(s), TestWard, TestDistrictf0844e, TestRegion\n- Moonlight Park — TSh 600,000/month, 2 bed(s), Temeke, TEMEKE, Dar es Salaam\nTap a property below to see more, or ask me something more specific.', '2026-08-11 18:57:05'),
(33, NULL, 'bc6a669f2a481fea2891856f8c049d33', 'hiii', 'I found 1 available property that might match:\n- Moonlight Park — TSh 600,000/month, 2 bed(s), Temeke, TEMEKE, Dar es Salaam\nTap a property below to see more, or ask me something more specific.', '2026-08-12 09:24:49'),
(34, NULL, 'property-24-3587c06c49726a1ec53ecf764241594b', 'is it taken', 'I can tell you this property has 2 bedroom(s), 1 bathroom(s), rents for TSh 600,000/month in Temeke, TEMEKE, Dar es Salaam. Ask me something more specific, or contact the landlord for details not listed here.', '2026-08-12 09:25:14'),
(35, NULL, 'match-09782f96f4dcb364', '2 room that are same', 'Found 1 matching properties.', '2026-08-12 09:25:33'),
(36, NULL, 'ece596818f5947764e6383c7bf85cba4', 'room with 2 beds', 'I found 1 available property that might match:\n- Moonlight Park — TSh 600,000/month, 2 bed(s), Temeke, TEMEKE, Dar es Salaam\nTap a property below to see more, or ask me something more specific.', '2026-08-12 10:26:25'),
(37, NULL, 'ece596818f5947764e6383c7bf85cba4', 'room with 1 bed', 'I found 1 available property that might match:\n- Moonlight Park — TSh 600,000/month, 2 bed(s), Temeke, TEMEKE, Dar es Salaam\nTap a property below to see more, or ask me something more specific.', '2026-08-12 10:26:47'),
(38, 20, '38c76cd1c33429e9e5326e6edb36f4aa', 'iwant room in dodoma', 'I found 1 available property that might match:\n- Moonlight Park — TSh 600,000/month, 2 bed(s), Temeke, TEMEKE, Dar es Salaam\nTap a property below to see more, or ask me something more specific.', '2026-08-14 13:10:04'),
(39, 20, 'match-1c72b2fe095bdcee', 'room in dodoma', 'Found 1 matching properties.', '2026-08-14 13:10:22'),
(40, 20, 'property-24-7524e9c2db87fd31a97d8488789c57c9', 'can i have room in dodoma', 'It has 2 bedroom(s) and 1 bathroom(s).', '2026-08-14 13:11:06'),
(41, 20, 'property-24-604bd89593cf8295bdf0484cac0b2e1e', 'can i have room in dodoma', 'It has 2 bedroom(s) and 1 bathroom(s).', '2026-08-14 13:11:36'),
(42, NULL, '348be9d11f8a3f0777434a91356c3ee5', 'what room as small cost', 'I found 1 available property that might match:\n- Moonlight Park — TSh 600,000/month, 2 bed(s), Temeke, TEMEKE, Dar es Salaam\nTap a property below to see more, or ask me something more specific.', '2026-08-14 13:20:09'),
(43, NULL, 'property-24-4974266be3a701db77dde1b987c2d74b', 'how beds', 'It has 2 bedroom(s) and 1 bathroom(s).', '2026-08-14 13:20:36'),
(44, NULL, 'match-7e38e85384a23395', 'rooms in dodoma', 'Found 1 matching properties.', '2026-08-14 13:20:58'),
(45, 20, 'c9e27c74f10ac7f14ac72489f5bb69ee', 'show 3 big rooms with high cost', 'I found 1 available property that might match:\n- Moonlight Park — TSh 600,000/month, 2 bed(s), Temeke, TEMEKE, Dar es Salaam\nTap a property below to see more, or ask me something more specific.', '2026-08-14 13:22:24'),
(46, NULL, 'match-f6b402d68e071bd8', 'house with small cost', 'Found 1 matching properties.', '2026-08-14 17:36:54'),
(47, NULL, 'match-9a44f1e83af9d277', 'house found in mbezi', 'Found 1 matching properties.', '2026-08-14 17:37:14'),
(48, NULL, 'match-766bbddee7e1d109', 'hiii', 'Found 1 matching properties.', '2026-08-14 17:38:10'),
(49, NULL, 'match-76c71f1c5594a2b3', 'hii', 'Found 1 matching properties.', '2026-08-14 18:42:01'),
(50, 20, '7162172aea84e312b97ba1d3579e3515', 'what room as small cost', 'I found 1 available property that might match:\n- Moonlight Park — TSh 600,000/month, 2 bed(s), Temeke, TEMEKE, Dar es Salaam\nTap a property below to see more, or ask me something more specific.', '2026-08-14 18:46:27'),
(51, 20, '7162172aea84e312b97ba1d3579e3515', 'iwant room in dodoma', 'I found 1 available property that might match:\n- Moonlight Park — TSh 600,000/month, 2 bed(s), Temeke, TEMEKE, Dar es Salaam\nTap a property below to see more, or ask me something more specific.', '2026-08-14 18:47:09'),
(52, NULL, 'test', 'room with 2 beds', 'I found 1 available property that might match:\n- Moonlight Park — TSh 600,000/month, 2 bed(s), Temeke, TEMEKE, Dar es Salaam\nTap a property below to see more, or ask me something more specific.', '2026-08-14 18:57:20'),
(53, NULL, 'match-1521865b9032005d', 'room with 2 beds', 'Found 1 matching properties.', '2026-08-14 18:58:27'),
(54, 20, 'match-92301b3b886c9016', 'room i mbenzi', 'Found 1 matching properties.', '2026-08-14 19:00:19'),
(55, 20, 'property-24-9958c1c126ac861212bad5365cd0edf9', 'can i have room in dodoma', 'It has 2 bedroom(s) and 1 bathroom(s).', '2026-08-14 19:00:31'),
(56, 20, 'property-24-d1e615296c3a3f49230f71d1ce71950a', 'can i have room in dodoma', 'It has 2 bedroom(s) and 1 bathroom(s).', '2026-08-14 19:00:36'),
(57, 20, 'property-24-7735a563758e4f4239bf9af1dfa2736d', 'can i have room in dodoma', 'It has 2 bedroom(s) and 1 bathroom(s).', '2026-08-14 19:00:36'),
(58, 20, 'property-24-843d4214a32854f578765689983121ba', 'can i have room in dodoma', 'It has 2 bedroom(s) and 1 bathroom(s).', '2026-08-14 19:00:36'),
(59, 20, 'property-24-2d9f736e87b3ddbea3a8061f79bce8ed', 'can i have room in dodoma', 'It has 2 bedroom(s) and 1 bathroom(s).', '2026-08-14 19:00:37'),
(60, 20, 'property-24-91927946754b023c975ed00df17855ff', 'can i have room in dodoma', 'It has 2 bedroom(s) and 1 bathroom(s).', '2026-08-14 19:01:23'),
(61, NULL, 'legacy-chat-test', 'Find me a room in Dar es Salaam under 500000', 'I couldn\'t find any available properties matching that yet. Try telling me a location, budget, and number of bedrooms - for example \"2 bedroom apartment in Mbezi under 600,000\".', '2026-08-14 19:18:00'),
(62, NULL, 'match-392c36c6d197f09e', 'two bedroom in Mbezi under 600000', 'Found 1 matching properties.', '2026-08-14 19:18:04'),
(63, NULL, 'legacy-chat-test', 'Find me a room in Dar es Salaam under 500000', 'I couldn\'t find any available properties matching that yet. Try telling me a location, budget, and number of bedrooms - for example \"2 bedroom apartment in Mbezi under 600,000\".', '2026-08-14 19:18:08'),
(64, NULL, 'match-88a57b2d52fa3d84', 'two bedroom in Mbezi under 600000', 'Found 1 matching properties.', '2026-08-14 19:18:08'),
(65, NULL, 'legacy-chat-test', 'Find me a room in Dar es Salaam under 500000', 'I couldn\'t find any available properties matching that yet. Try telling me a location, budget, and number of bedrooms - for example \"2 bedroom apartment in Mbezi under 600,000\".', '2026-08-14 19:21:10'),
(66, NULL, 'match-5d043ab37cc9f5d9', 'two bedroom in Mbezi under 600000', 'Found 1 matching properties.', '2026-08-14 19:21:10'),
(67, NULL, 'legacy-chat-test', 'Find me a room in Dar es Salaam under 500000', 'I couldn\'t find any available properties matching that yet. Try telling me a location, budget, and number of bedrooms - for example \"2 bedroom apartment in Mbezi under 600,000\".', '2026-08-14 19:25:19'),
(68, NULL, 'match-143508ec17090104', 'two bedroom in Mbezi under 600000', 'Found 1 matching properties.', '2026-08-14 19:25:19'),
(69, NULL, 'legacy-chat-test', 'Find me a room in Dar es Salaam under 500000', 'I couldn\'t find any available properties matching that yet. Try telling me a location, budget, and number of bedrooms - for example \"2 bedroom apartment in Mbezi under 600,000\".', '2026-08-14 19:39:09'),
(70, NULL, 'match-6af8f1a1b9a23a0a', 'two bedroom in Mbezi under 600000', 'Found 1 matching properties.', '2026-08-14 19:39:09'),
(71, NULL, 'debug-1', 'Find me a room in Dar es Salaam under 500000', 'I couldn\'t find any available properties matching that yet. Try telling me a location, budget, and number of bedrooms - for example \"2 bedroom apartment in Mbezi under 600,000\".', '2026-08-14 19:44:17'),
(72, NULL, 'debug-1', 'Find me a room in Dar es Salaam under 500000', 'I couldn\'t find any available properties matching that yet. Try telling me a location, budget, and number of bedrooms - for example \"2 bedroom apartment in Mbezi under 600,000\".', '2026-08-14 19:45:07'),
(73, NULL, '63b2e2ec0cece11de6a2da712f6ab62d', 'Find me a room in Dar es Salaam under 500000', 'I couldn\'t find any available properties matching that yet. Try telling me a location, budget, and number of bedrooms - for example \"2 bedroom apartment in Mbezi under 600,000\".', '2026-08-14 19:47:09'),
(74, NULL, '63b2e2ec0cece11de6a2da712f6ab62d', 'hii', 'I found 1 available property that might match:\n- Moonlight Park — TSh 600,000/month, 2 bed(s), Temeke, TEMEKE, Dar es Salaam\nTap a property below to see more, or ask me something more specific.', '2026-08-14 19:50:46'),
(75, NULL, '63b2e2ec0cece11de6a2da712f6ab62d', 'properties of moonpark', 'I found 1 available property that might match:\n- Moonlight Park — TSh 600,000/month, 2 bed(s), Temeke, TEMEKE, Dar es Salaam\nTap a property below to see more, or ask me something more specific.', '2026-08-14 19:53:52');

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `landlord_id` int(11) DEFAULT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `customer_email` varchar(100) DEFAULT NULL,
  `customer_phone` varchar(20) DEFAULT NULL,
  `amount` decimal(12,2) DEFAULT NULL,
  `arrival_date` date DEFAULT NULL,
  `status` enum('pending','confirmed','cancelled') DEFAULT 'pending',
  `payment_ref` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `room_id`, `user_id`, `landlord_id`, `customer_name`, `customer_email`, `customer_phone`, `amount`, `arrival_date`, `status`, `payment_ref`, `created_at`) VALUES
(1, 11, 7, NULL, 'aman abeid', 'abeidaman@gmail.com', '0750796327', 900000.00, '2026-07-18', 'confirmed', 'TX-793754', '2026-07-11 20:29:53'),
(3, 13, 9, NULL, 'win joas', 'joaswin@gmail.com', '0750796327', 400000.00, '2026-07-20', 'confirmed', 'TX-016913', '2026-07-13 16:26:57'),
(4, 13, 6, NULL, 'Amos abel', 'abelamos@gmail.com', '0750796327', 400000.00, '2026-07-20', 'confirmed', 'TX-148575', '2026-07-13 16:29:08'),
(5, 23, 8, NULL, 'amad amos', 'amosamad@gmail.com', '0750796327', 70000.00, '2026-07-20', 'confirmed', 'TX-565706', '2026-07-13 19:06:05'),
(6, 23, 8, NULL, 'amad amos', 'amosamad@gmail.com', '0750796327', 70000.00, '2026-07-20', 'confirmed', 'TX-411563', '2026-07-13 19:53:31'),
(7, 22, 8, NULL, 'amad amos', 'amosamad@gmail.com', '0750796327', 90000.00, '2026-07-20', 'confirmed', 'TX-476633', '2026-07-13 19:54:36');

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contracts`
--

CREATE TABLE `contracts` (
  `id` int(11) NOT NULL,
  `contract_number` varchar(50) NOT NULL,
  `booking_id` int(11) DEFAULT NULL,
  `property_id` int(11) DEFAULT NULL,
  `room_id` int(11) DEFAULT NULL,
  `landlord_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `monthly_rent` decimal(10,2) NOT NULL,
  `deposit` decimal(10,2) DEFAULT 0.00,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `payment_terms` text DEFAULT NULL,
  `responsibilities` text DEFAULT NULL,
  `termination_conditions` text DEFAULT NULL,
  `other_terms` text DEFAULT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'DRAFT',
  `customer_accepted_at` timestamp NULL DEFAULT NULL,
  `landlord_accepted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contract_acceptances`
--

CREATE TABLE `contract_acceptances` (
  `id` int(11) NOT NULL,
  `contract_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `role` varchar(30) NOT NULL,
  `accepted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `ip_address` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `email_verifications`
--

CREATE TABLE `email_verifications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `token_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `verified_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `email_verifications`
--

INSERT INTO `email_verifications` (`id`, `user_id`, `token_hash`, `expires_at`, `verified_at`, `created_at`) VALUES
(1, 14, '872b3219b2d3457a66da2955b499ab19046f2f8ad033b8b7383b1c528424d8cc', '2026-08-12 17:48:45', NULL, '2026-08-11 15:48:45'),
(2, 15, 'a6b8dd234324fa7289ff515e94c362fd86822cf481571d921ceaf3c2701e98ba', '2026-08-12 17:49:57', NULL, '2026-08-11 15:49:57'),
(3, 16, 'fcaa576f309a96e853c3a187e75f083593dad182265601945b5fef8d95ce79a4', '2026-08-12 17:52:41', NULL, '2026-08-11 15:52:41'),
(4, 17, '3f989c487d7643cc60a02b848c2170d71f724ea7b31c08f9ff7a3ca545b907f0', '2026-08-12 17:53:13', NULL, '2026-08-11 15:53:13'),
(5, 18, '89c2f4a14f887eaa82215b43ea1a4920181ddc9fa2ade49505d57a2c3a834180', '2026-08-12 17:54:26', NULL, '2026-08-11 15:54:26'),
(6, 19, '97ccb951fdca0d4334402549f47f6bbe79bb19c5e0e1ebd79e19c1cee960aacc', '2026-08-12 17:55:22', NULL, '2026-08-11 15:55:22'),
(7, 20, 'cda0ebb54423c13a6f6ac1389f7e9d0d5f7249741f695034ced125067fac553b', '2026-08-15 15:09:38', NULL, '2026-08-14 13:09:38'),
(8, 21, '66b894dfc0f85bd6e66dda752752597a7794f2d83af5113cd76831924f0cfeff', '2026-08-15 15:12:30', NULL, '2026-08-14 13:12:30');

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL,
  `email` varchar(191) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `success` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login_attempts`
--

INSERT INTO `login_attempts` (`id`, `email`, `ip_address`, `success`, `created_at`) VALUES
(1, 'abdulaziz@gmail.com', '::1', 1, '2026-08-09 19:37:34'),
(2, 'admin@smartrent.co.tz', '::1', 1, '2026-08-09 19:39:00'),
(3, 'matajoan@gmail.com', '::1', 1, '2026-08-09 19:40:25'),
(4, 'matajoan@gmail.com', '::1', 1, '2026-08-10 06:28:02'),
(5, 'matajoan@gmail.com', '::1', 1, '2026-08-10 20:49:37'),
(6, 'abdulaziz@gmail.com', '::1', 1, '2026-08-10 20:56:21'),
(7, 'admin@smartrent.co.tz', '127.0.0.1', 1, '2026-08-11 15:29:06'),
(8, 'jamesemma@gmail.com', '127.0.0.1', 1, '2026-08-11 18:51:50'),
(9, 'abelamina@gmail.com', '127.0.0.1', 1, '2026-08-11 18:54:02'),
(10, 'abelamina@gmail.com', '127.0.0.1', 1, '2026-08-11 19:08:37'),
(11, 'admin@smartrent.co.tz', '127.0.0.1', 1, '2026-08-11 19:08:48'),
(12, 'jamesemma@gmail.com', '127.0.0.1', 1, '2026-08-12 09:24:28'),
(13, 'admin@smartrent.co.tz', '127.0.0.1', 1, '2026-08-12 10:02:47'),
(14, 'admin@smartrent.co.tz', '127.0.0.1', 1, '2026-08-12 10:25:57'),
(15, 'foo@example.com', '127.0.0.1', 0, '2026-08-12 10:27:46'),
(16, 'abdulaziz@gmail.com', '::1', 1, '2026-08-12 11:44:37'),
(17, 'admin@smartrent.co.tz', '::1', 1, '2026-08-12 11:44:55'),
(18, 'admin@smartrent.co.tz', '127.0.0.1', 1, '2026-08-14 13:07:17'),
(19, 'kamanguafrica@gmail.com', '127.0.0.1', 1, '2026-08-14 13:17:48'),
(20, 'admin@smartrent.co.tz', '127.0.0.1', 1, '2026-08-14 13:18:34'),
(21, 'msafirievaline@gmail.com', '127.0.0.1', 1, '2026-08-14 13:21:48'),
(22, 'admin@smartrent.co.tz', '127.0.0.1', 1, '2026-08-14 18:00:44'),
(23, 'msafirievaline@gmail.com', '127.0.0.1', 1, '2026-08-14 18:46:20');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `name`, `email`, `phone`, `message`, `created_at`) VALUES
(1, 'Abel Kajuna', 'kajunaabel91@gmail.com', '0750796327', 'hellow agent can i have master room', '2026-07-11 15:53:56'),
(2, 'amina abel', 'abelamina@gmail.com', '0750976327', 'iwant o book two rooms of studio can i have discount', '2026-07-12 20:49:39'),
(3, 'win joas', 'joaswin@gmail.com', '0750796327', 'i want two double rooms in dodoma', '2026-08-04 10:01:55');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `landlord_id` int(11) DEFAULT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `customer_email` varchar(100) DEFAULT NULL,
  `customer_phone` varchar(20) DEFAULT NULL,
  `arrival_date` date DEFAULT NULL,
  `status` enum('ordered','confirmed','cancelled') DEFAULT 'ordered',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `room_id`, `user_id`, `landlord_id`, `customer_name`, `customer_email`, `customer_phone`, `arrival_date`, `status`, `created_at`) VALUES
(1, 11, 7, NULL, 'aman abeid', 'abeidaman@gmail.com', '0750796327', '2026-07-22', 'ordered', '2026-07-11 20:30:43'),
(2, 11, 4, NULL, 'Abel Kajuna', 'kajunaabel91@gmail.com', '0750796327', '2026-07-21', 'ordered', '2026-07-11 20:31:42'),
(3, 10, 6, NULL, 'Amos abel', 'abelamos@gmail.com', '0750796327', '2026-07-29', 'confirmed', '2026-07-11 20:34:10'),
(4, 9, 9, NULL, 'win joas', 'joaswin@gmail.com', '0750796327', '2026-07-23', 'confirmed', '2026-07-11 21:36:04'),
(5, 13, 1, NULL, 'Admin', 'admin@smartrent.co.tz', '0750796327', '2026-07-14', 'ordered', '2026-07-12 20:35:49'),
(6, 21, 6, NULL, 'Amos abel', 'abelamos@gmail.com', '0750796327', '2026-07-15', 'confirmed', '2026-07-13 19:55:26'),
(7, 20, 6, NULL, 'Amos abel', 'abelamos@gmail.com', '0750796327', '2026-07-15', 'confirmed', '2026-07-13 19:55:40');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `token_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `booking_id` int(11) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `amount` decimal(12,2) NOT NULL,
  `method` varchar(50) DEFAULT NULL,
  `status` enum('pending','successful','failed','cancelled') DEFAULT 'pending',
  `transaction_ref` varchar(100) DEFAULT NULL,
  `recipient_number` varchar(50) DEFAULT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `customer_email` varchar(100) DEFAULT NULL,
  `customer_phone` varchar(20) DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `receipt_number` varchar(100) DEFAULT NULL,
  `payment_status` enum('pending','successful','failed','cancelled') DEFAULT 'pending',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payouts`
--

CREATE TABLE `payouts` (
  `id` int(11) NOT NULL,
  `landlord_id` int(11) NOT NULL,
  `payment_id` int(11) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'PENDING',
  `payout_method` varchar(50) DEFAULT NULL,
  `payout_reference` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `platform_settings`
--

CREATE TABLE `platform_settings` (
  `setting_key` varchar(100) NOT NULL,
  `setting_value` varchar(255) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `platform_settings`
--

INSERT INTO `platform_settings` (`setting_key`, `setting_value`, `updated_at`) VALUES
('platform_commission_rate', '10', '2026-08-09 19:15:36');

-- --------------------------------------------------------

--
-- Table structure for table `properties`
--

CREATE TABLE `properties` (
  `id` int(11) NOT NULL,
  `landlord_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(50) DEFAULT NULL,
  `apartment` varchar(100) DEFAULT NULL,
  `house_no` varchar(50) DEFAULT NULL,
  `region` varchar(100) DEFAULT NULL,
  `district` varchar(100) DEFAULT NULL,
  `ward` varchar(100) DEFAULT NULL,
  `street` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `coords` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `bedrooms` int(11) DEFAULT 0,
  `bathrooms` int(11) DEFAULT 0,
  `amenities` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`amenities`)),
  `furnished` varchar(50) DEFAULT NULL,
  `room_size` int(11) DEFAULT NULL,
  `monthly_rent` decimal(12,2) DEFAULT NULL,
  `deposit` decimal(12,2) DEFAULT NULL,
  `service_charge` decimal(12,2) DEFAULT NULL,
  `availability` enum('available','booked','taken') DEFAULT 'available',
  `images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`images`)),
  `video` varchar(255) DEFAULT NULL,
  `virtual_tour` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `properties`
--

INSERT INTO `properties` (`id`, `landlord_id`, `name`, `type`, `apartment`, `house_no`, `region`, `district`, `ward`, `street`, `location`, `coords`, `description`, `bedrooms`, `bathrooms`, `amenities`, `furnished`, `room_size`, `monthly_rent`, `deposit`, `service_charge`, `availability`, `images`, `video`, `virtual_tour`, `created_at`) VALUES
(3, 10, 'Moonlight Park', 'Apartment', 'A', 'room3', 'Dar es Salaam', 'TEMEKE', 'Temeke', 'Wester road', 'Dar es salaam', '', '', 2, 1, '{\"kitchen\":true,\"parking\":true,\"wifi\":false,\"water\":true,\"electricity\":true,\"security\":true}', 'Fully Furnished', 11, 600000.00, 25000.00, 30000.00, 'available', '[\"uploads\\/property_1783973338_0.jfif\"]', '', '', '2026-07-13 20:08:58'),
(5, 14, 'Test Property 50fd26', 'Apartment', 'A1', '12', 'TestRegion', 'TestDistrictf0844e', 'TestWard', 'TestStreet', 'TestDistrictf0844e, TestRegion', '0.0000,0.0000', 'Dynamic listing created by automated test.', 2, 1, '[\"parking\",\"security\"]', 'Furnished', 80, 320000.00, 50000.00, 10000.00, 'available', '[\"uploads\\/property_1786463325_4433fd9acdf2.png\"]', NULL, NULL, '2026-08-11 15:48:45'),
(6, 15, 'Test Property ca58e7', 'Apartment', 'A1', '12', 'TestRegion', 'TestDistrictac2aaa', 'TestWard', 'TestStreet', 'TestDistrictac2aaa, TestRegion', '0.0000,0.0000', 'Dynamic listing created by automated test.', 2, 1, '[\"parking\",\"security\"]', 'Furnished', 80, 320000.00, 50000.00, 10000.00, 'available', '[\"uploads\\/property_1786463397_d66ee96aeb6f.png\"]', NULL, NULL, '2026-08-11 15:49:57'),
(7, 16, 'Test Property c03374', 'Apartment', 'A1', '12', 'TestRegion', 'TestDistrict6332ee', 'TestWard', 'TestStreet', 'TestDistrict6332ee, TestRegion', '0.0000,0.0000', 'Dynamic listing created by automated test.', 2, 1, '[\"parking\",\"security\"]', 'Furnished', 80, 320000.00, 50000.00, 10000.00, 'available', '[\"uploads\\/property_1786463561_389a533bba00.png\"]', NULL, NULL, '2026-08-11 15:52:41');

-- --------------------------------------------------------

--
-- Table structure for table `receipts`
--

CREATE TABLE `receipts` (
  `id` int(11) NOT NULL,
  `payment_id` int(11) NOT NULL,
  `receipt_number` varchar(100) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `customer_email` varchar(255) NOT NULL,
  `customer_phone` varchar(50) NOT NULL,
  `room_name` varchar(255) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `transaction_ref` varchar(100) NOT NULL,
  `issued_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `remember_tokens`
--

CREATE TABLE `remember_tokens` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `selector` char(24) NOT NULL,
  `token_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `area` varchar(100) DEFAULT NULL,
  `price` decimal(12,2) NOT NULL,
  `size` int(11) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `beds` int(11) DEFAULT 1,
  `badge` varchar(50) DEFAULT NULL,
  `status` enum('available','booked','ordered','taken') DEFAULT 'available',
  `image` longtext DEFAULT NULL,
  `landlord_id` int(11) DEFAULT NULL,
  `virtual_tour` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`id`, `title`, `location`, `area`, `price`, `size`, `type`, `beds`, `badge`, `status`, `image`, `landlord_id`, `virtual_tour`, `created_at`, `updated_at`) VALUES
(16, 'kibaigwa', 'Dodoma, kibaigwa', 'kibaigwa', 800000.00, 50, 'Single Room', 2, 'premium', 'available', 'uploads/room_1783967707_5504.jfif', NULL, NULL, '2026-07-13 18:35:07', '2026-07-13 18:35:07'),
(17, 'kajuna lodge', 'Dar es Salaam, mbezi beach', 'mbezi beach', 50000.00, 40, 'Studio', 2, 'premium', 'available', 'uploads/room_1783967773_8622.jfif', NULL, NULL, '2026-07-13 18:36:13', '2026-07-13 18:36:13'),
(18, 'maggy host', 'Arusha, Area C', 'Area C', 90000.00, 30, 'Studio', 2, 'popular', 'available', 'uploads/room_1783967821_5222.jfif', NULL, NULL, '2026-07-13 18:37:01', '2026-07-13 18:37:01'),
(19, 'Area C lodge', 'Dodoma, nzugun', 'nzugun', 600000.00, 20, 'Double Room', 2, 'premium', 'available', 'uploads/room_1783967893_5285.jfif', NULL, NULL, '2026-07-13 18:38:13', '2026-07-13 18:38:13'),
(20, 'animol', 'Mwanza, Msasani', 'Msasani', 100000.00, 30, 'Studio', 2, 'premium', 'ordered', 'uploads/room_1783967961_7442.jfif', NULL, NULL, '2026-07-13 18:39:21', '2026-07-13 19:55:40'),
(21, 'Evah LODGE', 'Mbeya, mbeya', 'mbeya', 600000.00, 70, 'Studio', 3, 'premium', 'ordered', 'uploads/room_1783968044_4833.jfif', NULL, NULL, '2026-07-13 18:40:44', '2026-07-13 19:55:26'),
(22, 'sun park', 'Dar es Salaam, kimara', 'kimara', 90000.00, 30, 'Single Room', 1, 'popular', 'taken', 'uploads/room_1783968168_8083.jfif', NULL, NULL, '2026-07-13 18:42:48', '2026-07-13 19:54:36'),
(23, 'Yohana House', 'Dar es Salaam, Makongo', 'Makongo', 70000.00, 20, 'Single Room', 1, 'popular', 'taken', 'uploads/room_1783968242_8374.jfif', NULL, NULL, '2026-07-13 18:44:02', '2026-07-13 19:53:31'),
(24, 'Moonlight Park', 'Dar es Salaam, TEMEKE, Temeke, Wester road', 'TEMEKE', 600000.00, 11, 'Apartment', 2, '', 'available', 'uploads/property_1783973338_0.jfif', 10, NULL, '2026-07-13 20:08:58', '2026-07-13 20:08:58');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('Admin','Landlord','Customer','Agent') DEFAULT 'Customer',
  `email_verified_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `failed_login_attempts` int(11) NOT NULL DEFAULT 0,
  `locked_until` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `email`, `phone`, `password_hash`, `role`, `email_verified_at`, `created_at`, `failed_login_attempts`, `locked_until`) VALUES
(1, 'Admin', 'admin@smartrent.co.tz', NULL, '$2y$10$H3LCqQkhbwOuTGEOMnGuuenW17bh3RJ/gq0d04ReGa605hJglHCIy', 'Admin', NULL, '2026-07-10 12:22:36', 0, NULL),
(2, 'Anitha Abel', 'abelanitha@gmail.com', '', '$2y$10$9hQzZlF1.B.4E0TlzhysF.xO94Zty2HAUQ1yQIH0qpiW8E6LbRdz2', 'Customer', NULL, '2026-07-10 13:13:10', 0, NULL),
(4, 'Abel Kajuna', 'kajunaabel91@gmail.com', '', '$2y$10$VTjeK9G3q1AECyxcJTKRauA9HsKh/0iIOugcBA61F7SjdTCB/.dfC', 'Customer', NULL, '2026-07-10 21:28:29', 0, NULL),
(5, 'innocent kajuna', 'kajunainnocent@gmail.com', '', '$2y$10$FFewjwWF/J7RHn4XoyMlHeGbfp8V1EU5lWwNmUxzW7R9NwIELRg3y', 'Customer', NULL, '2026-07-10 21:37:44', 0, NULL),
(6, 'Amos abel', 'abelamos@gmail.com', '', '$2y$10$GTj9ifubFDK.WW5RXozmtef7dNWbnZLXzB3/bjKRrgM04hp4Gl1OO', 'Customer', NULL, '2026-07-11 15:50:05', 0, NULL),
(7, 'aman abeid', 'abeidaman@gmail.com', '', '$2y$10$UkyBX03QzYpvfwgLshNlauX.vMrgOfVW/ODUrteXta0eEA.qxM/vC', 'Customer', NULL, '2026-07-11 19:27:17', 0, NULL),
(8, 'amad amos', 'amosamad@gmail.com', '', '$2y$10$AbGvKmvosF30FuvGaBKG7utyqnWf4STdSqxjHZC4tWn0QxHyoPdb6', 'Customer', NULL, '2026-07-11 20:35:21', 0, NULL),
(9, 'win joas', 'joaswin@gmail.com', '', '$2y$10$63d1rhvgwZYhaVobON.oWue1CJjL53/C4haSzmAJyfkW9rnHmanBe', 'Customer', NULL, '2026-07-11 21:33:35', 0, NULL),
(10, 'Emma James', 'jamesemma@gmail.com', '', '$2y$10$C1IhvsehhK/.Mh3atOuZdutYZ7XSe9MFHh/ymbzDqCkYqcFXYybEG', 'Landlord', NULL, '2026-07-12 20:39:45', 0, NULL),
(11, 'Amina Abel', 'abelamina@gmail.com', '', '$2y$10$EgNWadtDeQ0sgjs1iJXXEOdTyZdYs46zrTF8I8cgcD7lokkVcFSFy', 'Customer', NULL, '2026-07-12 20:47:24', 0, NULL),
(12, 'joan   mata', 'matajoan@gmail.com', '', '$2y$10$.W3HfWgi8aeyDlalCzv.5.eWfosUeK0jq/GKaqauGe.7CMQFgL6qW', 'Customer', NULL, '2026-08-07 08:52:11', 0, NULL),
(13, 'aziz abdul', 'abdulaziz@gmail.com', '', '$2y$10$2W/hoH7k.Yz4hF44qbsaseBHODim9k4XZ69DmFGTG8tbNmN2Gl186', 'Landlord', NULL, '2026-08-07 08:53:24', 0, NULL),
(14, 'AI Live Test Landlord', 'landlord_test_00a97c97@example.com', '0700111222', '$2y$10$ggQhlHZoT04YveNnF3beQ.GWdelReUKZGpflZqCJNR6WHfR0DnWQ2', 'Landlord', NULL, '2026-08-11 15:48:45', 0, NULL),
(15, 'AI Live Test Landlord', 'landlord_test_11f517e8@example.com', '0700111222', '$2y$10$9k3nWlTtIgKP/5sE3og./u99e.yoYM75RbVTijW58fDwsw8qtu/Mi', 'Landlord', NULL, '2026-08-11 15:49:57', 0, NULL),
(16, 'AI Live Test Landlord', 'landlord_test_36e9fb45@example.com', '0700111222', '$2y$10$nRunogJuvm/NJrFNbHVcw.HWuuO4bLpVfxAWqoUmm0Ocbkd5vtosm', 'Landlord', NULL, '2026-08-11 15:52:41', 0, NULL),
(17, 'AI Live Test Landlord', 'landlord_test_b35faff4@example.com', '0700111222', '$2y$10$an1V3ff1N3VvFZ/mW/SVzeDfgv9LI6QRgzjl2moKa8wzhjihJbbgK', 'Landlord', NULL, '2026-08-11 15:53:13', 0, NULL),
(18, 'AI Live Test Landlord', 'landlord_test_af0f855f@example.com', '0700111222', '$2y$10$5dOVdufb1iweqxLkxCGWyOuBuRrQnpuct6Qt9sHn2x8VkHxeZXJ7O', 'Landlord', NULL, '2026-08-11 15:54:26', 0, NULL),
(19, 'AI Live Test Landlord', 'landlord_test_2f476504@example.com', '0700111222', '$2y$10$P9cOIvaJdlCyVCjiics1/OEOGH6u1.zL4g3SJ/OMDPEIrUpQCK5pW', 'Landlord', NULL, '2026-08-11 15:55:22', 0, NULL),
(20, 'Evaline msafiri', 'msafirievaline@gmail.com', '', '$2y$10$zBDQtEf6mG87QBqFEkveaeDV.3sDqdAKLlZpd1itzMLpvOqtQ7P8K', 'Customer', NULL, '2026-08-14 13:09:38', 0, NULL),
(21, 'africa kamangu', 'kamanguafrica@gmail.com', '', '$2y$10$g1ZJWcxPv4XMmGO014GPT.RqX37Psd/PZcHvzbjkOm9TwoTlSpnfO', 'Landlord', NULL, '2026-08-14 13:12:30', 0, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ai_conversations`
--
ALTER TABLE `ai_conversations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_ai_conv_session` (`session_id`),
  ADD KEY `idx_ai_conv_customer` (`customer_id`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`),
  ADD KEY `expiration` (`expiration`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`),
  ADD KEY `expiration` (`expiration`);

--
-- Indexes for table `contracts`
--
ALTER TABLE `contracts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `contract_number` (`contract_number`),
  ADD KEY `idx_contracts_landlord` (`landlord_id`),
  ADD KEY `idx_contracts_customer` (`customer_id`),
  ADD KEY `idx_contracts_booking` (`booking_id`),
  ADD KEY `idx_contracts_status` (`status`);

--
-- Indexes for table `contract_acceptances`
--
ALTER TABLE `contract_acceptances`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_acceptances_contract` (`contract_id`);

--
-- Indexes for table `email_verifications`
--
ALTER TABLE `email_verifications`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_email_verifications_token_hash` (`token_hash`),
  ADD KEY `idx_email_verifications_user` (`user_id`);

--
-- Indexes for table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_login_attempts_ip_time` (`ip_address`,`created_at`),
  ADD KEY `idx_login_attempts_email_time` (`email`,`created_at`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_password_resets_token_hash` (`token_hash`),
  ADD KEY `idx_password_resets_user` (`user_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payouts`
--
ALTER TABLE `payouts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_payouts_landlord` (`landlord_id`),
  ADD KEY `idx_payouts_status` (`status`);

--
-- Indexes for table `platform_settings`
--
ALTER TABLE `platform_settings`
  ADD PRIMARY KEY (`setting_key`);

--
-- Indexes for table `properties`
--
ALTER TABLE `properties`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `receipts`
--
ALTER TABLE `receipts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `receipt_number` (`receipt_number`),
  ADD KEY `idx_payment` (`payment_id`),
  ADD KEY `idx_receipt_number` (`receipt_number`);

--
-- Indexes for table `remember_tokens`
--
ALTER TABLE `remember_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_remember_tokens_selector` (`selector`),
  ADD KEY `idx_remember_tokens_user` (`user_id`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ai_conversations`
--
ALTER TABLE `ai_conversations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `contracts`
--
ALTER TABLE `contracts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contract_acceptances`
--
ALTER TABLE `contract_acceptances`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `email_verifications`
--
ALTER TABLE `email_verifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payouts`
--
ALTER TABLE `payouts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `properties`
--
ALTER TABLE `properties`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `receipts`
--
ALTER TABLE `receipts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `remember_tokens`
--
ALTER TABLE `remember_tokens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `contract_acceptances`
--
ALTER TABLE `contract_acceptances`
  ADD CONSTRAINT `contract_acceptances_ibfk_1` FOREIGN KEY (`contract_id`) REFERENCES `contracts` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `email_verifications`
--
ALTER TABLE `email_verifications`
  ADD CONSTRAINT `fk_email_verifications_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD CONSTRAINT `fk_password_resets_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `receipts`
--
ALTER TABLE `receipts`
  ADD CONSTRAINT `receipts_ibfk_1` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `remember_tokens`
--
ALTER TABLE `remember_tokens`
  ADD CONSTRAINT `fk_remember_tokens_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
