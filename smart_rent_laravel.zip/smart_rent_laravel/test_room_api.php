<?php
$rooms = file_get_contents('http://127.0.0.1:8000/api/rooms');
$data = json_decode($rooms, true);

if (is_array($data) && count($data) > 0) {
    echo "Total rooms: " . count($data) . "\n";
    echo "First room:\n";
    $r = $data[0];
    echo "  ID: " . $r['id'] . "\n";
    echo "  Title: " . $r['title'] . "\n";
    echo "  Price: " . $r['price'] . "\n";
    echo "  Image: " . $r['image'] . "\n";
    echo "\nAPI is working correctly!\n";
} else {
    echo "Error: API not responding with data\n";
}
