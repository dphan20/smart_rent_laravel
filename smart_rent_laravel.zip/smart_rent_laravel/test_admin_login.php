<?php
// Test admin login timing and session persistence

$adminEmail = 'admin@smartrent.co.tz';
$adminPassword = 'Admin123!Test';
$jar = tempnam(sys_get_temp_dir(), 'adm');

echo "Testing Admin Login Flow\n";
echo "=======================\n\n";

// LOGIN
echo "1. Admin Login Request...\n";
$startTime = microtime(true);

$ch = curl_init('http://127.0.0.1:8000/api/auth/login');
curl_setopt_array($ch, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_COOKIEJAR => $jar,
  CURLOPT_COOKIEFILE => $jar,
  CURLOPT_POST => true,
  CURLOPT_POSTFIELDS => json_encode(['email' => $adminEmail, 'password' => $adminPassword]),
  CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Accept: application/json']
]);
$login = curl_exec($ch);
$loginCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$loginTime = microtime(true) - $startTime;

echo "   Status: $loginCode\n";
echo "   Time: " . round($loginTime * 1000) . "ms\n";

$loginData = json_decode($login, true);
if ($loginData['success']) {
    echo "   User: " . $loginData['user']['name'] . " (" . $loginData['user']['type'] . ")\n";
} else {
    echo "   Error: " . ($loginData['message'] ?? 'unknown') . "\n";
}
curl_close($ch);

// Extract cookie
$cookies = file_get_contents($jar);
echo "\n2. Session Cookie State:\n";
echo "   Jar contents:\n" . str_replace("\n", "\n   ", $cookies) . "\n";

// CHECK 1 - immediately
echo "\n3. Check Session (immediately after login)...\n";
$startTime = microtime(true);

$ch2 = curl_init('http://127.0.0.1:8000/api/auth/check');
curl_setopt_array($ch2, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_COOKIEJAR => $jar,
  CURLOPT_COOKIEFILE => $jar
]);
$check1 = curl_exec($ch2);
$check1Code = curl_getinfo($ch2, CURLINFO_HTTP_CODE);
$checkTime = microtime(true) - $startTime;

$check1Data = json_decode($check1, true);
echo "   Status: $check1Code\n";
echo "   Time: " . round($checkTime * 1000) . "ms\n";
echo "   LoggedIn: " . ($check1Data['loggedIn'] ? 'true' : 'false') . "\n";
if ($check1Data['loggedIn']) {
    echo "   User: " . $check1Data['user']['name'] . "\n";
}
curl_close($ch2);

// CHECK 2 - after 2 seconds
echo "\n4. Check Session (2 seconds later)...\n";
sleep(2);
$startTime = microtime(true);

$ch3 = curl_init('http://127.0.0.1:8000/api/auth/check');
curl_setopt_array($ch3, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_COOKIEJAR => $jar,
  CURLOPT_COOKIEFILE => $jar
]);
$check2 = curl_exec($ch3);
$check2Code = curl_getinfo($ch3, CURLINFO_HTTP_CODE);
$checkTime = microtime(true) - $startTime;

$check2Data = json_decode($check2, true);
echo "   Status: $check2Code\n";
echo "   Time: " . round($checkTime * 1000) . "ms\n";
echo "   LoggedIn: " . ($check2Data['loggedIn'] ? 'true' : 'false') . "\n";
if ($check2Data['loggedIn']) {
    echo "   User: " . $check2Data['user']['name'] . "\n";
} else {
    echo "   User logged out!\n";
}
curl_close($ch3);

@unlink($jar);
echo "\n✓ Test complete\n";
