<?php
// Test admin login and manually check cookies

$adminEmail = 'admin@smartrent.co.tz';
$adminPassword = 'Admin123!Test';
$jar = tempnam(sys_get_temp_dir(), 'adm');

echo "Testing Admin Login with Manual Cookie Handling\n";
echo "==============================================\n\n";

// LOGIN
echo "1. Admin Login Request...\n";
$startTime = microtime(true);

$ch = curl_init('http://127.0.0.1:8000/api/auth/login');
curl_setopt_array($ch, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_COOKIEJAR => $jar,
  CURLOPT_COOKIEFILE => $jar,
  CURLOPT_POST => true,
  CURLOPT_POSTFIELDS => json_encode(['email' => $adminEmail, 'password' => $adminPassword]),
  CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Accept: application/json'],
  CURLOPT_HEADER => true  // Get headers too
]);
$response = curl_exec($ch);
$loginCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$loginTime = microtime(true) - $startTime;

// Split headers and body
$header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
$headers = substr($response, 0, $header_size);
$body = substr($response, $header_size);

echo "   Status: $loginCode\n";
echo "   Time: " . round($loginTime * 1000) . "ms\n";

// Extract Set-Cookie from response headers
$sessionCookie = '';
$headerLines = explode("\r\n", $headers);
foreach ($headerLines as $line) {
    if (strpos($line, 'Set-Cookie:') === 0) {
        $cookie = substr($line, strlen('Set-Cookie: '));
        if (strpos($cookie, 'SMART_RENT_SESSID=') === 0) {
            $parts = explode(';', $cookie);
            $sessionCookie = trim($parts[0]);
            echo "   Found cookie: $sessionCookie\n";
            break;
        }
    }
}

$loginData = json_decode($body, true);
if ($loginData['success']) {
    echo "   User: " . $loginData['user']['name'] . " (" . $loginData['user']['type'] . ")\n";
} else {
    echo "   Error: " . ($loginData['message'] ?? 'unknown') . "\n";
}
curl_close($ch);

if (!$sessionCookie) {
    echo "\n✗ ERROR: No session cookie received from login response!\n";
    exit(1);
}

// CHECK 1 - immediately with manual cookie
echo "\n2. Check Session (immediately, with manual cookie)...\n";
$startTime = microtime(true);

$ch2 = curl_init('http://127.0.0.1:8000/api/auth/check');
curl_setopt_array($ch2, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_HTTPHEADER => ['Cookie: ' . $sessionCookie]
]);
$check1 = curl_exec($ch2);
$check1Code = curl_getinfo($ch2, CURLINFO_HTTP_CODE);
$checkTime = microtime(true) - $startTime;

$check1Data = json_decode($check1, true);
echo "   Status: $check1Code\n";
echo "   Time: " . round($checkTime * 1000) . "ms\n";
echo "   LoggedIn: " . ($check1Data['loggedIn'] ? 'true' : 'false') . "\n";
if ($check1Data['loggedIn']) {
    echo "   User: " . $check1Data['user']['name'] . " (" . $check1Data['user']['type'] . ")\n";
}
curl_close($ch2);

// CHECK 2 - after 3 seconds
echo "\n3. Check Session (3 seconds later, with same cookie)...\n";
sleep(3);
$startTime = microtime(true);

$ch3 = curl_init('http://127.0.0.1:8000/api/auth/check');
curl_setopt_array($ch3, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_HTTPHEADER => ['Cookie: ' . $sessionCookie]
]);
$check2 = curl_exec($ch3);
$check2Code = curl_getinfo($ch3, CURLINFO_HTTP_CODE);
$checkTime = microtime(true) - $startTime;

$check2Data = json_decode($check2, true);
echo "   Status: $check2Code\n";
echo "   Time: " . round($checkTime * 1000) . "ms\n";
echo "   LoggedIn: " . ($check2Data['loggedIn'] ? 'true' : 'false') . "\n";
if ($check2Data['loggedIn']) {
    echo "   User: " . $check2Data['user']['name'] . "\n";
} else {
    echo "   ✗ User was logged out after 3 seconds!\n";
}
curl_close($ch3);

@unlink($jar);
echo "\n✓ Test complete\n";
