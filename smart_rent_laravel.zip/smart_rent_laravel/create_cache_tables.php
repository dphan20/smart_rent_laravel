<?php
require __DIR__ . '/vendor/autoload.php';
$app = require __DIR__ . '/bootstrap/app.php';
$kernel = $app->make(\Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

// Create cache tables
DB::statement("CREATE TABLE IF NOT EXISTS cache ( `key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL, `value` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL, `expiration` int(11) NOT NULL, PRIMARY KEY (`key`), KEY `expiration` (`expiration`)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");

DB::statement("CREATE TABLE IF NOT EXISTS cache_locks ( `key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL, `owner` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL, `expiration` int(11) NOT NULL, PRIMARY KEY (`key`), KEY `expiration` (`expiration`)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");

echo "Cache tables created successfully!\n";
