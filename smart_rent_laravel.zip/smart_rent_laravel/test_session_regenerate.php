<?php
require_once __DIR__ . '/public/backend/config/session.php';

echo "Initial session ID: " . session_id() . "\n";
echo "Initial user_id: " . ($_SESSION['user_id'] ?? 'not set') . "\n";

// Simulate login
$_SESSION['user_id'] = 123;
$_SESSION['user_type'] = 'Customer';
echo "\nAfter setting user_id:\n";
echo "  Session ID: " . session_id() . "\n";
echo "  user_id: " . $_SESSION['user_id'] . "\n";

// Now regenerate (as login does)
session_regenerate_id(true);
echo "\nAfter session_regenerate_id(true):\n";
echo "  New session ID: " . session_id() . "\n";
echo "  user_id still set?: " . ($_SESSION['user_id'] ?? 'NOT SET!') . "\n";

// Check what's in the session file
$sessionDir = session_save_path();
if (empty($sessionDir)) {
    $sessionDir = sys_get_temp_dir();
}
echo "\nSession dir: $sessionDir\n";
echo "Session file: " . $sessionDir . '/sess_' . session_id() . "\n";
if (file_exists($sessionDir . '/sess_' . session_id())) {
    echo "Session file contents: " . file_get_contents($sessionDir . '/sess_' . session_id()) . "\n";
} else {
    echo "Session file does NOT exist!\n";
}
