<?php
$pdo = new PDO('mysql:host=127.0.0.1;port=3306;dbname=smartrent;charset=utf8mb4', 'root', '');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$tables = ['users', 'login_attempts', 'password_resets', 'remember_tokens', 'email_verifications'];
foreach ($tables as $table) {
    $row = $pdo->query("SHOW CREATE TABLE `$table`")->fetch(PDO::FETCH_ASSOC);
    echo "TABLE: $table\n" . $row['Create Table'] . "\n\n";
}
