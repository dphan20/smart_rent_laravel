<?php
$pdo = new PDO("mysql:host=127.0.0.1;port=3306;dbname=smartrent;charset=utf8mb4", "root", "");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Get admin user and try to determine their password
$admin = $pdo->query("SELECT id, full_name, email, password_hash, role FROM users WHERE role='Admin' LIMIT 1")->fetch();

if ($admin) {
    echo "Admin User:\n";
    echo "  ID: " . $admin['id'] . "\n";
    echo "  Name: " . $admin['full_name'] . "\n";
    echo "  Email: " . $admin['email'] . "\n";
    echo "  Role: " . $admin['role'] . "\n";
    echo "  Password Hash: " . $admin['password_hash'] . "\n";
    
    // Try common passwords
    $testPasswords = [
        'Admin@123',
        'admin@123',
        'password',
        '12345678',
        'admin',
        'Admin123!',
    ];
    
    echo "\nTesting passwords:\n";
    foreach ($testPasswords as $pass) {
        if (password_verify($pass, $admin['password_hash'])) {
            echo "  ✓ Password found: '$pass'\n";
            break;
        } else {
            echo "  ✗ '$pass' - no match\n";
        }
    }
} else {
    echo "No admin user found\n";
}
