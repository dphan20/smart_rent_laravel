<?php
/**
 * Detailed HTTP Login Flow Test with Cookie Tracking
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "=== DETAILED LOGIN FLOW TEST ===\n\n";

$baseUrl = 'http://127.0.0.1:8000';
$loginUrl = $baseUrl . '/api/auth/login';
$checkUrl = $baseUrl . '/api/auth/check';

$credentials = [
    'email' => 'admin@smartrent.test',
    'password' => 'Admin123!Test',
    'remember' => false
];

// Create a temporary cookie file
$cookieFile = tempnam(sys_get_temp_dir(), 'smartrent_');
echo "[DEBUG] Cookie file: $cookieFile\n\n";

// Step 1: Login
echo "[1] STEP 1: LOGIN REQUEST\n";
echo "------------------------------\n";
$curl = curl_init($loginUrl);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($credentials));
curl_setopt($curl, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($curl, CURLOPT_COOKIEJAR, $cookieFile);
curl_setopt($curl, CURLOPT_COOKIEFILE, $cookieFile);
curl_setopt($curl, CURLOPT_TIMEOUT, 10);
curl_setopt($curl, CURLOPT_VERBOSE, false);

$response = curl_exec($curl);
$httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
$loginData = json_decode($response, true);

curl_close($curl);

echo "HTTP Status: $httpCode\n";
echo "Response: " . json_encode($loginData, JSON_PRETTY_PRINT) . "\n\n";

// Check cookies
if (is_file($cookieFile)) {
    echo "[DEBUG] Cookies after login:\n";
    echo file_get_contents($cookieFile) . "\n\n";
}

// Step 2: Check session immediately
echo "[2] STEP 2: IMMEDIATE SESSION CHECK\n";
echo "------------------------------\n";
$curl = curl_init($checkUrl);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_COOKIEFILE, $cookieFile);
curl_setopt($curl, CURLOPT_TIMEOUT, 10);
curl_setopt($curl, CURLOPT_VERBOSE, false);

$response = curl_exec($curl);
$httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
$checkData = json_decode($response, true);

curl_close($curl);

echo "HTTP Status: $httpCode\n";
echo "Response: " . json_encode($checkData, JSON_PRETTY_PRINT) . "\n\n";

// Step 3: Check cookies again
if (is_file($cookieFile)) {
    echo "[DEBUG] Cookies after session check:\n";
    echo file_get_contents($cookieFile) . "\n\n";
}

// Step 4: Extract session ID and test directly
echo "[3] STEP 3: TESTING WITH EXPLICIT COOKIE\n";
echo "------------------------------\n";

// Read the cookie file and extract the session ID
$cookieContent = file_get_contents($cookieFile);
preg_match('/SMART_RENT_SESSID\s+([^\s\n]+)/', $cookieContent, $matches);
$sessionId = $matches[1] ?? null;

if ($sessionId) {
    echo "Extracted Session ID: $sessionId\n\n";
    
    // Test session check with explicit cookie header
    $curl = curl_init($checkUrl);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HTTPHEADER, ["Cookie: SMART_RENT_SESSID=$sessionId"]);
    curl_setopt($curl, CURLOPT_TIMEOUT, 10);
    
    $response = curl_exec($curl);
    $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    $checkData = json_decode($response, true);
    
    curl_close($curl);
    
    echo "HTTP Status: $httpCode\n";
    echo "Response with explicit cookie: " . json_encode($checkData, JSON_PRETTY_PRINT) . "\n\n";
} else {
    echo "[-] Failed to extract session ID from cookies\n\n";
}

// Clean up
@unlink($cookieFile);

echo "=== TEST COMPLETE ===\n";
