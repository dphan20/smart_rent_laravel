$ErrorActionPreference = "Stop"
$Path = "resources/views/app.blade.php"

if (-not (Test-Path $Path)) {
    Write-Error "FILE NOT FOUND: $Path`nRun this from your Laravel project root (the folder containing 'resources/views/app.blade.php')."
    exit 1
}

function Count-Occurrences([string]$haystack, [string]$needle) {
    return ([regex]::Matches($haystack, [regex]::Escape($needle))).Count
}

$raw = [System.IO.File]::ReadAllText($Path)
$hadCRLF = $raw.Contains("`r`n")
$data = $raw.Replace("`r`n", "`n")

if ($data.Contains("auth-only-nav")) {
    Write-Host "SKIP: already patched earlier."
    exit 0
}

function Do-Patch([string]$old, [string]$new, [string]$label) {
    $script:count = Count-Occurrences $script:data $old
    if ($script:count -ne 1) {
        Write-Error "ANCHOR NOT FOUND/UNIQUE ($($script:count)x) for: $label"
        exit 1
    }
    $script:data = $script:data.Replace($old, $new)
    Write-Host "patched: $label"
}

Do-Patch `
    '.sidebar-nav .admin-nav,.sidebar-nav .messages-nav,.sidebar-nav .reports-nav { display:none; }' `
    '.sidebar-nav .admin-nav,.sidebar-nav .messages-nav,.sidebar-nav .reports-nav,.sidebar-nav .auth-only-nav { display:none; }' `
    "css hide rule"

Do-Patch `
    '.sidebar-nav .admin-nav.show,.sidebar-nav .messages-nav.show,.sidebar-nav .reports-nav.show { display:flex; }' `
    '.sidebar-nav .admin-nav.show,.sidebar-nav .messages-nav.show,.sidebar-nav .reports-nav.show,.sidebar-nav .auth-only-nav.show { display:flex; }' `
    "css show rule"

Do-Patch `
    '<a href="#" data-nav="bookings"><i class="fas fa-calendar-check"></i> <span data-i18n="nav_bookings">Bookings</span></a>' `
    '<a href="#" class="auth-only-nav" data-nav="bookings"><i class="fas fa-calendar-check"></i> <span data-i18n="nav_bookings">Bookings</span></a>' `
    "nav link: bookings"

Do-Patch `
    '<a href="#" data-nav="orders"><i class="fas fa-clipboard-list"></i> <span data-i18n="nav_orders">Orders</span></a>' `
    '<a href="#" class="auth-only-nav" data-nav="orders"><i class="fas fa-clipboard-list"></i> <span data-i18n="nav_orders">Orders</span></a>' `
    "nav link: orders"

Do-Patch `
    '<a href="#" data-nav="contracts"><i class="fas fa-file-signature"></i> <span data-i18n="nav_contracts">My Contracts</span></a>' `
    '<a href="#" class="auth-only-nav" data-nav="contracts"><i class="fas fa-file-signature"></i> <span data-i18n="nav_contracts">My Contracts</span></a>' `
    "nav link: contracts"

Do-Patch `
    '<a href="#" data-nav="my-messages"><i class="fas fa-inbox"></i> <span data-i18n="nav_messages">Messages</span></a>' `
    '<a href="#" class="auth-only-nav" data-nav="my-messages"><i class="fas fa-inbox"></i> <span data-i18n="nav_messages">Messages</span></a>' `
    "nav link: my-messages"

Do-Patch `
    '<a href="#" data-nav="payment-dashboard"><i class="fas fa-wallet"></i> <span data-i18n="nav_payment_dashboard">Payment Dashboard</span></a>' `
    '<a href="#" class="auth-only-nav" data-nav="payment-dashboard"><i class="fas fa-wallet"></i> <span data-i18n="nav_payment_dashboard">Payment Dashboard</span></a>' `
    "nav link: payment-dashboard"

Do-Patch `
    "avatarLabel.textContent = currentUser.name.charAt(0).toUpperCase();" `
    "avatarLabel.textContent = currentUser.name.charAt(0).toUpperCase();`n                document.querySelectorAll('.auth-only-nav').forEach(function(el){ el.classList.add('show'); });" `
    "show auth-only-nav on login"

Do-Patch `
    "document.querySelector('.admin-nav').classList.remove('show');`n                document.querySelector('.messages-nav').classList.remove('show');`n                document.querySelector('.reports-nav').classList.remove('show');`n                if (landlordNav) landlordNav.style.display = 'none';`n                if (logoutLink) logoutLink.style.display = 'none';" `
    "document.querySelector('.admin-nav').classList.remove('show');`n                document.querySelector('.messages-nav').classList.remove('show');`n                document.querySelector('.reports-nav').classList.remove('show');`n                document.querySelectorAll('.auth-only-nav').forEach(function(el){ el.classList.remove('show'); });`n                if (landlordNav) landlordNav.style.display = 'none';`n                if (logoutLink) logoutLink.style.display = 'none';" `
    "hide auth-only-nav for guests"

Do-Patch `
    "function showSection(section) {`n            document.querySelectorAll('.content-section').forEach(el => el.classList.remove('active'));" `
    "function showSection(section) {`n            const authOnlySections = ['bookings', 'orders', 'contracts', 'my-messages', 'payment-dashboard'];`n            if (authOnlySections.includes(section) && !isLoggedIn()) {`n                section = 'browse';`n            }`n            document.querySelectorAll('.content-section').forEach(el => el.classList.remove('active'));" `
    "guard showSection() against direct/console access"

$data = $script:data
if ($hadCRLF) { $data = $data.Replace("`n", "`r`n") }
[System.IO.File]::WriteAllText($Path, $data)
Write-Host "DONE. Bookings, Orders, My Contracts, Messages, and Payment Dashboard are now hidden from guests and blocked from direct access until login."
