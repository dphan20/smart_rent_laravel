<?php
/**
 * Admin Auto-Logout Diagnosis
 * Tests if session persists after login
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "\n";
echo "╔════════════════════════════════════════════════════════════════╗\n";
echo "║        ADMIN AUTO-LOGOUT DIAGNOSIS - DETAILED TRACE            ║\n";
echo "╚════════════════════════════════════════════════════════════════╝\n\n";

$baseUrl = 'http://127.0.0.1:8000';
$loginUrl = $baseUrl . '/api/auth/login';
$checkUrl = $baseUrl . '/api/auth/check';

$credentials = [
    'email' => 'admin@smartrent.co.tz',
    'password' => 'admin123'
];

$cookieFile = tempnam(sys_get_temp_dir(), 'admin_test_');
echo "[DEBUG] Using cookie file: $cookieFile\n\n";

// Step 1: Login
echo "[STEP 1] Logging in admin...\n";
echo "─────────────────────────────────────────────────────────────────\n";

$curl = curl_init($loginUrl);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($credentials));
curl_setopt($curl, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($curl, CURLOPT_COOKIEJAR, $cookieFile);
curl_setopt($curl, CURLOPT_COOKIEFILE, $cookieFile);
curl_setopt($curl, CURLOPT_TIMEOUT, 10);
curl_setopt($curl, CURLOPT_VERBOSE, false);

$response = curl_exec($curl);
$info = curl_getinfo($curl);
$httpCode = $info['http_code'];
$loginData = json_decode($response, true);

curl_close($curl);

echo "HTTP Status: $httpCode\n";
echo "Login Success: " . ($loginData['success'] ? 'YES' : 'NO') . "\n";
if ($loginData['success']) {
    echo "User: " . $loginData['user']['name'] . " (" . $loginData['user']['type'] . ")\n";
}

// Check Set-Cookie header
echo "\nSet-Cookie Headers:\n";
if (!empty($info['redirect_url'])) {
    echo "  Redirect URL: " . $info['redirect_url'] . "\n";
}

echo "\nCookie file contents after login:\n";
if (file_exists($cookieFile)) {
    $content = file_get_contents($cookieFile);
    foreach (explode("\n", $content) as $line) {
        if (trim($line) && !str_starts_with(trim($line), '#')) {
            echo "  " . $line . "\n";
        }
    }
} else {
    echo "  [WARNING] Cookie file doesn't exist!\n";
}

// Step 2: Immediate session check
echo "\n[STEP 2] Immediate session check (should be logged in)...\n";
echo "─────────────────────────────────────────────────────────────────\n";

$curl = curl_init($checkUrl);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_COOKIEFILE, $cookieFile);
curl_setopt($curl, CURLOPT_COOKIEJAR, $cookieFile);
curl_setopt($curl, CURLOPT_TIMEOUT, 10);

$response = curl_exec($curl);
$httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
$checkData = json_decode($response, true);

curl_close($curl);

echo "HTTP Status: $httpCode\n";
echo "Logged In: " . ($checkData['loggedIn'] ? 'YES ✓' : 'NO ✗') . "\n";
if ($checkData['loggedIn']) {
    echo "User: " . $checkData['user']['name'] . "\n";
} else {
    echo "[WARNING] Session not persisted after login!\n";
}

// Step 3: Check for SMART_RENT_SESSID cookie specifically
echo "\n[STEP 3] Checking for SMART_RENT_SESSID cookie...\n";
echo "─────────────────────────────────────────────────────────────────\n";

if (file_exists($cookieFile)) {
    preg_match('/SMART_RENT_SESSID\s+([^\s\n]+)/', file_get_contents($cookieFile), $matches);
    $sessionId = $matches[1] ?? null;
    
    if ($sessionId) {
        echo "[✓] Session ID found: $sessionId\n";
        echo "\nTesting explicit cookie header...\n";
        
        $curl = curl_init($checkUrl);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER, ["Cookie: SMART_RENT_SESSID=$sessionId"]);
        curl_setopt($curl, CURLOPT_TIMEOUT, 10);
        
        $response = curl_exec($curl);
        $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $checkData = json_decode($response, true);
        
        curl_close($curl);
        
        echo "HTTP Status: $httpCode\n";
        echo "With explicit cookie: Logged In = " . ($checkData['loggedIn'] ? 'YES ✓' : 'NO ✗') . "\n";
    } else {
        echo "[✗] No SMART_RENT_SESSID cookie found!\n";
    }
}

// Step 4: Test with multiple requests
echo "\n[STEP 4] Testing session across 3 requests...\n";
echo "─────────────────────────────────────────────────────────────────\n";

for ($i = 1; $i <= 3; $i++) {
    echo "\nRequest #$i:\n";
    
    $curl = curl_init($checkUrl);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_COOKIEFILE, $cookieFile);
    curl_setopt($curl, CURLOPT_COOKIEJAR, $cookieFile);
    curl_setopt($curl, CURLOPT_TIMEOUT, 10);
    
    $response = curl_exec($curl);
    $checkData = json_decode($response, true);
    
    curl_close($curl);
    
    echo "  Logged In: " . ($checkData['loggedIn'] ? 'YES ✓' : 'NO ✗') . "\n";
    
    if ($i < 3) {
        sleep(1);
    }
}

echo "\n";
echo "╔════════════════════════════════════════════════════════════════╗\n";
echo "║                   DIAGNOSIS COMPLETE                           ║\n";
echo "╚════════════════════════════════════════════════════════════════╝\n\n";

// Cleanup
@unlink($cookieFile);
