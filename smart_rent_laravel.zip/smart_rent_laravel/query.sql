show tables; echo select * from migrations;
