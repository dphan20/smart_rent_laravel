<?php
$pdo = new PDO('mysql:host=127.0.0.1;port=3306;dbname=smartrent;charset=utf8mb4', 'root', '');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$stmt = $pdo->query("SHOW CREATE TABLE users");
$row = $stmt->fetch(PDO::FETCH_ASSOC);
echo "CREATE TABLE:\n" . $row['Create Table'] . "\n\n";

$show = $pdo->query("SELECT id, full_name, email, role FROM users ORDER BY id LIMIT 20");
foreach ($show as $r) {
    echo json_encode($r) . "\n";
}

$stmt2 = $pdo->query("SHOW TABLE STATUS LIKE 'users'");
$row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
echo "\nAUTO_INCREMENT=" . ($row2['Auto_increment'] ?? 'null') . "\n";
