<?php
/**
 * Admin Account Diagnosis and Fix
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'public/backend/config/database.php';
require_once 'public/backend/models/User.php';
require_once 'public/backend/helpers/functions.php';

echo "\n";
echo "╔════════════════════════════════════════════════════════════════╗\n";
echo "║           ADMIN ACCOUNT DIAGNOSIS & REPAIR                     ║\n";
echo "╚════════════════════════════════════════════════════════════════╝\n\n";

// Check admin@smartrent.co.tz account
echo "[1] Checking admin@smartrent.co.tz account...\n";
echo "─────────────────────────────────────────────────────────────────\n";

$adminEmail = 'admin@smartrent.co.tz';
$adminPassword = 'admin123';

$stmt = $pdo->prepare("
    SELECT id, full_name AS name, email, role, failed_login_attempts, locked_until 
    FROM users 
    WHERE email = ?
");
$stmt->execute([$adminEmail]);
$adminUser = $stmt->fetch();

if (!$adminUser) {
    echo "[!] Admin account NOT found with email: $adminEmail\n";
    echo "    Creating new admin account...\n\n";
    
    $stmt = $pdo->prepare("INSERT INTO users (full_name, email, phone, password_hash, role) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([
        'System Admin',
        $adminEmail,
        '+255700000000',
        password_hash($adminPassword, PASSWORD_DEFAULT),
        'Admin'
    ]);
    
    $adminId = $pdo->lastInsertId();
    echo "[✓] Admin account created with ID: $adminId\n";
    echo "    Email: $adminEmail\n";
    echo "    Password: $adminPassword\n";
} else {
    echo "[✓] Admin account found\n";
    echo "    ID: " . $adminUser['id'] . "\n";
    echo "    Name: " . $adminUser['name'] . "\n";
    echo "    Email: " . $adminUser['email'] . "\n";
    echo "    Role: " . $adminUser['role'] . "\n";
    echo "    Failed attempts: " . $adminUser['failed_login_attempts'] . "\n";
    echo "    Locked until: " . ($adminUser['locked_until'] ?? 'Not locked') . "\n\n";
    
    // Check if account is locked
    if ($adminUser['locked_until']) {
        $lockedTime = strtotime($adminUser['locked_until']);
        $now = time();
        
        if ($now > $lockedTime) {
            echo "[!] Account WAS locked but lock has expired\n";
            echo "    Resetting lock...\n";
            
            $stmt = $pdo->prepare("UPDATE users SET failed_login_attempts = 0, locked_until = NULL WHERE id = ?");
            $stmt->execute([$adminUser['id']]);
            echo "[✓] Lock cleared\n\n";
        } else {
            $minutesLeft = ceil(($lockedTime - $now) / 60);
            echo "[✗] Account IS LOCKED - $minutesLeft minutes remaining\n";
            echo "    Unlocking account...\n";
            
            $stmt = $pdo->prepare("UPDATE users SET failed_login_attempts = 0, locked_until = NULL WHERE id = ?");
            $stmt->execute([$adminUser['id']]);
            echo "[✓] Account unlocked\n\n";
        }
    } else {
        echo "[✓] Account is not locked\n\n";
    }
    
    // Reset password
    echo "[2] Resetting password...\n";
    echo "─────────────────────────────────────────────────────────────────\n";
    
    $newHash = password_hash($adminPassword, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("UPDATE users SET password_hash = ?, failed_login_attempts = 0, locked_until = NULL WHERE id = ?");
    $stmt->execute([$newHash, $adminUser['id']]);
    
    echo "[✓] Password reset to: $adminPassword\n\n";
}

// Test login with the repaired account
echo "[3] Testing login with repaired account...\n";
echo "─────────────────────────────────────────────────────────────────\n";

$testUser = User::findByEmail($adminEmail);
if (!$testUser) {
    echo "[✗] ERROR: Admin account not found after repair!\n";
} else {
    echo "[✓] Admin account found\n";
    echo "    Email: " . $testUser['email'] . "\n";
    echo "    Role: " . $testUser['type'] . "\n";
    echo "    Failed attempts: " . $testUser['failed_login_attempts'] . "\n";
    echo "    Locked: " . ($testUser['locked_until'] ? 'YES' : 'NO') . "\n";
    
    if (password_verify($adminPassword, $testUser['password_hash'])) {
        echo "[✓] Password verification: SUCCESS\n";
    } else {
        echo "[✗] Password verification: FAILED\n";
    }
}

echo "\n";
echo "╔════════════════════════════════════════════════════════════════╗\n";
echo "║                     REPAIR COMPLETE                            ║\n";
echo "╚════════════════════════════════════════════════════════════════╝\n\n";

echo "Admin Login Credentials:\n";
echo "  Email: $adminEmail\n";
echo "  Password: $adminPassword\n\n";

echo "Try logging in at: http://127.0.0.1:8000/app\n\n";
