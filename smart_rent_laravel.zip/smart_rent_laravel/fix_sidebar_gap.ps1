$ErrorActionPreference = "Stop"
$Path = "resources/views/app.blade.php"

if (-not (Test-Path $Path)) {
    Write-Error "FILE NOT FOUND: $Path`nRun this from your Laravel project root (the folder containing 'resources/views/app.blade.php')."
    exit 1
}

$raw = [System.IO.File]::ReadAllText($Path)
$hadCRLF = $raw.Contains("`r`n")
$data = $raw.Replace("`r`n", "`n")

$oldNav = '.sidebar-nav { display:flex; flex-direction:column; gap:2px; flex:1; }'
$newNav = '.sidebar-nav { display:flex; flex-direction:column; gap:2px; }'
$oldFooter = ".sidebar-footer { margin-top:auto; padding-top:20px; border-top:1px solid rgba(255,255,255,0.06); display:flex; flex-direction:column; gap:2px; }"
$newFooter = ".sidebar-footer { margin-top:20px; padding-top:20px; border-top:1px solid rgba(255,255,255,0.06); display:flex; flex-direction:column; gap:2px; }"

if (-not $data.Contains($oldNav) -and -not $data.Contains($oldFooter)) {
    Write-Host "SKIP: already patched earlier (or file has changed)."
    exit 0
}

$navCount = ([regex]::Matches($data, [regex]::Escape($oldNav))).Count
if ($navCount -ne 1) { Write-Error "ANCHOR NOT FOUND/UNIQUE ($navCount) for sidebar-nav rule"; exit 1 }
$data = $data.Replace($oldNav, $newNav)
Write-Host "patched: sidebar-nav (removed flex:1)"

$footerCount = ([regex]::Matches($data, [regex]::Escape($oldFooter))).Count
if ($footerCount -ne 1) { Write-Error "ANCHOR NOT FOUND/UNIQUE ($footerCount) for sidebar-footer rule"; exit 1 }
$data = $data.Replace($oldFooter, $newFooter)
Write-Host "patched: sidebar-footer (removed margin-top:auto)"

if ($hadCRLF) { $data = $data.Replace("`n", "`r`n") }
[System.IO.File]::WriteAllText($Path, $data)
Write-Host "DONE. The sidebar footer (Settings/Help & Support) now sits right below the nav links instead of being pinned to the bottom of the screen."
