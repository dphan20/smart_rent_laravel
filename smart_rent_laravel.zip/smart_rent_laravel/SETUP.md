# Smart Rent - Setup

The legacy PHP backend (`public/backend/api.php`) lives inside Laravel's
own `public/` folder, and `App\Support\LegacyBackend::url()` auto-detects
its URL from whatever host/port you're browsing on. That means **one**
running server is enough - login, signup, rooms, properties, and every
other endpoint all reach the backend automatically. You do NOT need to
start a second server on port 8001; `SMART_RENT_LEGACY_URL` in `.env`
should stay blank (see the comment above it in `.env` for the one
scenario where you'd deliberately set it).

## Option A: XAMPP / Apache (recommended)
1. Open the XAMPP control panel and start **both Apache and MySQL**.
2. Point an Apache vhost (or `htdocs` symlink) at this project's `public/`
   folder as the document root.
3. Import the database (see below), then open the app at whatever URL
   your vhost/htdocs path resolves to. Apache serves concurrent requests
   natively, so the backend proxy call never blocks.

## Option B: `php artisan serve` only (single terminal)
1. Start XAMPP's **MySQL** only (Apache isn't needed for this option).
2. Import the database (see below).
3. From this project folder, if you will ONLY test on Android/iOS (never
   Chrome/web), run:
   ```
   composer install
   php artisan serve --no-reload
   ```
   **The `--no-reload` flag is REQUIRED, not optional.** Without it,
   Laravel prints `WARN Unable to respect the PHP_CLI_SERVER_WORKERS
   environment variable without the --no-reload flag. Only creating a
   single server.` and silently falls back to a single PHP worker - and
   with only one worker, the Laravel→backend proxy call deadlocks
   against itself (every request hangs for ~15-34s: login, signup,
   `/api/rooms`, everything). `--no-reload` is also what lets Laravel
   honor `PHP_CLI_SERVER_WORKERS=4` (already set in `.env`), which is
   what actually gives the proxy call a free worker to land on instead
   of queuing behind the very request that's waiting on it.

   **If you WILL test the Chrome/web build**, use `dev_server.php`
   instead of `php artisan serve` (same host/port, everything above
   still applies — this just also fixes property/room/tour images,
   which the default router serves with no CORS header at all since it
   bypasses this project's code for any URL that matches a real file
   under `public/`, e.g. every image under `public/uploads`):
   ```
   composer install
   ```
   Windows (Command Prompt):
   ```
   set PHP_CLI_SERVER_WORKERS=4
   php -S 127.0.0.1:8000 -t public dev_server.php
   ```
   Windows (PowerShell):
   ```
   $env:PHP_CLI_SERVER_WORKERS=4
   php -S 127.0.0.1:8000 -t public dev_server.php
   ```
   macOS/Linux:
   ```
   PHP_CLI_SERVER_WORKERS=4 php -S 127.0.0.1:8000 -t public dev_server.php
   ```
   The `PHP_CLI_SERVER_WORKERS=4` part must be set in the shell itself,
   not just left in `.env` — `php -S` reads it before any of this
   project's PHP code (which is what loads `.env`) ever runs. See
   `dev_server.php` for the full explanation of what it fixes and why.
4. Open **http://127.0.0.1:8000/**.

You do not need two terminals or a second `php -S ... -t public/backend`
process with either option.

## Import the database
The dump is included at `database_dump/smartrent.sql`. Import it as a
database named exactly `smartrent`:

**Via phpMyAdmin:** create a database called `smartrent`, open it, go to
Import, and choose `database_dump/smartrent.sql`.

**Via command line**, from this project folder:
```
mysql -u root -e "CREATE DATABASE IF NOT EXISTS smartrent"
mysql -u root smartrent < database_dump/smartrent.sql
```

Do **not** run `php artisan migrate` against this database - it already
contains everything the app needs (including tables that would collide
with Laravel's own default migrations).

## Existing accounts in this database
The dump includes real registered users, e.g. `admin@smartrent.co.tz`
(role: Admin). Their passwords are hashed, so if you don't already know
one, register a brand new account through the app's sign-up form instead.

## If something still doesn't work
Check both terminal windows for red error text first - that's usually the
fastest way to see what's actually failing (a DB connection error looks
very different from a 404, which looks different from a PHP fatal error).
