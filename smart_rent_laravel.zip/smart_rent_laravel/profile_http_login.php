<?php
/**
 * Profile a full HTTP login request to find where the delay is
 */
$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => 'http://127.0.0.1:8000/api/auth/login',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode(['email' => 'admin@smartrent.co.tz', 'password' => 'Admin123!Test']),
    CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
    CURLOPT_HEADERFUNCTION => function($curl, $header) {
        $len = strlen($header);
        if (preg_match('/^Server:/i', $header) || preg_match('/^X-Response-Time:/i', $header)) {
            echo "HEADER: " . trim($header) . "\n";
        }
        return $len;
    },
    CURLOPT_VERBOSE => true,
    CURLOPT_STDERR => fopen('php://stderr', 'w'),
]);

echo "Sending login request...\n";
$start = microtime(true);
$response = curl_exec($ch);
$time = (microtime(true) - $start) * 1000;
curl_close($ch);

$data = json_decode($response, true);
echo "Status: " . ($data['success'] ? 'Success' : 'Failed') . "\n";
echo "Response Time: " . number_format($time, 2) . "ms\n";
