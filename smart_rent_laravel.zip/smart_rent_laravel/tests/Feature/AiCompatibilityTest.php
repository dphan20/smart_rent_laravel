<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\WithoutMiddleware;
use Tests\TestCase;

class AiCompatibilityTest extends TestCase
{
    use WithoutMiddleware;

    public function test_legacy_ai_chat_route_is_public_and_responds(): void
    {
        $response = $this->postJson('/api/ai/chat', [
            'message' => 'Find me a room in Dar es Salaam under 500000',
            'session_id' => 'legacy-chat-test',
        ]);

        $response->assertStatus(200)
            ->assertJsonStructure([
                'success',
                'reply',
                'properties',
            ]);
    }

    public function test_legacy_ai_match_route_is_public_and_responds(): void
    {
        $response = $this->postJson('/api/ai/match', [
            'query' => 'two bedroom in Mbezi under 600000',
        ]);

        $response->assertStatus(200)
            ->assertJsonStructure([
                'success',
                'results',
            ]);
    }

    public function test_detected_language_matches_question_language(): void
    {
        $service = new \App\Services\GroqService();

        $this->assertSame('english', $service->detectResponseLanguage('Find a room in Dar es Salaam under 500000'));
        $this->assertSame('swahili', $service->detectResponseLanguage('Ninahitaji chumba cha Dar es Salaam chini ya TZS 500000'));
    }
}
