<?php
$pdo = new PDO("mysql:host=127.0.0.1;port=3306;dbname=smartrent;charset=utf8mb4", "root", "");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Check if admin user exists
$admins = $pdo->query("SELECT id, full_name, email, role FROM users WHERE role='Admin' LIMIT 1")->fetchAll();
if (empty($admins)) {
    echo "No admin user found. Creating one...\n";
    $adminHash = password_hash('Admin@123', PASSWORD_DEFAULT);
    $pdo->exec("INSERT INTO users (full_name, email, phone, password_hash, role) VALUES ('Admin User', 'admin@smartrent.co.tz', '+255700000000', '$adminHash', 'Admin')");
    echo "Admin created: admin@smartrent.co.tz / Admin@123\n";
} else {
    $admin = $admins[0];
    echo "Admin user found:\n";
    echo "  ID: " . $admin['id'] . "\n";
    echo "  Name: " . $admin['full_name'] . "\n";
    echo "  Email: " . $admin['email'] . "\n";
    echo "  Role: " . $admin['role'] . "\n";
}
