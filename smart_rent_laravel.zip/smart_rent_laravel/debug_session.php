<?php
$email = 'php_cookie_' . bin2hex(random_bytes(4)) . '@example.com';
$pass = 'Pass123!';
$jar = sys_get_temp_dir() . '/smart_rent_cookie_' . bin2hex(random_bytes(4)) . '.txt';

$ch = curl_init('http://127.0.0.1:8000/api/auth/signup');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_COOKIEJAR => $jar,
    CURLOPT_COOKIEFILE => $jar,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode([
        'name' => 'PHP Cookie User',
        'email' => $email,
        'phone' => '0770000000',
        'password' => $pass,
        'type' => 'Customer',
    ]),
    CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Accept: application/json'],
    CURLOPT_HEADER => true,
]);
$signup = curl_exec($ch);
$signupInfo = curl_getinfo($ch);
err: if (curl_errno($ch)) { echo "SIGNUP_ERR=" . curl_error($ch) . PHP_EOL; }
else { echo "SIGNUP_STATUS=" . $signupInfo['http_code'] . PHP_EOL; echo $signup . PHP_EOL; }
curl_close($ch);

$ch2 = curl_init('http://127.0.0.1:8000/api/auth/check');
curl_setopt_array($ch2, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_COOKIEJAR => $jar,
    CURLOPT_COOKIEFILE => $jar,
    CURLOPT_HEADER => true,
]);
$check1 = curl_exec($ch2);
$info1 = curl_getinfo($ch2);
if (curl_errno($ch2)) { echo "CHECK1_ERR=" . curl_error($ch2) . PHP_EOL; }
else { echo "CHECK1_STATUS=" . $info1['http_code'] . PHP_EOL; echo $check1 . PHP_EOL; }
curl_close($ch2);

$ch3 = curl_init('http://127.0.0.1:8000/api/auth/login');
curl_setopt_array($ch3, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_COOKIEJAR => $jar,
    CURLOPT_COOKIEFILE => $jar,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode([
        'email' => $email,
        'password' => $pass,
    ]),
    CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Accept: application/json'],
    CURLOPT_HEADER => true,
]);
$login = curl_exec($ch3);
$loginInfo = curl_getinfo($ch3);
if (curl_errno($ch3)) { echo "LOGIN_ERR=" . curl_error($ch3) . PHP_EOL; }
else { echo "LOGIN_STATUS=" . $loginInfo['http_code'] . PHP_EOL; echo $login . PHP_EOL; }
curl_close($ch3);

$ch4 = curl_init('http://127.0.0.1:8000/api/auth/check');
curl_setopt_array($ch4, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_COOKIEJAR => $jar,
    CURLOPT_COOKIEFILE => $jar,
    CURLOPT_HEADER => true,
]);
$check2 = curl_exec($ch4);
$info2 = curl_getinfo($ch4);
if (curl_errno($ch4)) { echo "CHECK2_ERR=" . curl_error($ch4) . PHP_EOL; }
else { echo "CHECK2_STATUS=" . $info2['http_code'] . PHP_EOL; echo $check2 . PHP_EOL; }
curl_close($ch4);

@unlink($jar);
