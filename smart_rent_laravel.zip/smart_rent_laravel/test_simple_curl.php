<?php
/**
 * Simple HTTP Request Test
 */

$url = 'http://127.0.0.1:8000/api/check-session';

echo "Testing: $url\n\n";

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 5);
curl_setopt($ch, CURLOPT_VERBOSE, false);

$response = curl_exec($ch);
$info = curl_getinfo($ch);
$errno = curl_errno($ch);
$error = curl_error($ch);

curl_close($ch);

echo "HTTP Code: " . $info['http_code'] . "\n";
echo "Error: " . ($error ?: 'None') . "\n";
echo "Response:\n$response\n";
