﻿<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Rent - Room Rental System</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preconnect" href="https://cdnjs.cloudflare.com" crossorigin>
    <link rel="preconnect" href="https://cdn.jsdelivr.net" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,400;14..32,500;14..32,600;14..32,700;14..32,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root {
            --bg-body: #f4f7fb;
            --bg-main: #ffffff;
            --bg-sidebar: #0f172a;
            --bg-sidebar-hover: rgba(255,255,255,0.08);
            --bg-card: #ffffff;
            --bg-card-hover: #fafcff;
            --bg-input: #f8fafc;
            --bg-filter: #ffffff;
            --bg-feature: #ffffff;
            --bg-modal: #ffffff;
            --bg-toast: #0f172a;
            --bg-badge: #fef3c7;
            --bg-processing: #ffffff;
            --text-primary: #0f172a;
            --text-secondary: #64748b;
            --text-muted: #94a3b8;
            --text-inverse: #ffffff;
            --text-sidebar: #e2e8f0;
            --text-sidebar-muted: #94a3b8;
            --border-color: #eef2f6;
            --border-dark: #d1d9e6;
            --shadow-sm: 0 2px 8px rgba(0,0,0,0.02);
            --shadow-md: 0 4px 20px rgba(0,0,0,0.02);
            --shadow-lg: 0 20px 40px rgba(0,0,0,0.08);
            --shadow-xl: 0 32px 64px rgba(0,0,0,0.15);
            --gradient-gold: linear-gradient(135deg,#f59e0b,#d97706);
            --gradient-green: linear-gradient(135deg,#22c55e,#16a34a);
            --gradient-blue: linear-gradient(135deg,#3b82f6,#2563eb);
            --gold: #f59e0b;
            --gold-dark: #d97706;
            --green: #22c55e;
            --red: #ef4444;
            --blue: #3b82f6;
            --sidebar-width: 240px;
            --sidebar-width-collapsed: 72px;
        }
        [data-theme="dark"] {
            --bg-body: #0f172a;
            --bg-main: #1e293b;
            --bg-sidebar: #020617;
            --bg-sidebar-hover: rgba(255,255,255,0.05);
            --bg-card: #1e293b;
            --bg-card-hover: #263348;
            --bg-input: #263348;
            --bg-filter: #1e293b;
            --bg-feature: #1e293b;
            --bg-modal: #1e293b;
            --bg-toast: #1e293b;
            --bg-badge: #2d3748;
            --bg-processing: #1e293b;
            --text-primary: #f1f5f9;
            --text-secondary: #94a3b8;
            --text-muted: #64748b;
            --text-inverse: #0f172a;
            --text-sidebar: #e2e8f0;
            --text-sidebar-muted: #64748b;
            --border-color: #334155;
            --border-dark: #475569;
            --shadow-sm: 0 2px 8px rgba(0,0,0,0.3);
            --shadow-md: 0 4px 20px rgba(0,0,0,0.3);
            --shadow-lg: 0 20px 40px rgba(0,0,0,0.4);
            --shadow-xl: 0 32px 64px rgba(0,0,0,0.5);
        }
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',sans-serif; }
        body { background:var(--bg-body); display:flex; height:100vh; overflow:hidden; transition:background 0.3s,color 0.3s; color:var(--text-primary); }
        ::-webkit-scrollbar { width:6px; }
        ::-webkit-scrollbar-track { background:transparent; }
        ::-webkit-scrollbar-thumb { background:#cbd5e1; border-radius:8px; }
        [data-theme="dark"] ::-webkit-scrollbar-thumb { background:#475569; }
        .sidebar { width:var(--sidebar-width); min-width:var(--sidebar-width); background:var(--bg-sidebar); color:var(--text-sidebar); display:flex; flex-direction:column; padding:28px 16px 24px; height:100vh; overflow-y:auto; border-right:1px solid rgba(255,255,255,0.05); z-index:100; transition:width 0.3s,background 0.3s; }
        .sidebar-brand { display:flex; align-items:center; gap:12px; margin-bottom:40px; padding-left:6px; }
        .sidebar-brand .brand-icon { width:42px; height:42px; background:var(--gradient-gold); border-radius:12px; display:flex; align-items:center; justify-content:center; font-size:20px; font-weight:800; color:#0f172a; box-shadow:0 4px 12px rgba(245,158,11,0.3); flex-shrink:0; }
        .sidebar-brand h1 { font-size:22px; font-weight:800; letter-spacing:-0.5px; color:#fff; }
        .sidebar-brand h1 span { color:var(--gold); font-weight:300; }
        .sidebar-nav { display:flex; flex-direction:column; gap:2px; flex:1; }
        .sidebar-nav .nav-label { font-size:11px; text-transform:uppercase; letter-spacing:0.8px; color:var(--text-sidebar-muted); padding:12px 10px 6px; font-weight:700; }
        .sidebar-nav a { display:flex; align-items:center; gap:14px; padding:10px 14px; border-radius:12px; color:var(--text-sidebar-muted); text-decoration:none; font-size:14px; font-weight:500; transition:all 0.2s ease; cursor:pointer; }
        .sidebar-nav a i { width:20px; font-size:16px; text-align:center; }
        .sidebar-nav a:hover { background:var(--bg-sidebar-hover); color:var(--text-sidebar); }
        .sidebar-nav a.active { background:rgba(245,158,11,0.15); color:var(--gold); font-weight:600; box-shadow:inset 3px 0 0 var(--gold); }
        .sidebar-nav a.active i { color:var(--gold); }
        .sidebar-footer { margin-top:auto; padding-top:20px; border-top:1px solid rgba(255,255,255,0.06); display:flex; flex-direction:column; gap:2px; }
        .sidebar-footer a { display:flex; align-items:center; gap:14px; padding:10px 14px; border-radius:12px; color:var(--text-sidebar-muted); text-decoration:none; font-size:14px; font-weight:500; transition:all 0.2s ease; cursor:pointer; }
        .sidebar-footer a i { width:20px; font-size:16px; text-align:center; }
        .sidebar-footer a:hover { background:var(--bg-sidebar-hover); color:var(--text-sidebar); }
        .main-content { flex:1; padding:28px 36px 36px; overflow-y:auto; height:100vh; background:var(--bg-body); transition:background 0.3s; position:relative; }
        .page-header { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:28px; flex-wrap:wrap; gap:12px; }
        .page-header h2 { font-size:28px; font-weight:800; color:var(--text-primary); letter-spacing:-0.6px; background:linear-gradient(135deg,var(--text-primary),var(--text-secondary)); -webkit-background-clip:text; -webkit-text-fill-color:transparent; background-clip:text; }
        .page-header p { font-size:15px; color:var(--text-secondary); margin-top:4px; font-weight:500; }
        .header-actions { display:flex; align-items:center; gap:12px; flex-wrap:wrap; }
        .header-actions .user-avatar { width:44px; height:44px; border-radius:14px; background:var(--gradient-gold); color:#0f172a; display:flex; align-items:center; justify-content:center; font-weight:700; font-size:18px; cursor:pointer; box-shadow:0 4px 12px rgba(245,158,11,0.2); transition:all 0.2s ease; position:relative; text-transform:uppercase; user-select:none; }
        .header-actions .user-avatar:hover { transform:translateY(-2px) scale(1.02); box-shadow:0 8px 20px rgba(245,158,11,0.3); }
        .header-actions .user-avatar .admin-badge { position:absolute; bottom:-4px; right:-4px; background:var(--green); color:#fff; border-radius:50%; width:18px; height:18px; font-size:10px; display:flex; align-items:center; justify-content:center; border:2px solid var(--bg-body); }
        .header-actions .theme-toggle,.header-actions .lang-toggle { width:44px; height:44px; border-radius:14px; border:1px solid var(--border-color); background:var(--bg-main); color:var(--text-primary); font-size:18px; display:flex; align-items:center; justify-content:center; cursor:pointer; box-shadow:var(--shadow-sm); transition:all 0.2s ease; }
        .header-actions .theme-toggle:hover,.header-actions .lang-toggle:hover { background:var(--bg-card-hover); border-color:var(--border-dark); transform:translateY(-2px); box-shadow:var(--shadow-md); }
        .filters-section { background:var(--bg-filter); border-radius:20px; padding:24px 28px; box-shadow:var(--shadow-md); margin-bottom:28px; border:1px solid var(--border-color); transition:background 0.3s,border 0.3s; }
        .filters-top { display:flex; flex-wrap:wrap; align-items:center; gap:12px 16px; margin-bottom:20px; }
        .filters-top .search-wrapper { flex:1; min-width:200px; position:relative; }
        .filters-top .search-wrapper i { position:absolute; left:16px; top:50%; transform:translateY(-50%); color:var(--text-muted); font-size:16px; }
        .filters-top .search-wrapper input { width:100%; padding:12px 16px 12px 46px; border-radius:14px; border:1px solid var(--border-color); background:var(--bg-input); font-size:14px; color:var(--text-primary); transition:all 0.3s ease; outline:none; font-weight:500; }
        .filters-top .search-wrapper input:focus { border-color:var(--gold); box-shadow:0 0 0 4px rgba(245,158,11,0.1); background:var(--bg-main); }
        .filters-grid { display:flex; flex-wrap:wrap; gap:12px 16px; align-items:flex-end; }
        .filter-group { display:flex; flex-direction:column; gap:4px; min-width:120px; flex:1 0 auto; }
        .filter-group label { font-size:11px; font-weight:700; color:var(--text-secondary); text-transform:uppercase; letter-spacing:0.5px; }
        .filter-group select,.filter-group input { padding:10px 14px; border-radius:12px; border:1px solid var(--border-color); background:var(--bg-input); font-size:13px; color:var(--text-primary); outline:none; transition:all 0.3s ease; width:100%; min-width:100px; font-weight:500; }
        .filter-group select:focus,.filter-group input:focus { border-color:var(--gold); box-shadow:0 0 0 4px rgba(245,158,11,0.08); background:var(--bg-main); }
        .filter-group select { cursor:pointer; appearance:none; background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%2364748b' d='M6 8L1 3h10z'/%3E%3C/svg%3E"); background-repeat:no-repeat; background-position:right 14px center; padding-right:36px; }
        .filter-actions { display:flex; gap:8px; align-items:center; margin-left:auto; }
        .btn-apply { padding:10px 28px; background:var(--gradient-gold); color:#fff; border:none; border-radius:12px; font-weight:700; font-size:13px; cursor:pointer; transition:all 0.3s ease; white-space:nowrap; box-shadow:0 4px 12px rgba(245,158,11,0.2); }
        .btn-apply:hover { transform:translateY(-2px); box-shadow:0 8px 20px rgba(245,158,11,0.3); }
        .btn-clear { padding:10px 20px; background:transparent; color:var(--text-secondary); border:1px solid var(--border-color); border-radius:12px; font-weight:600; font-size:13px; cursor:pointer; transition:all 0.3s ease; white-space:nowrap; }
        .btn-clear:hover { background:var(--bg-card-hover); border-color:var(--border-dark); color:var(--text-primary); }
        .results-header { display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; flex-wrap:wrap; gap:8px; }
        .results-header .count { font-size:14px; color:var(--text-secondary); font-weight:500; }
        .results-header .count strong { color:var(--text-primary); font-weight:700; }
        .results-header .view-options { display:flex; gap:6px; }
        .results-header .view-options button { width:38px; height:38px; border-radius:10px; border:1px solid var(--border-color); background:var(--bg-main); color:var(--text-muted); cursor:pointer; transition:all 0.2s ease; display:flex; align-items:center; justify-content:center; font-size:14px; }
        .results-header .view-options button.active { background:var(--gold); border-color:var(--gold); color:#fff; box-shadow:0 2px 8px rgba(245,158,11,0.2); }
        .results-header .view-options button:hover:not(.active) { background:var(--bg-card-hover); border-color:var(--border-dark); color:var(--text-primary); }
        .room-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(280px,1fr)); gap:24px; margin-bottom:28px; }
        .room-card { background:var(--bg-card); border-radius:20px; box-shadow:var(--shadow-sm); border:1px solid var(--border-color); overflow:hidden; transition:all 0.35s cubic-bezier(0.25,0.46,0.45,0.94); display:flex; flex-direction:column; cursor:pointer; position:relative; }
        .room-card:hover { transform:translateY(-8px); box-shadow:var(--shadow-lg); border-color:var(--border-dark); }
        .room-card .card-image { height:300px; position:relative; overflow:hidden; background:var(--bg-input); }
        .room-card .card-image img { width:100%; height:100%; object-fit:cover; transition:transform 0.5s ease; }
        .room-card:hover .card-image img { transform:scale(1.05); }
        .room-card .card-image .room-badge { position:absolute; top:14px; left:14px; background:rgba(0,0,0,0.6); backdrop-filter:blur(6px); color:#fff; font-size:11px; font-weight:700; padding:5px 14px; border-radius:30px; letter-spacing:0.3px; text-transform:uppercase; border:1px solid rgba(255,255,255,0.1); }
        .room-card .card-image .status-badge { position:absolute; bottom:14px; left:14px; padding:4px 14px; border-radius:30px; font-size:11px; font-weight:700; text-transform:uppercase; background:rgba(0,0,0,0.7); backdrop-filter:blur(4px); color:#fff; border:1px solid rgba(255,255,255,0.15); }
        .room-card .card-image .status-badge.available { background:var(--green); color:#fff; }
        .room-card .card-image .status-badge.booked { background:var(--gold); color:#0f172a; }
        .room-card .card-image .status-badge.ordered { background:var(--blue); color:#fff; }
        .room-card .card-image .status-badge.taken { background:var(--red); color:#fff; }
        .room-card .card-body { padding:12px 16px 14px; flex:1; display:flex; flex-direction:column; }
        .room-card .card-body .room-title { font-size:16px; font-weight:700; color:var(--text-primary); margin-bottom:2px; line-height:1.2; }
        .room-card .card-body .room-location { font-size:12px; color:var(--text-secondary); display:flex; align-items:center; gap:5px; margin-bottom:6px; }
        .room-card .card-body .room-location i { font-size:12px; color:var(--text-muted); }
        .room-card .card-body .room-price { font-size:18px; font-weight:800; color:var(--text-primary); margin-bottom:2px; }
        .room-card .card-body .room-price small { font-size:12px; font-weight:500; color:var(--text-secondary); }
        .room-card .card-body .room-details { display:flex; flex-wrap:wrap; gap:5px 10px; margin:6px 0 8px; padding:7px 0; border-top:1px solid var(--border-color); border-bottom:1px solid var(--border-color); }
        .room-card .card-body .room-details span { font-size:11px; color:var(--text-secondary); display:flex; align-items:center; gap:4px; font-weight:500; }
        .room-card .card-body .room-details span i { color:var(--text-muted); font-size:14px; }
        .room-card .card-body .card-actions { display:flex; gap:8px; margin-top:4px; flex-wrap:wrap; }
        .room-card .card-body .card-actions .btn-details { flex:1; padding:8px 10px; border-radius:10px; border:1px solid var(--border-color); background:var(--bg-main); color:var(--text-primary); font-weight:600; font-size:12px; cursor:pointer; transition:all 0.25s ease; text-align:center; min-width:60px; }
        .room-card .card-body .card-actions .btn-details:hover { background:var(--bg-card-hover); border-color:var(--border-dark); transform:translateY(-1px); }
        .room-card .card-body .card-actions .btn-book,.room-card .card-body .card-actions .btn-order { flex:1; padding:10px 12px; border-radius:12px; border:none; font-weight:700; font-size:13px; cursor:pointer; transition:all 0.25s ease; text-align:center; min-width:60px; }
        .room-card .card-body .card-actions .btn-book { background:var(--gradient-gold); color:#fff; box-shadow:0 4px 12px rgba(245,158,11,0.15); }
        .room-card .card-body .card-actions .btn-book:hover:not(:disabled) { transform:translateY(-2px); box-shadow:0 8px 20px rgba(245,158,11,0.25); }
        .room-card .card-body .card-actions .btn-order { background:var(--gradient-blue); color:#fff; box-shadow:0 4px 12px rgba(59,130,246,0.15); }
        .room-card .card-body .card-actions .btn-order:hover:not(:disabled) { transform:translateY(-2px); box-shadow:0 8px 20px rgba(59,130,246,0.25); }
        .room-card .card-body .card-actions .btn-book:disabled,.room-card .card-body .card-actions .btn-order:disabled { opacity:0.5; cursor:not-allowed; transform:none!important; }
        .room-grid.list-view { display:flex; flex-direction:column; gap:16px; }
        .room-grid.list-view .room-card { flex-direction:row; align-items:stretch; min-height:180px; }
        .room-grid.list-view .room-card .card-image { width:180px; min-width:180px; height:auto; }
        .room-grid.list-view .room-card .card-body { display:flex; flex-direction:column; justify-content:center; }
        .room-grid.list-view .room-card .card-body .room-details { border:none; padding:8px 0; margin:8px 0 12px; }
        @media(max-width:768px){ .room-card .card-image { height:240px; } .room-grid.list-view .room-card { flex-direction:column; } .room-grid.list-view .room-card .card-image { width:100%; min-width:unset; height:240px; } }
        .pagination { display:flex; justify-content:center; align-items:center; gap:8px; margin:8px 0 32px; }
        .pagination button { width:40px; height:40px; border-radius:12px; border:1px solid var(--border-color); background:var(--bg-main); color:var(--text-primary); font-weight:600; font-size:14px; cursor:pointer; transition:all 0.2s ease; display:flex; align-items:center; justify-content:center; }
        .pagination button:hover:not(.active):not(:disabled) { background:var(--bg-card-hover); border-color:var(--border-dark); transform:translateY(-2px); }
        .pagination button.active { background:var(--gradient-gold); border-color:var(--gold); color:#fff; box-shadow:0 4px 12px rgba(245,158,11,0.2); }
        .pagination button:disabled { opacity:0.4; cursor:not-allowed; transform:none; }
        .pagination .page-dots { color:var(--text-muted); padding:0 6px; font-weight:700; }
        .pagination .page-info { font-size:13px; color:var(--text-muted); margin-left:12px; font-weight:500; }
        .features-section { display:grid; grid-template-columns:repeat(auto-fit,minmax(200px,1fr)); gap:16px; margin-top:12px; padding-top:8px; }
        .feature-card { background:var(--bg-feature); border-radius:16px; padding:18px 20px; border:1px solid var(--border-color); display:flex; align-items:center; gap:16px; transition:all 0.3s ease; box-shadow:var(--shadow-sm); }
        .feature-card:hover { border-color:var(--border-dark); box-shadow:var(--shadow-md); transform:translateY(-2px); }
        .feature-card .feature-icon { width:48px; height:48px; border-radius:14px; background:linear-gradient(135deg,#fef3c7,#fde68a); color:#d97706; display:flex; align-items:center; justify-content:center; font-size:22px; flex-shrink:0; }
        .feature-card .feature-text h4 { font-size:15px; font-weight:700; color:var(--text-primary); }
        .feature-card .feature-text p { font-size:12px; color:var(--text-secondary); margin-top:2px; font-weight:500; }
        .section-placeholder { animation:fadeIn 0.3s ease; }
        @keyframes fadeIn { from{ opacity:0; transform:translateY(8px); } to{ opacity:1; transform:translateY(0); } }
        .placeholder-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(300px,1fr)); gap:24px; }
        .placeholder-card { background:var(--bg-card); border-radius:20px; padding:24px; border:1px solid var(--border-color); box-shadow:var(--shadow-sm); transition:all 0.3s ease; }
        .placeholder-card:hover { box-shadow:var(--shadow-md); border-color:var(--border-dark); }
        .placeholder-card .icon-circle { width:52px; height:52px; border-radius:16px; background:#fef3c7; color:#d97706; display:flex; align-items:center; justify-content:center; font-size:24px; margin-bottom:16px; }
        .placeholder-card h3 { font-size:18px; font-weight:700; color:var(--text-primary); margin-bottom:6px; }
        .placeholder-card p { color:var(--text-secondary); font-size:14px; line-height:1.6; }
        .placeholder-card .status-badge { display:inline-block; padding:4px 12px; border-radius:20px; font-size:12px; font-weight:700; margin-top:10px; }
        .status-badge.success { background:#dcfce7; color:#16a34a; }
        .status-badge.warning { background:#fef3c7; color:#d97706; }
        .status-badge.info { background:#dbeafe; color:#2563eb; }
        .admin-form { max-width:700px; margin:0 auto; background:var(--bg-card); border-radius:20px; padding:32px; border:1px solid var(--border-color); box-shadow:var(--shadow-sm); }
        .admin-form .form-row { display:grid; grid-template-columns:1fr 1fr; gap:16px; }
        .admin-form .form-group { margin-bottom:16px; }
        .admin-form .form-group label { display:block; font-size:13px; font-weight:700; color:var(--text-primary); margin-bottom:4px; }
        .admin-form .form-group input,.admin-form .form-group select,.admin-form .form-group textarea { width:100%; padding:10px 14px; border-radius:12px; border:1px solid var(--border-color); background:var(--bg-input); font-size:14px; color:var(--text-primary); outline:none; transition:all 0.3s ease; }
        .admin-form .form-group input:focus,.admin-form .form-group select:focus,.admin-form .form-group textarea:focus { border-color:var(--gold); box-shadow:0 0 0 4px rgba(245,158,11,0.08); background:var(--bg-main); }
        .admin-form .form-group textarea { resize:vertical; min-height:60px; }
        .admin-form .form-group .file-upload-wrapper { display:flex; align-items:center; gap:12px; flex-wrap:wrap; }
        .admin-form .form-group .file-upload-wrapper input[type="file"] { flex:1; padding:8px; border:1px dashed var(--border-dark); border-radius:12px; background:var(--bg-input); cursor:pointer; }
        .admin-form .form-group .file-upload-wrapper .image-preview { width:80px; height:80px; border-radius:12px; object-fit:cover; border:1px solid var(--border-color); display:none; }
        .admin-form .form-group .file-upload-wrapper .image-preview.show { display:block; }
        .admin-form .btn-submit { padding:12px 32px; background:var(--gradient-green); color:#fff; border:none; border-radius:12px; font-weight:700; font-size:15px; cursor:pointer; transition:all 0.3s ease; box-shadow:0 4px 12px rgba(34,197,94,0.2); }
        .admin-form .btn-submit:hover { transform:translateY(-2px); box-shadow:0 8px 20px rgba(34,197,94,0.3); }
        .detail-modal-overlay { display:none; position:fixed; inset:0; background:rgba(0,0,0,0.75); backdrop-filter:blur(8px); z-index:2000; align-items:center; justify-content:center; padding:24px; animation:fadeIn 0.3s ease; }
        .detail-modal-overlay.open { display:flex; }
        .detail-modal { background:var(--bg-modal); border-radius:32px; max-width:960px; width:100%; max-height:92vh; overflow-y:auto; box-shadow:var(--shadow-xl); animation:modalIn 0.4s cubic-bezier(0.34,1.56,0.64,1); padding:0; transition:background 0.3s; position:relative; }
        @keyframes modalIn { from{ opacity:0; transform:scale(0.92) translateY(30px); } to{ opacity:1; transform:scale(1) translateY(0); } }
        .detail-modal .dm-close { position:absolute; top:18px; right:22px; background:rgba(0,0,0,0.5); backdrop-filter:blur(6px); border:1px solid rgba(255,255,255,0.15); color:#fff; width:44px; height:44px; border-radius:50%; font-size:22px; cursor:pointer; transition:all 0.25s ease; display:flex; align-items:center; justify-content:center; z-index:10; border:none; }
        .detail-modal .dm-close:hover { background:rgba(255,255,255,0.2); transform:rotate(90deg) scale(1.05); }
        .detail-modal .dm-image-wrap { position:relative; width:100%; height:480px; overflow:hidden; border-radius:32px 32px 0 0; background:var(--bg-input); cursor:zoom-in; }
        .detail-modal .dm-image-wrap img { width:100%; height:100%; object-fit:cover; transition:transform 0.4s cubic-bezier(0.25,0.46,0.45,0.94); transform-origin:center center; }
        .detail-modal .dm-image-wrap.zoomed img { transform:scale(2.2); cursor:zoom-out; }
        .detail-modal .dm-image-wrap .dm-zoom-hint { position:absolute; bottom:20px; right:20px; background:rgba(0,0,0,0.6); backdrop-filter:blur(6px); color:#fff; padding:6px 16px; border-radius:30px; font-size:12px; font-weight:500; letter-spacing:0.3px; border:1px solid rgba(255,255,255,0.1); pointer-events:none; }
        .detail-modal .dm-image-wrap .dm-status-overlay { position:absolute; top:20px; left:20px; display:flex; gap:10px; flex-wrap:wrap; }
        .detail-modal .dm-image-wrap .dm-status-overlay .dm-badge { padding:6px 18px; border-radius:30px; font-size:12px; font-weight:700; text-transform:uppercase; background:rgba(0,0,0,0.6); backdrop-filter:blur(6px); color:#fff; border:1px solid rgba(255,255,255,0.1); }
        .detail-modal .dm-image-wrap .dm-status-overlay .dm-badge.available { background:var(--green); color:#fff; }
        .detail-modal .dm-image-wrap .dm-status-overlay .dm-badge.booked { background:var(--gold); color:#0f172a; }
        .detail-modal .dm-image-wrap .dm-status-overlay .dm-badge.ordered { background:var(--blue); color:#fff; }
        .detail-modal .dm-image-wrap .dm-status-overlay .dm-badge.taken { background:var(--red); color:#fff; }
        .detail-modal .dm-image-wrap .dm-gallery-nav { position:absolute; top:50%; transform:translateY(-50%); width:40px; height:40px; border-radius:50%; border:none; background:rgba(0,0,0,0.5); color:#fff; font-size:16px; cursor:pointer; z-index:3; display:flex; align-items:center; justify-content:center; transition:background 0.2s; }
        .detail-modal .dm-image-wrap .dm-gallery-nav:hover { background:rgba(0,0,0,0.75); }
        .detail-modal .dm-image-wrap .dm-gallery-prev { left:16px; }
        .detail-modal .dm-image-wrap .dm-gallery-next { right:16px; }
        .detail-modal .dm-image-wrap .dm-gallery-counter { position:absolute; bottom:20px; left:50%; transform:translateX(-50%); background:rgba(0,0,0,0.6); backdrop-filter:blur(6px); color:#fff; padding:5px 14px; border-radius:30px; font-size:12px; font-weight:600; border:1px solid rgba(255,255,255,0.1); pointer-events:none; }
        .detail-modal .dm-gallery-thumbs { display:flex; gap:8px; padding:12px 24px 0; overflow-x:auto; }
        .detail-modal .dm-gallery-thumbs img { width:64px; height:48px; object-fit:cover; border-radius:8px; cursor:pointer; opacity:0.6; border:2px solid transparent; transition:0.2s; flex-shrink:0; }
        .detail-modal .dm-gallery-thumbs img:hover { opacity:0.9; }
        .detail-modal .dm-gallery-thumbs img.active { opacity:1; border-color:var(--gold); }
        .detail-modal .dm-body { padding:28px 36px 32px; }
        .detail-modal .dm-body .dm-top { display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:12px; margin-bottom:12px; }
        .detail-modal .dm-body .dm-top h2 { font-size:28px; font-weight:800; color:var(--text-primary); letter-spacing:-0.5px; margin:0; }
        .detail-modal .dm-body .dm-top .dm-price-tag { font-size:26px; font-weight:800; color:var(--gold); background:var(--bg-badge); padding:6px 22px; border-radius:30px; white-space:nowrap; }
        .detail-modal .dm-body .dm-meta { display:flex; flex-wrap:wrap; gap:16px 28px; margin:8px 0 18px; padding:14px 0; border-top:1px solid var(--border-color); border-bottom:1px solid var(--border-color); }
        .detail-modal .dm-body .dm-meta span { font-size:14px; color:var(--text-secondary); display:flex; align-items:center; gap:8px; font-weight:500; }
        .detail-modal .dm-body .dm-meta span i { color:var(--text-muted); width:18px; font-size:15px; }
        .detail-modal .dm-body .dm-desc { font-size:15px; color:var(--text-secondary); line-height:1.7; margin-bottom:20px; }
        .detail-modal .dm-body .dm-actions { display:flex; gap:12px; flex-wrap:wrap; margin-top:6px; }
        .detail-modal .dm-body .dm-actions .btn-dm-primary { padding:12px 32px; border-radius:14px; border:none; background:var(--gradient-gold); color:#fff; font-weight:700; font-size:15px; cursor:pointer; transition:all 0.3s ease; box-shadow:0 4px 16px rgba(245,158,11,0.25); display:flex; align-items:center; gap:8px; }
        .detail-modal .dm-body .dm-actions .btn-dm-primary:hover:not(:disabled) { transform:translateY(-3px); box-shadow:0 8px 28px rgba(245,158,11,0.35); }
        .detail-modal .dm-body .dm-actions .btn-dm-primary:disabled { opacity:0.5; cursor:not-allowed; transform:none!important; }
        .detail-modal .dm-body .dm-actions .btn-dm-secondary { padding:12px 32px; border-radius:14px; border:1px solid var(--border-color); background:var(--bg-main); color:var(--text-primary); font-weight:600; font-size:15px; cursor:pointer; transition:all 0.3s ease; display:flex; align-items:center; gap:8px; }
        .detail-modal .dm-body .dm-actions .btn-dm-secondary:hover { background:var(--bg-card-hover); border-color:var(--border-dark); transform:translateY(-2px); }
        .detail-modal .dm-body .dm-actions .btn-dm-blue { background:var(--gradient-blue); box-shadow:0 4px 16px rgba(59,130,246,0.2); }
        .detail-modal .dm-body .dm-actions .btn-dm-blue:hover:not(:disabled) { box-shadow:0 8px 28px rgba(59,130,246,0.3); }
        @media(max-width:768px){ .detail-modal .dm-image-wrap { height:280px; border-radius:24px 24px 0 0; } .detail-modal .dm-body { padding:20px 20px 24px; } .detail-modal .dm-body .dm-top h2 { font-size:22px; } .detail-modal .dm-body .dm-top .dm-price-tag { font-size:20px; padding:4px 16px; } .detail-modal .dm-body .dm-actions { flex-direction:column; } .detail-modal .dm-body .dm-actions .btn-dm-primary,.detail-modal .dm-body .dm-actions .btn-dm-secondary { width:100%; justify-content:center; } .detail-modal .dm-close { top:12px; right:14px; width:38px; height:38px; font-size:18px; } }
        @media(max-width:480px){ .detail-modal .dm-image-wrap { height:200px; } .detail-modal .dm-body .dm-top { flex-direction:column; align-items:flex-start; } .detail-modal .dm-body .dm-meta { gap:10px 16px; } .detail-modal .dm-body .dm-meta span { font-size:12px; } }
        .modal-overlay { display:none; position:fixed; inset:0; background:rgba(15,23,42,0.6); z-index:1000; align-items:center; justify-content:center; padding:20px; }
        .modal-overlay.open { display:flex; }
        .modal { background:var(--bg-modal); border-radius:24px; max-width:520px; width:100%; padding:32px 36px 28px; box-shadow:var(--shadow-xl); animation:modalIn 0.3s cubic-bezier(0.34,1.56,0.64,1); max-height:90vh; overflow-y:auto; transition:background 0.3s; }
        .modal .modal-close { float:right; background:none; border:none; font-size:24px; color:var(--text-muted); cursor:pointer; transition:color 0.2s ease; line-height:1; padding:4px; }
        .modal .modal-close:hover { color:var(--text-primary); }
        .modal h3 { font-size:24px; font-weight:800; color:var(--text-primary); margin-bottom:4px; }
        .modal .modal-sub { color:var(--text-secondary); font-size:14px; margin-bottom:20px; font-weight:500; }
        .modal .modal-detail-row { display:flex; justify-content:space-between; padding:12px 0; border-bottom:1px solid var(--border-color); font-size:15px; }
        .modal .modal-detail-row .label { color:var(--text-secondary); font-weight:500; }
        .modal .modal-detail-row .value { color:var(--text-primary); font-weight:700; }
        .modal .modal-actions { display:flex; gap:12px; margin-top:24px; }
        .modal .modal-actions .btn-secondary { flex:1; padding:12px; border-radius:14px; border:1px solid var(--border-color); background:var(--bg-main); color:var(--text-primary); font-weight:600; font-size:14px; cursor:pointer; transition:all 0.2s ease; }
        .modal .modal-actions .btn-secondary:hover { background:var(--bg-card-hover); }
        .modal .modal-actions .btn-primary { flex:1; padding:12px; border-radius:14px; border:none; background:var(--gradient-gold); color:#fff; font-weight:700; font-size:14px; cursor:pointer; transition:all 0.3s ease; box-shadow:0 4px 12px rgba(245,158,11,0.2); }
        .modal .modal-actions .btn-primary:hover { transform:translateY(-2px); box-shadow:0 8px 20px rgba(245,158,11,0.3); }
        .auth-modal .auth-tabs { display:flex; gap:0; margin-bottom:20px; border-bottom:2px solid var(--border-color); }
        .auth-modal .auth-tabs button { flex:1; padding:10px 0; background:none; border:none; font-weight:600; font-size:15px; color:var(--text-secondary); cursor:pointer; transition:all 0.2s ease; position:relative; }
        .auth-modal .auth-tabs button.active { color:var(--gold); }
        .auth-modal .auth-tabs button.active::after { content:''; position:absolute; bottom:-2px; left:0; right:0; height:2px; background:var(--gold); }
        .auth-modal .auth-tabs button:hover { color:var(--text-primary); }
        .auth-modal .auth-panel { display:none; }
        .auth-modal .auth-panel.active { display:block; }
        .auth-modal .form-group { margin-bottom:16px; }
        .auth-modal .form-group label { display:block; font-size:13px; font-weight:700; color:var(--text-primary); margin-bottom:4px; }
        .auth-modal .form-group input { width:100%; padding:12px 16px; border-radius:12px; border:1px solid var(--border-color); background:var(--bg-input); font-size:14px; color:var(--text-primary); transition:all 0.3s ease; outline:none; }
        .auth-modal .form-group input:focus { border-color:var(--gold); box-shadow:0 0 0 4px rgba(245,158,11,0.08); background:var(--bg-main); }
        .auth-modal .form-group .auth-checkbox { display:flex; align-items:center; gap:10px; margin-top:4px; }
        .auth-modal .form-group .auth-checkbox input[type="checkbox"] { width:18px; height:18px; accent-color:var(--gold); cursor:pointer; }
        .auth-modal .form-group .auth-checkbox label { font-size:13px; font-weight:500; color:var(--text-secondary); cursor:pointer; margin:0; }
        .auth-modal .btn-auth { width:100%; padding:14px; border:none; border-radius:12px; background:var(--gradient-gold); color:#fff; font-weight:700; font-size:16px; cursor:pointer; transition:all 0.3s ease; box-shadow:0 4px 12px rgba(245,158,11,0.2); }
        .auth-modal .btn-auth:hover { transform:translateY(-2px); box-shadow:0 8px 20px rgba(245,158,11,0.3); }
        .auth-modal .auth-error { color:var(--red); font-size:13px; padding:8px 12px; background:#fef2f2; border-radius:10px; margin-bottom:12px; display:none; align-items:center; gap:8px; }
        .auth-modal .auth-error.show { display:flex; }
        .auth-modal .auth-success { color:var(--green); font-size:13px; padding:8px 12px; background:#dcfce7; border-radius:10px; margin-bottom:12px; display:none; align-items:center; gap:8px; }
        .auth-modal .auth-success.show { display:flex; }
        .toast-container { position:fixed; bottom:24px; right:24px; z-index:2000; display:flex; flex-direction:column; gap:10px; }
        .toast { background:var(--bg-toast); color:var(--text-inverse); padding:16px 24px; border-radius:16px; box-shadow:var(--shadow-xl); font-size:14px; font-weight:500; display:flex; align-items:center; gap:14px; animation:toastIn 0.4s cubic-bezier(0.34,1.56,0.64,1); min-width:260px; border:1px solid rgba(255,255,255,0.05); }
        .toast i { font-size:20px; }
        .toast.success i { color:var(--green); }
        .toast.info i { color:var(--blue); }
        .toast.warning i { color:var(--gold); }
        .toast.error i { color:var(--red); }
        @keyframes toastIn { from{ opacity:0; transform:translateX(40px) scale(0.9); } to{ opacity:1; transform:translateX(0) scale(1); } }
        @media(max-width:1024px){ .sidebar { width:var(--sidebar-width-collapsed); min-width:var(--sidebar-width-collapsed); padding:20px 10px; } .sidebar-brand h1 { display:none; } .sidebar-brand .brand-icon { margin:0 auto; width:44px; height:44px; font-size:18px; } .sidebar-nav a span,.sidebar-footer a span { display:none; } .sidebar-nav a { justify-content:center; padding:12px; } .sidebar-nav a i { font-size:20px; width:auto; } .sidebar-nav .nav-label { display:none; } .sidebar-footer a { justify-content:center; padding:12px; } .sidebar-footer a i { font-size:20px; width:auto; } .main-content { padding:20px 18px 24px; } .admin-form .form-row { grid-template-columns:1fr; } }
        @media(max-width:768px){ .sidebar { display:none; } .main-content { padding:16px 14px 20px; height:100vh; } .filters-section { padding:16px 18px; } .filters-grid { flex-direction:column; gap:10px; } .filter-group { min-width:100%; width:100%; } .filter-actions { margin-left:0; width:100%; justify-content:stretch; } .filter-actions .btn-apply,.filter-actions .btn-clear { flex:1; text-align:center; } .room-grid { grid-template-columns:1fr; } .page-header h2 { font-size:24px; } .features-section { grid-template-columns:1fr 1fr; } .modal { padding:24px 18px 20px; margin:10px; } .results-header { flex-direction:column; align-items:flex-start; gap:8px; } .pagination .page-info { display:none; } .placeholder-grid { grid-template-columns:1fr; } .admin-form { padding:20px; } .admin-form .form-row { grid-template-columns:1fr; } .room-card .card-body .card-actions { flex-direction:column; } .room-card .card-body .card-actions .btn-details,.room-card .card-body .card-actions .btn-book,.room-card .card-body .card-actions .btn-order { width:100%; } .header-actions .theme-toggle,.header-actions .lang-toggle { width:38px; height:38px; font-size:15px; } }
        @media(max-width:480px){ .features-section { grid-template-columns:1fr; } .filters-top { flex-direction:column; } .filters-top .search-wrapper { width:100%; } .pagination button { width:36px; height:36px; font-size:12px; } .header-actions .theme-toggle,.header-actions .lang-toggle { width:34px; height:34px; font-size:13px; } }
        .mobile-toggle { display:none; background:var(--bg-sidebar); color:#fff; border:none; border-radius:14px; padding:10px 16px; font-size:18px; cursor:pointer; margin-bottom:16px; align-items:center; gap:10px; box-shadow:var(--shadow-sm); }
        @media(max-width:768px){ .mobile-toggle { display:inline-flex; } .mobile-toggle span { font-size:16px; font-weight:700; } }
        .sidebar-overlay { display:none; position:fixed; inset:0; background:rgba(0,0,0,0.3); z-index:99; backdrop-filter:blur(4px); }
        .sidebar-overlay.open { display:block; }
        @media(max-width:768px){ .sidebar.mobile-open { display:flex; position:fixed; left:0; top:0; height:100vh; z-index:100; width:280px; min-width:280px; box-shadow:8px 0 40px rgba(0,0,0,0.1); animation:slideIn 0.3s cubic-bezier(0.34,1.56,0.64,1); } }
        @keyframes slideIn { from{ transform:translateX(-100%); opacity:0; } to{ transform:translateX(0); opacity:1; } }
        .content-section { display:none; }
        .content-section.active { display:block; animation:fadeIn 0.3s ease; }
        .sidebar-nav .admin-nav,.sidebar-nav .messages-nav,.sidebar-nav .reports-nav { display:none; }
        .sidebar-nav .admin-nav.show,.sidebar-nav .messages-nav.show,.sidebar-nav .reports-nav.show { display:flex; }
        .contact-form { max-width:600px; margin:0 auto; background:var(--bg-card); border-radius:20px; padding:32px; border:1px solid var(--border-color); box-shadow:var(--shadow-sm); }
        .contact-form .form-group { margin-bottom:16px; }
        .contact-form .form-group label { display:block; font-size:13px; font-weight:700; color:var(--text-primary); margin-bottom:4px; }
        .contact-form .form-group input,.contact-form .form-group textarea { width:100%; padding:10px 14px; border-radius:12px; border:1px solid var(--border-color); background:var(--bg-input); font-size:14px; color:var(--text-primary); outline:none; transition:all 0.3s ease; }
        .contact-form .form-group input:focus,.contact-form .form-group textarea:focus { border-color:var(--gold); box-shadow:0 0 0 4px rgba(245,158,11,0.08); background:var(--bg-main); }
        .contact-form .form-group textarea { min-height:100px; resize:vertical; }
        .contact-form .btn-send { padding:12px 32px; background:var(--gradient-blue); color:#fff; border:none; border-radius:12px; font-weight:700; font-size:15px; cursor:pointer; transition:all 0.3s ease; box-shadow:0 4px 12px rgba(59,130,246,0.2); }
        .contact-form .btn-send:hover { transform:translateY(-2px); box-shadow:0 8px 20px rgba(59,130,246,0.3); }
        .message-item { background:var(--bg-card); border-radius:16px; padding:20px; border:1px solid var(--border-color); margin-bottom:16px; transition:all 0.3s ease; }
        .message-item:hover { border-color:var(--border-dark); box-shadow:var(--shadow-sm); }
        .message-item .msg-header { display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px; margin-bottom:8px; }
        .message-item .msg-header .name { font-weight:700; color:var(--text-primary); font-size:16px; }
        .message-item .msg-header .date { font-size:12px; color:var(--text-muted); }
        .message-item .msg-contact { font-size:13px; color:var(--text-secondary); margin-bottom:6px; }
        .message-item .msg-contact i { width:16px; color:var(--text-muted); }
        .message-item .msg-body { color:var(--text-primary); font-size:14px; line-height:1.6; margin-top:6px; padding-top:10px; border-top:1px solid var(--border-color); }
        .payment-summary-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:16px; margin-bottom:28px; }
        .payment-summary-card { background:var(--bg-card); border-radius:16px; padding:20px 18px; border:1px solid var(--border-color); box-shadow:var(--shadow-sm); transition:all 0.3s ease; }
        .payment-summary-card:hover { transform:translateY(-3px); box-shadow:var(--shadow-md); border-color:var(--border-dark); }
        .payment-summary-card .ps-icon { width:42px; height:42px; border-radius:12px; display:flex; align-items:center; justify-content:center; font-size:18px; margin-bottom:10px; }
        .payment-summary-card .ps-icon.green { background:#dcfce7; color:#16a34a; }
        .payment-summary-card .ps-icon.orange { background:#fef3c7; color:#d97706; }
        .payment-summary-card .ps-icon.red { background:#fee2e2; color:#dc2626; }
        .payment-summary-card .ps-icon.blue { background:#dbeafe; color:#2563eb; }
        .payment-summary-card .ps-icon.purple { background:#ede9fe; color:#7c3aed; }
        .payment-summary-card .ps-icon.teal { background:#ccfbf1; color:#0d9488; }
        .payment-summary-card .ps-label { font-size:12px; font-weight:600; color:var(--text-secondary); text-transform:uppercase; letter-spacing:0.4px; }
        .payment-summary-card .ps-value { font-size:22px; font-weight:800; color:var(--text-primary); margin-top:2px; }
        .payment-summary-card .ps-sub { font-size:12px; color:var(--text-muted); margin-top:2px; }
        .booking-summary-card { background:var(--bg-card); border-radius:20px; padding:24px 28px; border:1px solid var(--border-color); box-shadow:var(--shadow-sm); margin-bottom:28px; }
        .booking-summary-card .bs-header { display:flex; align-items:center; gap:16px; margin-bottom:20px; flex-wrap:wrap; }
        .booking-summary-card .bs-header h4 { font-weight:700; color:var(--text-primary); font-size:18px; margin:0; }
        .booking-summary-card .bs-body { display:grid; grid-template-columns:120px 1fr; gap:20px; }
        .booking-summary-card .bs-body .bs-img { width:120px; height:120px; border-radius:14px; object-fit:cover; border:1px solid var(--border-color); }
        .booking-summary-card .bs-body .bs-info { display:grid; grid-template-columns:1fr 1fr 1fr; gap:8px 20px; }
        .booking-summary-card .bs-body .bs-info .bs-item { display:flex; flex-direction:column; }
        .booking-summary-card .bs-body .bs-info .bs-item .bs-label { font-size:11px; font-weight:600; color:var(--text-muted); text-transform:uppercase; letter-spacing:0.3px; }
        .booking-summary-card .bs-body .bs-info .bs-item .bs-value { font-size:14px; font-weight:600; color:var(--text-primary); }
        @media(max-width:768px){ .booking-summary-card .bs-body { grid-template-columns:1fr; } .booking-summary-card .bs-body .bs-img { width:100%; height:160px; } .booking-summary-card .bs-body .bs-info { grid-template-columns:1fr 1fr; } }
        @media(max-width:480px){ .booking-summary-card .bs-body .bs-info { grid-template-columns:1fr; } }
        .payment-methods-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(110px,1fr)); gap:12px; margin-bottom:24px; }
        .payment-method-card { background:var(--bg-card); border:2px solid var(--border-color); border-radius:14px; padding:16px 12px; text-align:center; cursor:pointer; transition:all 0.25s ease; box-shadow:var(--shadow-sm); }
        .payment-method-card:hover { border-color:var(--border-dark); transform:translateY(-2px); box-shadow:var(--shadow-md); }
        .payment-method-card.selected { border-color:var(--gold); background:var(--bg-badge); box-shadow:0 0 0 4px rgba(245,158,11,0.1); }
        .payment-method-card .pm-icon { font-size:28px; margin-bottom:4px; display:block; }
        .payment-method-card .pm-name { font-size:12px; font-weight:600; color:var(--text-primary); }
        .payment-method-card .pm-check { display:none; color:var(--gold); font-size:14px; margin-top:4px; }
        .payment-method-card.selected .pm-check { display:block; }
        .payment-panel { background:var(--bg-card); border-radius:16px; padding:24px 28px; border:1px solid var(--border-color); margin-bottom:24px; display:none; animation:fadeIn 0.3s ease; }
        .payment-panel.active { display:block; }
        .payment-panel .pp-row { display:grid; grid-template-columns:1fr 1fr; gap:16px; }
        .payment-panel .pp-group { margin-bottom:14px; }
        .payment-panel .pp-group label { display:block; font-size:12px; font-weight:600; color:var(--text-primary); margin-bottom:4px; }
        .payment-panel .pp-group input,.payment-panel .pp-group select { width:100%; padding:10px 14px; border-radius:12px; border:1px solid var(--border-color); background:var(--bg-input); font-size:14px; color:var(--text-primary); outline:none; transition:all 0.3s ease; }
        .payment-panel .pp-group input:focus,.payment-panel .pp-group select:focus { border-color:var(--gold); box-shadow:0 0 0 4px rgba(245,158,11,0.08); background:var(--bg-main); }
        .payment-panel .btn-continue { padding:12px 32px; background:var(--gradient-gold); color:#fff; border:none; border-radius:12px; font-weight:700; font-size:14px; cursor:pointer; transition:all 0.3s ease; box-shadow:0 4px 12px rgba(245,158,11,0.2); }
        .payment-panel .btn-continue:hover { transform:translateY(-2px); box-shadow:0 8px 20px rgba(245,158,11,0.3); }
        @media(max-width:640px){ .payment-panel .pp-row { grid-template-columns:1fr; } }
        .payment-history-wrap { background:var(--bg-card); border-radius:20px; padding:20px 24px; border:1px solid var(--border-color); overflow-x:auto; margin-bottom:28px; }
        .payment-history-wrap table { width:100%; border-collapse:collapse; font-size:13px; }
        .payment-history-wrap table thead { background:var(--bg-input); border-radius:12px; }
        .payment-history-wrap table th { padding:12px 14px; text-align:left; font-weight:700; color:var(--text-secondary); font-size:11px; text-transform:uppercase; letter-spacing:0.5px; border-bottom:2px solid var(--border-color); }
        .payment-history-wrap table td { padding:12px 14px; border-bottom:1px solid var(--border-color); color:var(--text-primary); vertical-align:middle; }
        .payment-history-wrap table tr:hover td { background:var(--bg-card-hover); }
        .payment-history-wrap .status-badge-sm { display:inline-block; padding:2px 12px; border-radius:20px; font-size:11px; font-weight:700; }
        .status-badge-sm.success { background:#dcfce7; color:#16a34a; }
        .status-badge-sm.warning { background:#fef3c7; color:#d97706; }
        .status-badge-sm.danger { background:#fee2e2; color:#dc2626; }
        .status-badge-sm.secondary { background:#f1f5f9; color:#64748b; }
        .payment-history-wrap .btn-receipt { padding:4px 12px; border-radius:8px; border:1px solid var(--border-color); background:var(--bg-main); font-size:11px; font-weight:600; color:var(--text-primary); cursor:pointer; transition:all 0.2s ease; }
        .payment-history-wrap .btn-receipt:hover { background:var(--bg-card-hover); border-color:var(--border-dark); }
        .receipt-preview { background:var(--bg-card); border-radius:20px; padding:28px 32px; border:1px solid var(--border-color); max-width:540px; margin:0 auto; }
        .receipt-preview .rp-header { display:flex; justify-content:space-between; align-items:center; border-bottom:2px dashed var(--border-color); padding-bottom:16px; margin-bottom:16px; }
        .receipt-preview .rp-header .rp-brand { font-size:22px; font-weight:800; color:var(--text-primary); }
        .receipt-preview .rp-header .rp-brand span { color:var(--gold); }
        .receipt-preview .rp-header .rp-badge { font-size:11px; font-weight:700; color:#22c55e; background:#dcfce7; padding:4px 14px; border-radius:30px; }
        .receipt-preview .rp-body { display:grid; grid-template-columns:1fr 1fr; gap:6px 20px; }
        .receipt-preview .rp-body .rp-item { display:flex; flex-direction:column; }
        .receipt-preview .rp-body .rp-item .rp-label { font-size:10px; font-weight:600; color:var(--text-muted); text-transform:uppercase; letter-spacing:0.3px; }
        .receipt-preview .rp-body .rp-item .rp-value { font-size:14px; font-weight:600; color:var(--text-primary); }
        .receipt-preview .rp-footer { margin-top:20px; padding-top:16px; border-top:2px dashed var(--border-color); display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px; }
        .receipt-preview .rp-footer .rp-qr { width:60px; height:60px; background:var(--bg-input); border-radius:12px; display:flex; align-items:center; justify-content:center; color:var(--text-muted); font-size:28px; border:1px solid var(--border-color); }
        .receipt-preview .rp-footer .rp-actions { display:flex; gap:10px; }
        .receipt-preview .rp-footer .rp-actions button { padding:8px 18px; border-radius:10px; border:none; font-weight:600; font-size:12px; cursor:pointer; transition:all 0.2s ease; }
        .receipt-preview .rp-footer .rp-actions .btn-print { background:var(--bg-sidebar); color:#fff; }
        .receipt-preview .rp-footer .rp-actions .btn-print:hover { background:#1e293b; }
        .receipt-preview .rp-footer .rp-actions .btn-download { background:var(--gold); color:#fff; }
        .receipt-preview .rp-footer .rp-actions .btn-download:hover { background:var(--gold-dark); }
        @media(max-width:480px){ .receipt-preview .rp-body { grid-template-columns:1fr; } .receipt-preview .rp-footer { flex-direction:column; align-items:stretch; } .receipt-preview .rp-footer .rp-qr { margin:0 auto; } .receipt-preview .rp-footer .rp-actions { justify-content:center; } }
        .processing-modal .modal-content { border-radius:24px; border:none; box-shadow:var(--shadow-xl); background:var(--bg-processing); }
        .processing-modal .modal-header { border-bottom:none; padding-bottom:0; }
        .processing-modal .modal-body { text-align:center; padding:30px 36px 36px; }
        .processing-modal .modal-body .pm-spinner { width:72px; height:72px; border-radius:50%; border:4px solid var(--border-color); border-top-color:var(--gold); animation:spin 0.8s linear infinite; margin:0 auto 20px; }
        @keyframes spin { to{ transform:rotate(360deg); } }
        .processing-modal .modal-body .pm-status { font-size:16px; font-weight:600; color:var(--text-primary); margin-bottom:4px; }
        .processing-modal .modal-body .pm-sub { font-size:13px; color:var(--text-secondary); }
        .processing-modal .modal-body .pm-progress { margin-top:20px; height:4px; background:var(--border-color); border-radius:4px; overflow:hidden; }
        .processing-modal .modal-body .pm-progress .pm-bar { height:100%; background:var(--gradient-gold); border-radius:4px; width:0%; transition:width 0.4s ease; }
        .processing-modal .modal-body .pm-result { display:none; margin-top:16px; }
        .processing-modal .modal-body .pm-result .pm-result-icon { font-size:56px; margin-bottom:8px; }
        .processing-modal .modal-body .pm-result .pm-result-icon.success { color:var(--green); }
        .processing-modal .modal-body .pm-result .pm-result-icon.failed { color:var(--red); }
        .processing-modal .modal-body .pm-result .pm-result-icon.cancelled { color:var(--gold); }
        .processing-modal .modal-body .pm-result .pm-result-icon.pending { color:var(--gold); }
        .processing-modal .modal-body .pm-result .pm-result-title { font-size:20px; font-weight:800; color:var(--text-primary); }
        .processing-modal .modal-body .pm-result .pm-result-sub { font-size:13px; color:var(--text-secondary); }
        .pm-icon-mpesa { color:#6b1d9e; }
        .pm-icon-airtel { color:#ff0000; }
        .pm-icon-mixx { color:#00a651; }
        .pm-icon-halo { color:#1a8bcb; }
        .pm-icon-visa { color:#1a1f71; }
        .pm-icon-mastercard { color:#eb001b; }
        .pm-icon-paypal { color:#003087; }
        .admin-stats-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(140px,1fr)); gap:12px; margin-bottom:24px; }
        .admin-stat-card { background:var(--bg-card); border-radius:14px; padding:16px 18px; border:1px solid var(--border-color); text-align:center; transition:all 0.3s ease; }
        .admin-stat-card:hover { transform:translateY(-2px); box-shadow:var(--shadow-sm); }
        .admin-stat-card .as-number { font-size:28px; font-weight:800; color:var(--text-primary); }
        .admin-stat-card .as-label { font-size:12px; font-weight:600; color:var(--text-secondary); text-transform:uppercase; letter-spacing:0.3px; }
        .admin-stat-card .as-label .as-dot { display:inline-block; width:8px; height:8px; border-radius:50%; margin-right:4px; }
        .admin-stat-card .as-label .as-dot.green { background:var(--green); }
        .admin-stat-card .as-label .as-dot.orange { background:var(--gold); }
        .admin-stat-card .as-label .as-dot.blue { background:var(--blue); }
        .admin-stat-card .as-label .as-dot.red { background:var(--red); }
        .admin-stat-card .as-label .as-dot.gray { background:var(--text-muted); }
        .breadcrumb-custom { font-size:13px; color:var(--text-muted); margin-bottom:12px; display:flex; align-items:center; gap:6px; flex-wrap:wrap; }
        .breadcrumb-custom a { color:var(--text-secondary); text-decoration:none; font-weight:500; }
        .breadcrumb-custom a:hover { color:var(--gold); }
        .breadcrumb-custom .sep { color:var(--border-dark); }
        .breadcrumb-custom .current { color:var(--text-primary); font-weight:600; }
        .datetime-display { font-size:13px; color:var(--text-secondary); font-weight:500; display:flex; align-items:center; gap:8px; }
        .datetime-display i { color:var(--text-muted); }
        .complete-payment-section { background:var(--bg-card); border-radius:20px; padding:28px 30px; border:1px solid var(--border-color); box-shadow:var(--shadow-sm); margin-bottom:32px; }
        .complete-payment-section .cp-header { display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px; margin-bottom:20px; padding-bottom:16px; border-bottom:1px solid var(--border-color); }
        .complete-payment-section .cp-header h4 { font-weight:700; color:var(--text-primary); font-size:18px; margin:0; }
        .complete-payment-section .cp-header .cp-room-badge { background:var(--bg-badge); color:var(--gold-dark); padding:4px 16px; border-radius:30px; font-size:13px; font-weight:600; }
        .cp-grid { display:grid; grid-template-columns:1fr 1.2fr; gap:30px; }
        .cp-summary { border:1px solid var(--border-color); border-radius:16px; padding:20px; background:var(--bg-card-hover); }
        .cp-summary img { width:100%; height:160px; object-fit:cover; border-radius:12px; margin-bottom:12px; }
        .cp-summary .cp-room-title { font-size:18px; font-weight:700; color:var(--text-primary); }
        .cp-summary .cp-detail { display:flex; justify-content:space-between; padding:6px 0; border-bottom:1px solid var(--border-color); font-size:14px; }
        .cp-summary .cp-total { font-size:20px; font-weight:800; color:var(--gold); margin-top:10px; }
        .cp-form .form-group { margin-bottom:14px; }
        .cp-form .form-group label { display:block; font-size:12px; font-weight:700; color:var(--text-primary); margin-bottom:4px; }
        .cp-form .form-group input,.cp-form .form-group select { width:100%; padding:10px 14px; border-radius:12px; border:1px solid var(--border-color); background:var(--bg-input); font-size:14px; transition:all 0.3s ease; outline:none; color:var(--text-primary); }
        .cp-form .form-group input:focus,.cp-form .form-group select:focus { border-color:var(--gold); box-shadow:0 0 0 4px rgba(245,158,11,0.08); background:var(--bg-main); }
        .cp-form .cp-payment-methods { display:flex; flex-wrap:wrap; gap:8px; margin:12px 0 16px; }
        .cp-form .cp-payment-methods .cp-method { flex:1 0 calc(33% - 8px); min-width:80px; padding:10px; border:2px solid var(--border-color); border-radius:12px; text-align:center; cursor:pointer; transition:0.2s; background:var(--bg-main); font-size:12px; font-weight:600; color:var(--text-primary); }
        .cp-form .cp-payment-methods .cp-method i { font-size:20px; display:block; margin-bottom:2px; }
        .cp-form .cp-payment-methods .cp-method:hover { border-color:var(--gold); }
        .cp-form .cp-payment-methods .cp-method.selected { border-color:var(--gold); background:var(--bg-badge); }
        .cp-form .cp-mobile-fields,.cp-form .cp-card-fields,.cp-form .cp-paypal-fields { display:none; margin-top:10px; }
        .cp-form .cp-mobile-fields.show,.cp-form .cp-card-fields.show,.cp-form .cp-paypal-fields.show { display:block; }
        .cp-form .cp-row { display:grid; grid-template-columns:1fr 1fr; gap:12px; }
        .cp-form .btn-pay-now { padding:12px 28px; background:var(--gradient-gold); color:#fff; border:none; border-radius:12px; font-weight:700; font-size:15px; cursor:pointer; width:100%; box-shadow:0 4px 12px rgba(245,158,11,0.2); transition:0.3s; }
        .cp-form .btn-pay-now:hover { transform:translateY(-2px); box-shadow:0 8px 20px rgba(245,158,11,0.3); }
        .cp-form .btn-pay-now:disabled { opacity:0.6; cursor:not-allowed; transform:none; }
        .cp-form .btn-cancel-payment { background:transparent; color:var(--text-secondary); border:1px solid var(--border-color); padding:10px 20px; border-radius:12px; font-weight:600; cursor:pointer; width:100%; margin-top:8px; transition:0.2s; }
        .cp-form .btn-cancel-payment:hover { background:var(--bg-card-hover); }
        @media(max-width:768px){ .cp-grid { grid-template-columns:1fr; } .cp-form .cp-row { grid-template-columns:1fr; } }
        @media(max-width:768px){ .payment-summary-grid { grid-template-columns:repeat(2,1fr); } .payment-methods-grid { grid-template-columns:repeat(4,1fr); } }
        @media(max-width:480px){ .payment-summary-grid { grid-template-columns:1fr 1fr; } .payment-methods-grid { grid-template-columns:repeat(3,1fr); } .admin-stats-grid { grid-template-columns:1fr 1fr; } }
        .auth-agent-toggle { display:flex; align-items:center; gap:10px; padding:6px 0 4px; }
        .auth-agent-toggle input[type="checkbox"] { width:18px; height:18px; accent-color:var(--gold); cursor:pointer; flex-shrink:0; }
        .auth-agent-toggle label { font-size:13px; font-weight:500; color:var(--text-secondary); cursor:pointer; margin:0; }
        .auth-agent-toggle .agent-hint { font-size:11px; color:var(--text-muted); display:block; margin-top:2px; }
        .modal-overlay { backdrop-filter:none!important; -webkit-backdrop-filter:none!important; }
        .login-section-wrapper { max-width:520px; width:100%; margin:0 auto; background:var(--bg-card); border-radius:28px; padding:36px 36px 32px; box-shadow:var(--shadow-xl); border:1px solid var(--border-color); animation:fadeIn 0.4s ease; position:relative; }
        .login-section-wrapper .login-brand { text-align:center; margin-bottom:24px; }
        .login-section-wrapper .login-brand .brand-icon-lg { width:60px; height:60px; background:var(--gradient-gold); border-radius:18px; display:flex; align-items:center; justify-content:center; font-size:26px; font-weight:800; color:#0f172a; margin:0 auto 10px; box-shadow:0 8px 24px rgba(245,158,11,0.25); }
        .login-section-wrapper .login-brand h2 { font-size:24px; font-weight:800; color:var(--text-primary); letter-spacing:-0.5px; }
        .login-section-wrapper .login-brand h2 span { color:var(--gold); }
        .login-section-wrapper .login-brand p { color:var(--text-secondary); font-size:14px; font-weight:500; margin-top:2px; }
        .login-section-wrapper .login-tabs { display:flex; gap:0; margin-bottom:22px; border-bottom:2px solid var(--border-color); }
        .login-section-wrapper .login-tabs button { flex:1; padding:10px 0; background:none; border:none; font-weight:600; font-size:14px; color:var(--text-secondary); cursor:pointer; transition:all 0.2s ease; position:relative; font-family:'Inter',sans-serif; }
        .login-section-wrapper .login-tabs button.active { color:var(--gold); }
        .login-section-wrapper .login-tabs button.active::after { content:''; position:absolute; bottom:-2px; left:0; right:0; height:2px; background:var(--gold); }
        .login-section-wrapper .login-tabs button:hover { color:var(--text-primary); }
        .login-section-wrapper .login-panel { display:none; }
        .login-section-wrapper .login-panel.active { display:block; animation:fadeIn 0.3s ease; }
        .login-section-wrapper .form-group { margin-bottom:16px; }
        .login-section-wrapper .form-group label { display:block; font-size:13px; font-weight:700; color:var(--text-primary); margin-bottom:4px; }
        .login-section-wrapper .form-group input { width:100%; padding:12px 16px; border-radius:14px; border:1px solid var(--border-color); background:var(--bg-input); font-size:15px; color:var(--text-primary); transition:all 0.3s ease; outline:none; font-family:'Inter',sans-serif; }
        .login-section-wrapper .form-group input:focus { border-color:var(--gold); box-shadow:0 0 0 4px rgba(245,158,11,0.1); background:var(--bg-main); }
        .login-section-wrapper .form-group input::placeholder { color:var(--text-muted); font-weight:400; }
        .login-section-wrapper .login-error { color:var(--red); font-size:13px; padding:10px 14px; background:#fef2f2; border-radius:12px; margin-bottom:16px; display:none; align-items:center; gap:10px; border:1px solid #fecaca; }
        .login-section-wrapper .login-error.show { display:flex; }
        .login-section-wrapper .login-success { color:var(--green); font-size:13px; padding:10px 14px; background:#dcfce7; border-radius:12px; margin-bottom:16px; display:none; align-items:center; gap:10px; border:1px solid #bbf7d0; }
        .login-section-wrapper .login-success.show { display:flex; }
        .login-section-wrapper .btn-login { width:100%; padding:14px; border:none; border-radius:14px; background:var(--gradient-gold); color:#fff; font-weight:700; font-size:16px; cursor:pointer; transition:all 0.3s ease; box-shadow:0 4px 16px rgba(245,158,11,0.25); font-family:'Inter',sans-serif; }
        .login-section-wrapper .btn-login:hover { transform:translateY(-2px); box-shadow:0 8px 28px rgba(245,158,11,0.35); }
        .login-section-wrapper .btn-login:disabled { opacity:0.6; cursor:not-allowed; transform:none!important; }
        .login-section-wrapper .login-links { display:flex; flex-wrap:wrap; justify-content:space-between; gap:8px; margin-top:14px; font-size:14px; }
        .login-section-wrapper .login-links a { color:var(--text-secondary); text-decoration:none; font-weight:500; transition:color 0.2s ease; cursor:pointer; }
        .login-section-wrapper .login-links a:hover { color:var(--gold); }
        .login-section-wrapper .login-links .link-primary { color:var(--gold); font-weight:600; }
        .login-section-wrapper .login-links .link-primary:hover { color:var(--gold-dark); }
        .login-section-wrapper .login-divider { display:flex; align-items:center; gap:16px; margin:18px 0 16px; color:var(--text-muted); font-size:12px; font-weight:600; }
        .login-section-wrapper .login-divider::before,.login-section-wrapper .login-divider::after { content:''; flex:1; height:1px; background:var(--border-color); }
        .login-section-wrapper .login-footer-text { text-align:center; font-size:13px; color:var(--text-secondary); margin-top:14px; }
        .login-section-wrapper .login-footer-text a { color:var(--gold); font-weight:600; text-decoration:none; cursor:pointer; }
        .login-section-wrapper .login-footer-text a:hover { text-decoration:underline; }
        .login-section-wrapper .forgot-password-form { display:none; }
        .login-section-wrapper .forgot-password-form.active { display:block; }
        .login-section-wrapper .forgot-password-form .back-to-login { display:inline-flex; align-items:center; gap:6px; color:var(--text-secondary); cursor:pointer; font-weight:500; font-size:14px; margin-bottom:16px; transition:color 0.2s ease; }
        .login-section-wrapper .forgot-password-form .back-to-login:hover { color:var(--gold); }
        .login-section-wrapper .forgot-password-form .btn-back-login { background:transparent; border:none; color:var(--text-secondary); font-weight:600; cursor:pointer; font-size:14px; padding:0; font-family:'Inter',sans-serif; transition:color 0.2s ease; }
        .login-section-wrapper .forgot-password-form .btn-back-login:hover { color:var(--gold); }
        .landlord-property-form { max-width:800px; margin:0 auto; background:var(--bg-card); border-radius:24px; padding:32px 36px; border:1px solid var(--border-color); box-shadow:var(--shadow-md); }
        .landlord-property-form .form-grid-2 { display:grid; grid-template-columns:1fr 1fr; gap:16px; }
        .landlord-property-form .form-group { margin-bottom:16px; }
        .landlord-property-form .form-group label { display:block; font-size:13px; font-weight:700; color:var(--text-primary); margin-bottom:4px; }
        .landlord-property-form .form-group input,.landlord-property-form .form-group select,.landlord-property-form .form-group textarea { width:100%; padding:10px 14px; border-radius:12px; border:1px solid var(--border-color); background:var(--bg-input); font-size:14px; color:var(--text-primary); outline:none; transition:all 0.3s ease; font-family:'Inter',sans-serif; }
        .landlord-property-form .form-group input:focus,.landlord-property-form .form-group select:focus,.landlord-property-form .form-group textarea:focus { border-color:var(--gold); box-shadow:0 0 0 4px rgba(245,158,11,0.08); background:var(--bg-main); }
        .landlord-property-form .form-group textarea { resize:vertical; min-height:70px; }
        .landlord-property-form .form-group .checkbox-group { display:flex; flex-wrap:wrap; gap:12px 20px; padding-top:4px; }
        .landlord-property-form .form-group .checkbox-group label { display:flex; align-items:center; gap:8px; font-weight:500; font-size:14px; color:var(--text-secondary); cursor:pointer; }
        .landlord-property-form .form-group .checkbox-group input[type="checkbox"] { width:18px; height:18px; accent-color:var(--gold); cursor:pointer; }
        .landlord-property-form .form-group .file-upload-area { border:2px dashed var(--border-dark); border-radius:14px; padding:24px; text-align:center; cursor:pointer; transition:all 0.3s ease; background:var(--bg-input); }
        .landlord-property-form .form-group .file-upload-area:hover { border-color:var(--gold); background:var(--bg-card-hover); }
        .landlord-property-form .form-group .file-upload-area input[type="file"] { display:none; }
        .landlord-property-form .form-group .file-upload-area .upload-icon { font-size:36px; color:var(--text-muted); display:block; margin-bottom:8px; }
        .landlord-property-form .form-group .file-upload-area .upload-text { font-size:14px; color:var(--text-secondary); font-weight:500; }
        .landlord-property-form .form-group .file-upload-area .upload-hint { font-size:12px; color:var(--text-muted); margin-top:4px; }
        .landlord-property-form .form-group .image-preview-grid { display:flex; flex-wrap:wrap; gap:10px; margin-top:10px; }
        .landlord-property-form .form-group .image-preview-grid img { width:80px; height:80px; border-radius:12px; object-fit:cover; border:1px solid var(--border-color); }
        .landlord-property-form .form-actions { display:flex; gap:12px; margin-top:8px; flex-wrap:wrap; }
        .landlord-property-form .form-actions .btn-submit-prop { padding:12px 32px; background:var(--gradient-green); color:#fff; border:none; border-radius:12px; font-weight:700; font-size:15px; cursor:pointer; transition:all 0.3s ease; box-shadow:0 4px 12px rgba(34,197,94,0.2); font-family:'Inter',sans-serif; }
        .landlord-property-form .form-actions .btn-submit-prop:hover { transform:translateY(-2px); box-shadow:0 8px 20px rgba(34,197,94,0.3); }
        .landlord-property-form .form-actions .btn-save-draft { padding:12px 28px; background:transparent; color:var(--text-secondary); border:1px solid var(--border-color); border-radius:12px; font-weight:600; font-size:15px; cursor:pointer; transition:all 0.3s ease; font-family:'Inter',sans-serif; }
        .landlord-property-form .form-actions .btn-save-draft:hover { background:var(--bg-card-hover); border-color:var(--border-dark); }
        .landlord-property-list { display:grid; grid-template-columns:repeat(auto-fill,minmax(280px,1fr)); gap:20px; margin-top:24px; }
        .landlord-property-card { background:var(--bg-card); border-radius:18px; padding:20px; border:1px solid var(--border-color); box-shadow:var(--shadow-sm); transition:all 0.3s ease; }
        .landlord-property-card:hover { transform:translateY(-4px); box-shadow:var(--shadow-md); border-color:var(--border-dark); }
        .landlord-property-card img { width:100%; height:160px; object-fit:cover; border-radius:12px; margin-bottom:12px; }
        .landlord-property-card .prop-title { font-size:17px; font-weight:700; color:var(--text-primary); }
        .landlord-property-card .prop-location { font-size:13px; color:var(--text-secondary); margin-bottom:6px; }
        .landlord-property-card .prop-price { font-size:18px; font-weight:800; color:var(--text-primary); }
        .landlord-property-card .prop-status { display:inline-block; padding:2px 12px; border-radius:20px; font-size:11px; font-weight:700; margin-top:6px; }
        .landlord-property-card .prop-status.available { background:#dcfce7; color:#16a34a; }
        .landlord-property-card .prop-status.taken { background:#fee2e2; color:#dc2626; }
        .landlord-property-card .prop-status.booked { background:#fef3c7; color:#d97706; }

        /* Generic, reusable upload widgets - same visual language as the
           landlord property form's file-upload-area, but not scoped to any
           one form so the Admin room form (and anywhere else) can reuse it
           identically instead of duplicating a second design. */
        .file-upload-area { border:2px dashed var(--border-dark); border-radius:14px; padding:24px; text-align:center; cursor:pointer; transition:all 0.3s ease; background:var(--bg-input); }
        .file-upload-area:hover { border-color:var(--gold); background:var(--bg-card-hover); }
        .file-upload-area input[type="file"] { display:none; }
        .file-upload-area .upload-icon { font-size:36px; color:var(--text-muted); display:block; margin-bottom:8px; }
        .file-upload-area .upload-text { font-size:14px; color:var(--text-secondary); font-weight:500; }
        .file-upload-area .upload-hint { font-size:12px; color:var(--text-muted); margin-top:4px; }
        .image-preview-grid { display:flex; flex-wrap:wrap; gap:10px; margin-top:10px; }
        .image-preview-grid img { width:80px; height:80px; border-radius:12px; object-fit:cover; border:1px solid var(--border-color); }

        /* Professional dashboard header banner - shared by Admin Panel and
           Landlord Dashboard so both feel like one consistent, polished
           product instead of two differently-styled screens. */
        .dashboard-hero { position:relative; overflow:hidden; border-radius:24px; padding:28px 32px; margin-bottom:24px; background:linear-gradient(135deg,#0f172a,#1e293b 60%,#312e18); box-shadow:var(--shadow-lg); display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:16px; }
        .dashboard-hero::before { content:''; position:absolute; top:-60px; right:-60px; width:220px; height:220px; border-radius:50%; background:radial-gradient(circle,rgba(245,158,11,0.35),transparent 70%); pointer-events:none; }
        .dashboard-hero::after { content:''; position:absolute; bottom:-80px; left:20%; width:180px; height:180px; border-radius:50%; background:radial-gradient(circle,rgba(59,130,246,0.18),transparent 70%); pointer-events:none; }
        .dashboard-hero .dh-left { position:relative; z-index:1; }
        .dashboard-hero .dh-eyebrow { text-transform:uppercase; letter-spacing:1.2px; font-size:11px; font-weight:700; color:var(--gold); margin-bottom:6px; display:flex; align-items:center; gap:6px; }
        .dashboard-hero h2 { color:#fff; font-size:26px; font-weight:800; margin:0 0 6px; }
        .dashboard-hero p { color:rgba(255,255,255,0.65); font-size:14px; margin:0; font-weight:500; }
        .dashboard-hero .dh-right { position:relative; z-index:1; display:flex; align-items:center; gap:12px; flex-wrap:wrap; }
        .dashboard-hero .dh-datetime { background:rgba(255,255,255,0.08); border:1px solid rgba(255,255,255,0.12); color:#fff; padding:9px 16px; border-radius:12px; font-size:13px; font-weight:600; display:flex; align-items:center; gap:8px; backdrop-filter:blur(6px); }
        .dashboard-hero .dh-datetime i { color:var(--gold); }
        .dashboard-hero .dh-badge { background:rgba(245,158,11,0.15); border:1px solid rgba(245,158,11,0.35); color:var(--gold); padding:9px 16px; border-radius:12px; font-size:13px; font-weight:700; display:flex; align-items:center; gap:8px; }

        /* Section wrapper used to visually group each block of the
           dashboards (stats / forms / listings) into distinct, professional
           "cards" with a clear icon + title header, instead of loose
           headings floating directly on the page background. */
        .dash-section { background:var(--bg-card); border:1px solid var(--border-color); border-radius:22px; padding:26px 28px; margin-bottom:24px; box-shadow:var(--shadow-sm); }
        .dash-section-header { display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-bottom:20px; }
        .dash-section-header .dsh-title { display:flex; align-items:center; gap:12px; }
        .dash-section-header .dsh-icon { width:40px; height:40px; border-radius:12px; background:var(--gradient-gold); color:#fff; display:flex; align-items:center; justify-content:center; font-size:16px; flex-shrink:0; box-shadow:0 4px 12px rgba(245,158,11,0.25); }
        .dash-section-header h4 { font-weight:800; color:var(--text-primary); margin:0; font-size:17px; }
        .dash-section-header .dsh-sub { font-size:12.5px; color:var(--text-secondary); margin:2px 0 0; font-weight:500; }

        /* Stat cards with a coloured top accent + icon chip - a slightly
           richer version of .admin-stat-card used on both dashboards so the
           "at a glance" numbers feel like a real analytics product. */
        .stat-card-pro { position:relative; background:var(--bg-card); border:1px solid var(--border-color); border-radius:16px; padding:18px 20px 16px; overflow:hidden; transition:all 0.3s ease; }
        .stat-card-pro:hover { transform:translateY(-3px); box-shadow:var(--shadow-md); }
        .stat-card-pro::before { content:''; position:absolute; top:0; left:0; right:0; height:3px; background:var(--accent, var(--gold)); }
        .stat-card-pro .sc-top { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:10px; }
        .stat-card-pro .sc-icon { width:36px; height:36px; border-radius:10px; display:flex; align-items:center; justify-content:center; font-size:14px; background:color-mix(in srgb, var(--accent, var(--gold)) 15%, transparent); color:var(--accent, var(--gold)); }
        .stat-card-pro .sc-number { font-size:24px; font-weight:800; color:var(--text-primary); line-height:1.1; }
        .stat-card-pro .sc-label { font-size:12px; font-weight:600; color:var(--text-secondary); margin-top:4px; }
        .pro-stats-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(160px,1fr)); gap:14px; margin-bottom:24px; }
        @media(max-width:640px){ .login-section-wrapper { padding:24px 18px 20px; } .login-section-wrapper .login-brand .brand-icon-lg { width:48px; height:48px; font-size:20px; } .login-section-wrapper .login-brand h2 { font-size:20px; } .login-section-wrapper .login-tabs button { font-size:13px; padding:8px 0; } .login-section-wrapper .form-group input { font-size:14px; padding:11px 14px; } .login-section-wrapper .btn-login { font-size:15px; padding:13px; } .login-section-wrapper .login-links { flex-direction:column; align-items:center; gap:4px; } .landlord-property-form { padding:20px 16px; } .landlord-property-form .form-grid-2 { grid-template-columns:1fr; } }
        @media(max-width:380px){ .login-section-wrapper { padding:18px 12px 16px; } .login-section-wrapper .login-brand .brand-icon-lg { width:40px; height:40px; font-size:16px; } .login-section-wrapper .login-brand h2 { font-size:18px; } .landlord-property-form .form-actions { flex-direction:column; } .landlord-property-form .form-actions .btn-submit-prop,.landlord-property-form .form-actions .btn-save-draft { width:100%; text-align:center; } }
        #loginContent { display:none; align-items:center; justify-content:center; min-height:70vh; padding:20px 0; }
        #loginContent.active { display:flex; }
        .booking-card, .order-card { background:var(--bg-card); border-radius:16px; padding:18px 20px; border:1px solid var(--border-color); margin-bottom:14px; transition:all 0.3s ease; }
        .booking-card:hover, .order-card:hover { border-color:var(--border-dark); box-shadow:var(--shadow-sm); }
        .booking-card .bc-header, .order-card .oc-header { display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:6px 12px; margin-bottom:6px; }
        .booking-card .bc-header .bc-room, .order-card .oc-header .oc-room { font-weight:700; font-size:17px; color:var(--text-primary); }
        .booking-card .bc-header .bc-time, .order-card .oc-header .oc-time { font-size:12px; color:var(--text-muted); }
        .booking-card .bc-details, .order-card .oc-details { display:flex; flex-wrap:wrap; gap:6px 18px; font-size:13px; color:var(--text-secondary); margin:4px 0 8px; }
        .booking-card .bc-details span, .order-card .oc-details span { display:flex; align-items:center; gap:5px; }
        .booking-card .bc-details i, .order-card .oc-details i { color:var(--text-muted); width:14px; }
        .booking-card .bc-actions, .order-card .oc-actions { display:flex; gap:8px; flex-wrap:wrap; margin-top:6px; }
        .booking-card .bc-actions button, .order-card .oc-actions button { padding:4px 14px; border-radius:10px; border:1px solid var(--border-color); background:var(--bg-main); font-size:12px; font-weight:600; cursor:pointer; transition:all 0.2s ease; color:var(--text-primary); }
        .booking-card .bc-actions button:hover, .order-card .oc-actions button:hover { background:var(--bg-card-hover); border-color:var(--border-dark); }
        .booking-card .bc-actions .btn-edit:hover, .order-card .oc-actions .btn-edit:hover { border-color:var(--gold); color:var(--gold); }
        .booking-card .bc-actions .btn-delete:hover, .order-card .oc-actions .btn-delete:hover { border-color:var(--red); color:var(--red); }
        .app-footer { margin-top:40px; padding:20px 0 10px; border-top:1px solid var(--border-color); display:flex; flex-wrap:wrap; justify-content:space-between; align-items:center; gap:12px; color:var(--text-secondary); font-size:13px; }
        .app-footer .footer-brand { font-weight:700; color:var(--text-primary); }
        .app-footer .footer-brand span { color:var(--gold); }
        .app-footer .footer-tagline { font-weight:500; color:var(--text-muted); font-style:italic; }
        .app-footer .footer-location { display:flex; align-items:center; gap:6px; color:var(--text-muted); }
        .app-footer .footer-location i { color:var(--gold); }
        .settings-toggle { display:flex; align-items:center; justify-content:space-between; padding:14px 18px; background:var(--bg-card); border-radius:14px; border:1px solid var(--border-color); margin-bottom:12px; transition:all 0.3s ease; }
        .settings-toggle:hover { border-color:var(--border-dark); }
        .settings-toggle .st-label { font-weight:600; color:var(--text-primary); font-size:14px; }
        .settings-toggle .st-label small { display:block; font-weight:400; color:var(--text-muted); font-size:12px; }
        .settings-toggle .st-switch { position:relative; width:48px; height:26px; background:var(--border-dark); border-radius:14px; cursor:pointer; transition:background 0.3s; flex-shrink:0; }
        .settings-toggle .st-switch.active { background:var(--gold); }
        .settings-toggle .st-switch .st-knob { position:absolute; top:2px; left:2px; width:22px; height:22px; background:#fff; border-radius:50%; transition:transform 0.3s; box-shadow:0 2px 6px rgba(0,0,0,0.15); }
        .settings-toggle .st-switch.active .st-knob { transform:translateX(22px); }
        .support-contact { display:inline-flex; align-items:center; gap:8px; padding:12px 20px; background:var(--bg-card); border-radius:14px; border:1px solid var(--border-color); color:var(--text-primary); font-weight:600; text-decoration:none; transition:all 0.3s ease; font-size:15px; cursor:pointer; }
        .support-contact:hover { border-color:var(--gold); transform:translateY(-2px); box-shadow:var(--shadow-sm); color:var(--text-primary); }
        .support-contact i { color:var(--gold); font-size:18px; }
        .report-edit-field { width:100%; padding:8px 12px; border-radius:10px; border:1px solid var(--border-color); background:var(--bg-input); font-size:13px; color:var(--text-primary); transition:all 0.3s ease; }
        .report-edit-field:focus { border-color:var(--gold); box-shadow:0 0 0 3px rgba(245,158,11,0.1); background:var(--bg-main); outline:none; }
        .account-quick-card { background:linear-gradient(135deg, rgba(245,158,11,0.12), rgba(59,130,246,0.12)); border:1px solid var(--border-color); border-radius:18px; padding:18px; margin-bottom:20px; box-shadow:var(--shadow-sm); }
        .account-quick-grid { display:grid; grid-template-columns:repeat(auto-fit, minmax(280px, 1fr)); gap:16px; margin-top:12px; }
        .account-quick-card h4 { margin:0 0 6px 0; color:var(--text-primary); font-size:16px; font-weight:700; }
        .account-quick-card p { margin:0; color:var(--text-secondary); font-size:13px; }
        .account-quick-card .form-group { margin-bottom:10px; }
        .account-quick-card input { width:100%; }
        .account-quick-card.show { display:block; }
        .account-toggle { border:none; background:var(--bg-card); color:var(--text-primary); width:42px; height:42px; border-radius:50%; display:inline-flex; align-items:center; justify-content:center; cursor:pointer; box-shadow:var(--shadow-sm); }
    </style>
</head>
<body>
    <!-- ===== SIDEBAR ===== -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>
    <aside class="sidebar" id="sidebar">
        <a href="/" class="sidebar-brand" title="Back to home" style="text-decoration:none;"><div class="brand-icon">SR</div><h1>Smart<span>Rent</span></h1></a>
        <nav class="sidebar-nav">
            <div class="nav-label" data-i18n="nav_main">Main</div>
            <a href="#" class="active" data-nav="browse"><i class="fas fa-home"></i> <span data-i18n="nav_browse">Browse Rooms</span></a>
            <a href="#" data-nav="bookings"><i class="fas fa-calendar-check"></i> <span data-i18n="nav_bookings">Bookings</span></a>
            <a href="#" data-nav="orders"><i class="fas fa-clipboard-list"></i> <span data-i18n="nav_orders">Orders</span></a>
            <a href="#" data-nav="contracts"><i class="fas fa-file-signature"></i> <span data-i18n="nav_contracts">My Contracts</span></a>
            <a href="#" data-nav="contact"><i class="fas fa-envelope"></i> <span data-i18n="nav_contact">Contact</span></a>
            <a href="#" class="reports-nav" data-nav="reports"><i class="fas fa-chart-bar"></i> <span data-i18n="nav_reports">Reports</span></a>
            <a href="#" data-nav="payment-dashboard"><i class="fas fa-wallet"></i> <span data-i18n="nav_payment_dashboard">Payment Dashboard</span></a>
            <a href="#" class="admin-nav" data-nav="admin"><i class="fas fa-user-cog"></i> <span data-i18n="nav_admin">Admin Panel</span></a>
            <a href="#" class="messages-nav" data-nav="messages"><i class="fas fa-inbox"></i> <span data-i18n="nav_messages">Messages</span></a>
            <a href="#" class="landlord-nav" data-nav="landlord" style="display:none;"><i class="fas fa-building"></i> <span data-i18n="nav_landlord">My Properties</span></a>
        </nav>
        <div class="sidebar-footer">
            <a href="#" data-nav="settings"><i class="fas fa-cog"></i> <span data-i18n="nav_settings">Settings</span></a>
            <a href="#" data-nav="help"><i class="fas fa-life-ring"></i> <span data-i18n="nav_help">Help &amp; Support</span></a>
            <a href="#" id="logoutLink" style="color:var(--red); display:none;"><i class="fas fa-sign-out-alt"></i> <span data-i18n="nav_logout">Logout</span></a>
        </div>
    </aside>

    <!-- ===== MAIN ===== -->
    <main class="main-content" id="mainApp">
        <button class="mobile-toggle" id="mobileToggle"><i class="fas fa-bars"></i> <span>SmartRent</span></button>

        <div class="page-header">
            <div><h2 id="pageTitle">Browse Rooms</h2><p id="pageSubtitle">Find the perfect room for your stay in Tanzania</p></div>
            <div class="header-actions">
                <a href="/" class="theme-toggle" id="homeBtn" title="Home"><i class="fas fa-house"></i></a>
                <button type="button" class="theme-toggle" id="backBtn" title="Back to home"><i class="fas fa-arrow-left"></i></button>
                <button class="theme-toggle" id="themeToggle"><i class="fas fa-moon" id="themeIcon"></i></button>
                <button class="theme-toggle" id="langToggle" title="Badilisha Lugha / Switch Language"><i class="fas fa-language"></i></button>
                <button class="account-toggle" id="accountSettingsToggle" style="display:none;"><i class="fas fa-user-cog"></i></button>
                <div class="user-avatar" id="userAvatar"><span id="avatarLabel">👤</span><span class="admin-badge" id="adminBadge" style="display:none;"><i class="fas fa-check"></i></span></div>
            </div>
        </div>

        <div id="accountQuickCard" class="account-quick-card" style="display:none;">
            <h4>Account Settings</h4>
            <p>Update your profile or change your password from anywhere in the app.</p>
            <div class="account-quick-grid">
                <form id="accountProfileForm">
                    <div class="form-group">
                        <label>Full Name</label>
                        <input type="text" id="accountProfileName" class="form-control" placeholder="Your full name" required>
                    </div>
                    <div class="form-group">
                        <label>Email Address</label>
                        <input type="email" id="accountProfileEmail" class="form-control" placeholder="you@example.com" required>
                    </div>
                    <div class="form-group">
                        <label>Phone Number</label>
                        <input type="text" id="accountProfilePhone" class="form-control" placeholder="+255 712 345 678">
                    </div>
                    <button type="submit" class="btn-apply" style="width:100%;padding:10px;"><i class="fas fa-save"></i> Save Profile</button>
                </form>
                <form id="accountPasswordForm">
                    <div class="form-group">
                        <label>Current Password</label>
                        <input type="password" id="accountCurrentPassword" class="form-control" placeholder="••••••••" required>
                    </div>
                    <div class="form-group">
                        <label>New Password</label>
                        <input type="password" id="accountNewPassword" class="form-control" placeholder="••••••••" required minlength="6"><small style="color:#888;">At least 6 characters.</small>
                    </div>
                    <div class="form-group">
                        <label>Confirm New Password</label>
                        <input type="password" id="accountConfirmPassword" class="form-control" placeholder="••••••••" required>
                    </div>
                    <button type="submit" class="btn-apply" style="width:100%;padding:10px;"><i class="fas fa-key"></i> Update Password</button>
                </form>
            </div>
            <div id="accountQuickMessage" style="margin-top:10px;font-size:13px;"></div>
        </div>

        <!-- ===== LOGIN SECTION ===== -->
        <div id="loginContent" class="content-section">
            <div class="login-section-wrapper">
                <div class="login-brand"><div class="brand-icon-lg">SR</div><h2>Smart<span>Rent</span></h2><p>Sign in to your account or create one</p></div>
                <div class="login-tabs" id="loginTabs">
                    <button class="active" data-login-tab="login">Sign In</button>
                    <button data-login-tab="customer">Create Customer Account</button>
                    <button data-login-tab="landlord">Register as Landlord</button>
                </div>
                <div class="login-panel active" id="loginPanel">
                    <div class="login-error" id="loginPageError"><i class="fas fa-exclamation-circle"></i> <span id="loginPageErrorText">Invalid credentials</span></div>
                    <div class="login-success" id="loginPageSuccess"><i class="fas fa-check-circle"></i> <span id="loginPageSuccessText">Success</span></div>
                    <form id="loginPageForm">
                        <div class="form-group"><label>Email Address</label><input type="email" id="loginPageEmail" placeholder="john@example.com" required autocomplete="email"></div>
                        <div class="form-group"><label>Password</label><input type="password" id="loginPagePassword" placeholder="••••••••" required autocomplete="current-password"></div>
                        <button type="submit" class="btn-login"><i class="fas fa-sign-in-alt"></i> Sign In</button>
                    </form>
                    <div class="login-links"><a href="#" id="forgotPasswordLink">Forgot Password?</a><a href="#" id="backToHomeLink">← Back to Home</a></div>
                    <div class="login-divider">or</div>
                    <div class="login-footer-text"><span>Don't have an account?</span> <a href="#" id="switchToCustomer">Create Customer Account</a> · <a href="#" id="switchToLandlord">Register as Landlord</a></div>
                </div>
                <div class="login-panel" id="customerPanel">
                    <div class="login-error" id="customerPageError"><i class="fas fa-exclamation-circle"></i> <span id="customerPageErrorText">Error</span></div>
                    <div class="login-success" id="customerPageSuccess"><i class="fas fa-check-circle"></i> <span id="customerPageSuccessText">Account created!</span></div>
                    <form id="customerSignupForm">
                        <div class="form-group"><label>Full Name *</label><input type="text" id="customerName" placeholder="John Doe" required autocomplete="name"></div>
                        <div class="form-group"><label>Email Address *</label><input type="email" id="customerEmail" placeholder="john@example.com" required autocomplete="email"></div>
                        <div class="form-group"><label>Password *</label><input type="password" id="customerPassword" placeholder="••••••••" required autocomplete="new-password" minlength="6"><small style="color:#888;">At least 6 characters.</small></div>
                        <div class="form-group"><label>Confirm Password *</label><input type="password" id="customerConfirmPassword" placeholder="••••••••" required autocomplete="new-password"></div>
                        <button type="submit" class="btn-login"><i class="fas fa-user-plus"></i> Create Account</button>
                    </form>
                    <div class="login-footer-text"><span>Already have an account?</span> <a href="#" id="switchToLoginFromCustomer">Sign In</a></div>
                </div>
                <div class="login-panel" id="landlordPanel">
                    <div class="login-error" id="landlordPageError"><i class="fas fa-exclamation-circle"></i> <span id="landlordPageErrorText">Error</span></div>
                    <div class="login-success" id="landlordPageSuccess"><i class="fas fa-check-circle"></i> <span id="landlordPageSuccessText">Account created!</span></div>
                    <form id="landlordSignupForm">
                        <div class="form-group"><label>Full Name *</label><input type="text" id="landlordName" placeholder="John Doe" required autocomplete="name"></div>
                        <div class="form-group"><label>Email Address *</label><input type="email" id="landlordEmail" placeholder="john@example.com" required autocomplete="email"></div>
                        <div class="form-group"><label>Password *</label><input type="password" id="landlordPassword" placeholder="••••••••" required autocomplete="new-password" minlength="6"><small style="color:#888;">At least 6 characters.</small></div>
                        <div class="form-group"><label>Confirm Password *</label><input type="password" id="landlordConfirmPassword" placeholder="••••••••" required autocomplete="new-password"></div>
                        <button type="submit" class="btn-login"><i class="fas fa-building"></i> Register as Landlord</button>
                    </form>
                    <div class="login-footer-text"><span>Already have an account?</span> <a href="#" id="switchToLoginFromLandlord">Sign In</a></div>
                </div>
                <div class="forgot-password-form" id="forgotPasswordForm">
                    <div class="login-error" id="forgotPageError"><i class="fas fa-exclamation-circle"></i> <span id="forgotPageErrorText">Error</span></div>
                    <div class="login-success" id="forgotPageSuccess"><i class="fas fa-check-circle"></i> <span id="forgotPageSuccessText">Reset link sent!</span></div>
                    <div class="back-to-login" id="backToLoginFromForgot"><i class="fas fa-arrow-left"></i> Back to Sign In</div>
                    <form id="forgotPasswordForm">
                        <div class="form-group"><label>Email Address</label><input type="email" id="forgotEmail" placeholder="john@example.com" required autocomplete="email"></div>
                        <button type="submit" class="btn-login"><i class="fas fa-paper-plane"></i> Send Reset Link</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- ===== BROWSE ROOMS ===== -->
        <div id="browseContent" class="content-section active">
            <section class="filters-section" id="filtersSection">
                <div class="filters-top">
                    <div class="search-wrapper"><i class="fas fa-search"></i><input type="text" id="searchInput" placeholder="Search by location, area, or property name..."></div>
                    <button type="button" class="btn-apply" id="openAiMatchmakerBtn" style="white-space:nowrap;background:var(--gradient-gold, linear-gradient(135deg,#f59e0b,#d97706));"><i class="fas fa-wand-magic-sparkles"></i> AI House Matchmaker</button>
                </div>
                <div class="filters-grid">
                    <div class="filter-group"><label>Location</label><select id="filterLocation"><option value="">All Locations</option></select></div>
                    <div class="filter-group"><label>Area</label><select id="filterArea"><option value="">All Areas</option></select></div>
                    <div class="filter-group"><label>Max Price (TSh)</label><input type="number" id="filterMaxPrice" placeholder="e.g. 800000" min="0" step="10000"></div>
                    <div class="filter-group"><label>Min Size (sqft)</label><input type="number" id="filterMinSize" placeholder="e.g. 100" min="0" step="10"></div>
                    <div class="filter-group"><label>Room Type</label><select id="filterRoomType"><option value="">All Types</option></select></div>
                    <div class="filter-group"><label>Sort By</label><select id="filterSort"><option value="default">Default</option><option value="price-low">Price: Low → High</option><option value="price-high">Price: High → Low</option><option value="size-low">Size: Low → High</option><option value="size-high">Size: High → Low</option></select></div>
                    <div class="filter-actions"><button class="btn-apply" id="applyFiltersBtn"><i class="fas fa-sliders-h"></i> Apply</button><button class="btn-clear" id="clearFiltersBtn">Clear</button></div>
                </div>
            </section>
            <div class="results-header"><span class="count" id="resultsCount">Showing <strong>0</strong> of <strong>0</strong> Rooms</span><div class="view-options"><button class="active" title="Grid view" id="gridViewBtn"><i class="fas fa-th"></i></button><button title="List view" id="listViewBtn"><i class="fas fa-list"></i></button></div></div>
            <div class="room-grid" id="roomGrid"></div>
            <div class="pagination" id="pagination"><button id="prevPage" disabled><i class="fas fa-chevron-left"></i></button><button class="active" data-page="1">1</button><button data-page="2">2</button><button data-page="3">3</button><span class="page-dots">…</span><button data-page="11">11</button><button id="nextPage"><i class="fas fa-chevron-right"></i></button></div>
            <div class="features-section">
                <div class="feature-card"><div class="feature-icon"><i class="fas fa-shield-alt"></i></div><div class="feature-text"><h4>Secure Booking</h4><p>Your booking is safe with us</p></div></div>
                <div class="feature-card"><div class="feature-icon"><i class="fas fa-headset"></i></div><div class="feature-text"><h4>24/7 Support</h4><p>We're here to help anytime</p></div></div>
                <div class="feature-card"><div class="feature-icon"><i class="fas fa-check-circle"></i></div><div class="feature-text"><h4>Verified Properties</h4><p>All rooms are verified</p></div></div>
                <div class="feature-card"><div class="feature-icon"><i class="fas fa-credit-card"></i></div><div class="feature-text"><h4>Easy Payments</h4><p>Multiple payment options</p></div></div>
            </div>
        </div>

        <!-- ===== BOOKINGS ===== -->
        <div id="bookingsContent" class="content-section"><div class="section-placeholder"><h3 style="font-size:20px;font-weight:700;color:var(--text-primary);margin-bottom:16px;">Your Bookings</h3><div id="bookingsList" class="placeholder-grid"></div></div></div>

        <!-- ===== ORDERS ===== -->
        <div id="ordersContent" class="content-section"><div class="section-placeholder"><h3 style="font-size:20px;font-weight:700;color:var(--text-primary);margin-bottom:16px;">Your Orders</h3><div id="ordersList" class="placeholder-grid"></div></div></div>
        <div id="contractsContent" class="content-section"><div class="section-placeholder"><h3 style="font-size:20px;font-weight:700;color:var(--text-primary);margin-bottom:16px;">My Contracts</h3><div id="contractsList" class="placeholder-grid"></div></div></div>

        <!-- ===== CONTACT ===== -->
        <div id="contactContent" class="content-section">
            <div class="section-placeholder"><h3 style="font-size:20px;font-weight:700;color:var(--text-primary);margin-bottom:16px;">Send a Message to Admin</h3><p style="color:var(--text-secondary);margin-bottom:24px;">Fill in your details and we'll get back to you as soon as possible.</p>
                <form id="contactForm" class="contact-form">
                    <div class="form-group"><label>Full Name *</label><input type="text" id="contactName" placeholder="e.g. John Doe" required></div>
                    <div class="form-group"><label>Email *</label><input type="email" id="contactEmail" placeholder="john@example.com" required></div>
                    <div class="form-group"><label>Phone Number *</label><input type="tel" id="contactPhone" placeholder="+255 712 345 678" required></div>
                    <div class="form-group"><label>Message *</label><textarea id="contactMessage" placeholder="Describe what you need..." required></textarea></div>
                    <button type="submit" class="btn-send"><i class="fas fa-paper-plane"></i> Send Message</button>
                </form>
            </div>
        </div>

        <!-- ===== REPORTS ===== -->
        <div id="reportsContent" class="content-section">
            <div class="section-placeholder">
                <h3 style="font-size:20px;font-weight:700;color:var(--text-primary);margin-bottom:16px;">Reports & Analytics</h3>
                <div id="reportsContainer">
                    <div id="reportBookingsSection">
                        <h4 style="font-weight:600;color:var(--text-primary);margin:16px 0 10px;"><i class="fas fa-calendar-check" style="color:var(--gold);margin-right:8px;"></i> Bookings</h4>
                        <div id="reportBookingsList"></div>
                    </div>
                    <div id="reportOrdersSection">
                        <h4 style="font-weight:600;color:var(--text-primary);margin:24px 0 10px;"><i class="fas fa-clipboard-list" style="color:var(--gold);margin-right:8px;"></i> Orders</h4>
                        <div id="reportOrdersList"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ===== PAYMENT DASHBOARD ===== -->
        <div id="paymentDashboardContent" class="content-section">
            <div class="section-placeholder">
                <div class="breadcrumb-custom"><a href="#" onclick="showSection('browse'); return false;">Dashboard</a><span class="sep">/</span><span class="current">Payment Dashboard</span></div>
                <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;margin-bottom:20px;">
                    <div><h3 style="font-size:24px;font-weight:800;color:var(--text-primary);margin:0;"><i class="fas fa-wallet" style="color:var(--gold);margin-right:8px;"></i> Payment Dashboard</h3><p style="color:var(--text-secondary);font-weight:500;margin:2px 0 0;">Manage your rental payments securely.</p></div>
                    <div class="datetime-display"><i class="fas fa-calendar-alt"></i><span id="paymentDateTime"></span></div>
                </div>
                <div class="complete-payment-section" id="completePaymentSection">
                    <div class="cp-header"><h4><i class="fas fa-credit-card" style="color:var(--gold);margin-right:8px;"></i> Complete Payment</h4><span class="cp-room-badge" id="cpRoomBadge">No room selected</span></div>
                    <div class="cp-grid">
                        <div class="cp-summary" id="cpSummary">
                            <img id="cpRoomImg" src="https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?w=400&h=300&fit=crop" alt="Room">
                            <div class="cp-room-title" id="cpRoomTitle">Select a room to book</div>
                            <div class="cp-detail"><span>House ID</span><span id="cpHouseId">—</span></div>
                            <div class="cp-detail"><span>Apartment</span><span id="cpApartment">—</span></div>
                            <div class="cp-detail"><span>Landlord</span><span id="cpLandlord">—</span></div>
                            <div class="cp-detail"><span>Location</span><span id="cpLocation">—</span></div>
                            <div class="cp-detail"><span>Area</span><span id="cpArea">—</span></div>
                            <div class="cp-detail"><span>Size</span><span id="cpSize">—</span></div>
                            <div class="cp-detail"><span>Price</span><span id="cpPrice">—</span></div>
                            <div class="cp-total"><span>Total:</span> <span id="cpTotal">TSh 0</span></div>
                        </div>
                        <div class="cp-form" id="cpForm">
                            <form id="cpPaymentForm">
                                <input type="hidden" id="cpBookingId" value=""><input type="hidden" id="cpAmount" value="0">
                                <div style="background:var(--bg-card-hover);border-radius:14px;padding:16px 18px;border:1px solid var(--border-color);margin-bottom:16px;">
                                    <h6 style="font-weight:700;color:var(--text-primary);margin-bottom:10px;font-size:14px;"><i class="fas fa-user" style="color:var(--gold);margin-right:6px;"></i> Customer Details</h6>
                                    <div class="form-group"><label>Full Name *</label><input type="text" id="cpCustomerName" placeholder="e.g. John Doe" required></div>
                                    <div class="form-group"><label>Email *</label><input type="email" id="cpCustomerEmail" placeholder="john@example.com" required></div>
                                    <div class="form-group"><label>Phone Number *</label><input type="tel" id="cpCustomerPhone" placeholder="+255 712 345 678" required></div>
                                    <div class="form-group"><label><i class="fas fa-user-tag" style="color:var(--gold);margin-right:4px;"></i> Receiver / Recipient Number *</label><input type="text" id="cpRecipientNumber" placeholder="e.g. 0751234567 or 0651234567" required><small style="font-size:11px;color:var(--text-muted);">Enter the receiver’s Tanzanian mobile number for the transaction.</small></div>
                                </div>
                                <label style="font-size:13px;font-weight:700;color:var(--text-primary);display:block;margin-bottom:6px;">Select Payment Method</label>
                                <div class="cp-payment-methods" id="cpPaymentMethods">
                                    <div class="cp-method" data-provider="mpesa" data-type="mobile"><i class="fas fa-mobile-alt" style="color:#6b1d9e;"></i> M-Pesa</div>
                                    <div class="cp-method" data-provider="airtel" data-type="mobile"><i class="fas fa-mobile-alt" style="color:#ff0000;"></i> Airtel</div>
                                    <div class="cp-method" data-provider="mixx" data-type="mobile"><i class="fas fa-mobile-alt" style="color:#00a651;"></i> Mixx</div>
                                    <div class="cp-method" data-provider="halopesa" data-type="mobile"><i class="fas fa-mobile-alt" style="color:#1a8bcb;"></i> HaloPesa</div>
                                    <div class="cp-method" data-provider="visa" data-type="card"><i class="fas fa-credit-card" style="color:#1a1f71;"></i> Visa</div>
                                    <div class="cp-method" data-provider="mastercard" data-type="card"><i class="fas fa-credit-card" style="color:#eb001b;"></i> Mastercard</div>
                                    <div class="cp-method" data-provider="paypal" data-type="paypal"><i class="fab fa-paypal" style="color:#003087;"></i> PayPal</div>
                                </div>
                                <input type="hidden" id="cpSelectedProvider" value="">
                                <div id="cpMobileFields" class="cp-mobile-fields"><div class="form-group"><label>Mobile Number</label><input type="tel" id="cpPhone" placeholder="e.g. 712345678"></div></div>
                                <div id="cpCardFields" class="cp-card-fields">
                                    <div class="form-group"><label>Card Holder</label><input type="text" id="cpCardHolder" placeholder="John Doe"></div>
                                    <div class="form-group"><label>Card Number</label><input type="text" id="cpCardNumber" placeholder="1234 5678 9012 3456"></div>
                                    <div class="cp-row"><div class="form-group"><label>Expiry (MM/YY)</label><input type="text" id="cpExpiry" placeholder="MM/YY"></div><div class="form-group"><label>CVV</label><input type="text" id="cpCvv" placeholder="123"></div></div>
                                </div>
                                <div id="cpPaypalFields" class="cp-paypal-fields"><p style="color:var(--text-secondary);font-size:13px;margin:8px 0;">You will be redirected to PayPal to complete your payment.</p></div>
                                <div class="form-group" id="cpVerificationGroup" style="display:none;">
                                    <label id="cpVerificationLabel">Payment PIN / OTP / Password</label>
                                    <input type="password" id="cpVerificationCode" placeholder="Enter your 4–6 digit PIN or password" autocomplete="one-time-code">
                                    <small style="font-size:11px;color:var(--text-muted);" id="cpVerificationHint">Enter the confirmation code sent to your phone or your secure payment password.</small>
                                </div>
                                <button type="submit" class="btn-pay-now" id="cpPayBtn"><i class="fas fa-lock"></i> Pay Now</button>
                                <button type="button" class="btn-cancel-payment" onclick="clearPaymentSelection()">Cancel</button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="payment-summary-grid" id="paymentSummaryGrid">
                    <div class="payment-summary-card"><div class="ps-icon orange"><i class="fas fa-coins"></i></div><div class="ps-label">Total Payable</div><div class="ps-value" id="totalPayable">TSh 0</div><div class="ps-sub">All bookings</div></div>
                    <div class="payment-summary-card"><div class="ps-icon red"><i class="fas fa-hourglass-half"></i></div><div class="ps-label">Pending</div><div class="ps-value" id="pendingPayments">0</div><div class="ps-sub">Awaiting confirmation</div></div>
                    <div class="payment-summary-card"><div class="ps-icon green"><i class="fas fa-check-circle"></i></div><div class="ps-label">Completed</div><div class="ps-value" id="completedPayments">0</div><div class="ps-sub">Successful payments</div></div>
                    <div class="payment-summary-card"><div class="ps-icon red"><i class="fas fa-times-circle"></i></div><div class="ps-label">Failed</div><div class="ps-value" id="failedPayments">0</div><div class="ps-sub">Unsuccessful</div></div>
                    <div class="payment-summary-card"><div class="ps-icon blue"><i class="fas fa-calendar-day"></i></div><div class="ps-label">Last Payment</div><div class="ps-value" id="lastPaymentDate">—</div><div class="ps-sub">Most recent</div></div>
                    <div class="payment-summary-card"><div class="ps-icon purple"><i class="fas fa-bed"></i></div><div class="ps-label">Selected Booking</div><div class="ps-value" id="selectedBooking">—</div><div class="ps-sub">Current selection</div></div>
                </div>
                <!-- NEW EXTRA SUMMARY ROW -->
                <div class="payment-summary-grid" style="margin-top:16px;">
                    <div class="payment-summary-card"><div class="ps-icon green"><i class="fas fa-check-double"></i></div><div class="ps-label">Completed Bookings</div><div class="ps-value" id="completedBookings">0</div><div class="ps-sub">Confirmed bookings</div></div>
                    <div class="payment-summary-card"><div class="ps-icon purple"><i class="fas fa-shopping-cart"></i></div><div class="ps-label">Total Orders</div><div class="ps-value" id="totalOrders">0</div><div class="ps-sub">All orders placed</div></div>
                    <div class="payment-summary-card"><div class="ps-icon red"><i class="fas fa-ban"></i></div><div class="ps-label">Cancelled Payments</div><div class="ps-value" id="cancelledPayments">0</div><div class="ps-sub">Failed or cancelled</div></div>
                </div>
                <div class="booking-summary-card" id="bookingSummaryCard">
                    <div class="bs-header"><h4><i class="fas fa-file-invoice" style="color:var(--gold);margin-right:8px;"></i> Booking Summary</h4><span style="font-size:12px;color:var(--text-muted);margin-left:auto;" id="bookingRefDisplay">Ref: —</span></div>
                    <div class="bs-body" id="bookingSummaryBody">
                        <img src="https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?w=240&h=240&fit=crop&crop=center" alt="Room" class="bs-img" id="bsRoomImg">
                        <div class="bs-info" id="bsInfoGrid">
                            <div class="bs-item"><span class="bs-label">Room Name</span><span class="bs-value" id="bsRoomName">—</span></div>
                            <div class="bs-item"><span class="bs-label">Apartment</span><span class="bs-value" id="bsApartment">—</span></div>
                            <div class="bs-item"><span class="bs-label">Landlord</span><span class="bs-value" id="bsLandlord">—</span></div>
                            <div class="bs-item"><span class="bs-label">Region</span><span class="bs-value" id="bsRegion">—</span></div>
                            <div class="bs-item"><span class="bs-label">District</span><span class="bs-value" id="bsDistrict">—</span></div>
                            <div class="bs-item"><span class="bs-label">Street / Area</span><span class="bs-value" id="bsStreet">—</span></div>
                            <div class="bs-item"><span class="bs-label">Room Size</span><span class="bs-value" id="bsSize">—</span></div>
                            <div class="bs-item"><span class="bs-label">Rental Duration</span><span class="bs-value" id="bsDuration">—</span></div>
                            <div class="bs-item"><span class="bs-label">Monthly Cost</span><span class="bs-value" id="bsMonthly">—</span></div>
                            <div class="bs-item"><span class="bs-label">Deposit</span><span class="bs-value" id="bsDeposit">—</span></div>
                            <div class="bs-item"><span class="bs-label">Service Charge</span><span class="bs-value" id="bsService">—</span></div>
                            <div class="bs-item"><span class="bs-label">Discount</span><span class="bs-value" id="bsDiscount">—</span></div>
                            <div class="bs-item" style="grid-column:1/-1;"><span class="bs-label">Total Amount</span><span class="bs-value" id="bsTotal" style="font-size:20px;font-weight:800;color:var(--gold);">—</span></div>
                        </div>
                    </div>
                </div>
                <div class="payment-history-wrap" style="margin-top:28px;">
                    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;margin-bottom:16px;"><h4 style="font-weight:700;color:var(--text-primary);margin:0;"><i class="fas fa-history" style="color:var(--gold);margin-right:8px;"></i> Payment History</h4><span style="font-size:12px;color:var(--text-muted);">Showing recent transactions</span></div>
                    <table id="paymentHistoryTable"><thead><tr><th>Transaction Ref</th><th>Customer</th><th>Recipient</th><th>Room</th><th>Method</th><th>Amount</th><th>Date</th><th>Status</th><th>Receipt</th></tr></thead><tbody id="paymentHistoryBody"></tbody></table>
                </div>
                <div style="margin-top:12px;">
                    <h4 style="font-weight:700;color:var(--text-primary);margin-bottom:16px;"><i class="fas fa-receipt" style="color:var(--gold);margin-right:8px;"></i> Receipt Preview</h4>
                    <div class="receipt-preview" id="receiptPreview">
                        <div class="rp-header"><div class="rp-brand">Smart<span>Rent</span></div><span class="rp-badge"><i class="fas fa-check-circle"></i> PAID</span></div>
                        <div class="rp-body">
                            <div class="rp-item"><span class="rp-label">Receipt #</span><span class="rp-value" id="rpReceiptNo">RCP-2026-001</span></div>
                            <div class="rp-item"><span class="rp-label">Transaction Ref</span><span class="rp-value" id="rpTxRef">TX-2026-001</span></div>
                            <div class="rp-item"><span class="rp-label">Booking #</span><span class="rp-value" id="rpBookingNo">BK-2026-001</span></div>
                            <div class="rp-item"><span class="rp-label">Tenant</span><span class="rp-value" id="rpTenant">John Doe</span></div>
                            <div class="rp-item"><span class="rp-label">Email</span><span class="rp-value" id="rpEmail">john@example.com</span></div>
                            <div class="rp-item"><span class="rp-label">Phone</span><span class="rp-value" id="rpPhone">+255 712 345 678</span></div>
                            <div class="rp-item"><span class="rp-label">Recipient</span><span class="rp-value" id="rpRecipient">—</span></div>
                            <div class="rp-item"><span class="rp-label">Room</span><span class="rp-value" id="rpRoom">Modern Single Room</span></div>
                            <div class="rp-item"><span class="rp-label">Apartment</span><span class="rp-value" id="rpApartment">Sunset Apartments</span></div>
                            <div class="rp-item"><span class="rp-label">Landlord</span><span class="rp-value" id="rpLandlord">Mr. Joseph</span></div>
                            <div class="rp-item"><span class="rp-label">Location</span><span class="rp-value" id="rpLocation">Dar es Salaam, Kinondoni</span></div>
                            <div class="rp-item"><span class="rp-label">Payment Method</span><span class="rp-value" id="rpMethod">M-Pesa</span></div>
                            <div class="rp-item"><span class="rp-label">Amount Paid</span><span class="rp-value" id="rpAmount" style="font-weight:800;color:var(--gold);">TSh 500,000</span></div>
                            <div class="rp-item"><span class="rp-label">Date</span><span class="rp-value" id="rpDate">2026-07-06</span></div>
                            <div class="rp-item"><span class="rp-label">Status</span><span class="rp-value" style="color:var(--green);font-weight:700;" id="rpStatus">Successful</span></div>
                        </div>
                        <div class="rp-footer"><div class="rp-qr"><i class="fas fa-qrcode"></i></div><div class="rp-actions"><button class="btn-print" id="btnPrintReceipt"><i class="fas fa-print"></i> Print</button><button class="btn-download" id="btnDownloadReceipt"><i class="fas fa-download"></i> Download</button></div></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ===== ADMIN PANEL ===== -->
        <div id="adminContent" class="content-section">
            <div class="dashboard-hero">
                <div class="dh-left">
                    <div class="dh-eyebrow"><i class="fas fa-shield-halved"></i> Admin Control Center</div>
                    <h2>Platform Overview</h2>
                    <p>Live figures computed from the database — refreshes each time you open this page.</p>
                </div>
                <div class="dh-right">
                    <span class="dh-badge"><i class="fas fa-user-cog"></i> Administrator</span>
                    <span class="dh-datetime"><i class="fas fa-calendar-alt"></i><span id="adminDateTime"></span></span>
                </div>
            </div>

            <div class="dash-section">
                <div class="dash-section-header">
                    <div class="dsh-title"><div class="dsh-icon"><i class="fas fa-chart-line"></i></div><div><h4>Platform Overview</h4><p class="dsh-sub">Key numbers across the whole platform</p></div></div>
                </div>
                <div class="admin-stats-grid" id="platformStatsGrid">
                    <div class="admin-stat-card"><div class="as-number" id="pfTotalProperties">0</div><div class="as-label"><span class="as-dot gray"></span> Total Properties</div></div>
                    <div class="admin-stat-card"><div class="as-number" id="pfTotalCustomers">0</div><div class="as-label"><span class="as-dot blue"></span> Total Customers</div></div>
                    <div class="admin-stat-card"><div class="as-number" id="pfTotalLandlords">0</div><div class="as-label"><span class="as-dot orange"></span> Total Landlords</div></div>
                    <div class="admin-stat-card"><div class="as-number" id="pfTotalBookings">0</div><div class="as-label"><span class="as-dot green"></span> Total Bookings</div></div>
                    <div class="admin-stat-card"><div class="as-number" id="pfActiveContracts">0</div><div class="as-label"><span class="as-dot green"></span> Active Contracts</div></div>
                    <div class="admin-stat-card"><div class="as-number" id="pfTotalTransactions">0</div><div class="as-label"><span class="as-dot blue"></span> Total Transactions</div></div>
                    <div class="admin-stat-card"><div class="as-number" id="pfPlatformRevenue">TSh 0</div><div class="as-label"><span class="as-dot gray"></span> Platform Revenue</div></div>
                    <div class="admin-stat-card"><div class="as-number" id="pfPendingPayouts">TSh 0</div><div class="as-label"><span class="as-dot red"></span> Pending Payouts</div></div>
                </div>
                <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:20px;margin-top:8px;">
                    <div class="admin-stat-card" style="text-align:left;padding:18px;"><h5 style="font-weight:700;color:var(--text-primary);margin-bottom:12px;font-size:14px;">Monthly Transactions</h5><canvas id="chartMonthlyTransactions" height="220"></canvas></div>
                    <div class="admin-stat-card" style="text-align:left;padding:18px;"><h5 style="font-weight:700;color:var(--text-primary);margin-bottom:12px;font-size:14px;">Monthly Platform Commission</h5><canvas id="chartMonthlyCommission" height="220"></canvas></div>
                    <div class="admin-stat-card" style="text-align:left;padding:18px;"><h5 style="font-weight:700;color:var(--text-primary);margin-bottom:12px;font-size:14px;">Revenue Trend</h5><canvas id="chartRevenue" height="220"></canvas></div>
                </div>

                <!-- These four are quick status/breakdown snapshots rather than
                     trend charts, so they're kept at a medium, fixed height
                     (instead of the taller trend charts above) in their own
                     tighter row - maintainAspectRatio:false on the Chart.js
                     side (see renderPlatformCharts) makes this height stick
                     regardless of column width. -->
                <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px;margin-top:16px;">
                    <div class="admin-stat-card" style="text-align:left;padding:14px;"><h5 style="font-weight:700;color:var(--text-primary);margin-bottom:10px;font-size:13px;">Property Listings</h5><div style="position:relative;height:160px;"><canvas id="chartPropertyListings"></canvas></div></div>
                    <div class="admin-stat-card" style="text-align:left;padding:14px;"><h5 style="font-weight:700;color:var(--text-primary);margin-bottom:10px;font-size:13px;">Bookings by Status</h5><div style="position:relative;height:160px;"><canvas id="chartBookings"></canvas></div></div>
                    <div class="admin-stat-card" style="text-align:left;padding:14px;"><h5 style="font-weight:700;color:var(--text-primary);margin-bottom:10px;font-size:13px;">Payment Status</h5><div style="position:relative;height:160px;"><canvas id="chartPaymentStatus"></canvas></div></div>
                    <div class="admin-stat-card" style="text-align:left;padding:14px;"><h5 style="font-weight:700;color:var(--text-primary);margin-bottom:10px;font-size:13px;">Contracts by Status</h5><div style="position:relative;height:160px;"><canvas id="chartContracts"></canvas></div></div>
                </div>
            </div>

            <div class="dash-section">
                <div class="dash-section-header">
                    <div class="dsh-title"><div class="dsh-icon" style="background:var(--gradient-blue);"><i class="fas fa-file-invoice-dollar"></i></div><div><h4>Platform Revenue Report</h4><p class="dsh-sub">Commission and payout breakdown for a chosen period</p></div></div>
                    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
                        <select id="commissionReportRange" style="border-radius:8px;padding:7px 10px;border:1px solid var(--border-color, #ddd);">
                            <option value="today">Today</option>
                            <option value="week">This Week</option>
                            <option value="month" selected>This Month</option>
                            <option value="year">This Year</option>
                            <option value="custom">Custom Range</option>
                        </select>
                        <input type="date" id="commissionReportFrom" style="display:none;border-radius:8px;padding:6px 8px;border:1px solid var(--border-color, #ddd);">
                        <input type="date" id="commissionReportTo" style="display:none;border-radius:8px;padding:6px 8px;border:1px solid var(--border-color, #ddd);">
                        <button id="commissionReportCsvBtn" type="button" style="border:none;border-radius:8px;padding:8px 14px;background:var(--gold, #b8863f);color:#fff;cursor:pointer;font-weight:600;font-size:13px;"><i class="fas fa-download"></i> Export CSV</button>
                    </div>
                </div>
                <div class="admin-stats-grid" id="commissionReportSummary">
                    <div class="admin-stat-card"><div class="as-number" id="crVolume">TSh 0</div><div class="as-label"><span class="as-dot blue"></span> Transaction Volume</div></div>
                    <div class="admin-stat-card"><div class="as-number" id="crCommission">TSh 0</div><div class="as-label"><span class="as-dot gray"></span> Platform Commission</div></div>
                    <div class="admin-stat-card"><div class="as-number" id="crLandlordPayouts">TSh 0</div><div class="as-label"><span class="as-dot green"></span> Landlord Payouts</div></div>
                    <div class="admin-stat-card"><div class="as-number" id="crPendingPayouts">TSh 0</div><div class="as-label"><span class="as-dot red"></span> Pending Payouts</div></div>
                    <div class="admin-stat-card"><div class="as-number" id="crSuccessful">0</div><div class="as-label"><span class="as-dot green"></span> Successful Payments</div></div>
                    <div class="admin-stat-card"><div class="as-number" id="crFailed">0</div><div class="as-label"><span class="as-dot red"></span> Failed Payments</div></div>
                </div>
                <div class="admin-stat-card" style="text-align:left;padding:16px;margin-top:4px;">
                    <h5 style="font-weight:700;color:var(--text-primary);margin-bottom:10px;font-size:14px;">Monthly Breakdown</h5>
                    <div style="position:relative;height:150px;"><canvas id="chartCommissionReport"></canvas></div>
                </div>
            </div>

            <div class="dash-section">
                <div class="dash-section-header">
                    <div class="dsh-title"><div class="dsh-icon" style="background:var(--gradient-green);"><i class="fas fa-door-open"></i></div><div><h4>Room Inventory</h4><p class="dsh-sub">Add new rooms and delete rooms that are already taken</p></div></div>
                </div>
                <div class="admin-stats-grid" id="adminStatsGrid"><div class="admin-stat-card"><div class="as-number" id="adminTotalRooms">0</div><div class="as-label"><span class="as-dot gray"></span> Total Rooms</div></div><div class="admin-stat-card"><div class="as-number" id="adminAvailableRooms">0</div><div class="as-label"><span class="as-dot green"></span> Available</div></div><div class="admin-stat-card"><div class="as-number" id="adminBookedRooms">0</div><div class="as-label"><span class="as-dot orange"></span> Booked</div></div><div class="admin-stat-card"><div class="as-number" id="adminOrderedRooms">0</div><div class="as-label"><span class="as-dot blue"></span> Ordered</div></div><div class="admin-stat-card"><div class="as-number" id="adminTakenRooms">0</div><div class="as-label"><span class="as-dot red"></span> Taken</div></div></div>
                <form id="adminForm" class="admin-form" enctype="multipart/form-data" style="margin-top:8px;">
                    <h4 style="margin-bottom:16px;font-weight:700;"><i class="fas fa-plus-circle" style="color:var(--gold);margin-right:8px;"></i> Add New Room</h4>
                    <div class="form-row"><div class="form-group"><label>Room Title *</label><input type="text" id="roomTitle" placeholder="e.g. Modern Single Room" required></div><div class="form-group"><label>Price (TSh) *</label><input type="number" id="roomPrice" placeholder="e.g. 500000" required min="0" step="any"></div></div>
                    <div class="form-row"><div class="form-group"><label>Location (City) *</label><input list="roomLocationList" type="text" id="roomLocation" placeholder="e.g. Dar es Salaam" required autocomplete="off"><datalist id="roomLocationList"></datalist></div><div class="form-group"><label>Area / District *</label><input type="text" id="roomArea" placeholder="e.g. Kinondoni" required autocomplete="off"></div></div>
                    <div class="form-row"><div class="form-group"><label>Size (sqft) *</label><input type="number" id="roomSize" placeholder="e.g. 150" required min="0" step="any"></div><div class="form-group"><label>Room Type *</label><input list="roomTypeList" type="text" id="roomType" placeholder="e.g. Single Room" required autocomplete="off"><datalist id="roomTypeList"></datalist></div></div>
                    <div class="form-row"><div class="form-group"><label>Number of Beds *</label><input type="number" id="roomBeds" placeholder="e.g. 1" required min="1" step="1"></div><div class="form-group"><label>Badge (optional)</label><input type="text" id="roomBadge" placeholder="e.g. Popular, Premium"></div></div>
                    <div class="form-row"><div class="form-group"><label>Listing Purpose *</label><select id="roomListingPurpose" required><option value="rental">Rental (long-term)</option><option value="holiday">Holiday (short-term/vacation)</option></select></div></div>
                    <div class="form-group"><label>Room Images *</label><div class="file-upload-area" id="roomImageArea"><i class="fas fa-cloud-upload-alt upload-icon"></i><div class="upload-text">Drop images here or click to upload</div><div class="upload-hint">PNG, JPG, WEBP up to 8MB each — add as many as you like, the first photo becomes the cover</div><input type="file" id="roomImage" accept="image/*" multiple required></div><div class="image-preview-grid" id="roomImagePreview"></div></div>
                    <div class="form-group"><label>Single 360&deg; Photo (optional)</label><input type="file" id="roomVirtualTourFile" accept="image/jpeg,image/png,image/webp"><div style="font-size:11px;color:var(--text-muted);margin-top:4px;">Works exactly like the landlord's 360&deg; upload — one quick panorama, or paste an external tour link below instead.</div><input type="text" id="roomVirtualTour" placeholder="https://... (external tour link, optional)" style="margin-top:8px;"></div>
                    <button type="submit" class="btn-submit" id="addRoomBtn"><i class="fas fa-plus-circle"></i> Add Room</button>
                </form>
                <div style="margin-top:36px;"><h4 style="font-weight:700;color:var(--text-primary);margin-bottom:16px;">All Rooms <span style="font-weight:400;font-size:14px;color:var(--text-secondary);">(click Delete to remove taken rooms)</span></h4><div id="adminRoomList" class="placeholder-grid" style="grid-template-columns:repeat(auto-fill,minmax(260px,1fr));"></div></div>
            </div>
        </div>

        <!-- ===== MESSAGES ===== -->
        <div id="messagesContent" class="content-section"><div class="section-placeholder"><h3 style="font-size:20px;font-weight:700;color:var(--text-primary);margin-bottom:16px;">Messages from Customers</h3><div id="messagesList"></div></div></div>

        <!-- ===== SETTINGS ===== -->
        <div id="settingsContent" class="content-section"><div class="section-placeholder"><h3 style="font-size:20px;font-weight:700;color:var(--text-primary);margin-bottom:16px;">Settings</h3>
            <div class="placeholder-grid">
                <div class="placeholder-card">
                    <div class="icon-circle"><i class="fas fa-user-edit"></i></div>
                    <h3>Profile Details</h3>
                    <p style="font-size:13px;color:var(--text-secondary);">Update your account information</p>
                    <form id="profileUpdateForm" style="margin-top:12px;">
                        <div class="form-group" style="margin-bottom:10px;">
                            <label style="font-size:12px;font-weight:600;">Full Name</label>
                            <input type="text" id="profileName" class="form-control" placeholder="Your full name" required style="border-radius:10px;border:1px solid var(--border-color);padding:8px 12px;background:var(--bg-input);color:var(--text-primary);">
                        </div>
                        <div class="form-group" style="margin-bottom:10px;">
                            <label style="font-size:12px;font-weight:600;">Email Address</label>
                            <input type="email" id="profileEmail" class="form-control" placeholder="you@example.com" required style="border-radius:10px;border:1px solid var(--border-color);padding:8px 12px;background:var(--bg-input);color:var(--text-primary);">
                        </div>
                        <div class="form-group" style="margin-bottom:10px;">
                            <label style="font-size:12px;font-weight:600;">Phone Number</label>
                            <input type="text" id="profilePhone" class="form-control" placeholder="+255 712 345 678" style="border-radius:10px;border:1px solid var(--border-color);padding:8px 12px;background:var(--bg-input);color:var(--text-primary);">
                        </div>
                        <button type="submit" class="btn-apply" style="width:100%;padding:10px;"><i class="fas fa-save"></i> Save Profile</button>
                    </form>
                    <div id="profileUpdateMessage" style="margin-top:8px;font-size:13px;"></div>
                </div>
                <div class="placeholder-card">
                    <div class="icon-circle"><i class="fas fa-key"></i></div>
                    <h3>Change Password</h3>
                    <p style="font-size:13px;color:var(--text-secondary);">Update your password securely</p>
                    <form id="changePasswordForm" style="margin-top:12px;">
                        <div class="form-group" style="margin-bottom:10px;">
                            <label style="font-size:12px;font-weight:600;">Current Password</label>
                            <input type="password" id="currentPassword" class="form-control" placeholder="••••••••" required style="border-radius:10px;border:1px solid var(--border-color);padding:8px 12px;background:var(--bg-input);color:var(--text-primary);">
                        </div>
                        <div class="form-group" style="margin-bottom:10px;">
                            <label style="font-size:12px;font-weight:600;">New Password</label>
                            <input type="password" id="newPassword" class="form-control" placeholder="••••••••" required minlength="6" style="border-radius:10px;border:1px solid var(--border-color);padding:8px 12px;background:var(--bg-input);color:var(--text-primary);"><small style="color:#888;">At least 6 characters.</small>
                        </div>
                        <div class="form-group" style="margin-bottom:10px;">
                            <label style="font-size:12px;font-weight:600;">Confirm New Password</label>
                            <input type="password" id="confirmNewPassword" class="form-control" placeholder="••••••••" required style="border-radius:10px;border:1px solid var(--border-color);padding:8px 12px;background:var(--bg-input);color:var(--text-primary);">
                        </div>
                        <button type="submit" class="btn-apply" style="width:100%;padding:10px;"><i class="fas fa-save"></i> Update Password</button>
                    </form>
                    <div id="passwordChangeMessage" style="margin-top:8px;font-size:13px;"></div>
                </div>
                <div class="placeholder-card">
                    <div class="icon-circle"><i class="fas fa-bell"></i></div>
                    <h3>Notifications</h3>
                    <p style="font-size:13px;color:var(--text-secondary);">Turn on/off notifications for new rooms</p>
                    <div class="settings-toggle" style="margin-top:12px;">
                        <div class="st-label">New Room Alerts <small>Get notified when new rooms are added</small></div>
                        <div class="st-switch active" id="notifToggle" onclick="toggleNotification()">
                            <div class="st-knob"></div>
                        </div>
                    </div>
                    <div class="settings-toggle">
                        <div class="st-label">Email Updates <small>Receive weekly room recommendations</small></div>
                        <div class="st-switch" id="emailToggle" onclick="toggleEmailNotifications()">
                            <div class="st-knob"></div>
                        </div>
                    </div>
                </div>
                <div class="placeholder-card">
                    <div class="icon-circle"><i class="fas fa-globe"></i></div>
                    <h3>Language & Theme</h3>
                    <p style="font-size:13px;color:var(--text-secondary);">Switch theme quickly</p>
                    <div style="display:flex;gap:10px;margin-top:12px;flex-wrap:wrap;">
                        <button class="btn-apply" onclick="setTheme('light'); showToast('Light theme activated','info');" style="padding:6px 18px;font-size:12px;background:var(--bg-sidebar);color:#fff;">☀️ Light</button>
                        <button class="btn-apply" onclick="setTheme('dark'); showToast('Dark theme activated','info');" style="padding:6px 18px;font-size:12px;background:var(--bg-sidebar);color:#fff;">🌙 Dark</button>
                    </div>
                </div>
            </div>
        </div></div>

        <!-- ===== HELP ===== -->
        <div id="helpContent" class="content-section"><div class="section-placeholder"><h3 style="font-size:20px;font-weight:700;color:var(--text-primary);margin-bottom:16px;">Help & Support</h3>
            <div class="placeholder-grid">
                <div class="placeholder-card">
                    <div class="icon-circle"><i class="fas fa-question-circle"></i></div>
                    <h3>FAQ</h3>
                    <p>Find answers to commonly asked questions.</p>
                    <button class="btn-details" style="margin-top:12px;padding:8px 20px;border:1px solid var(--border-color);border-radius:12px;background:var(--bg-main);color:var(--text-primary);">View FAQ</button>
                </div>
                <div class="placeholder-card">
                    <div class="icon-circle"><i class="fas fa-headset"></i></div>
                    <h3>Contact Support</h3>
                    <p>We're here to help 24/7 via chat or email.</p>
                    <div style="margin-top:12px;">
                        <a href="#" class="support-contact" onclick="showSection('contact'); return false;">
                            <i class="fas fa-phone-alt"></i> +255 750 796 327
                        </a>
                        <p style="font-size:12px;color:var(--text-muted);margin-top:6px;">Click to go to Contact page</p>
                    </div>
                </div>
                <div class="placeholder-card">
                    <div class="icon-circle"><i class="fas fa-map-pin"></i></div>
                    <h3>Location</h3>
                    <p style="font-size:14px;font-weight:600;color:var(--text-primary);">Dar es Salaam, Tanzania</p>
                    <p style="font-size:13px;color:var(--text-secondary);">Serving all regions across Tanzania</p>
                </div>
            </div>
        </div></div>

        <!-- ===== LANDLORD DASHBOARD (UPDATED) ===== -->
        <div id="landlordContent" class="content-section">
            <div class="dashboard-hero">
                <div class="dh-left">
                    <div class="dh-eyebrow"><i class="fas fa-building"></i> Landlord Workspace</div>
                    <h2>Landlord Dashboard</h2>
                    <p>Manage your properties and rentals.</p>
                </div>
                <div class="dh-right">
                    <span class="dh-badge"><i class="fas fa-building"></i> Landlord</span>
                    <span class="dh-datetime"><i class="fas fa-calendar-alt"></i><span id="landlordDateTime"></span></span>
                </div>
            </div>

            <div class="dash-section">
                <div class="dash-section-header">
                    <div class="dsh-title"><div class="dsh-icon"><i class="fas fa-chart-pie"></i></div><div><h4>Your Portfolio at a Glance</h4><p class="dsh-sub">Live totals across everything you manage</p></div></div>
                </div>
                <div class="admin-stats-grid" id="landlordStatsGrid">
                    <div class="admin-stat-card"><div class="as-number" id="lpTotalProperties">0</div><div class="as-label"><span class="as-dot gray"></span> Total Properties</div></div>
                    <div class="admin-stat-card"><div class="as-number" id="lpAvailableProperties">0</div><div class="as-label"><span class="as-dot green"></span> Available</div></div>
                    <div class="admin-stat-card"><div class="as-number" id="lpBookedProperties">0</div><div class="as-label"><span class="as-dot orange"></span> Booked</div></div>
                    <div class="admin-stat-card"><div class="as-number" id="lpTakenProperties">0</div><div class="as-label"><span class="as-dot red"></span> Taken</div></div>
                    <div class="admin-stat-card"><div class="as-number" id="lpTotalBookings">0</div><div class="as-label"><span class="as-dot blue"></span> Bookings Received</div></div>
                    <div class="admin-stat-card"><div class="as-number" id="lpTotalOrders">0</div><div class="as-label"><span class="as-dot blue"></span> Orders Received</div></div>
                    <div class="admin-stat-card"><div class="as-number" id="lpMonthlyRentTotal">TSh 0</div><div class="as-label"><span class="as-dot gray"></span> Combined Monthly Rent</div></div>
                </div>
            </div>

            <div class="dash-section">
                <div class="dash-section-header">
                    <div class="dsh-title"><div class="dsh-icon" style="background:var(--gradient-green);"><i class="fas fa-upload"></i></div><div><h4>Upload Property</h4><p class="dsh-sub">List a new property — images, amenities and pricing</p></div></div>
                </div>
                <form id="landlordPropertyForm" class="landlord-property-form" enctype="multipart/form-data">
                    <div class="form-grid-2"><div class="form-group"><label>Property Name *</label><input type="text" id="propName" placeholder="e.g. Sunset Apartments" required></div><div class="form-group"><label>Property Type *</label><select id="propType" required><option value="Apartment">Apartment</option><option value="Room">Room</option><option value="House">House</option><option value="Hostel">Hostel</option><option value="Commercial">Commercial Space</option></select></div></div>
                    <div class="form-group"><label>Listing Purpose *</label><select id="propListingPurpose" required><option value="rental">Rental (long-term)</option><option value="holiday">Holiday (short-term/vacation)</option></select></div>
                    <div class="form-grid-2"><div class="form-group"><label>Apartment / Building Name</label><input type="text" id="propApartment" placeholder="e.g. Block A"></div><div class="form-group"><label>House / Room Number</label><input type="text" id="propHouseNo" placeholder="e.g. 12B"></div></div>
                    <div class="form-grid-2"><div class="form-group"><label>Region *</label><input list="propRegionList" type="text" id="propRegion" placeholder="e.g. Dar es Salaam" required autocomplete="off"><datalist id="propRegionList"></datalist></div><div class="form-group"><label>District *</label><input type="text" id="propDistrict" placeholder="e.g. Kinondoni" required></div></div>
                    <div class="form-grid-2"><div class="form-group"><label>Ward</label><input type="text" id="propWard" placeholder="e.g. Mikocheni"></div><div class="form-group"><label>Street *</label><input type="text" id="propStreet" placeholder="e.g. Ali Hassan Mwinyi Road" required></div></div>
                    <div class="form-group"><label>Location (City) *</label><input type="text" id="propLocation" placeholder="e.g. Dar es Salaam" required></div>
                    <div class="form-group"><label>Google Map Coordinates (Placeholder)</label><input type="text" id="propCoords" placeholder="e.g. -6.7924, 39.2083"></div>
                    <div class="form-group"><label>Description</label><textarea id="propDescription" placeholder="Describe the property, features, nearby amenities..."></textarea></div>
                    <div class="form-grid-2"><div class="form-group"><label>Number of Bedrooms *</label><input type="number" id="propBedrooms" placeholder="e.g. 2" min="0" required></div><div class="form-group"><label>Number of Bathrooms *</label><input type="number" id="propBathrooms" placeholder="e.g. 1" min="0" required></div></div>
                    <div class="form-group"><label>Amenities</label><div class="checkbox-group"><label><input type="checkbox" id="propKitchen"> Kitchen</label><label><input type="checkbox" id="propParking"> Parking</label><label><input type="checkbox" id="propWifi"> Wi-Fi</label><label><input type="checkbox" id="propWater"> Water</label><label><input type="checkbox" id="propElectricity"> Electricity</label><label><input type="checkbox" id="propSecurity"> Security</label></div></div>
                    <div class="form-group"><label>Furnished</label><select id="propFurnished"><option value="Unfurnished">Unfurnished</option><option value="Semi-Furnished">Semi-Furnished</option><option value="Fully Furnished">Fully Furnished</option></select></div>
                    <div class="form-grid-2"><div class="form-group"><label>Room Size (sqft) *</label><input type="number" id="propRoomSize" placeholder="e.g. 200" min="0" required></div><div class="form-group"><label>Monthly Rent (TSh) *</label><input type="number" id="propMonthlyRent" placeholder="e.g. 500000" min="0" required></div></div>
                    <div class="form-grid-2"><div class="form-group"><label>Deposit (TSh)</label><input type="number" id="propDeposit" placeholder="e.g. 250000" min="0"></div><div class="form-group"><label>Service Charge (TSh)</label><input type="number" id="propServiceCharge" placeholder="e.g. 25000" min="0"></div></div>
                    <div class="form-group"><label>Availability Status *</label><select id="propAvailability" required><option value="available">Available</option><option value="booked">Booked</option><option value="taken">Taken</option></select></div>
                    <div class="form-group"><label>Property Images *</label><div class="file-upload-area" id="propImageArea"><i class="fas fa-cloud-upload-alt upload-icon"></i><div class="upload-text">Drop images here or click to upload</div><div class="upload-hint">PNG, JPG up to 5MB each</div><input type="file" id="propImages" accept="image/*" multiple required></div><div class="image-preview-grid" id="propImagePreview"></div></div>
                    <div class="form-grid-2"><div class="form-group"><label>Video (Placeholder URL)</label><input type="text" id="propVideo" placeholder="https://youtube.com/..."></div><div class="form-group"><label>Single 360&deg; Photo (optional)</label><input type="file" id="propVirtualTourFile" accept="image/jpeg,image/png,image/webp"><div style="font-size:11px;color:var(--text-muted);margin-top:4px;">Just one quick panorama, or paste an external tour link below instead. <strong>For a full 360&deg; Virtual Tour with multiple rooms and clickable hotspot navigation between them, use the "360&deg; Virtual Tour" button on this property after saving it below.</strong></div><input type="text" id="propVirtualTour" placeholder="https://... (external tour link, optional)" style="margin-top:8px;"></div></div>
                    <div class="form-actions">
                        <!-- UPDATED: Upload button with loading state -->
                        <button type="submit" class="btn-submit-prop" id="uploadPropertyBtn"><i class="fas fa-cloud-upload-alt"></i> Upload</button>
                        <button type="button" class="btn-save-draft" onclick="savePropertyDraft()"><i class="fas fa-save"></i> Save Draft</button>
                    </div>
                </form>
            </div>

            <div class="dash-section">
                <div class="dash-section-header">
                    <div class="dsh-title"><div class="dsh-icon" style="background:var(--gradient-blue);"><i class="fas fa-list"></i></div><div><h4>My Properties</h4><p class="dsh-sub">Everything you have listed so far</p></div></div>
                </div>
                <div id="landlordPropertyList" class="landlord-property-list"></div>
            </div>

            <div class="dash-section">
                <div class="dash-section-header">
                    <div class="dsh-title"><div class="dsh-icon" style="background:linear-gradient(135deg,#8b5cf6,#6d28d9);"><i class="fas fa-calendar-check"></i></div><div><h4>Bookings &amp; Orders</h4><p class="dsh-sub">Activity happening on your properties</p></div></div>
                </div>
                <h5 style="font-weight:700;color:var(--text-primary);margin-bottom:16px;font-size:14px;"><i class="fas fa-calendar-check" style="color:var(--gold);margin-right:6px;"></i> Bookings on My Properties</h5>
                <div id="landlordBookingsList"></div>
                <h5 style="font-weight:700;color:var(--text-primary);margin:24px 0 16px;font-size:14px;"><i class="fas fa-clipboard-list" style="color:var(--gold);margin-right:6px;"></i> Orders on My Properties</h5>
                <div id="landlordOrdersList"></div>
            </div>
        </div>

        <!-- ===== FOOTER ===== -->
        <div class="app-footer">
            <div class="footer-brand">© 2026 <span>SmartRent</span></div>
            <div class="footer-tagline">“Automated booking, trusted space and zero stress”</div>
            <div class="footer-location"><i class="fas fa-map-marker-alt"></i> Dar es Salaam, Tanzania</div>
        </div>
    </main>

    <!-- ===== MODALS ===== -->
    <!-- Room image gallery manager (Admin / owning Landlord) -->
    <div class="modal fade" id="imageManagerModal" tabindex="-1" aria-hidden="true"><div class="modal-dialog modal-dialog-centered"><div class="modal-content" style="border-radius:20px;">
        <div class="modal-header"><h5 class="modal-title"><i class="fas fa-images" style="color:var(--gold);margin-right:8px;"></i> Manage Images</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body">
            <div id="imgMgrGrid" style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:16px;"></div>
            <div class="file-upload-area" id="imgMgrUploadArea" style="cursor:pointer;border:2px dashed var(--border-color);border-radius:14px;padding:16px;text-align:center;">
                <i class="fas fa-cloud-upload-alt upload-icon"></i>
                <div class="upload-text">Click to add more images</div>
                <div class="upload-hint">PNG, JPG, WEBP up to 5MB each</div>
                <input type="file" id="imgMgrFileInput" accept="image/*" multiple style="display:none;">
            </div>
            <div id="imgMgrPreview" style="display:flex;flex-wrap:wrap;gap:8px;margin-top:10px;"></div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn-submit-prop" id="imgMgrUploadBtn"><i class="fas fa-upload"></i> Upload New Images</button>
        </div>
    </div></div></div>

    <div class="detail-modal-overlay" id="detailModalOverlay">
        <div class="detail-modal" id="detailModal">
            <button class="dm-close" id="dmCloseBtn"><i class="fas fa-times"></i></button>
            <div class="dm-image-wrap" id="dmImageWrap"><img id="dmImage" src="https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?w=960&h=540&fit=crop&crop=center" alt="Room"><div class="dm-zoom-hint"><i class="fas fa-search-plus"></i> Click to zoom</div><div class="dm-status-overlay" id="dmStatusOverlay"><span class="dm-badge available" id="dmStatusBadge">Available</span><span class="dm-badge" id="dmPurposeBadge" style="background:#6d28d9;color:#fff;">Rental</span></div><button type="button" class="dm-gallery-nav dm-gallery-prev" id="dmGalleryPrev" style="display:none;" aria-label="Previous image"><i class="fas fa-chevron-left"></i></button><button type="button" class="dm-gallery-nav dm-gallery-next" id="dmGalleryNext" style="display:none;" aria-label="Next image"><i class="fas fa-chevron-right"></i></button><div class="dm-gallery-counter" id="dmGalleryCounter" style="display:none;">1 / 1</div></div>
            <div class="dm-gallery-thumbs" id="dmGalleryThumbs" style="display:none;"></div>
            <div class="dm-body">
                <div class="dm-top"><h2 id="dmTitle">Modern Single Room</h2><div class="dm-price-tag" id="dmPrice">TSh 500,000</div></div>
                <div class="dm-meta" id="dmMeta"><span><i class="fas fa-map-marker-alt"></i> <span id="dmLocation">Dar es Salaam, Kinondoni</span></span><span><i class="fas fa-vector-square"></i> <span id="dmSize">150 sqft</span></span><span><i class="fas fa-tag"></i> <span id="dmType">Single Room</span></span><span><i class="fas fa-bed"></i> <span id="dmBeds">1 Bed</span></span><span><i class="fas fa-building"></i> <span id="dmArea">Kinondoni</span></span><span id="dmHouseIdWrap" style="display:none;"><i class="fas fa-fingerprint"></i> House ID: <span id="dmHouseId"></span></span></div>
                <div class="dm-desc" id="dmDesc">A beautiful modern room with ample natural light and a comfortable ambiance. Located in a prime area with easy access to shopping, dining, and public transport. Perfect for professionals and students alike.</div>
                <button class="btn-dm-secondary" id="dmVirtualTourBtn" style="display:none;margin-bottom:12px;"><i class="fas fa-vr-cardboard"></i> View 360&deg; Virtual Tour</button>

                <div id="dmAskAiSection" style="margin:14px 0;padding:14px;border:1px solid var(--border-color);border-radius:12px;background:var(--bg-modal);">
                    <div style="font-weight:700;font-size:14px;margin-bottom:8px;"><i class="fas fa-robot"></i> Ask AI about this property</div>
                    <div id="dmAskAiAnswer" style="font-size:13px;color:var(--text-secondary);margin-bottom:10px;display:none;"></div>
                    <div style="display:flex;gap:8px;">
                        <input type="text" id="dmAskAiInput" placeholder="e.g. Is this suitable for a family of four?" style="flex:1;padding:8px 10px;border-radius:8px;border:1px solid var(--border-color);background:var(--bg-input);color:var(--text-primary);font-size:13px;">
                        <button type="button" class="btn-dm-secondary" id="dmAskAiBtn" style="white-space:nowrap;"><i class="fas fa-paper-plane"></i> Ask</button>
                    </div>
                </div>

                <div id="dmSimilarSection" style="margin:14px 0;display:none;">
                    <div style="font-weight:700;font-size:14px;margin-bottom:8px;">You may also like</div>
                    <div id="dmSimilarList" style="display:flex;gap:10px;overflow-x:auto;padding-bottom:4px;"></div>
                </div>

                <div class="dm-actions"><button class="btn-dm-primary" id="dmBookBtn"><i class="fas fa-check"></i> Book Now</button><button class="btn-dm-primary btn-dm-blue" id="dmOrderBtn"><i class="fas fa-shopping-cart"></i> Order Now</button><button class="btn-dm-secondary" id="dmCloseAction"><i class="fas fa-times"></i> Close</button></div>
            </div>
        </div>
    </div>

    <div class="detail-modal-overlay" id="tourModalOverlay" style="z-index:2100;">
        <div class="detail-modal" id="tourModal" style="max-width:960px;padding:0;overflow:hidden;">
            <button class="dm-close" id="tourCloseBtn"><i class="fas fa-times"></i></button>
            <div id="tourViewerContainer" style="width:100%;height:70vh;min-height:360px;background:#111;display:flex;align-items:center;justify-content:center;">
                <div id="tourLoading" style="color:#fff;font-size:14px;"><i class="fas fa-spinner fa-spin"></i> Loading virtual tour...</div>
            </div>
        </div>
    </div>

    <!-- ===== 360° TOUR MANAGER (admin/landlord editor) ===== -->
    <div class="detail-modal-overlay" id="tourManagerOverlay" style="z-index:2150;">
        <div class="detail-modal" id="tourManagerModal" style="max-width:1000px;max-height:88vh;overflow-y:auto;">
            <button class="dm-close" id="tourManagerCloseBtn"><i class="fas fa-times"></i></button>
            <h3 style="font-weight:800;margin:0 0 4px;"><i class="fas fa-street-view" style="color:var(--gold);margin-right:8px;"></i> Manage 360° Virtual Tour</h3>
            <p id="tourManagerSubtitle" style="color:var(--text-secondary);font-size:13px;margin:0 0 18px;"></p>

            <div id="tourManagerSceneList" style="display:flex;gap:12px;overflow-x:auto;padding-bottom:10px;margin-bottom:16px;"></div>

            <form id="tourManagerUploadForm" style="display:flex;flex-wrap:wrap;gap:10px;align-items:flex-end;padding:14px;border:1px dashed var(--border-color);border-radius:12px;margin-bottom:20px;">
                <div style="flex:1;min-width:160px;">
                    <label style="display:block;font-size:12px;font-weight:600;margin-bottom:4px;">Scene name</label>
                    <input type="text" id="tourSceneName" placeholder="e.g. Living Room" required style="width:100%;padding:8px 10px;border:1px solid var(--border-color);border-radius:8px;background:var(--bg-main);color:var(--text-primary);">
                </div>
                <div style="flex:1;min-width:160px;">
                    <label style="display:block;font-size:12px;font-weight:600;margin-bottom:4px;">360° panorama image</label>
                    <input type="file" id="tourSceneImage" accept="image/jpeg,image/png,image/webp" required style="width:100%;font-size:12px;">
                </div>
                <button type="submit" class="btn-dm-primary" id="tourUploadBtn" style="padding:9px 18px;"><i class="fas fa-cloud-upload-alt"></i> Add Scene</button>
            </form>

            <div id="tourHotspotEditorWrap" style="display:none;">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
                    <h4 style="font-weight:700;margin:0;">Hotspots — <span id="tourEditingSceneName"></span></h4>
                    <span style="font-size:12px;color:var(--text-secondary);">Click anywhere on the panorama to place a hotspot</span>
                </div>
                <div id="tourEditorViewer" style="width:100%;height:420px;border-radius:12px;overflow:hidden;background:#111;margin-bottom:14px;"></div>

                <form id="tourHotspotForm" style="display:none;flex-wrap:wrap;gap:10px;align-items:flex-end;padding:14px;border:1px solid var(--border-color);border-radius:12px;margin-bottom:16px;">
                    <input type="hidden" id="hsYaw"><input type="hidden" id="hsPitch">
                    <input type="hidden" id="hsTargetYaw"><input type="hidden" id="hsTargetPitch"><input type="hidden" id="hsTargetHfov">
                    <div style="min-width:150px;">
                        <label style="display:block;font-size:12px;font-weight:600;margin-bottom:4px;">Type</label>
                        <select id="hsType" style="width:100%;padding:8px;border:1px solid var(--border-color);border-radius:8px;background:var(--bg-main);color:var(--text-primary);">
                            <option value="navigation">Room navigation</option>
                            <option value="viewpoint">Viewpoint (same panorama)</option>
                            <option value="info">Information</option>
                        </select>
                    </div>
                    <div id="hsTargetWrap" style="min-width:170px;">
                        <label style="display:block;font-size:12px;font-weight:600;margin-bottom:4px;">Target room</label>
                        <select id="hsTarget" style="width:100%;padding:8px;border:1px solid var(--border-color);border-radius:8px;background:var(--bg-main);color:var(--text-primary);"></select>
                    </div>
                    <div id="hsViewpointWrap" style="display:none;min-width:220px;">
                        <label style="display:block;font-size:12px;font-weight:600;margin-bottom:4px;">Target view</label>
                        <div style="display:flex;gap:6px;align-items:center;">
                            <button type="button" id="hsSetViewpointBtn" class="btn-dm-secondary" style="padding:8px 10px;font-size:12px;white-space:nowrap;"><i class="fas fa-crosshairs"></i> Use current view</button>
                            <span id="hsViewpointStatus" style="font-size:11px;color:var(--text-secondary);">Not set</span>
                        </div>
                        <div style="font-size:11px;color:var(--text-secondary);margin-top:3px;">Rotate/zoom the panorama above to the direction you want, then click "Use current view".</div>
                    </div>
                    <div style="flex:1;min-width:150px;">
                        <label style="display:block;font-size:12px;font-weight:600;margin-bottom:4px;">Title</label>
                        <input type="text" id="hsTitle" placeholder="e.g. Bedroom" style="width:100%;padding:8px 10px;border:1px solid var(--border-color);border-radius:8px;background:var(--bg-main);color:var(--text-primary);">
                    </div>
                    <div style="flex:1;min-width:180px;">
                        <label style="display:block;font-size:12px;font-weight:600;margin-bottom:4px;">Description</label>
                        <input type="text" id="hsDesc" placeholder="Optional details" style="width:100%;padding:8px 10px;border:1px solid var(--border-color);border-radius:8px;background:var(--bg-main);color:var(--text-primary);">
                    </div>
                    <button type="submit" class="btn-dm-primary" style="padding:9px 16px;"><i class="fas fa-map-pin"></i> Save Hotspot</button>
                    <button type="button" class="btn-dm-secondary" id="hsCancelBtn" style="padding:9px 16px;">Cancel</button>
                </form>

                <div id="tourHotspotList"></div>
            </div>
        </div>
    </div>

    <!-- ===== AI HOUSE MATCHMAKER ===== -->
    <div class="detail-modal-overlay" id="aiMatchmakerOverlay">
        <div class="detail-modal" id="aiMatchmakerModal" style="max-width:640px;">
            <button class="dm-close" id="aiMatchmakerCloseBtn"><i class="fas fa-times"></i></button>
            <h4 style="font-weight:800;color:var(--text-primary);margin-bottom:4px;"><i class="fas fa-wand-magic-sparkles" style="color:var(--gold);"></i> AI House Matchmaker</h4>
            <p style="color:var(--text-secondary);font-size:13px;margin-bottom:14px;">Describe what you're looking for in your own words — we'll match it against real, currently available listings.</p>
            <form id="aiMatchmakerForm">
                <textarea id="aiMatchmakerQuery" rows="3" placeholder='e.g. "I need a two bedroom house in Mbezi under 600,000 with parking and security"' style="width:100%;border-radius:12px;border:1px solid var(--border-color);padding:12px 14px;background:var(--bg-input);color:var(--text-primary);resize:vertical;font-family:inherit;font-size:14px;"></textarea>
                <button type="submit" class="btn-apply" style="margin-top:10px;width:100%;justify-content:center;"><i class="fas fa-search"></i> Find My Match</button>
            </form>
            <div id="aiMatchmakerResults" style="margin-top:16px;max-height:50vh;overflow-y:auto;"></div>
        </div>
    </div>

    <!-- ===== FLOATING AI CHATBOT ===== -->
    <button id="aiChatFab" title="Ask Smart Rent AI" style="position:fixed;bottom:24px;right:24px;width:58px;height:58px;border-radius:50%;background:var(--gradient-gold, linear-gradient(135deg,#f59e0b,#d97706));color:#fff;border:none;box-shadow:0 8px 24px rgba(0,0,0,0.25);font-size:22px;z-index:1500;cursor:pointer;">
        <i class="fas fa-robot"></i>
    </button>
    <div id="aiChatPanel" style="display:none;position:fixed;bottom:96px;right:24px;width:360px;max-width:calc(100vw - 32px);height:480px;max-height:calc(100vh - 140px);background:var(--bg-modal);border-radius:20px;box-shadow:0 12px 40px rgba(0,0,0,0.35);z-index:1500;flex-direction:column;overflow:hidden;border:1px solid var(--border-color);">
        <div style="padding:14px 16px;background:var(--gradient-gold, linear-gradient(135deg,#f59e0b,#d97706));color:#fff;display:flex;align-items:center;justify-content:space-between;">
            <span style="font-weight:700;font-size:14px;"><i class="fas fa-robot"></i> Smart Rent AI</span>
            <button id="aiChatCloseBtn" style="background:none;border:none;color:#fff;font-size:18px;cursor:pointer;line-height:1;">&times;</button>
        </div>
        <div id="aiChatMessages" style="flex:1;overflow-y:auto;padding:14px;display:flex;flex-direction:column;gap:10px;"></div>
        <form id="aiChatForm" style="display:flex;gap:8px;padding:10px;border-top:1px solid var(--border-color);">
            <input type="text" id="aiChatInput" placeholder="Ask about properties, booking, payments..." style="flex:1;border-radius:20px;border:1px solid var(--border-color);padding:8px 14px;background:var(--bg-input);color:var(--text-primary);font-size:13px;">
            <button type="submit" style="width:36px;height:36px;border-radius:50%;border:none;background:var(--gold);color:#fff;cursor:pointer;"><i class="fas fa-paper-plane"></i></button>
        </form>
    </div>

    <!-- NOTE: the old popup "authModal" (Sign In / Sign Up modal) that used
    to appear here has been removed. It was dead markup: no JS ever opened
    it, but it sat in the DOM with its own #loginEmail/#signupEmail/etc.
    fields, which is exactly the kind of leftover that causes confusing
    "something happened in the background" symptoms. Book/Order now only
    ever route to the single real login flow (#loginContent /
    showLoginRequired), never this modal. -->
    <!-- LEGACY-AUTH-MODAL-REMOVED -->

    <div class="modal fade" id="paymentProcessingModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false"><div class="modal-dialog modal-dialog-centered" style="max-width:440px;"><div class="modal-content processing-modal"><div class="modal-header border-0 pb-0"><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" id="procModalClose"></button></div><div class="modal-body"><div class="pm-spinner" id="procSpinner"></div><div class="pm-status" id="procStatus">Preparing Payment...</div><div class="pm-sub" id="procSub">Please wait while we process your transaction.</div><div class="pm-progress"><div class="pm-bar" id="procBar" style="width:0%;"></div></div><div class="pm-result" id="procResult"><div class="pm-result-icon" id="procResultIcon"><i class="fas fa-check-circle"></i></div><div class="pm-result-title" id="procResultTitle">Payment Successful</div><div class="pm-result-sub" id="procResultSub">Your transaction has been completed.</div></div></div></div></div></div>

    <div class="modal fade" id="confirmPaymentModal" tabindex="-1" aria-hidden="true"><div class="modal-dialog modal-dialog-centered" style="max-width:440px;"><div class="modal-content" style="border-radius:24px;border:none;box-shadow:var(--shadow-xl);background:var(--bg-modal);"><div class="modal-header border-0 pb-0"><h5 class="modal-title fw-bold" style="color:var(--text-primary);"><i class="fas fa-shield-alt" style="color:var(--gold);margin-right:8px;"></i> Confirm Payment</h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body" style="padding:20px 28px 28px;"><p style="color:var(--text-secondary);font-weight:500;">You are about to make a payment of <strong id="confirmAmount" style="color:var(--text-primary);">TSh 0</strong> using <strong id="confirmMethod" style="color:var(--text-primary);">—</strong>.</p><p style="color:var(--text-muted);font-size:13px;">Please confirm the details before proceeding.</p><div style="display:flex;gap:12px;margin-top:16px;"><button class="btn btn-outline-secondary flex-fill" data-bs-dismiss="modal" style="border-radius:12px;font-weight:600;border-color:var(--border-color);color:var(--text-secondary);">Cancel</button><button class="btn flex-fill" id="confirmPayBtn" style="border-radius:12px;font-weight:700;background:var(--gradient-gold);color:#fff;border:none;">Confirm Payment</button></div></div></div></div></div>

    <div class="toast-container" id="toastContainer"></div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

    <script>
        // ========== CONFIGURATION ==========
        // Laravel API base route. The frontend uses /api/ for AJAX requests.
        const API_BASE = @json(rtrim(url('/api'), '/').'/');
        // Uses Laravel's own url() helper (not window.location.origin) so it
        // still resolves correctly when this app is served from a subfolder,
        // e.g. http://localhost/smart_rent/public/ under XAMPP.
        const UPLOADS_BASE = @json(rtrim(url('/uploads'), '/').'/');
        const LEGACY_URL = @json(\App\Support\LegacyBackend::url(request()));
        const LEGACY_BACKEND_BASE = LEGACY_URL.replace(/\/api\.php$/, '');
        // Must match backend/helpers/functions.php::validatePasswordStrength()
        // exactly - a mismatch here is what caused signups to fail with a
        // confusing generic error even when the form looked satisfied.
        function passwordPolicyError(password) {
            if (!password || password.length < 6) return 'Password must be at least 6 characters long.';
            return null;
        }

        let csrfToken = null;
        // In-flight token request, shared by any calls that arrive while a
        // fetch is already pending. Without this, two apiFetch() calls fired
        // back-to-back (e.g. the SMS send and the booking create right after
        // a payment) would each independently hit /auth/csrf before either
        // had resolved. If that happened before any session cookie existed
        // yet, the server hands out two DIFFERENT sessions with two
        // DIFFERENT csrf tokens; whichever Set-Cookie the browser applies
        // last wins, so one of the two requests carries a token that no
        // longer matches the active session -> "Invalid CSRF token".
        let csrfTokenPromise = null;

        async function ensureCsrfToken() {
            if (csrfToken) return csrfToken;
            if (!csrfTokenPromise) {
                csrfTokenPromise = (async () => {
                    try {
                        const response = await fetch(`${API_BASE}auth/csrf`, { credentials: 'same-origin', headers: { Accept: 'application/json' } });
                        if (response.ok) {
                            const data = await response.json();
                            if (data && data.csrf_token) {
                                csrfToken = data.csrf_token;
                                localStorage.setItem('smartrent_csrf_token', csrfToken);
                                return csrfToken;
                            }
                        }
                    } catch (e) { /* ignore */ }
                    const stored = localStorage.getItem('smartrent_csrf_token');
                    if (stored) {
                        csrfToken = stored;
                        return csrfToken;
                    }
                    return '';
                })().finally(() => {
                    if (!csrfToken) csrfTokenPromise = null;
                });
            }
            return csrfTokenPromise;
        }

        // A 403 "Invalid CSRF token" means the cached token is stale (session
        // was reset/rotated, or lost the race above). Clear it so the next
        // apiFetch call fetches a fresh one instead of repeating the failure.
        function invalidateCsrfToken() {
            csrfToken = null;
            csrfTokenPromise = null;
            localStorage.removeItem('smartrent_csrf_token');
        }

        async function apiFetch(endpoint, options = {}, _isRetry = false) {
            const url = API_BASE + endpoint;
            let headers = { ...options.headers };
            let body = options.body;
            const method = (options.method || 'GET').toUpperCase();
            const isAuthRequest = typeof endpoint === 'string' && endpoint.startsWith('auth/');
            const isAuthLoginSignup = isAuthRequest && (endpoint === 'auth/login' || endpoint === 'auth/signup');
            if (body instanceof FormData) {
                delete headers['Content-Type'];
            } else if (isAuthRequest && method !== 'GET' && method !== 'OPTIONS' && body && typeof body === 'object' && !Array.isArray(body)) {
                const params = new URLSearchParams();
                Object.entries(body).forEach(([key, value]) => params.append(key, value));
                headers['Content-Type'] = 'application/x-www-form-urlencoded';
                body = params.toString();
            } else {
                headers['Content-Type'] = 'application/json';
                body = JSON.stringify(body);
            }
            if (method !== 'GET' && method !== 'OPTIONS' && !isAuthLoginSignup) {
                const token = await ensureCsrfToken();
                if (token) headers['X-CSRF-Token'] = token;
            }
            const response = await fetch(url, {
                ...options,
                headers,
                body,
                credentials: 'same-origin'
            });

            if (response.status === 401) {
                invalidateCsrfToken();
                const isTransientAuthCheck = endpoint === 'auth/check';
                const hasStoredUser = !!localStorage.getItem('smartrent_current_user');

                if (!isTransientAuthCheck && hasStoredUser && currentUser) {
                    try {
                        const freshCheck = await fetch(`${API_BASE}auth/check`, {
                            credentials: 'same-origin',
                            headers: { Accept: 'application/json' }
                        });
                        if (freshCheck.ok) {
                            const freshPayload = await freshCheck.json().catch(() => null);
                            if (freshPayload && freshPayload.loggedIn && freshPayload.user) {
                                currentUser = freshPayload.user;
                                localStorage.setItem('smartrent_current_user', JSON.stringify(freshPayload.user));
                                updateAvatar();
                                return freshPayload.user;
                            }
                        }
                    } catch (e) {
                        // Ignore refresh failures here; the user is already logged in and
                        // a transient 401 should not kick them out of the active session.
                    }
                }

                currentUser = null;
                localStorage.removeItem('smartrent_current_user');
                updateAvatar();
                if (!isTransientAuthCheck && hasStoredUser) {
                    showToast('⚠️ Session expired. Please login again.', 'warning');
                    showLoginSection();
                }
                throw new Error('Unauthorized');
            }

            const text = await response.text();
            let payload = null;
            try {
                payload = text ? JSON.parse(text) : null;
            } catch (e) {
                payload = null;
            }

            if (response.status === 403 && payload && payload.error === 'Invalid CSRF token' && !_isRetry) {
                // Stale/mismatched token (see ensureCsrfToken for why this can
                // happen). Drop it and retry exactly once with a fresh one
                // instead of failing the whole transaction.
                invalidateCsrfToken();
                return apiFetch(endpoint, options, true);
            }

            if (!response.ok) {
                const message = payload && (payload.error || payload.message) ? (payload.error || payload.message) : (text || 'API request failed');
                throw new Error(message);
            }

            return payload || {};
        }

        // ========== STATE ==========
        let currentUser = null;
        // Action to resume once a guest completes login/signup from the
        // main login section after being routed there by showLoginRequired()
        // (e.g. clicking Book/Order while signed out). Set once, consumed
        // once, so it can never fire twice.
        let pendingAuthAction = null;
        let roomsData = [];
        let filteredRooms = [];
        let currentPage = 1;
        const perPage = 6;
        let isGridView = true;
        let messages = [];
        let paymentHistory = [];
        let landlordProperties = [];
        let currentTheme = localStorage.getItem('smartrent_theme') || 'light';
        let currentLang = localStorage.getItem('smartrent_lang') || 'en';
        let bookingRecords = [];
        let orderRecords = [];
        let accountQuickCardOpen = false;

        // ========== HELPERS ==========
        // Escapes text before it's interpolated into innerHTML template
        // literals, so a landlord/customer typing HTML/script into a name,
        // description, message, or reference field can't have it executed
        // in another user's (or the admin's) browser. Every render function
        // below that injects a database-sourced string into innerHTML runs
        // that string through this first.
        function escapeHtml(value) {
            if (value === null || value === undefined) return '';
            return String(value)
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#39;');
        }

        function showToast(message, type = 'info') {
            const container = document.getElementById('toastContainer');
            const toast = document.createElement('div');
            toast.className = `toast ${type}`;
            const iconMap = { success: 'fa-check-circle', info: 'fa-info-circle', warning: 'fa-exclamation-triangle', error: 'fa-times-circle' };
            toast.innerHTML = `<i class="fas ${iconMap[type] || 'fa-info-circle'}"></i> ${escapeHtml(message)}`;
            container.appendChild(toast);
            setTimeout(() => {
                toast.style.opacity = '0';
                toast.style.transform = 'translateX(40px) scale(0.9)';
                toast.style.transition = 'all 0.4s ease';
                setTimeout(() => toast.remove(), 400);
            }, 2800);
        }

        let allRoomOptions = { locations: [], areas: [], types: [] };

        function buildRoomOptions(rooms) {
            const unique = { locations: new Set(), areas: new Set(), types: new Set() };
            rooms.forEach(room => {
                if (room.location) unique.locations.add(room.location.trim());
                if (room.area) unique.areas.add(room.area.trim());
                if (room.type) unique.types.add(room.type.trim());
            });
            return {
                locations: Array.from(unique.locations).filter(v => v).sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' })),
                areas: Array.from(unique.areas).filter(v => v).sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' })),
                types: Array.from(unique.types).filter(v => v).sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' }))
            };
        }

        function setSelectOptions(select, options, placeholder) {
            if (!select) return;
            select.innerHTML = `<option value="">${placeholder}</option>` + options.map(value => `<option value="${escapeHtml(value)}">${escapeHtml(value)}</option>`).join('');
        }

        function setDatalistOptions(datalist, options) {
            if (!datalist) return;
            datalist.innerHTML = options.map(value => `<option value="${escapeHtml(value)}"></option>`).join('');
        }

        function updateRoomFilterOptions(options) {
            setSelectOptions(filterLocation, options.locations, 'All Locations');
            setSelectOptions(filterArea, options.areas, 'All Areas');
            setSelectOptions(filterRoomType, options.types, 'All Types');
            setDatalistOptions(roomLocationList, options.locations);
            setDatalistOptions(roomTypeList, options.types);
            setDatalistOptions(propRegionList, options.locations);
        }

        // Safely resolves a property's `images` column into a plain array.
        // The DB stores this as a JSON-encoded string (see
        // backend/controllers/PropertyController.php), but this also
        // tolerates it already being an array (e.g. if some future code
        // path decodes it earlier) and never throws - a null, empty, or
        // malformed value just yields [] instead of crashing whatever is
        // rendering the property card.
        function parsePropertyImages(images) {
            if (!images) return [];
            if (Array.isArray(images)) {
                return images
                    .map(value => (typeof value === 'string' ? value.trim() : ''))
                    .filter(value => value !== '');
            }
            if (typeof images === 'string') {
                const trimmed = images.trim();
                if (!trimmed) return [];
                try {
                    const parsed = JSON.parse(trimmed);
                    if (Array.isArray(parsed)) {
                        return parsed
                            .map(value => (typeof value === 'string' ? value.trim() : ''))
                            .filter(value => value !== '');
                    }
                    if (typeof parsed === 'string' && parsed.trim()) {
                        return [parsed.trim()];
                    }
                } catch (e) {
                    // Some older DB rows may contain a single unquoted string or
                    // escaped JSON content; handle those as a single image path.
                    if (trimmed.startsWith('uploads/') || trimmed.startsWith('/uploads/') || trimmed.startsWith('http://') || trimmed.startsWith('https://')) {
                        return [trimmed];
                    }
                    return [];
                }
            }
            return [];
        }

        function normalizeImageSrc(img) {
            if (img === null || img === undefined || img === '') return null;
            const value = String(img).trim();
            if (!value) return null;
            if (/^(data:image\/|https?:\/\/|blob:)/i.test(value)) return value;
            if (/^(?:[a-z]+:)?\/\//i.test(value)) return value;

            const cleanPath = value.replace(/\\/g, '/').replace(/^\/+/, '').replace(/^['"]|['"]$/g, '');
            if (!cleanPath) return null;

            // Uploaded room/property images are stored in Laravel's own
            // public/uploads folder (see public/uploads/*), so they are served
            // locally by this same app. Avoid the old base64 fallback for any
            // normal DB path; if it does not resolve to a real URL, return null.
            if (cleanPath.startsWith('uploads/')) {
                return `${UPLOADS_BASE}${cleanPath.replace(/^uploads\//, '')}`;
            }
            if (cleanPath.startsWith('public/uploads/')) {
                return `${UPLOADS_BASE}${cleanPath.replace(/^public\/uploads\//, '')}`;
            }
            if (cleanPath.startsWith('backend/')) {
                return `${LEGACY_BACKEND_BASE}/${cleanPath.replace(/^backend\//, '')}`;
            }
            if (cleanPath.startsWith('css/') || cleanPath.startsWith('js/')) {
                return `${window.location.origin}/${cleanPath}`;
            }

            return null;
        }

        // ========== AUTH ==========
        function isLoggedIn() { return currentUser !== null; }
        function isAdmin() { return currentUser && currentUser.type === 'Admin'; }
        function isLandlord() { return currentUser && currentUser.type === 'Landlord'; }
        function isCustomer() { return currentUser && currentUser.type === 'Customer'; }

        async function loginUser(email, password) {
            try {
                // remember: true so the login survives a browser refresh via
                // the server's remember-token cookie, not just the native
                // PHP session. The user only gets logged out by clicking
                // Logout, never automatically.
                const result = await apiFetch('auth/login', { method: 'POST', body: { email, password, remember: true } });
                if (result.success) {
                    currentUser = result.user;
                    localStorage.setItem('smartrent_current_user', JSON.stringify(result.user));
                    return { success: true, user: result.user };
                } else {
                    return { success: false, message: result.message };
                }
            } catch (e) {
                return { success: false, message: e.message };
            }
        }

        function populateProfileForm() {
            if (!currentUser) return;
            const nameField = document.getElementById('profileName');
            const emailField = document.getElementById('profileEmail');
            const phoneField = document.getElementById('profilePhone');
            if (nameField) nameField.value = currentUser.name || '';
            if (emailField) emailField.value = currentUser.email || '';
            if (phoneField) phoneField.value = currentUser.phone || '';
        }

        async function signupUser(name, email, phone, password, type) {
            try {
                const result = await apiFetch('auth/signup', { method: 'POST', body: { name, email, phone, password, type } });
                if (result.success) {
                    currentUser = result.user;
                    localStorage.setItem('smartrent_current_user', JSON.stringify(result.user));
                    return { success: true, user: result.user };
                } else {
                    return { success: false, message: result.message };
                }
            } catch (e) {
                return { success: false, message: e.message };
            }
        }

        async function logoutUser() {
            try {
                await apiFetch('auth/logout', { method: 'POST' });
            } catch (e) {}
            currentUser = null;
            localStorage.removeItem('smartrent_current_user');
            updateAvatar();

            // Clear any login/signup form fields so the logged-out user's
            // details don't linger on screen (or via browser autofill) for
            // whoever uses the login page next.
            ['loginPageForm', 'customerSignupForm', 'landlordSignupForm'].forEach(id => {
                const form = document.getElementById(id);
                if (form) form.reset();
            });
            ['loginPageError', 'loginPageSuccess'].forEach(id => {
                const el = document.getElementById(id);
                if (el) el.classList.remove('show');
            });
            // A logout should never leave a stale "resume this action after
            // login" callback armed for whatever the next person logs in as.
            pendingAuthAction = null;

            showLoginSection();
            showToast('✅ You have been logged out successfully', 'success');
        }

        async function checkSession() {
            try {
                const storedUser = localStorage.getItem('smartrent_current_user');
                if (storedUser) {
                    try {
                        currentUser = JSON.parse(storedUser);
                    } catch (e) {
                        currentUser = null;
                        localStorage.removeItem('smartrent_current_user');
                    }
                }

                const result = await apiFetch('auth/check');
                if (result.loggedIn) {
                    currentUser = result.user;
                    localStorage.setItem('smartrent_current_user', JSON.stringify(result.user));
                } else {
                    // The server has definitively answered (this request
                    // succeeded, it isn't a network/transient failure - see
                    // the catch block below for that case) that there is no
                    // valid session. Trust that over any stale cached user,
                    // otherwise the UI shows a "logged in" state that the
                    // server disagrees with, which only gets discovered (and
                    // corrected with a jarring logout) the next time some
                    // other API call happens to fail with 401.
                    currentUser = null;
                    localStorage.removeItem('smartrent_current_user');
                }
                updateAvatar();
                return !!currentUser;
            } catch (e) {
                if (currentUser) {
                    updateAvatar();
                    return true;
                }
                currentUser = null;
                localStorage.removeItem('smartrent_current_user');
                updateAvatar();
                return false;
            }
        }

        function populateAccountQuickForm() {
            if (!currentUser) return;
            const nameField = document.getElementById('accountProfileName');
            const emailField = document.getElementById('accountProfileEmail');
            const phoneField = document.getElementById('accountProfilePhone');
            if (nameField) nameField.value = currentUser.name || '';
            if (emailField) emailField.value = currentUser.email || '';
            if (phoneField) phoneField.value = currentUser.phone || '';
        }

        function showAccountQuickCard(force = false) {
            const card = document.getElementById('accountQuickCard');
            const toggle = document.getElementById('accountSettingsToggle');
            if (!card) return;
            const shouldShow = Boolean(currentUser) && (force || accountQuickCardOpen);
            card.classList.toggle('show', shouldShow);
            card.style.display = shouldShow ? 'block' : 'none';
            if (toggle) toggle.style.display = currentUser ? 'inline-flex' : 'none';
        }

        function toggleAccountQuickCard() {
            if (!currentUser) {
                accountQuickCardOpen = false;
                showAccountQuickCard(false);
                return;
            }
            accountQuickCardOpen = !accountQuickCardOpen;
            showAccountQuickCard();
        }

        function updateAvatar() {
            const avatarLabel = document.getElementById('avatarLabel');
            const adminBadge = document.getElementById('adminBadge');
            const logoutLink = document.getElementById('logoutLink');
            const landlordNav = document.querySelector('.landlord-nav');
            if (currentUser) {
                avatarLabel.textContent = currentUser.name.charAt(0).toUpperCase();
                if (isAdmin()) {
                    adminBadge.style.display = 'flex';
                    document.querySelector('.admin-nav').classList.add('show');
                    document.querySelector('.messages-nav').classList.add('show');
                    document.querySelector('.reports-nav').classList.add('show');
                    if (landlordNav) landlordNav.style.display = 'none';
                } else if (isLandlord()) {
                    adminBadge.style.display = 'none';
                    document.querySelector('.admin-nav').classList.remove('show');
                    document.querySelector('.messages-nav').classList.remove('show');
                    document.querySelector('.reports-nav').classList.remove('show');
                    if (landlordNav) landlordNav.style.display = 'flex';
                } else {
                    adminBadge.style.display = 'none';
                    document.querySelector('.admin-nav').classList.remove('show');
                    document.querySelector('.messages-nav').classList.remove('show');
                    document.querySelector('.reports-nav').classList.remove('show');
                    if (landlordNav) landlordNav.style.display = 'none';
                }
                if (logoutLink) logoutLink.style.display = 'flex';
                populateAccountQuickForm();
                showAccountQuickCard();
            } else {
                avatarLabel.textContent = '👤';
                adminBadge.style.display = 'none';
                document.querySelector('.admin-nav').classList.remove('show');
                document.querySelector('.messages-nav').classList.remove('show');
                document.querySelector('.reports-nav').classList.remove('show');
                if (landlordNav) landlordNav.style.display = 'none';
                if (logoutLink) logoutLink.style.display = 'none';
                showAccountQuickCard();
            }
        }

        // ========== THEME & LANGUAGE ==========
        function setTheme(theme) {
            currentTheme = theme;
            document.documentElement.setAttribute('data-theme', theme);
            localStorage.setItem('smartrent_theme', theme);
            const icon = document.getElementById('themeIcon');
            if (icon) icon.className = theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        }

        const SR_I18N = {
            en: {
                nav_main: 'Main', nav_browse: 'Browse Rooms', nav_bookings: 'Bookings', nav_orders: 'Orders',
                nav_contracts: 'My Contracts', nav_contact: 'Contact', nav_reports: 'Reports',
                nav_payment_dashboard: 'Payment Dashboard', nav_admin: 'Admin Panel', nav_messages: 'Messages',
                nav_landlord: 'My Properties', nav_settings: 'Settings', nav_help: 'Help & Support', nav_logout: 'Logout',
                title_browse: 'Browse Rooms', sub_browse: 'Find the perfect room for your stay in Tanzania',
                title_bookings: 'Your Bookings', sub_bookings: 'View all your confirmed bookings',
                title_orders: 'Your Orders', sub_orders: 'View all your orders',
                title_contracts: 'My Contracts', sub_contracts: 'View, accept, and download your rental contracts',
                title_contact: 'Contact', sub_contact: '',
                title_reports: 'Reports & Analytics', sub_reports: 'Manage all bookings and orders',
                title_admin: 'Admin Panel', sub_admin: '',
                title_messages: 'Messages', sub_messages: '',
                title_settings: 'Settings', sub_settings: '',
                title_help: 'Help & Support', sub_help: '',
                title_payment_dashboard: 'Payment Dashboard', sub_payment_dashboard: '',
                title_landlord: 'Landlord Dashboard', sub_landlord: 'Manage your properties and rentals.',
                title_welcome: 'Welcome', sub_welcome: 'Sign in to your account or create one'
            },
            sw: {
                nav_main: 'Kuu', nav_browse: 'Tazama Vyumba', nav_bookings: 'Uhifadhi', nav_orders: 'Maagizo',
                nav_contracts: 'Mikataba Yangu', nav_contact: 'Wasiliana Nasi', nav_reports: 'Ripoti',
                nav_payment_dashboard: 'Dashibodi ya Malipo', nav_admin: 'Paneli ya Msimamizi', nav_messages: 'Ujumbe',
                nav_landlord: 'Mali Zangu', nav_settings: 'Mipangilio', nav_help: 'Msaada', nav_logout: 'Toka',
                title_browse: 'Tazama Vyumba', sub_browse: 'Pata chumba kinachokufaa kwa kukaa kwako Tanzania',
                title_bookings: 'Uhifadhi Wako', sub_bookings: 'Angalia uhifadhi wako wote uliothibitishwa',
                title_orders: 'Maagizo Yako', sub_orders: 'Angalia maagizo yako yote',
                title_contracts: 'Mikataba Yangu', sub_contracts: 'Angalia, kubali, na pakua mikataba yako ya upangaji',
                title_contact: 'Wasiliana Nasi', sub_contact: '',
                title_reports: 'Ripoti na Uchambuzi', sub_reports: 'Simamia uhifadhi wote na maagizo',
                title_admin: 'Paneli ya Msimamizi', sub_admin: '',
                title_messages: 'Ujumbe', sub_messages: '',
                title_settings: 'Mipangilio', sub_settings: '',
                title_help: 'Msaada', sub_help: '',
                title_payment_dashboard: 'Dashibodi ya Malipo', sub_payment_dashboard: '',
                title_landlord: 'Dashibodi ya Mwenye Nyumba', sub_landlord: 'Simamia mali na upangaji wako.',
                title_welcome: 'Karibu', sub_welcome: 'Ingia kwenye akaunti yako au fungua akaunti mpya'
            }
        };

        function t(key) {
            const dict = SR_I18N[currentLang] || {};
            if (Object.prototype.hasOwnProperty.call(dict, key)) return dict[key];
            if (Object.prototype.hasOwnProperty.call(SR_I18N.en, key)) return SR_I18N.en[key];
            return key;
        }

        function applyTranslations() {
            document.querySelectorAll('[data-i18n]').forEach(el => {
                const key = el.getAttribute('data-i18n');
                const value = t(key);
                if (value) el.textContent = value;
            });
            document.documentElement.setAttribute('lang', currentLang);
            const activeLink = document.querySelector('.sidebar-nav a.active, .sidebar-footer a.active');
            const section = activeLink ? activeLink.dataset.nav : null;
            if (section && document.getElementById('pageTitle')) {
                const titleKey = 'title_' + section.replace(/-/g, '_');
                const subKey = 'sub_' + section.replace(/-/g, '_');
                if (Object.prototype.hasOwnProperty.call(SR_I18N.en, titleKey)) {
                    document.getElementById('pageTitle').textContent = t(titleKey);
                    document.getElementById('pageSubtitle').textContent = t(subKey);
                }
            } else if (document.getElementById('loginContent')?.classList.contains('active')) {
                document.getElementById('pageTitle').textContent = t('title_welcome');
                document.getElementById('pageSubtitle').textContent = t('sub_welcome');
            }
        }

        function setLanguage(lang) {
            if (lang !== 'en' && lang !== 'sw') lang = 'en';
            currentLang = lang;
            localStorage.setItem('smartrent_lang', lang);
            applyTranslations();
            showToast(lang === 'sw' ? 'Lugha imebadilishwa kuwa Kiswahili' : 'Language switched to English', 'info');
        }

        // ========== LOGIN UI ==========
        function showLoginSection() {
            document.querySelectorAll('.content-section').forEach(el => el.classList.remove('active'));
            document.getElementById('loginContent').classList.add('active');
            document.getElementById('pageTitle').textContent = t('title_welcome');
            document.getElementById('pageSubtitle').textContent = t('sub_welcome');
            switchLoginTab('login');
            document.getElementById('loginPageError').classList.remove('show');
            document.getElementById('loginPageSuccess').classList.remove('show');
            document.getElementById('forgotPasswordForm').classList.remove('active');
            document.querySelectorAll('.sidebar-nav a, .sidebar-footer a').forEach(link => link.classList.remove('active'));
        }

        function hideLoginSection() {
            document.getElementById('loginContent').classList.remove('active');
        }

        function switchLoginTab(tab) {
            document.querySelectorAll('#loginTabs button').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.login-panel').forEach(p => p.classList.remove('active'));
            document.getElementById('forgotPasswordForm').classList.remove('active');
            const tabMap = { 'login': 'loginPanel', 'customer': 'customerPanel', 'landlord': 'landlordPanel' };
            const btn = document.querySelector(`[data-login-tab="${tab}"]`);
            if (btn) btn.classList.add('active');
            const panel = document.getElementById(tabMap[tab]);
            if (panel) panel.classList.add('active');
            document.getElementById('loginPageError').classList.remove('show');
            document.getElementById('loginPageSuccess').classList.remove('show');
        }

        // ========== NAVIGATION ==========
        function showSection(section) {
            document.querySelectorAll('.content-section').forEach(el => el.classList.remove('active'));
            if (currentUser) {
                populateProfileForm();
                populateAccountQuickForm();
                showAccountQuickCard();
            }
            const targetMap = {
                'browse': 'browseContent', 'bookings': 'bookingsContent', 'orders': 'ordersContent',
                'contracts': 'contractsContent',
                'contact': 'contactContent', 'reports': 'reportsContent', 'admin': 'adminContent',
                'messages': 'messagesContent', 'settings': 'settingsContent', 'help': 'helpContent',
                'payment-dashboard': 'paymentDashboardContent', 'landlord': 'landlordContent'
            };
            const targetId = targetMap[section];
            if (targetId) document.getElementById(targetId).classList.add('active');

            const titles = {
                'browse': [t('title_browse'), t('sub_browse')],
                'bookings': [t('title_bookings'), t('sub_bookings')],
                'orders': [t('title_orders'), t('sub_orders')],
                'contracts': [t('title_contracts'), t('sub_contracts')],
                'contact': [t('title_contact'), t('sub_contact')],
                'reports': [t('title_reports'), t('sub_reports')],
                'admin': [t('title_admin'), t('sub_admin')],
                'messages': [t('title_messages'), t('sub_messages')],
                'settings': [t('title_settings'), t('sub_settings')],
                'help': [t('title_help'), t('sub_help')],
                'payment-dashboard': [t('title_payment_dashboard'), t('sub_payment_dashboard')],
                'landlord': [t('title_landlord'), t('sub_landlord')]
            };
            const [title, sub] = titles[section] || ['', ''];
            if (title) document.getElementById('pageTitle').textContent = title;
            if (sub) document.getElementById('pageSubtitle').textContent = sub;

            document.querySelectorAll('.sidebar-nav a, .sidebar-footer a').forEach(link => {
                link.classList.remove('active');
                if (link.dataset.nav === section) link.classList.add('active');
            });

            if (section === 'admin') { renderAdminRoomList(); updateAdminStats(); }
            if (section === 'messages') { renderMessages(); }
            if (section === 'bookings' || section === 'orders') { renderBookingsOrders(); }
            if (section === 'contracts') { fetchAndRenderContracts(); }
            if (section === 'payment-dashboard') { updatePaymentDashboard(); renderPaymentHistory(); }
            if (section === 'landlord') {
                renderLandlordProperties();
                updateLandlordDateTime();
                renderLandlordBookingsOrders();
                if (document.getElementById('propName').value.trim() === '') {
                    restorePropertyDraft();
                }
            }
            if (section === 'reports') { renderReports(); }

            if (window.innerWidth <= 768) {
                sidebar.classList.remove('mobile-open');
                sidebarOverlay.classList.remove('open');
                document.body.style.overflow = '';
            }
        }

        // ========== RENDER ROOMS ==========
        function renderRooms() {
            const start = (currentPage - 1) * perPage;
            const end = start + perPage;
            const pageRooms = filteredRooms.slice(start, end);

            if (pageRooms.length === 0) {
                roomGrid.innerHTML = `<div style="grid-column:1/-1;text-align:center;padding:60px 0;color:var(--text-secondary);"><i class="fas fa-search" style="font-size:48px;display:block;margin-bottom:16px;color:var(--text-muted);"></i><h3 style="color:var(--text-primary);font-weight:700;font-size:20px;">No rooms found</h3><p style="font-size:15px;margin-top:4px;">Try adjusting your filters or search terms.</p></div>`;
                resultsCount.innerHTML = `Showing <strong>0</strong> of <strong>0</strong> Rooms`;
                renderPagination();
                return;
            }

            const gridClass = isGridView ? '' : 'list-view';
            roomGrid.className = `room-grid ${gridClass}`;

            roomGrid.innerHTML = pageRooms.map(room => {
                const imgSrc = normalizeImageSrc(parsePropertyImages(room.image)[0]) || `https://picsum.photos/seed/${room.id}/400/300`;
                const statusLabel = room.status.charAt(0).toUpperCase() + room.status.slice(1);
                const statusClass = room.status;
                const isBookedOrOrdered = (room.status === 'booked' || room.status === 'ordered' || room.status === 'taken');
                return `
                    <div class="room-card" data-id="${room.id}">
                        <div class="card-image">
                            <img src="${imgSrc}" alt="${escapeHtml(room.title)}" loading="lazy" decoding="async" style="background:var(--bg-input);">
                            <span class="status-badge ${statusClass}">${statusLabel}</span>
                        </div>
                        <div class="card-body">
                            <div class="room-title">${escapeHtml(room.title)}</div>
                            <div class="room-location"><i class="fas fa-map-pin"></i> ${escapeHtml(room.location)}</div>
                            <div class="room-price">TSh ${Number(room.price||0).toLocaleString()} <small>/ month</small></div>
                            <div class="room-details">
                                <span><i class="fas fa-vector-square"></i> ${room.size} sqft</span>
                                <span><i class="fas fa-tag"></i> ${escapeHtml(room.type)}</span>
                                <span><i class="fas fa-bed"></i> ${room.beds} Bed${room.beds > 1 ? 's' : ''}</span>
                            </div>
                            <div class="card-actions">
                                <button class="btn-details" data-id="${room.id}">View Details</button>
                            </div>
                        </div>
                    </div>
                `;
            }).join('');

            resultsCount.innerHTML = `Showing <strong>${pageRooms.length}</strong> of <strong>${filteredRooms.length}</strong> Rooms`;
            renderPagination();
            attachCardEvents();
        }

        function renderPagination() {
            const totalPages = Math.ceil(filteredRooms.length / perPage) || 1;
            const prevBtn = document.getElementById('prevPage');
            const nextBtn = document.getElementById('nextPage');
            const existingBtns = pagination.querySelectorAll('button:not(#prevPage):not(#nextPage)');
            existingBtns.forEach(b => b.remove());
            const dots = pagination.querySelector('.page-dots');
            if (dots) dots.remove();
            const info = pagination.querySelector('.page-info');
            if (info) info.remove();

            let startPage = Math.max(1, currentPage - 2);
            let endPage = Math.min(totalPages, currentPage + 2);
            if (totalPages <= 7) { startPage = 1; endPage = totalPages; } else {
                if (currentPage <= 3) { startPage = 1; endPage = 5; } else if (currentPage >= totalPages - 2) { startPage = totalPages - 4; endPage = totalPages; } else { startPage = currentPage - 2; endPage = currentPage + 2; }
            }

            const fragment = document.createDocumentFragment();
            const nextBtnRef = document.getElementById('nextPage');
            for (let i = startPage; i <= endPage; i++) {
                const btn = document.createElement('button');
                btn.textContent = i;
                btn.dataset.page = i;
                if (i === currentPage) btn.className = 'active';
                btn.addEventListener('click', () => goToPage(i));
                fragment.appendChild(btn);
            }
            if (totalPages > 7) {
                if (startPage > 2) { const dot = document.createElement('span'); dot.className = 'page-dots'; dot.textContent = '…'; fragment.insertBefore(dot, fragment.firstChild); }
                if (endPage < totalPages - 1) { const dot = document.createElement('span'); dot.className = 'page-dots'; dot.textContent = '…'; fragment.appendChild(dot); }
            }
            pagination.insertBefore(fragment, nextBtnRef);
            prevPageBtn.disabled = currentPage <= 1;
            nextPageBtn.disabled = currentPage >= totalPages;
            const span = document.createElement('span');
            span.className = 'page-info';
            span.textContent = `Page ${currentPage} of ${totalPages}`;
            pagination.appendChild(span);
        }

        function goToPage(page) {
            const totalPages = Math.ceil(filteredRooms.length / perPage) || 1;
            if (page < 1 || page > totalPages) return;
            currentPage = page;
            renderRooms();
            roomGrid.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }

        function attachCardEvents() {
            document.querySelectorAll('.btn-details').forEach(btn => {
                btn.addEventListener('click', function(e) {
                    e.stopPropagation();
                    const id = parseInt(this.dataset.id);
                    const room = filteredRooms.find(r => r.id === id) || roomsData.find(r => r.id === id);
                    if (room) openDetailModal(room);
                });
            });
            document.querySelectorAll('.room-card').forEach(card => {
                card.addEventListener('dblclick', function(e) {
                    if (e.target.closest('button')) return;
                    const id = parseInt(this.dataset.id);
                    const room = filteredRooms.find(r => r.id === id) || roomsData.find(r => r.id === id);
                    if (room) openDetailModal(room);
                });
                card.addEventListener('click', function(e) {
                    if (e.target.closest('button')) return;
                    const id = parseInt(this.dataset.id);
                    const room = filteredRooms.find(r => r.id === id) || roomsData.find(r => r.id === id);
                    if (room) openDetailModal(room);
                });
            });
        }

        // ========== DETAIL MODAL ==========
        const detailOverlay = document.getElementById('detailModalOverlay');
        const dmCloseBtn = document.getElementById('dmCloseBtn');
        const dmCloseAction = document.getElementById('dmCloseAction');
        const dmBookBtn = document.getElementById('dmBookBtn');
        const dmOrderBtn = document.getElementById('dmOrderBtn');
        const dmImage = document.getElementById('dmImage');
        const dmImageWrap = document.getElementById('dmImageWrap');
        const dmTitle = document.getElementById('dmTitle');
        const dmPrice = document.getElementById('dmPrice');
        const dmLocation = document.getElementById('dmLocation');
        const dmSize = document.getElementById('dmSize');
        const dmType = document.getElementById('dmType');
        const dmBeds = document.getElementById('dmBeds');
        const dmArea = document.getElementById('dmArea');
        const dmDesc = document.getElementById('dmDesc');
        const dmStatusBadge = document.getElementById('dmStatusBadge');
        let currentDetailRoom = null;
        let isZoomed = false;
        let dmGalleryImages = [];
        let dmGalleryIndex = 0;

        /**
         * Renders whichever image in dmGalleryImages is "current" into the
         * main dmImage, and shows/hides the prev/next arrows, the counter,
         * and the thumbnail strip depending on how many images there are:
         * 0 images -> fallback placeholder, no controls. 1 image -> just
         * the image, no controls (same as before this feature existed).
         * 2+ images -> full gallery navigation, with circular wraparound.
         */
        function renderDmGalleryImage() {
            const prevBtn = document.getElementById('dmGalleryPrev');
            const nextBtn = document.getElementById('dmGalleryNext');
            const counter = document.getElementById('dmGalleryCounter');
            const thumbs = document.getElementById('dmGalleryThumbs');
            const total = dmGalleryImages.length;

            if (total === 0) {
                dmImage.src = 'https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?w=960&h=540&fit=crop&crop=center';
                prevBtn.style.display = 'none';
                nextBtn.style.display = 'none';
                counter.style.display = 'none';
                thumbs.style.display = 'none';
                thumbs.innerHTML = '';
                return;
            }

            if (dmGalleryIndex < 0) dmGalleryIndex = total - 1;
            if (dmGalleryIndex >= total) dmGalleryIndex = 0;

            const src = normalizeImageSrc(dmGalleryImages[dmGalleryIndex]);
            dmImage.src = src || 'https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?w=960&h=540&fit=crop&crop=center';
            dmImage.onerror = function() {
                // A broken/missing image must never throw a JS error or
                // leave a blank box - fall back to the placeholder.
                this.onerror = null;
                this.src = 'https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?w=960&h=540&fit=crop&crop=center';
            };

            if (total > 1) {
                prevBtn.style.display = 'flex';
                nextBtn.style.display = 'flex';
                counter.style.display = 'block';
                counter.textContent = `${dmGalleryIndex + 1} / ${total}`;
                thumbs.style.display = 'flex';
                thumbs.innerHTML = dmGalleryImages.map((img, i) => {
                    const thumbSrc = normalizeImageSrc(img) || '';
                    return `<img src="${thumbSrc}" data-idx="${i}" class="${i === dmGalleryIndex ? 'active' : ''}" onerror="this.style.display='none'">`;
                }).join('');
                thumbs.querySelectorAll('img').forEach(el => {
                    el.addEventListener('click', function(e) {
                        e.stopPropagation();
                        dmGalleryIndex = parseInt(this.dataset.idx, 10);
                        renderDmGalleryImage();
                    });
                });
            } else {
                prevBtn.style.display = 'none';
                nextBtn.style.display = 'none';
                counter.style.display = 'none';
                thumbs.style.display = 'none';
                thumbs.innerHTML = '';
            }
        }

        document.getElementById('dmGalleryPrev').addEventListener('click', function(e) {
            e.stopPropagation();
            dmGalleryIndex--;
            renderDmGalleryImage();
        });
        document.getElementById('dmGalleryNext').addEventListener('click', function(e) {
            e.stopPropagation();
            dmGalleryIndex++;
            renderDmGalleryImage();
        });

        function openDetailModal(room) {
            currentDetailRoom = room;
            dmGalleryImages = parsePropertyImages(room.image);
            dmGalleryIndex = 0;
            renderDmGalleryImage();
            dmTitle.textContent = room.title;
            dmPrice.textContent = `TSh ${Number(room.price||0).toLocaleString()}`;
            dmLocation.textContent = room.location;
            dmSize.textContent = `${room.size} sqft`;
            dmType.textContent = room.type;
            dmBeds.textContent = `${room.beds} Bed${room.beds > 1 ? 's' : ''}`;
            dmArea.textContent = room.area || room.location.split(',')[0] || '—';
            const houseIdWrap = document.getElementById('dmHouseIdWrap');
            if (room.house_id) {
                document.getElementById('dmHouseId').textContent = room.house_id;
                houseIdWrap.style.display = 'flex';
            } else {
                houseIdWrap.style.display = 'none';
            }
            dmDesc.textContent = `A beautiful ${room.type.toLowerCase()} located in ${room.location}. This room offers ${room.size} sqft of comfortable living space with ${room.beds} bed${room.beds > 1 ? 's' : ''}.`;
            const statusMap = { 'available': { label: 'Available', cls: 'available' }, 'booked': { label: 'Booked', cls: 'booked' }, 'ordered': { label: 'Ordered', cls: 'ordered' }, 'taken': { label: 'Taken', cls: 'taken' } };
            const s = statusMap[room.status] || statusMap['available'];
            dmStatusBadge.textContent = s.label;
            dmStatusBadge.className = `dm-badge ${s.cls}`;
            const purposeBadge = document.getElementById('dmPurposeBadge');
            if (purposeBadge) {
                purposeBadge.textContent = room.listing_purpose === 'holiday' ? 'Holiday' : 'Rental';
                purposeBadge.style.background = room.listing_purpose === 'holiday' ? '#0891b2' : '#6d28d9';
            }
            const isAvailable = room.status === 'available';
            dmBookBtn.disabled = !isAvailable;
            dmOrderBtn.disabled = !isAvailable;
            dmBookBtn.textContent = isAvailable ? 'Book Now' : 'Unavailable';
            dmOrderBtn.textContent = isAvailable ? 'Order Now' : 'Unavailable';
            const tourBtn = document.getElementById('dmVirtualTourBtn');
            if (room.virtual_tour) {
                tourBtn.style.display = 'inline-flex';
                tourBtn.onclick = () => openVirtualTour(room.virtual_tour);
            } else {
                tourBtn.style.display = 'none';
                tourBtn.onclick = null;
            }
            // If a multi-scene 360° tour (uploaded via the new tour manager)
            // exists for this listing, it takes over the same button and is
            // preferred over the single legacy virtual_tour image/link -
            // but the legacy behavior above still runs first and is left
            // fully intact for every listing that never got a multi-scene
            // tour, so nothing existing changes for them.
            attachMultiSceneTourButton(room.id, tourBtn);
            isZoomed = false;
            dmImageWrap.classList.remove('zoomed');
            detailOverlay.classList.add('open');
            document.body.style.overflow = 'hidden';

            // Reset the ask-AI box for the newly opened property.
            const askInput = document.getElementById('dmAskAiInput');
            const askAnswer = document.getElementById('dmAskAiAnswer');
            if (askInput) askInput.value = '';
            if (askAnswer) { askAnswer.style.display = 'none'; askAnswer.textContent = ''; }

            fetchAndRenderSimilarProperties(room.id);
        }

        function closeDetailModal() {
            detailOverlay.classList.remove('open');
            document.body.style.overflow = '';
            isZoomed = false;
            dmImageWrap.classList.remove('zoomed');
            currentDetailRoom = null;
            const simSection = document.getElementById('dmSimilarSection');
            if (simSection) simSection.style.display = 'none';
        }

        async function fetchAndRenderSimilarProperties(roomId) {
            const section = document.getElementById('dmSimilarSection');
            const list = document.getElementById('dmSimilarList');
            if (!section || !list || !roomId) return;
            if (!isLoggedIn()) { section.style.display = 'none'; return; }
            try {
                const result = await apiFetch('ai/similar?room_id=' + encodeURIComponent(roomId));
                const items = (result && Array.isArray(result.results)) ? result.results : [];
                if (items.length === 0) { section.style.display = 'none'; return; }
                list.innerHTML = items.map(s => `
                    <div style="min-width:160px;max-width:160px;border:1px solid var(--border-color);border-radius:10px;overflow:hidden;cursor:pointer;background:var(--bg-modal);flex-shrink:0;"
                         onclick="openDetailModal(summaryToRoomLike(${escapeHtml(JSON.stringify(s))}))">
                        <img src="${normalizeImageSrc(s.image) || 'https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?w=320&h=180&fit=crop'}" style="width:100%;height:80px;object-fit:cover;">
                        <div style="padding:8px;">
                            <div style="font-size:12px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${escapeHtml(s.name || '')}</div>
                            <div style="font-size:11px;color:var(--text-secondary);">TSh ${Number(s.monthly_rent || 0).toLocaleString()}</div>
                            <div style="font-size:10px;color:var(--gold);margin-top:2px;">${s.match_score != null ? s.match_score + '% match' : ''}</div>
                        </div>
                    </div>
                `).join('');
                section.style.display = 'block';
            } catch (err) {
                section.style.display = 'none';
            }
        }

        async function askAiAboutCurrentProperty() {
            const input = document.getElementById('dmAskAiInput');
            const answerEl = document.getElementById('dmAskAiAnswer');
            const btn = document.getElementById('dmAskAiBtn');
            if (!input || !answerEl || !currentDetailRoom) return;
            const question = input.value.trim();
            if (!question) return;
            if (!isLoggedIn()) { showLoginRequired(() => {}); return; }

            answerEl.style.display = 'block';
            answerEl.textContent = 'Thinking...';
            btn.disabled = true;
            try {
                const result = await apiFetch('ai/ask-property', {
                    method: 'POST',
                    body: { room_id: currentDetailRoom.id, question }
                });
                answerEl.textContent = (result && result.reply) ? result.reply : 'Sorry, I could not answer that.';
            } catch (err) {
                answerEl.textContent = 'Sorry, something went wrong: ' + err.message;
            } finally {
                btn.disabled = false;
            }
        }

        document.getElementById('dmAskAiBtn')?.addEventListener('click', askAiAboutCurrentProperty);
        document.getElementById('dmAskAiInput')?.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') { e.preventDefault(); askAiAboutCurrentProperty(); }
        });

        dmCloseBtn.addEventListener('click', closeDetailModal);

        // ========== 360° VIRTUAL TOUR VIEWER ==========
        let pannellumLoaded = false;
        let pannellumViewerInstance = null;

        function loadPannellumAssets() {
            if (pannellumLoaded) return Promise.resolve();
            return new Promise((resolve, reject) => {
                const css = document.createElement('link');
                css.rel = 'stylesheet';
                css.href = 'https://cdn.jsdelivr.net/npm/pannellum@2.5.6/build/pannellum.css';
                document.head.appendChild(css);
                const script = document.createElement('script');
                script.src = 'https://cdn.jsdelivr.net/npm/pannellum@2.5.6/build/pannellum.js';
                script.onload = () => { pannellumLoaded = true; resolve(); };
                script.onerror = reject;
                document.body.appendChild(script);
            });
        }

        function isPanoramaImage(url) {
            return /\.(jpe?g|png|webp)(\?.*)?$/i.test(url);
        }

        async function openVirtualTour(rawUrl) {
            const url = normalizeImageSrc(rawUrl) || rawUrl;
            const overlay = document.getElementById('tourModalOverlay');
            const container = document.getElementById('tourViewerContainer');
            container.innerHTML = '<div id="tourLoading" style="color:#fff;font-size:14px;"><i class="fas fa-spinner fa-spin"></i> Loading virtual tour...</div>';
            overlay.classList.add('open');
            document.body.style.overflow = 'hidden';

            if (isPanoramaImage(url)) {
                try {
                    await loadPannellumAssets();
                    container.innerHTML = '<div id="pannellumViewer" style="width:100%;height:100%;"></div>';
                    if (pannellumViewerInstance) {
                        pannellumViewerInstance.destroy();
                        pannellumViewerInstance = null;
                    }
                    pannellumViewerInstance = window.pannellum.viewer('pannellumViewer', {
                        type: 'equirectangular',
                        panorama: url,
                        autoLoad: true,
                        compass: false
                    });
                } catch (e) {
                    container.innerHTML = '<div style="color:#fff;padding:24px;text-align:center;">Could not load the 360&deg; viewer. <a href="' + escapeHtml(url) + '" target="_blank" rel="noopener" style="color:var(--gold);">Open the image directly</a>.</div>';
                }
            } else {
                // External tour link (Matterport, Kuula, YouTube 360, etc.) -
                // embed as an iframe rather than assuming it's a panorama image.
                container.innerHTML = '<iframe src="' + escapeHtml(url) + '" style="width:100%;height:100%;border:0;" allow="vr; xr; accelerometer; gyroscope; fullscreen" allowfullscreen></iframe>';
            }
        }

        function closeVirtualTour() {
            document.getElementById('tourModalOverlay').classList.remove('open');
            document.body.style.overflow = '';
            document.getElementById('tourViewerContainer').innerHTML = '';
            if (pannellumViewerInstance) {
                pannellumViewerInstance.destroy();
                pannellumViewerInstance = null;
            }
        }

        document.getElementById('tourCloseBtn').addEventListener('click', closeVirtualTour);
        document.getElementById('tourModalOverlay').addEventListener('click', function(e) {
            if (e.target === this) closeVirtualTour();
        });

        // ========== 360° MULTI-SCENE TOUR (new: hotspot navigation) ==========
        // Separate from the single-image openVirtualTour() above, which is
        // left completely untouched so listings that only ever had the old
        // single virtual_tour field keep working exactly as before.

        const multiSceneTourCache = new Map(); // listingId -> scenes[] | null (checked once per modal session)

        async function fetchMultiSceneTour(listingId) {
            if (multiSceneTourCache.has(listingId)) return multiSceneTourCache.get(listingId);
            // The listing could be a room or a property - openDetailModal()
            // is fed from both roomsData and AI-normalized summaries with
            // no reliable type tag, so try room first then property, same
            // resolution order ChatController::askProperty() already uses
            // for the same ambiguity.
            for (const listingType of ['room', 'property']) {
                try {
                    const res = await apiFetch(`tours?listing_type=${listingType}&listing_id=${encodeURIComponent(listingId)}`);
                    if (res && Array.isArray(res.scenes) && res.scenes.length > 0) {
                        multiSceneTourCache.set(listingId, res.scenes);
                        return res.scenes;
                    }
                } catch (e) { /* try the other listing type */ }
            }
            multiSceneTourCache.set(listingId, null);
            return null;
        }

        async function attachMultiSceneTourButton(listingId, tourBtn) {
            if (!listingId || !tourBtn) return;
            const scenes = await fetchMultiSceneTour(listingId);
            if (scenes && scenes.length > 0) {
                tourBtn.style.display = 'inline-flex';
                tourBtn.onclick = () => openMultiSceneTour(scenes);
            }
            // If no multi-scene tour exists, leave whatever openDetailModal
            // already set (the legacy single virtual_tour button, or hidden).
        }

        function buildPannellumScenes(scenes) {
            const byId = {};
            scenes.forEach(s => { byId[s.id] = s; });
            const pannellumScenes = {};
            scenes.forEach(scene => {
                const hotSpots = (scene.hotspots || []).map(h => {
                    if (h.type === 'navigation' && h.target_tour_id && byId[h.target_tour_id]) {
                        return { pitch: Number(h.pitch), yaw: Number(h.yaw), type: 'scene', text: h.title || byId[h.target_tour_id].name, sceneId: String(h.target_tour_id) };
                    }
                    if (h.type === 'viewpoint' && h.target_yaw !== null && h.target_yaw !== undefined && h.target_pitch !== null && h.target_pitch !== undefined) {
                        // Same-panorama viewpoint: no scene change, just spin
                        // the existing viewer to the saved orientation.
                        return {
                            pitch: Number(h.pitch), yaw: Number(h.yaw), type: 'info',
                            text: h.title || 'Look here',
                            clickHandlerFunc: function () {
                                const targetHfov = (h.target_hfov !== null && h.target_hfov !== undefined) ? Number(h.target_hfov) : pannellumViewerInstance.getHfov();
                                pannellumViewerInstance.lookAt(Number(h.target_pitch), Number(h.target_yaw), targetHfov, 1000);
                            }
                        };
                    }
                    // 'info' hotspots, and navigation/viewpoint hotspots
                    // missing their target, degrade to a plain info marker
                    // instead of a dead/crashing click target.
                    return { pitch: Number(h.pitch), yaw: Number(h.yaw), type: 'info', text: [h.title, h.description].filter(Boolean).join(' — ') || 'Info' };
                });
                pannellumScenes[String(scene.id)] = {
                    title: scene.name,
                    type: 'equirectangular',
                    panorama: normalizeImageSrc(scene.image) || scene.image,
                    hotSpots
                };
            });
            return pannellumScenes;
        }

        async function openMultiSceneTour(scenes) {
            const overlay = document.getElementById('tourModalOverlay');
            const container = document.getElementById('tourViewerContainer');
            container.innerHTML = '<div id="tourLoading" style="color:#fff;font-size:14px;"><i class="fas fa-spinner fa-spin"></i> Loading virtual tour...</div>';
            overlay.classList.add('open');
            document.body.style.overflow = 'hidden';

            try {
                await loadPannellumAssets();
                container.style.position = 'relative';
                // A scene-navigation strip sits on top of the panorama so
                // the customer can jump directly to ANY of the property's
                // 360° rooms at any time - not only by finding and clicking
                // a hotspot inside the current panorama. This is what makes
                // 4 (or more) linked rooms reliably reachable even if a
                // hotspot is missing, mis-aimed, or its target was removed.
                const navHtml = scenes.map(s => `
                    <button type="button" class="tour-scene-nav-btn" data-scene-id="${s.id}"
                        style="pointer-events:auto;padding:6px 14px;border:none;border-radius:20px;background:rgba(0,0,0,0.55);color:#fff;font-size:12px;font-weight:600;cursor:pointer;white-space:nowrap;">
                        ${escapeHtml(s.name)}
                    </button>`).join('');
                container.innerHTML = `
                    <div id="pannellumViewer" style="width:100%;height:100%;"></div>
                    <div id="tourSceneNav" style="position:absolute;top:10px;left:10px;right:70px;display:flex;gap:6px;flex-wrap:wrap;z-index:20;pointer-events:none;">${navHtml}</div>
                `;

                if (pannellumViewerInstance) {
                    pannellumViewerInstance.destroy();
                    pannellumViewerInstance = null;
                }
                const primary = scenes.find(s => Number(s.is_primary) === 1) || scenes[0];
                pannellumViewerInstance = window.pannellum.viewer('pannellumViewer', {
                    default: { firstScene: String(primary.id), sceneFadeDuration: 800, compass: false },
                    scenes: buildPannellumScenes(scenes)
                });

                function setActiveSceneNav(sceneId) {
                    document.querySelectorAll('#tourSceneNav .tour-scene-nav-btn').forEach(b => {
                        const active = String(b.dataset.sceneId) === String(sceneId);
                        b.style.background = active ? 'var(--gold)' : 'rgba(0,0,0,0.55)';
                        b.style.color = active ? '#111' : '#fff';
                    });
                }
                setActiveSceneNav(primary.id);

                // Clicking a nav button jumps straight to that scene via
                // Pannellum's own loadScene() API - works for any number of
                // scenes, independent of hotspots.
                document.getElementById('tourSceneNav').addEventListener('click', function (e) {
                    const btn = e.target.closest('.tour-scene-nav-btn');
                    if (!btn) return;
                    const sceneId = btn.dataset.sceneId;
                    pannellumViewerInstance.loadScene(sceneId);
                    setActiveSceneNav(sceneId);
                });

                // Keep the nav strip in sync when the customer instead
                // navigates via an in-panorama hotspot. getScene() (rather
                // than the event's own argument) is used because Pannellum
                // passes inconsistent argument shapes to 'scenechange'
                // depending on whether the change came from a hotspot click
                // or loadScene() - getScene() is reliable either way.
                pannellumViewerInstance.on('load', function () {
                    setActiveSceneNav(pannellumViewerInstance.getScene());
                });
            } catch (e) {
                container.innerHTML = '<div style="color:#fff;padding:24px;text-align:center;">Could not load the 360&deg; tour. Please try again.</div>';
            }
        }

        // ========== 360° TOUR MANAGER (admin/landlord editor) ==========
        let tourEditorViewerInstance = null;
        let tourManagerState = { listingType: null, listingId: null, listingName: null, scenes: [], editingSceneId: null, pendingHotspot: null, editingHotspotId: null };

        function openTourManager(listingType, listingId, listingName) {
            tourManagerState = { listingType, listingId, listingName, scenes: [], editingSceneId: null, pendingHotspot: null, editingHotspotId: null };
            document.getElementById('tourManagerSubtitle').textContent = `${listingName} — upload 360° panoramas and connect rooms with clickable hotspots.`;
            document.getElementById('tourHotspotEditorWrap').style.display = 'none';
            document.getElementById('tourHotspotForm').style.display = 'none';
            document.getElementById('tourManagerOverlay').classList.add('open');
            document.body.style.overflow = 'hidden';
            loadTourManagerScenes();
        }

        function closeTourManager() {
            document.getElementById('tourManagerOverlay').classList.remove('open');
            document.body.style.overflow = '';
            if (tourEditorViewerInstance) { tourEditorViewerInstance.destroy(); tourEditorViewerInstance = null; }
            // The customer-facing viewer caches "does this listing have a
            // multi-scene tour" per listing for the session - invalidate it
            // so a scene/hotspot just added or removed here shows up next
            // time the customer opens this listing, without needing a page reload.
            if (tourManagerState.listingId != null) multiSceneTourCache.delete(tourManagerState.listingId);
        }

        document.getElementById('tourManagerCloseBtn').addEventListener('click', closeTourManager);
        document.getElementById('tourManagerOverlay').addEventListener('click', function(e) {
            if (e.target === this) closeTourManager();
        });

        async function loadTourManagerScenes() {
            const list = document.getElementById('tourManagerSceneList');
            list.innerHTML = '<p style="color:var(--text-secondary);font-size:13px;">Loading scenes...</p>';
            try {
                const res = await apiFetch(`tours?listing_type=${tourManagerState.listingType}&listing_id=${tourManagerState.listingId}`);
                tourManagerState.scenes = (res && Array.isArray(res.scenes)) ? res.scenes : [];
                renderTourManagerScenes();
            } catch (e) {
                list.innerHTML = '<p style="color:var(--red);font-size:13px;">Could not load scenes: ' + escapeHtml(e.message) + '</p>';
            }
        }

        function renderTourManagerScenes() {
            const list = document.getElementById('tourManagerSceneList');
            if (tourManagerState.scenes.length === 0) {
                list.innerHTML = '<p style="color:var(--text-secondary);font-size:13px;">No 360&deg; scenes yet. Upload the first panorama below to get started.</p>';
                return;
            }
            list.innerHTML = tourManagerState.scenes.map(s => `
                <div style="min-width:150px;max-width:150px;border:1px solid var(--border-color);border-radius:10px;overflow:hidden;flex-shrink:0;background:var(--bg-modal);${tourManagerState.editingSceneId === s.id ? 'outline:2px solid var(--gold);' : ''}">
                    <img src="${normalizeImageSrc(s.image)}" style="width:100%;height:90px;object-fit:cover;cursor:pointer;" onclick="openHotspotEditor(${s.id})">
                    <div style="padding:8px;">
                        <div style="font-size:12px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${escapeHtml(s.name)}${Number(s.is_primary) === 1 ? ' <span title="Starting scene" style="color:var(--gold);">★</span>' : ''}</div>
                        <div style="font-size:10px;color:var(--text-secondary);">${(s.hotspots || []).length} hotspot${(s.hotspots || []).length === 1 ? '' : 's'}</div>
                        <div style="display:flex;gap:6px;margin-top:6px;">
                            <button style="flex:1;font-size:11px;padding:4px;border:1px solid var(--border-color);border-radius:6px;background:var(--bg-main);color:var(--text-primary);cursor:pointer;" onclick="openHotspotEditor(${s.id})">Hotspots</button>
                            <button style="font-size:11px;padding:4px 8px;border:none;border-radius:6px;background:var(--red);color:#fff;cursor:pointer;" onclick="deleteTourScene(${s.id})"><i class="fas fa-trash"></i></button>
                        </div>
                    </div>
                </div>
            `).join('');
        }

        document.getElementById('tourManagerUploadForm').addEventListener('submit', async function (e) {
            e.preventDefault();
            const nameInput = document.getElementById('tourSceneName');
            const fileInput = document.getElementById('tourSceneImage');
            const btn = document.getElementById('tourUploadBtn');
            if (!fileInput.files[0] || !nameInput.value.trim()) return;

            const fd = new FormData();
            fd.append('listing_type', tourManagerState.listingType);
            fd.append('listing_id', tourManagerState.listingId);
            fd.append('name', nameInput.value.trim());
            fd.append('image', fileInput.files[0]);

            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Uploading...';
            try {
                await apiFetch('tours', { method: 'POST', body: fd });
                nameInput.value = '';
                fileInput.value = '';
                showToast('360° scene uploaded.', 'success');
                await loadTourManagerScenes();
            } catch (err) {
                showToast('Error: ' + err.message, 'error');
            } finally {
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-cloud-upload-alt"></i> Add Scene';
            }
        });

        async function deleteTourScene(id) {
            const scene = tourManagerState.scenes.find(s => s.id === id);
            if (!scene) return;
            if (!confirm(`Delete the "${scene.name}" scene? Any hotspot pointing to it from another scene will stop navigating (but won't be deleted).`)) return;
            try {
                await apiFetch('tours/' + id, { method: 'DELETE' });
                if (tourManagerState.editingSceneId === id) {
                    document.getElementById('tourHotspotEditorWrap').style.display = 'none';
                    tourManagerState.editingSceneId = null;
                }
                showToast('Scene deleted.', 'success');
                await loadTourManagerScenes();
            } catch (err) {
                showToast('Error: ' + err.message, 'error');
            }
        }

        async function openHotspotEditor(sceneId) {
            tourManagerState.editingSceneId = sceneId;
            tourManagerState.pendingHotspot = null;
            tourManagerState.editingHotspotId = null;
            renderTourManagerScenes();

            const scene = tourManagerState.scenes.find(s => s.id === sceneId);
            if (!scene) return;

            document.getElementById('tourHotspotEditorWrap').style.display = 'block';
            document.getElementById('tourEditingSceneName').textContent = scene.name;
            document.getElementById('tourHotspotForm').style.display = 'none';

            // Populate the "target room" dropdown with every OTHER scene.
            const targetSelect = document.getElementById('hsTarget');
            targetSelect.innerHTML = tourManagerState.scenes
                .filter(s => s.id !== sceneId)
                .map(s => `<option value="${s.id}">${escapeHtml(s.name)}</option>`).join('')
                || '<option value="">No other scenes yet</option>';

            const viewerEl = document.getElementById('tourEditorViewer');
            viewerEl.innerHTML = '<div style="color:#fff;padding:20px;text-align:center;"><i class="fas fa-spinner fa-spin"></i> Loading panorama...</div>';
            try {
                await loadPannellumAssets();
                viewerEl.innerHTML = '';
                if (tourEditorViewerInstance) { tourEditorViewerInstance.destroy(); tourEditorViewerInstance = null; }
                tourEditorViewerInstance = window.pannellum.viewer(viewerEl, {
                    type: 'equirectangular',
                    panorama: normalizeImageSrc(scene.image) || scene.image,
                    autoLoad: true,
                    compass: false,
                    hotSpotDebug: false,
                    hotSpots: (scene.hotspots || []).map(h => ({
                        pitch: Number(h.pitch), yaw: Number(h.yaw),
                        type: 'info',
                        text: (h.type === 'navigation' ? '➡ ' : h.type === 'viewpoint' ? '↻ ' : 'ℹ ') + (h.title || 'Hotspot') + ' (click list below to edit)'
                    }))
                });
                // Placing a hotspot: the user clicks anywhere on the loaded
                // panorama. Pannellum's mouseEventToCoords() converts a
                // screen click into the pitch/yaw the viewer is actually
                // looking at, so the person never has to type or calculate
                // coordinates themselves.
                //
                // IMPORTANT: a plain 'click' (or 'mousedown' alone) also
                // fires at the START of every drag the user makes to look
                // around the panorama, which would drop an unwanted hotspot
                // on every pan. Pannellum has no built-in click-vs-drag
                // distinction, so it's done manually here: record the
                // pointer position on mousedown, and only treat the
                // following mouseup as a "click" (and place a hotspot) if
                // the pointer barely moved in between. A real drag moves
                // far more than a few pixels and is ignored.
                let hsPointerDown = null;
                tourEditorViewerInstance.on('mousedown', function (ev) {
                    hsPointerDown = { x: ev.clientX, y: ev.clientY };
                });
                tourEditorViewerInstance.on('mouseup', function (ev) {
                    const down = hsPointerDown;
                    hsPointerDown = null;
                    if (!down) return;
                    const dx = ev.clientX - down.x;
                    const dy = ev.clientY - down.y;
                    if (Math.sqrt(dx * dx + dy * dy) > 6) return; // was a drag, not a click

                    const coords = tourEditorViewerInstance.mouseEventToCoords(ev);
                    if (!coords) return;
                    tourManagerState.pendingHotspot = { pitch: coords[0], yaw: coords[1] };
                    tourManagerState.editingHotspotId = null;
                    document.getElementById('hsYaw').value = coords[1];
                    document.getElementById('hsPitch').value = coords[0];
                    document.getElementById('hsType').value = 'navigation';
                    document.getElementById('hsTargetWrap').style.display = 'block';
                    document.getElementById('hsViewpointWrap').style.display = 'none';
                    document.getElementById('hsTargetYaw').value = '';
                    document.getElementById('hsTargetPitch').value = '';
                    document.getElementById('hsTargetHfov').value = '';
                    document.getElementById('hsViewpointStatus').textContent = 'Not set';
                    document.getElementById('hsTitle').value = '';
                    document.getElementById('hsDesc').value = '';
                    document.getElementById('tourHotspotForm').style.display = 'flex';
                });
            } catch (e) {
                viewerEl.innerHTML = '<div style="color:#fff;padding:20px;text-align:center;">Could not load this panorama.</div>';
            }

            renderTourHotspotList(scene);
        }

        document.getElementById('hsType').addEventListener('change', function () {
            document.getElementById('hsTargetWrap').style.display = this.value === 'navigation' ? 'block' : 'none';
            document.getElementById('hsViewpointWrap').style.display = this.value === 'viewpoint' ? 'block' : 'none';
        });
        document.getElementById('hsCancelBtn').addEventListener('click', function () {
            document.getElementById('tourHotspotForm').style.display = 'none';
            tourManagerState.pendingHotspot = null;
            tourManagerState.editingHotspotId = null;
        });
        // "Use current view" for viewpoint hotspots: grabs whatever
        // direction/zoom the admin has the panorama rotated to RIGHT NOW
        // in the editor viewer and stores it as the hotspot's target -
        // this is the real viewer orientation, never a typed-in or
        // random value.
        document.getElementById('hsSetViewpointBtn').addEventListener('click', function () {
            if (!tourEditorViewerInstance) return;
            const yaw = tourEditorViewerInstance.getYaw();
            const pitch = tourEditorViewerInstance.getPitch();
            const hfov = tourEditorViewerInstance.getHfov();
            document.getElementById('hsTargetYaw').value = yaw;
            document.getElementById('hsTargetPitch').value = pitch;
            document.getElementById('hsTargetHfov').value = hfov;
            document.getElementById('hsViewpointStatus').textContent =
                `Set (yaw ${yaw.toFixed(0)}°, pitch ${pitch.toFixed(0)}°)`;
        });

        document.getElementById('tourHotspotForm').addEventListener('submit', async function (e) {
            e.preventDefault();
            if (!tourManagerState.pendingHotspot) return;
            const type = document.getElementById('hsType').value;
            const payload = {
                type,
                yaw: document.getElementById('hsYaw').value,
                pitch: document.getElementById('hsPitch').value,
                title: document.getElementById('hsTitle').value.trim(),
                description: document.getElementById('hsDesc').value.trim(),
                target_tour_id: type === 'navigation' ? document.getElementById('hsTarget').value : null,
                target_yaw: type === 'viewpoint' ? document.getElementById('hsTargetYaw').value : null,
                target_pitch: type === 'viewpoint' ? document.getElementById('hsTargetPitch').value : null,
                target_hfov: type === 'viewpoint' ? document.getElementById('hsTargetHfov').value : null
            };
            if (type === 'navigation' && !payload.target_tour_id) {
                showToast('Choose a target room for the navigation hotspot.', 'warning');
                return;
            }
            if (type === 'viewpoint' && (payload.target_yaw === '' || payload.target_pitch === '')) {
                showToast('Rotate the panorama to the target view and click "Use current view".', 'warning');
                return;
            }
            try {
                if (tourManagerState.editingHotspotId) {
                    await apiFetch('tours/hotspot/' + tourManagerState.editingHotspotId, { method: 'PUT', body: payload });
                } else {
                    await apiFetch(`tours/${tourManagerState.editingSceneId}/hotspots`, { method: 'POST', body: payload });
                }
                document.getElementById('tourHotspotForm').style.display = 'none';
                tourManagerState.pendingHotspot = null;
                tourManagerState.editingHotspotId = null;
                showToast('Hotspot saved.', 'success');
                await loadTourManagerScenes();
                await openHotspotEditor(tourManagerState.editingSceneId);
            } catch (err) {
                showToast('Error: ' + err.message, 'error');
            }
        });

        function renderTourHotspotList(scene) {
            const wrap = document.getElementById('tourHotspotList');
            const hotspots = scene.hotspots || [];
            if (hotspots.length === 0) {
                wrap.innerHTML = '<p style="color:var(--text-secondary);font-size:13px;">No hotspots yet — click anywhere on the panorama above to add one.</p>';
                return;
            }
            wrap.innerHTML = hotspots.map(h => {
                const target = tourManagerState.scenes.find(s => s.id === h.target_tour_id);
                const desc = h.type === 'navigation'
                    ? `Navigates to <strong>${escapeHtml(target ? target.name : 'a deleted scene')}</strong>`
                    : h.type === 'viewpoint'
                        ? `Rotates the view within this same panorama`
                        : escapeHtml(h.description || 'Information hotspot');
                const icon = h.type === 'navigation' ? '➡️' : (h.type === 'viewpoint' ? '↻' : 'ℹ️');
                return `
                    <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 10px;border:1px solid var(--border-color);border-radius:8px;margin-bottom:6px;">
                        <div>
                            <div style="font-size:13px;font-weight:600;">${icon} ${escapeHtml(h.title || 'Untitled')}</div>
                            <div style="font-size:12px;color:var(--text-secondary);">${desc}</div>
                        </div>
                        <button style="font-size:11px;padding:4px 8px;border:none;border-radius:6px;background:var(--red);color:#fff;cursor:pointer;" onclick="deleteTourHotspot(${h.id})"><i class="fas fa-trash"></i></button>
                    </div>
                `;
            }).join('');
        }

        async function deleteTourHotspot(id) {
            if (!confirm('Delete this hotspot?')) return;
            try {
                await apiFetch('tours/hotspot/' + id, { method: 'DELETE' });
                showToast('Hotspot deleted.', 'success');
                await loadTourManagerScenes();
                if (tourManagerState.editingSceneId) await openHotspotEditor(tourManagerState.editingSceneId);
            } catch (err) {
                showToast('Error: ' + err.message, 'error');
            }
        }


        // ========== AI HOUSE MATCHMAKER ==========
        function summaryToRoomLike(s) {
            return {
                id: s.room_id, title: s.name, location: s.location, price: s.monthly_rent,
                size: s.room_size, type: s.type, beds: s.bedrooms, image: s.image,
                status: s.status || 'available', virtual_tour: s.virtual_tour,
                listing_purpose: s.listing_purpose || 'rental'
            };
        }

        function openAiMatchmaker() {
            document.getElementById('aiMatchmakerOverlay').classList.add('open');
            document.body.style.overflow = 'hidden';
        }
        function closeAiMatchmaker() {
            document.getElementById('aiMatchmakerOverlay').classList.remove('open');
            document.body.style.overflow = '';
        }
        document.getElementById('openAiMatchmakerBtn').addEventListener('click', openAiMatchmaker);
        document.getElementById('aiMatchmakerCloseBtn').addEventListener('click', closeAiMatchmaker);
        document.getElementById('aiMatchmakerOverlay').addEventListener('click', (e) => {
            if (e.target === e.currentTarget) closeAiMatchmaker();
        });

        function renderAiMatchResults(results) {
            const box = document.getElementById('aiMatchmakerResults');
            if (!results || results.length === 0) {
                box.innerHTML = `<p style="color:var(--text-secondary);text-align:center;padding:20px 0;">No available properties matched that yet. Try a different location or budget.</p>`;
                return;
            }
            box.innerHTML = results.map(s => `
                <div style="display:flex;gap:12px;padding:12px;border:1px solid var(--border-color);border-radius:14px;margin-bottom:10px;cursor:${s.room_id ? 'pointer' : 'default'};" ${s.room_id ? `onclick="closeAiMatchmaker();openDetailModal(summaryToRoomLike(${escapeHtml(JSON.stringify(s))}))"` : ''}>
                    <img src="${normalizeImageSrc(parsePropertyImages(s.image)[0]) || 'https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?w=200&h=150&fit=crop'}" style="width:80px;height:64px;object-fit:cover;border-radius:10px;flex-shrink:0;">
                    <div style="flex:1;min-width:0;">
                        <div style="display:flex;justify-content:space-between;align-items:start;gap:8px;">
                            <strong style="color:var(--text-primary);font-size:14px;">${escapeHtml(s.name)}</strong>
                            ${s.match_score !== null ? `<span style="background:var(--gold);color:#fff;font-size:11px;font-weight:700;padding:2px 8px;border-radius:10px;white-space:nowrap;">${s.match_score}% match</span>` : ''}
                        </div>
                        <div style="font-size:12px;color:var(--text-secondary);margin-top:2px;"><i class="fas fa-map-pin"></i> ${escapeHtml(s.location)} &nbsp;•&nbsp; ${s.bedrooms} bed &nbsp;•&nbsp; TSh ${Number(s.monthly_rent||0).toLocaleString()}/mo</div>
                        ${(s.match_reasons && s.match_reasons.length) ? `<ul style="margin:6px 0 0;padding-left:16px;font-size:11px;color:var(--text-muted);">${s.match_reasons.map(r => `<li>${escapeHtml(r)}</li>`).join('')}</ul>` : ''}
                    </div>
                </div>
            `).join('');
        }

        document.getElementById('aiMatchmakerForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            const query = document.getElementById('aiMatchmakerQuery').value.trim();
            if (!query) return;
            const box = document.getElementById('aiMatchmakerResults');
            box.innerHTML = `<p style="text-align:center;padding:20px 0;color:var(--text-secondary);"><i class="fas fa-spinner fa-spin"></i> Searching real listings...</p>`;
            try {
                const data = await apiFetch('ai/match', { method: 'POST', body: { query } });
                renderAiMatchResults(data.results || []);
            } catch (err) {
                box.innerHTML = `<p style="color:var(--red);text-align:center;padding:20px 0;">${escapeHtml(err.message)}</p>`;
            }
        });

        // ========== FLOATING AI CHATBOT ==========
        let aiChatSessionId = null;
        function openAiChat() {
            const panel = document.getElementById('aiChatPanel');
            panel.style.display = 'flex';
            const msgs = document.getElementById('aiChatMessages');
            if (!msgs.children.length) {
                appendAiChatBubble('ai', "Hello! I'm the Smart Rent assistant. Ask me about available properties, booking, contracts, or payments.");
            }
        }
        function closeAiChat() {
            document.getElementById('aiChatPanel').style.display = 'none';
        }
        document.getElementById('aiChatFab').addEventListener('click', () => {
            const panel = document.getElementById('aiChatPanel');
            panel.style.display === 'flex' ? closeAiChat() : openAiChat();
        });
        document.getElementById('aiChatCloseBtn').addEventListener('click', closeAiChat);

        function appendAiChatBubble(who, text, properties) {
            const msgs = document.getElementById('aiChatMessages');
            const bubble = document.createElement('div');
            bubble.style.cssText = who === 'user'
                ? 'align-self:flex-end;background:var(--gold);color:#fff;padding:8px 12px;border-radius:14px 14px 2px 14px;max-width:85%;font-size:13px;white-space:pre-wrap;'
                : 'align-self:flex-start;background:var(--bg-main);color:var(--text-primary);padding:8px 12px;border-radius:14px 14px 14px 2px;max-width:90%;font-size:13px;white-space:pre-wrap;border:1px solid var(--border-color);';
            bubble.textContent = text; // textContent - never innerHTML - for chat message bodies
            msgs.appendChild(bubble);

            if (properties && properties.length) {
                const list = document.createElement('div');
                list.style.cssText = 'align-self:flex-start;max-width:90%;display:flex;flex-direction:column;gap:6px;';
                list.innerHTML = properties.map(s => `
                    <div style="display:flex;gap:8px;padding:8px;border:1px solid var(--border-color);border-radius:10px;cursor:${s.room_id ? 'pointer' : 'default'};background:var(--bg-modal);" ${s.room_id ? `onclick="closeAiChat();openDetailModal(summaryToRoomLike(${escapeHtml(JSON.stringify(s))}))"` : ''}>
                        <img src="${normalizeImageSrc(parsePropertyImages(s.image)[0]) || 'https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?w=120&h=90&fit=crop'}" style="width:52px;height:42px;object-fit:cover;border-radius:8px;flex-shrink:0;">
                        <div style="min-width:0;">
                            <div style="font-size:12px;font-weight:700;color:var(--text-primary);">${escapeHtml(s.name)}</div>
                            <div style="font-size:11px;color:var(--text-secondary);">TSh ${Number(s.monthly_rent||0).toLocaleString()}/mo &nbsp;•&nbsp; ${escapeHtml(s.location)}</div>
                        </div>
                    </div>
                `).join('');
                msgs.appendChild(list);
            }
            msgs.scrollTop = msgs.scrollHeight;
        }

        document.getElementById('aiChatForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            const input = document.getElementById('aiChatInput');
            const message = input.value.trim();
            if (!message) return;
            appendAiChatBubble('user', message);
            input.value = '';
            const msgs = document.getElementById('aiChatMessages');
            const thinking = document.createElement('div');
            thinking.id = 'aiChatThinking';
            thinking.style.cssText = 'align-self:flex-start;color:var(--text-muted);font-size:12px;padding:4px 12px;';
            thinking.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Thinking...';
            msgs.appendChild(thinking);
            msgs.scrollTop = msgs.scrollHeight;
            try {
                const data = await apiFetch('ai/chat', { method: 'POST', body: { message, session_id: aiChatSessionId } });
                aiChatSessionId = data.session_id || aiChatSessionId;
                document.getElementById('aiChatThinking')?.remove();
                // Defense in depth: never render a blank/undefined bubble,
                // even if the backend ever returns a response with no
                // usable reply text.
                const replyText = (data && typeof data.reply === 'string' && data.reply.trim())
                    ? data.reply
                    : (data && data.message) || "Sorry, I couldn't find an answer to that. Please try asking again.";
                appendAiChatBubble('ai', replyText, data && data.properties);
            } catch (err) {
                document.getElementById('aiChatThinking')?.remove();
                appendAiChatBubble('ai', "Sorry, I couldn't process that right now. Please try again.");
            }
        });

        dmCloseAction.addEventListener('click', closeDetailModal);
        dmBookBtn.addEventListener('click', function() {
            if (!currentDetailRoom || currentDetailRoom.status !== 'available') return;
            if (!isLoggedIn()) {
                showLoginRequired(() => { proceedWithBooking(currentDetailRoom); closeDetailModal(); });
                return;
            }
            proceedWithBooking(currentDetailRoom);
            closeDetailModal();
        });
        dmOrderBtn.addEventListener('click', function() {
            if (!currentDetailRoom || currentDetailRoom.status !== 'available') return;
            if (!isLoggedIn()) {
                showLoginRequired(() => { proceedWithOrder(currentDetailRoom); closeDetailModal(); });
                return;
            }
            proceedWithOrder(currentDetailRoom);
            closeDetailModal();
        });
        detailOverlay.addEventListener('click', (e) => { if (e.target === detailOverlay) closeDetailModal(); });
        document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeDetailModal(); });
        dmImageWrap.addEventListener('click', function(e) {
            if (e.target === dmImage || e.target.closest('.dm-image-wrap')) {
                isZoomed = !isZoomed;
                this.classList.toggle('zoomed', isZoomed);
                const hint = this.querySelector('.dm-zoom-hint');
                if (hint) hint.textContent = isZoomed ? '🔍 Click to zoom out' : '🔍 Click to zoom';
            }
        });
        // ========== BOOKINGS & ORDERS ==========
        function proceedWithBooking(room) {
            if (!room) { showToast('Room not found.', 'error'); return; }
            if (!isLoggedIn()) {
                showLoginRequired(() => proceedWithBooking(room));
                return;
            }
            if (currentUser) {
                document.getElementById('cpCustomerName').value = currentUser.name || '';
                document.getElementById('cpCustomerEmail').value = currentUser.email || '';
                document.getElementById('cpCustomerPhone').value = currentUser.phone || '';
            }
            goToPaymentDashboard(room);
        }

        function proceedWithOrder(room) {
            if (!room) { showToast('Room not found.', 'error'); return; }
            if (!isLoggedIn()) {
                showLoginRequired(() => proceedWithOrder(room));
                return;
            }
            const customerName = currentUser.name || '';
            const customerEmail = currentUser.email || '';
            const customerPhone = currentUser.phone || '';
            const html = `
                <div class="modal fade" id="orderConfirmModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
                    <div class="modal-dialog modal-dialog-centered" style="max-width:480px;">
                        <div class="modal-content" style="border-radius:24px;border:none;box-shadow:var(--shadow-xl);background:var(--bg-modal);">
                            <div class="modal-header border-0 pb-0">
                                <h5 class="modal-title fw-bold" style="color:var(--text-primary);"><i class="fas fa-clipboard-check" style="color:var(--gold);margin-right:8px;"></i> Confirm Order</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body" style="padding:20px 28px 28px;">
                                <p style="color:var(--text-secondary);">You are about to place an order for <strong style="color:var(--text-primary);">${escapeHtml(room.title)}</strong>.</p>
                                <p style="color:var(--text-muted);font-size:13px;">Please confirm your details and expected arrival date.</p>
                                <form id="orderConfirmForm">
                                    <div class="form-group" style="margin-bottom:12px;">
                                        <label style="font-size:12px;font-weight:600;color:var(--text-primary);">Full Name *</label>
                                        <input type="text" id="orderCustomerName" class="form-control" value="${escapeHtml(customerName)}" placeholder="Your full name" required style="border-radius:12px;border:1px solid var(--border-color);padding:10px 14px;background:var(--bg-input);color:var(--text-primary);width:100%;">
                                    </div>
                                    <div class="form-group" style="margin-bottom:12px;">
                                        <label style="font-size:12px;font-weight:600;color:var(--text-primary);">Email *</label>
                                        <input type="email" id="orderCustomerEmail" class="form-control" value="${escapeHtml(customerEmail)}" placeholder="Your email" required style="border-radius:12px;border:1px solid var(--border-color);padding:10px 14px;background:var(--bg-input);color:var(--text-primary);width:100%;">
                                    </div>
                                    <div class="form-group" style="margin-bottom:12px;">
                                        <label style="font-size:12px;font-weight:600;color:var(--text-primary);">Phone Number *</label>
                                        <input type="tel" id="orderCustomerPhone" class="form-control" value="${escapeHtml(customerPhone)}" placeholder="+255 712 345 678" required style="border-radius:12px;border:1px solid var(--border-color);padding:10px 14px;background:var(--bg-input);color:var(--text-primary);width:100%;">
                                    </div>
                                    <div class="form-group" style="margin-bottom:12px;">
                                        <label style="font-size:12px;font-weight:600;color:var(--text-primary);">Expected Arrival Date *</label>
                                        <input type="date" id="orderArrivalDate" class="form-control" required style="border-radius:12px;border:1px solid var(--border-color);padding:10px 14px;background:var(--bg-input);color:var(--text-primary);width:100%;">
                                    </div>
                                    <div style="display:flex;gap:12px;margin-top:16px;">
                                        <button type="button" class="btn btn-outline-secondary flex-fill" data-bs-dismiss="modal" style="border-radius:12px;font-weight:600;border-color:var(--border-color);color:var(--text-secondary);">Cancel</button>
                                        <button type="submit" class="btn flex-fill" style="border-radius:12px;font-weight:700;background:var(--gradient-blue);color:#fff;border:none;">Place Order</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            const existing = document.getElementById('orderConfirmModal');
            if (existing) existing.remove();
            document.body.insertAdjacentHTML('beforeend', html);
            const modal = new bootstrap.Modal(document.getElementById('orderConfirmModal'), { backdrop: 'static', keyboard: true });
            modal.show();

            document.getElementById('orderConfirmForm').addEventListener('submit', function(e) {
                e.preventDefault();
                const name = document.getElementById('orderCustomerName').value.trim();
                const email = document.getElementById('orderCustomerEmail').value.trim();
                const phone = document.getElementById('orderCustomerPhone').value.trim();
                const arrivalDate = document.getElementById('orderArrivalDate').value;
                if (!name || !email || !phone || !arrivalDate) {
                    showToast('Please fill in all fields.', 'warning');
                    return;
                }
                const orderData = {
                    room_id: room.id,
                    user_id: currentUser ? currentUser.id : null,
                    landlord_id: room.landlordId || null,
                    customer_name: name,
                    customer_email: email,
                    customer_phone: phone,
                    arrival_date: arrivalDate,
                    status: 'ordered'
                };
                apiFetch('orders', { method: 'POST', body: orderData })
                    .then(result => {
                        if (result.success) {
                            modal.hide();
                            document.getElementById('orderConfirmModal').remove();
                            showToast(`✅ Order placed for "${room.title}"!`, 'success');
                            showToast(`📧 ${name}, your order has been received and is pending confirmation from the landlord/admin.`, 'info');
                            Promise.all([applyFilters(), fetchBookings(), fetchOrders()])
                                .then(() => {
                                    renderBookingsOrders();
                                    renderAdminRoomList();
                                    updateAdminStats();
                                    if (isLandlord()) renderLandlordBookingsOrders();
                                    if (isAdmin()) renderReports();
                                });
                        } else {
                            showToast('❌ Order failed: ' + result.message, 'error');
                        }
                    })
                    .catch(err => {
                        // e.g. someone else booked/ordered this room a moment ago
                        showToast('❌ ' + err.message, 'error');
                        applyFilters();
                    });
            });
        }

        function renderBookingsOrders() {
            const bookingsContainer = document.getElementById('bookingsList');
            if (bookingsContainer) {
                let displayBookings = [...bookingRecords];
                if (isCustomer() && currentUser) {
                    displayBookings = displayBookings.filter(b => String(b.user_id) === String(currentUser.id));
                }
                if (isLandlord() && currentUser) {
                    displayBookings = displayBookings.filter(b => String(b.landlord_id) === String(currentUser.id));
                }
                if (displayBookings.length === 0) {
                    bookingsContainer.innerHTML = `<p style="grid-column:1/-1;color:var(--text-secondary);text-align:center;padding:20px 0;">No bookings yet. Book a room to get started.</p>`;
                } else {
                    bookingsContainer.innerHTML = displayBookings.map(b => `
                        <div class="booking-card">
                            <div class="bc-header">
                                <span class="bc-room"><i class="fas fa-bed" style="color:var(--gold);"></i> ${escapeHtml(b.room_title)}</span>
                                <span class="bc-time"><i class="far fa-calendar-alt"></i> ${new Date(b.created_at).toLocaleString()}</span>
                            </div>
                            <div class="bc-details">
                                <span><i class="fas fa-map-pin"></i> ${escapeHtml(b.room_location) || '—'}</span>
                                <span><i class="fas fa-user"></i> ${escapeHtml(b.customer_name) || '—'}</span>
                                <span><i class="fas fa-envelope"></i> ${escapeHtml(b.customer_email) || '—'}</span>
                                <span><i class="fas fa-phone"></i> ${escapeHtml(b.customer_phone) || '—'}</span>
                                <span><i class="fas fa-tag"></i> TSh ${(b.amount || 0).toLocaleString()}</span>
                                <span><span class="status-badge-sm success">${escapeHtml(b.status) || 'Confirmed'}</span></span>
                            </div>
                            <div class="bc-actions">
                                <button class="btn-edit" onclick="editBooking(${b.id})"><i class="fas fa-edit"></i> Edit</button>
                                <button class="btn-delete" onclick="deleteBooking(${b.id})"><i class="fas fa-trash-alt"></i> Delete</button>
                            </div>
                        </div>
                    `).join('');
                }
            }

            const ordersContainer = document.getElementById('ordersList');
            if (ordersContainer) {
                let displayOrders = [...orderRecords];
                if (isCustomer() && currentUser) {
                    displayOrders = displayOrders.filter(o => String(o.user_id) === String(currentUser.id));
                }
                if (isLandlord() && currentUser) {
                    displayOrders = displayOrders.filter(o => String(o.landlord_id) === String(currentUser.id));
                }
                if (displayOrders.length === 0) {
                    ordersContainer.innerHTML = `<p style="grid-column:1/-1;color:var(--text-secondary);text-align:center;padding:20px 0;">No orders yet. Order a room to get started.</p>`;
                } else {
                    ordersContainer.innerHTML = displayOrders.map(o => `
                        <div class="order-card">
                            <div class="oc-header">
                                <span class="oc-room"><i class="fas fa-shopping-cart" style="color:var(--blue);"></i> ${escapeHtml(o.room_title)}</span>
                                <span class="oc-time"><i class="far fa-calendar-alt"></i> ${new Date(o.created_at).toLocaleString()}</span>
                            </div>
                            <div class="oc-details">
                                <span><i class="fas fa-map-pin"></i> ${escapeHtml(o.room_location) || '—'}</span>
                                <span><i class="fas fa-user"></i> ${escapeHtml(o.customer_name) || '—'}</span>
                                <span><i class="fas fa-envelope"></i> ${escapeHtml(o.customer_email) || '—'}</span>
                                <span><i class="fas fa-phone"></i> ${escapeHtml(o.customer_phone) || '—'}</span>
                                <span><i class="fas fa-calendar-day"></i> Arrival: ${escapeHtml(o.arrival_date) || '—'}</span>
                                <span>${orderStatusBadgeHtml(o)}</span>
                            </div>
                            <div class="oc-actions">
                                ${orderActionsHtml(o)}
                            </div>
                        </div>
                    `).join('');
                }
            }
        }

        // ========== REPORTS ==========
        function orderStatusBadgeHtml(o) {
            const status = o.status || 'ordered';
            const cls = status === 'confirmed' ? 'success' : status === 'cancelled' ? 'secondary' : 'warning';
            const label = status.charAt(0).toUpperCase() + status.slice(1);
            return `<span class="status-badge-sm ${cls}">${label}</span>`;
        }

        function orderActionsHtml(o) {
            const canManage = isAdmin() || isLandlord();
            const pending = (o.status || 'ordered') === 'ordered';
            let buttons = '';
            if (canManage && pending) {
                buttons += `<button class="btn-edit" style="background:var(--green);color:#fff;" onclick="confirmOrder(${o.id})"><i class="fas fa-check"></i> Confirm</button>`;
            }
            buttons += `<button class="btn-edit" onclick="editOrder(${o.id})"><i class="fas fa-edit"></i> Edit</button>`;
            buttons += `<button class="btn-delete" onclick="deleteOrder(${o.id})"><i class="fas fa-trash-alt"></i> Delete</button>`;
            return buttons;
        }

        function renderReports() {
            let displayBookings = [...bookingRecords];
            let displayOrders = [...orderRecords];

            if (isLandlord() && currentUser) {
                displayBookings = displayBookings.filter(b => String(b.landlord_id) === String(currentUser.id));
                displayOrders = displayOrders.filter(o => String(o.landlord_id) === String(currentUser.id));
            } else if (isCustomer() && currentUser) {
                displayBookings = displayBookings.filter(b => String(b.user_id) === String(currentUser.id));
                displayOrders = displayOrders.filter(o => String(o.user_id) === String(currentUser.id));
            }

            const bookingsContainer = document.getElementById('reportBookingsList');
            const ordersContainer = document.getElementById('reportOrdersList');

            if (bookingsContainer) {
                if (displayBookings.length === 0) {
                    bookingsContainer.innerHTML = `<p style="color:var(--text-secondary);padding:8px 0;">No bookings to display.</p>`;
                } else {
                    bookingsContainer.innerHTML = displayBookings.map(b => `
                        <div class="booking-card" style="margin-bottom:10px;">
                            <div class="bc-header">
                                <span class="bc-room"><i class="fas fa-bed" style="color:var(--gold);"></i> ${escapeHtml(b.room_title)}</span>
                                <span class="bc-time"><i class="far fa-calendar-alt"></i> ${new Date(b.created_at).toLocaleString()}</span>
                            </div>
                            <div class="bc-details">
                                <span><i class="fas fa-map-pin"></i> ${escapeHtml(b.room_location) || '—'}</span>
                                <span><i class="fas fa-user"></i> ${escapeHtml(b.customer_name) || '—'}</span>
                                <span><i class="fas fa-envelope"></i> ${escapeHtml(b.customer_email) || '—'}</span>
                                <span><i class="fas fa-phone"></i> ${escapeHtml(b.customer_phone) || '—'}</span>
                                <span><i class="fas fa-tag"></i> TSh ${(b.amount || 0).toLocaleString()}</span>
                                <span><span class="status-badge-sm success">${escapeHtml(b.status) || 'Confirmed'}</span></span>
                            </div>
                            <div class="bc-actions">
                                <button class="btn-edit" onclick="editBooking(${b.id})"><i class="fas fa-edit"></i> Edit</button>
                                <button class="btn-delete" onclick="deleteBooking(${b.id})"><i class="fas fa-trash-alt"></i> Delete</button>
                            </div>
                        </div>
                    `).join('');
                }
            }

            if (ordersContainer) {
                if (displayOrders.length === 0) {
                    ordersContainer.innerHTML = `<p style="color:var(--text-secondary);padding:8px 0;">No orders to display.</p>`;
                } else {
                    ordersContainer.innerHTML = displayOrders.map(o => `
                        <div class="order-card" style="margin-bottom:10px;">
                            <div class="oc-header">
                                <span class="oc-room"><i class="fas fa-shopping-cart" style="color:var(--blue);"></i> ${escapeHtml(o.room_title)}</span>
                                <span class="oc-time"><i class="far fa-calendar-alt"></i> ${new Date(o.created_at).toLocaleString()}</span>
                            </div>
                            <div class="oc-details">
                                <span><i class="fas fa-map-pin"></i> ${escapeHtml(o.room_location) || '—'}</span>
                                <span><i class="fas fa-user"></i> ${escapeHtml(o.customer_name) || '—'}</span>
                                <span><i class="fas fa-envelope"></i> ${escapeHtml(o.customer_email) || '—'}</span>
                                <span><i class="fas fa-phone"></i> ${escapeHtml(o.customer_phone) || '—'}</span>
                                <span><i class="fas fa-calendar-day"></i> Arrival: ${escapeHtml(o.arrival_date) || '—'}</span>
                                <span>${orderStatusBadgeHtml(o)}</span>
                            </div>
                            <div class="oc-actions">
                                ${orderActionsHtml(o)}
                            </div>
                        </div>
                    `).join('');
                }
            }
        }

        // ========== EDIT / DELETE BOOKINGS & ORDERS ==========
        function editBooking(id) {
            const booking = bookingRecords.find(b => b.id === id);
            if (!booking) { showToast('Booking not found.', 'error'); return; }
            const newArrival = prompt('Update arrival date (YYYY-MM-DD) or leave blank:', booking.arrival_date || '');
            if (newArrival !== null) {
                booking.arrival_date = newArrival || booking.arrival_date || '';
                apiFetch('bookings/' + id, { method: 'PUT', body: { arrival_date: booking.arrival_date } })
                    .then(() => {
                        Promise.all([fetchBookings(), fetchOrders()])
                            .then(() => {
                                renderBookingsOrders();
                                renderReports();
                                if (isLandlord()) renderLandlordBookingsOrders();
                                showToast('✅ Booking updated!', 'success');
                            });
                    })
                    .catch(err => showToast('Error: ' + err.message, 'error'));
            }
        }

        function deleteBooking(id) {
            if (!confirm('Delete this booking? This action cannot be undone.')) return;
            const booking = bookingRecords.find(b => b.id === id);
            if (!booking) return;
            apiFetch('bookings/' + id, { method: 'DELETE' })
                .then(() => {
                    if (booking.room_id) {
                        const room = roomsData.find(r => r.id === booking.room_id);
                        if (room && room.status === 'taken') {
                            room.status = 'available';
                            apiFetch('rooms/' + room.id, { method: 'PUT', body: { status: 'available' } })
                                .then(() => {
                                    applyFilters();
                                    renderAdminRoomList();
                                    updateAdminStats();
                                });
                        }
                    }
                    Promise.all([fetchBookings(), fetchOrders()])
                        .then(() => {
                            renderBookingsOrders();
                            renderReports();
                            if (isLandlord()) renderLandlordBookingsOrders();
                            showToast('🗑️ Booking deleted.', 'success');
                        });
                })
                .catch(err => showToast('Error: ' + err.message, 'error'));
        }

        function confirmOrder(id) {
            const order = orderRecords.find(o => o.id === id);
            if (!order) { showToast('Order not found.', 'error'); return; }
            if (!confirm(`Confirm this order for "${order.room_title}" by ${order.customer_name}?`)) return;
            apiFetch('orders/' + id, { method: 'PUT', body: { status: 'confirmed' } })
                .then(() => {
                    Promise.all([fetchBookings(), fetchOrders()])
                        .then(() => {
                            renderBookingsOrders();
                            renderReports();
                            if (isLandlord()) renderLandlordBookingsOrders();
                            showToast(`✅ Order confirmed for "${order.room_title}".`, 'success');
                        });
                })
                .catch(err => showToast('Error: ' + err.message, 'error'));
        }

        function cancelOrder(id) {
            const order = orderRecords.find(o => o.id === id);
            if (!order) { showToast('Order not found.', 'error'); return; }
            if (!confirm(`Cancel this order for "${order.room_title}"? The room will become available again.`)) return;
            apiFetch('orders/' + id, { method: 'PUT', body: { status: 'cancelled' } })
                .then(() => {
                    Promise.all([applyFilters(), fetchBookings(), fetchOrders()])
                        .then(() => {
                            renderBookingsOrders();
                            renderAdminRoomList();
                            updateAdminStats();
                            renderReports();
                            if (isLandlord()) renderLandlordBookingsOrders();
                            showToast(`🗑️ Order cancelled for "${order.room_title}".`, 'info');
                        });
                })
                .catch(err => showToast('Error: ' + err.message, 'error'));
        }

        function editOrder(id) {
            const order = orderRecords.find(o => o.id === id);
            if (!order) { showToast('Order not found.', 'error'); return; }
            const newArrival = prompt('Update arrival date (YYYY-MM-DD):', order.arrival_date || '');
            if (newArrival !== null) {
                order.arrival_date = newArrival || order.arrival_date || '';
                apiFetch('orders/' + id, { method: 'PUT', body: { arrival_date: order.arrival_date } })
                    .then(() => {
                        Promise.all([fetchBookings(), fetchOrders()])
                            .then(() => {
                                renderBookingsOrders();
                                renderReports();
                                if (isLandlord()) renderLandlordBookingsOrders();
                                showToast('✅ Order updated!', 'success');
                            });
                    })
                    .catch(err => showToast('Error: ' + err.message, 'error'));
            }
        }

        function deleteOrder(id) {
            if (!confirm('Delete this order? This action cannot be undone.')) return;
            const order = orderRecords.find(o => o.id === id);
            if (!order) return;
            apiFetch('orders/' + id, { method: 'DELETE' })
                .then(() => {
                    if (order.room_id) {
                        const room = roomsData.find(r => r.id === order.room_id);
                        if (room && room.status === 'ordered') {
                            room.status = 'available';
                            apiFetch('rooms/' + room.id, { method: 'PUT', body: { status: 'available' } })
                                .then(() => {
                                    applyFilters();
                                    renderAdminRoomList();
                                    updateAdminStats();
                                });
                        }
                    }
                    Promise.all([fetchBookings(), fetchOrders()])
                        .then(() => {
                            renderBookingsOrders();
                            renderReports();
                            if (isLandlord()) renderLandlordBookingsOrders();
                            showToast('🗑️ Order deleted.', 'success');
                        });
                })
                .catch(err => showToast('Error: ' + err.message, 'error'));
        }

        // ========== LANDLORD BOOKINGS & ORDERS ==========
        function renderLandlordBookingsOrders() {
            if (!isLandlord() || !currentUser) return;
            const landlordId = currentUser.id;

            const landlordBookings = bookingRecords.filter(b => String(b.landlord_id) === String(landlordId));
            const landlordOrders = orderRecords.filter(o => String(o.landlord_id) === String(landlordId));

            const bookingsContainer = document.getElementById('landlordBookingsList');
            const ordersContainer = document.getElementById('landlordOrdersList');

            if (bookingsContainer) {
                if (landlordBookings.length === 0) {
                    bookingsContainer.innerHTML = `<p style="color:var(--text-secondary);padding:8px 0;">No bookings on your properties yet.</p>`;
                } else {
                    bookingsContainer.innerHTML = landlordBookings.map(b => `
                        <div class="booking-card" style="margin-bottom:10px;">
                            <div class="bc-header">
                                <span class="bc-room"><i class="fas fa-bed" style="color:var(--gold);"></i> ${escapeHtml(b.room_title)}</span>
                                <span class="bc-time"><i class="far fa-calendar-alt"></i> ${new Date(b.created_at).toLocaleString()}</span>
                            </div>
                            <div class="bc-details">
                                <span><i class="fas fa-user"></i> ${escapeHtml(b.customer_name) || '—'}</span>
                                <span><i class="fas fa-envelope"></i> ${escapeHtml(b.customer_email) || '—'}</span>
                                <span><i class="fas fa-phone"></i> ${escapeHtml(b.customer_phone) || '—'}</span>
                                <span><i class="fas fa-tag"></i> TSh ${(b.amount || 0).toLocaleString()}</span>
                                <span><span class="status-badge-sm success">${escapeHtml(b.status) || 'Confirmed'}</span></span>
                            </div>
                            <div class="bc-actions">
                                <button class="btn-edit" onclick="editBooking(${b.id})"><i class="fas fa-edit"></i> Edit</button>
                                <button class="btn-delete" onclick="deleteBooking(${b.id})"><i class="fas fa-trash-alt"></i> Delete</button>
                            </div>
                        </div>
                    `).join('');
                }
            }

            if (ordersContainer) {
                if (landlordOrders.length === 0) {
                    ordersContainer.innerHTML = `<p style="color:var(--text-secondary);padding:8px 0;">No orders on your properties yet.</p>`;
                } else {
                    ordersContainer.innerHTML = landlordOrders.map(o => `
                        <div class="order-card" style="margin-bottom:10px;">
                            <div class="oc-header">
                                <span class="oc-room"><i class="fas fa-shopping-cart" style="color:var(--blue);"></i> ${escapeHtml(o.room_title)}</span>
                                <span class="oc-time"><i class="far fa-calendar-alt"></i> ${new Date(o.created_at).toLocaleString()}</span>
                            </div>
                            <div class="oc-details">
                                <span><i class="fas fa-user"></i> ${escapeHtml(o.customer_name) || '—'}</span>
                                <span><i class="fas fa-envelope"></i> ${escapeHtml(o.customer_email) || '—'}</span>
                                <span><i class="fas fa-phone"></i> ${escapeHtml(o.customer_phone) || '—'}</span>
                                <span><i class="fas fa-calendar-day"></i> Arrival: ${escapeHtml(o.arrival_date) || '—'}</span>
                                <span>${orderStatusBadgeHtml(o)}</span>
                            </div>
                            <div class="oc-actions">
                                ${orderActionsHtml(o)}
                            </div>
                        </div>
                    `).join('');
                }
            }

            const lpTotalBookings = document.getElementById('lpTotalBookings');
            const lpTotalOrders = document.getElementById('lpTotalOrders');
            if (lpTotalBookings) lpTotalBookings.textContent = landlordBookings.length;
            if (lpTotalOrders) lpTotalOrders.textContent = landlordOrders.length;
        }

        // ========== FILTERS ==========
        function applyFilters() {
            const search = searchInput.value.toLowerCase().trim();
            const loc = filterLocation.value;
            const area = filterArea.value;
            const maxPrice = parseFloat(filterMaxPrice.value) || Infinity;
            const minSize = parseFloat(filterMinSize.value) || 0;
            const roomType = filterRoomType.value;
            const sort = filterSort.value;

            let params = {};
            if (search) params.search = search;
            if (loc) params.location = loc;
            if (area) params.area = area;
            if (maxPrice !== Infinity) params.max_price = maxPrice;
            if (minSize > 0) params.min_size = minSize;
            if (roomType) params.type = roomType;
            if (sort && sort !== 'default') params.sort = sort;

            return apiFetch('rooms?' + new URLSearchParams(params).toString())
                .then(rooms => {
                    roomsData = rooms;
                    filteredRooms = [...roomsData];
                    currentPage = 1;
                    renderRooms();
                    showToast(`Found ${rooms.length} rooms`, 'info');
                })
                .catch(err => {
                    showToast('Failed to load rooms: ' + err.message, 'error');
                });
        }

        function clearFilters() {
            searchInput.value = '';
            filterLocation.value = '';
            filterArea.value = '';
            filterMaxPrice.value = '';
            filterMinSize.value = '';
            filterRoomType.value = '';
            filterSort.value = 'default';
            applyFilters();
            showToast('Filters cleared', 'info');
        }

        // ========== ADMIN ==========
        // Multi-image gallery preview - same behaviour as the landlord's
        // propImages picker: renders a thumbnail per selected file into
        // #roomImagePreview, first file is always the cover shot.
        //
        // FIX: this used to also write into a legacy `imagePreview` global
        // (document.getElementById('imagePreview')) that no longer exists
        // anywhere in the page HTML. Since that lookup returned null,
        // imagePreview was always null, and the "Add Room" submit handler
        // below crashed with a TypeError the instant it tried to read
        // imagePreview.src - BEFORE it ever reached the upload request.
        // That silent crash is why the Upload button spun forever: it was
        // already switched to its loading state, but the code that resets
        // it (in the fetch's .finally()) never ran because the fetch was
        // never even started. The fix is to read the preview straight off
        // the rendered thumbnail, exactly like the (working) Landlord
        // property form already does with #propImagePreview.
        document.getElementById('roomImage').addEventListener('change', function(e) {
            const preview = document.getElementById('roomImagePreview');
            preview.innerHTML = '';
            const files = e.target.files;
            for (let i = 0; i < Math.min(files.length, 12); i++) {
                const reader = new FileReader();
                reader.onload = function(ev) {
                    const img = document.createElement('img');
                    img.src = ev.target.result;
                    preview.appendChild(img);
                };
                reader.readAsDataURL(files[i]);
            }
        });

        document.getElementById('roomImageArea').addEventListener('click', function() {
            document.getElementById('roomImage').click();
        });

        // Single 360° panorama file preview - identical behaviour to the
        // landlord's propVirtualTourFile picker (shows the picked image and
        // its filename, with a Remove option).
        document.getElementById('roomVirtualTourFile').addEventListener('change', function(e) {
            const file = e.target.files[0];
            let preview = document.getElementById('roomVirtualTourPreview');
            if (!preview) {
                preview = document.createElement('div');
                preview.id = 'roomVirtualTourPreview';
                preview.style.cssText = 'margin-top:8px;display:flex;align-items:center;gap:10px;';
                e.target.insertAdjacentElement('afterend', preview);
            }
            preview.innerHTML = '';
            if (!file) return;

            const reader = new FileReader();
            reader.onload = function(ev) {
                preview.innerHTML = `
                    <img src="${ev.target.result}" alt="360° tour preview" style="width:64px;height:64px;object-fit:cover;border-radius:10px;border:1px solid var(--border-color);">
                    <span style="font-size:12px;color:var(--text-secondary);">${escapeHtml(file.name)} selected — will upload with this room.</span>
                    <button type="button" id="roomVirtualTourClearBtn" style="border:none;background:none;color:var(--red);cursor:pointer;font-size:12px;text-decoration:underline;">Remove</button>
                `;
                document.getElementById('roomVirtualTourClearBtn').addEventListener('click', function() {
                    document.getElementById('roomVirtualTourFile').value = '';
                    preview.innerHTML = '';
                });
            };
            reader.readAsDataURL(file);
        });

        document.getElementById('adminForm').addEventListener('submit', function(e) {
            e.preventDefault();
            if (!isAdmin()) { showToast('Please login as admin first.', 'warning'); return; }
            const title = document.getElementById('roomTitle').value.trim();
            const price = parseFloat(document.getElementById('roomPrice').value);
            const locationCity = document.getElementById('roomLocation').value;
            const area = document.getElementById('roomArea').value.trim();
            const size = parseFloat(document.getElementById('roomSize').value);
            const type = document.getElementById('roomType').value;
            const beds = parseInt(document.getElementById('roomBeds').value);
            const badge = document.getElementById('roomBadge').value.trim();
            const listingPurpose = document.getElementById('roomListingPurpose').value;
            const imageFiles = document.getElementById('roomImage').files;
            if (!title || !price || !locationCity || !area || !size || !type || !beds || !imageFiles.length) {
                showToast('Please fill all required fields and select at least one image.', 'warning');
                return;
            }

            const addRoomBtn = document.getElementById('addRoomBtn');
            addRoomBtn.disabled = true;
            addRoomBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Uploading...';
            addRoomBtn.classList.add('btn-upload-loading');

            // Show the room in the browser the moment the files are read -
            // don't wait on the network round trip first. The thumbnails in
            // #roomImagePreview are already rendered data: URLs from the
            // roomImage 'change' listener above, so we can reuse the first
            // one directly (same approach the Landlord property form uses
            // with #propImagePreview); normalizeImageSrc() already passes
            // data: URLs straight through unchanged. This temp entry is
            // replaced by the real, server-persisted room a moment later
            // once the upload confirms - it's a preview, not a substitute
            // for saving to the DB.
            const tempId = 'temp-' + Date.now();
            const firstPreviewImg = document.querySelector('#roomImagePreview img');
            const optimisticRoom = {
                id: tempId,
                title, price,
                location: `${locationCity}, ${area}`,
                area, size, type, beds,
                badge: badge || '',
                listing_purpose: listingPurpose,
                status: 'available',
                image: firstPreviewImg ? firstPreviewImg.src : '',
                _optimistic: true
            };
            roomsData = [optimisticRoom, ...roomsData];
            filteredRooms = [optimisticRoom, ...filteredRooms];
            renderRooms();
            renderAdminRoomList();
            updateAdminStats();

            const formData = new FormData();
            formData.append('title', title);
            formData.append('price', price);
            formData.append('location', `${locationCity}, ${area}`);
            formData.append('area', area);
            formData.append('size', size);
            formData.append('type', type);
            formData.append('beds', beds);
            formData.append('badge', badge || '');
            formData.append('listing_purpose', listingPurpose);
            formData.append('status', 'available');
            for (let i = 0; i < imageFiles.length; i++) {
                formData.append('images[]', imageFiles[i]);
            }
            // Optional single 360° photo - works exactly like the
            // landlord's propVirtualTourFile/propVirtualTour fields.
            formData.append('virtualTour', document.getElementById('roomVirtualTour').value.trim());
            const tourFile = document.getElementById('roomVirtualTourFile').files[0];
            if (tourFile) formData.append('virtualTourImage', tourFile);

            apiFetch('rooms', { method: 'POST', body: formData })
                .then(result => {
                    if (result.success) {
                        adminForm.reset();
                        document.getElementById('roomImagePreview').innerHTML = '';
                        const tourPreview = document.getElementById('roomVirtualTourPreview');
                        if (tourPreview) tourPreview.innerHTML = '';
                        // Replace the temp preview entry with the real,
                        // server-persisted list (real id, real uploads/ path).
                        applyFilters().then(() => {
                            renderAdminRoomList();
                            updateAdminStats();
                            showToast(`✅ "${title}" added successfully!`, 'success');
                            showSection('browse');
                        });
                    } else {
                        // Upload failed - remove the temp preview so nothing
                        // is left on screen that wasn't actually saved.
                        roomsData = roomsData.filter(r => r.id !== tempId);
                        filteredRooms = filteredRooms.filter(r => r.id !== tempId);
                        renderRooms();
                        renderAdminRoomList();
                        updateAdminStats();
                        showToast('❌ Failed: ' + result.message, 'error');
                    }
                })
                .catch(err => {
                    roomsData = roomsData.filter(r => r.id !== tempId);
                    filteredRooms = filteredRooms.filter(r => r.id !== tempId);
                    renderRooms();
                    renderAdminRoomList();
                    updateAdminStats();
                    showToast('Error: ' + err.message, 'error');
                })
                .finally(() => {
                    // Always restore the button, no matter what happened above,
                    // so it can never look permanently "stuck loading".
                    addRoomBtn.disabled = false;
                    addRoomBtn.innerHTML = '<i class="fas fa-plus-circle"></i> Add Room';
                    addRoomBtn.classList.remove('btn-upload-loading');
                });
        });

        function renderAdminRoomList() {
            const container = document.getElementById('adminRoomList');
            if (!container) return;
            if (roomsData.length === 0) {
                container.innerHTML = `<p style="grid-column:1/-1;color:var(--text-secondary);text-align:center;padding:20px 0;">No rooms available.</p>`;
                return;
            }
            container.innerHTML = roomsData.map(room => `
                <div class="placeholder-card" style="cursor:default;${room._optimistic ? 'opacity:0.65;' : ''}">
                    <img src="${normalizeImageSrc(parsePropertyImages(room.image)[0]) || ''}" alt="${escapeHtml(room.title)}" style="width:100%;height:120px;object-fit:cover;border-radius:12px;margin-bottom:10px;">
                    <h4 style="font-weight:700;color:var(--text-primary);">${escapeHtml(room.title)}</h4>
                    <p style="font-size:13px;color:var(--text-secondary);">${escapeHtml(room.location)}</p>
                    <p style="font-weight:700;color:var(--text-primary);">TSh ${Number(room.price||0).toLocaleString()}</p>
                    <span style="display:inline-block;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:700;color:#fff;background:${room.listing_purpose === 'holiday' ? '#0891b2' : '#6d28d9'};margin-bottom:6px;">${room.listing_purpose === 'holiday' ? 'Holiday' : 'Rental'}</span>
                    ${room._optimistic
                        ? `<span class="status-badge available"><i class="fas fa-spinner fa-spin"></i> Saving...</span>`
                        : `<span class="status-badge ${room.status}">${room.status.charAt(0).toUpperCase()+room.status.slice(1)}</span>
                    <div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap;">
                        <button class="btn-details" style="padding:4px 12px;border:1px solid var(--border-color);border-radius:8px;background:var(--bg-main);color:var(--text-primary);cursor:pointer;white-space:nowrap;" onclick="openDetailModal(roomsData.find(r => r.id === ${room.id}))">View</button>
                        <button class="btn-details" style="padding:4px 12px;border:1px solid var(--border-color);border-radius:8px;background:var(--bg-main);color:var(--text-primary);cursor:pointer;white-space:nowrap;" onclick="openImageManager('room', ${room.id})"><i class="fas fa-images"></i> Images</button>
                        <button class="btn-details" style="padding:4px 12px;border:1px solid var(--border-color);border-radius:8px;background:var(--bg-main);color:var(--text-primary);cursor:pointer;white-space:nowrap;" onclick="openTourManager('room', ${room.id}, ${JSON.stringify(room.title)})"><i class="fas fa-street-view"></i> 360° Virtual Tour</button>
                        <button class="btn-delete" style="padding:4px 12px;border:none;border-radius:8px;background:var(--red);color:#fff;cursor:pointer;font-weight:600;white-space:nowrap;" onclick="deleteRoom(${room.id})">Delete</button>
                    </div>`}
                </div>
            `).join('');
        }

        // ========== IMAGE GALLERY MANAGER (Admin / owning Landlord) ==========
        // Generalized over a { type: 'room'|'property', id } target so the
        // exact same modal, upload flow and delete flow serve Admin's Room
        // cards and Landlord's Property cards identically - both now call
        // this directly with an id they already have in hand, with no
        // house_id/title matching step in between (that matching approach
        // was the extra, fragile layer that made only the Landlord button
        // depend on a lookup succeeding; this removes it entirely).
        let imgMgrTarget = { type: 'room', id: null };
        let imgMgrPendingFiles = [];
        const imageManagerModal = new bootstrap.Modal(document.getElementById('imageManagerModal'));

        function openImageManager(type, id) {
            imgMgrTarget = { type, id };
            imgMgrPendingFiles = [];
            document.getElementById('imgMgrFileInput').value = '';
            document.getElementById('imgMgrPreview').innerHTML = '';
            renderImageManagerGrid();
            imageManagerModal.show();
        }

        /** Finds the record (room or property) the gallery manager currently targets. */
        function imgMgrCurrentRecord() {
            if (imgMgrTarget.type === 'property') {
                return landlordProperties.find(p => p.id === imgMgrTarget.id);
            }
            return roomsData.find(r => r.id === imgMgrTarget.id);
        }

        function renderImageManagerGrid() {
            const grid = document.getElementById('imgMgrGrid');
            const record = imgMgrCurrentRecord();
            // Properties store their gallery in `images`, rooms in `image` -
            // parsePropertyImages() already accepts either shape.
            const images = record ? parsePropertyImages(imgMgrTarget.type === 'property' ? record.images : record.image) : [];
            if (images.length === 0) {
                grid.innerHTML = `<p style="grid-column:1/-1;color:var(--text-secondary);text-align:center;padding:10px 0;">No images yet.</p>`;
                return;
            }
            grid.innerHTML = images.map((img, i) => `
                <div style="position:relative;">
                    <img src="${normalizeImageSrc(img) || ''}" style="width:100%;height:80px;object-fit:cover;border-radius:10px;" onerror="this.style.opacity='0.3'">
                    <button type="button" onclick="deleteRoomImage(${i})" style="position:absolute;top:4px;right:4px;background:var(--red);color:#fff;border:none;border-radius:50%;width:24px;height:24px;cursor:pointer;font-size:12px;line-height:1;"><i class="fas fa-times"></i></button>
                </div>
            `).join('');
        }

        function deleteRoomImage(index) {
            if (!confirm('Delete this image?')) return;
            const endpoint = imgMgrTarget.type === 'property' ? 'properties' : 'rooms';
            apiFetch(`${endpoint}/${imgMgrTarget.id}/images/${index}`, { method: 'DELETE' })
                .then(result => {
                    if (result && result.success) {
                        const record = imgMgrCurrentRecord();
                        if (record) {
                            if (imgMgrTarget.type === 'property') record.images = JSON.stringify(result.images);
                            else record.image = JSON.stringify(result.images);
                        }
                        renderImageManagerGrid();
                        showToast('🗑️ Image deleted.', 'success');
                    } else {
                        showToast('Error: ' + (result && (result.error || result.message) || 'Delete failed'), 'error');
                    }
                })
                .catch(err => showToast('❌ ' + err.message, 'error'));
        }

        document.getElementById('imgMgrUploadArea').addEventListener('click', () => document.getElementById('imgMgrFileInput').click());
        document.getElementById('imgMgrFileInput').addEventListener('change', function(e) {
            imgMgrPendingFiles = Array.from(e.target.files || []);
            const preview = document.getElementById('imgMgrPreview');
            preview.innerHTML = imgMgrPendingFiles.map(f => `<span style="font-size:12px;padding:4px 10px;border-radius:8px;background:var(--bg-input);color:var(--text-primary);">${escapeHtml(f.name)}</span>`).join('');
        });

        document.getElementById('imgMgrUploadBtn').addEventListener('click', function() {
            if (!imgMgrPendingFiles.length) {
                showToast('Choose at least one image first.', 'warning');
                return;
            }
            const fd = new FormData();
            imgMgrPendingFiles.forEach(f => fd.append('images[]', f));
            const btn = this;
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Uploading...';
            const endpoint = imgMgrTarget.type === 'property' ? 'properties' : 'rooms';
            apiFetch(`${endpoint}/${imgMgrTarget.id}/images`, { method: 'POST', body: fd })
                .then(result => {
                    if (result && result.success) {
                        const record = imgMgrCurrentRecord();
                        if (record) {
                            if (imgMgrTarget.type === 'property') record.images = JSON.stringify(result.images);
                            else record.image = JSON.stringify(result.images);
                        }
                        imgMgrPendingFiles = [];
                        document.getElementById('imgMgrFileInput').value = '';
                        document.getElementById('imgMgrPreview').innerHTML = '';
                        renderImageManagerGrid();
                        showToast('✅ Images uploaded.', 'success');
                    } else {
                        showToast('Error: ' + (result && (result.error || result.message) || 'Upload failed'), 'error');
                    }
                })
                .catch(err => showToast('❌ ' + err.message, 'error'))
                .finally(() => {
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-upload"></i> Upload New Images';
                });
        });

        /**
         * "View" on a landlord property card - opens the same rich,
         * fully-working detail modal (gallery, amenities, booking status,
         * 360° button) that customers see when browsing, instead of a
         * placeholder toast, by resolving to the paired Room record (the
         * detail modal is Room-shaped since that's what customers actually
         * browse/book). Falls back gracefully with a clear message on the
         * rare older listing where no paired room can be found at all.
         */
        function viewPropertyDetails(houseId, propertyName) {
            const findMatch = (list) => {
                let match = houseId ? list.find(r => r.house_id && r.house_id === houseId) : null;
                if (!match && propertyName) {
                    match = list.find(r => r.title === propertyName && (!currentUser || String(r.landlord_id) === String(currentUser.id)));
                }
                return match;
            };
            const cached = findMatch(roomsData);
            if (cached) { openDetailModal(cached); return; }

            showToast('Loading property details…', 'info');
            const narrow = houseId ? apiFetch('rooms?house_id=' + encodeURIComponent(houseId)) : Promise.resolve([]);
            narrow.then(rooms => {
                let match = findMatch(rooms);
                if (match) {
                    if (!roomsData.some(r => r.id === match.id)) roomsData = [...roomsData, match];
                    openDetailModal(match);
                    return;
                }
                return apiFetch('rooms').then(all => {
                    roomsData = all;
                    const fresh = findMatch(all);
                    if (!fresh) {
                        showToast('Could not load details for this property yet - try again in a moment.', 'warning');
                        return;
                    }
                    openDetailModal(fresh);
                });
            }).catch(() => showToast('Could not load details for this property - please try again.', 'error'));
        }

        function deleteRoom(id) {
            if (!isAdmin()) { showToast('You must be admin to delete.', 'warning'); return; }
            const room = roomsData.find(r => r.id === id);
            if (!room) return;
            if (confirm(`Delete "${room.title}" (status: ${room.status})? This action cannot be undone.`)) {
                apiFetch('rooms/' + id, { method: 'DELETE' })
                    .then(() => {
                        applyFilters().then(() => {
                            renderAdminRoomList();
                            updateAdminStats();
                            renderBookingsOrders();
                            showToast(`🗑️ "${room.title}" deleted.`, 'success');
                        });
                    })
                    .catch(err => showToast('Error: ' + err.message, 'error'));
            }
        }

        function updateAdminStats() {
            const total = roomsData.length;
            const available = roomsData.filter(r => r.status === 'available').length;
            const booked = roomsData.filter(r => r.status === 'booked').length;
            const ordered = roomsData.filter(r => r.status === 'ordered').length;
            const taken = roomsData.filter(r => r.status === 'taken').length;
            document.getElementById('adminTotalRooms').textContent = total;
            document.getElementById('adminAvailableRooms').textContent = available;
            document.getElementById('adminBookedRooms').textContent = booked;
            document.getElementById('adminOrderedRooms').textContent = ordered;
            document.getElementById('adminTakenRooms').textContent = taken;
            if (isAdmin()) loadPlatformDashboard();
        }

        // ========== ADMIN PLATFORM DASHBOARD (KPIs + charts) ==========
        let platformCharts = {};
        function tsh(n) { return 'TSh ' + Math.round(Number(n) || 0).toLocaleString(); }

        async function loadPlatformDashboard() {
            const grid = document.getElementById('platformStatsGrid');
            if (!grid) return; // not on the admin page
            try {
                // Fetch without using apiFetch to avoid clearing session on error
                const response = await fetch(API_BASE + 'admin/dashboard', {
                    credentials: 'same-origin',
                    headers: { Accept: 'application/json' }
                });
                if (response.ok) {
                    const data = await response.json();
                    renderPlatformKpis(data.kpis || {});
                    renderPlatformCharts(data.charts || {});
                }
            } catch (err) {
                console.error('Failed to load platform dashboard:', err);
            }
            if (document.getElementById('commissionReportSummary')) {
                loadCommissionReport();
            }
        }

        function renderPlatformKpis(kpis) {
            document.getElementById('pfTotalProperties').textContent = kpis.total_properties ?? 0;
            document.getElementById('pfTotalCustomers').textContent = kpis.total_customers ?? 0;
            document.getElementById('pfTotalLandlords').textContent = kpis.total_landlords ?? 0;
            document.getElementById('pfTotalBookings').textContent = kpis.total_bookings ?? 0;
            document.getElementById('pfActiveContracts').textContent = kpis.active_contracts ?? 0;
            document.getElementById('pfTotalTransactions').textContent = kpis.total_transactions ?? 0;
            document.getElementById('pfPlatformRevenue').textContent = tsh(kpis.platform_revenue);
            document.getElementById('pfPendingPayouts').textContent = tsh(kpis.pending_payouts) + (kpis.pending_payouts_count ? ` (${kpis.pending_payouts_count})` : '');
        }

        function monthLabel(ym) {
            // '2026-08' -> 'Aug'
            const [y, m] = String(ym).split('-');
            const names = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
            const idx = parseInt(m, 10) - 1;
            return names[idx] ?? ym;
        }

        function makeOrUpdateChart(canvasId, type, data, options) {
            const canvas = document.getElementById(canvasId);
            if (!canvas || typeof Chart === 'undefined') return;
            if (platformCharts[canvasId]) {
                platformCharts[canvasId].data = data;
                platformCharts[canvasId].update();
                return;
            }
            platformCharts[canvasId] = new Chart(canvas.getContext('2d'), {
                type, data,
                options: Object.assign({ responsive: true, plugins: { legend: { display: type !== 'bar' } } }, options || {})
            });
        }

        const CHART_COLORS = ['#f59e0b', '#22c55e', '#3b82f6', '#ef4444', '#a855f7', '#06b6d4', '#eab308'];

        function renderPlatformCharts(charts) {
            const months = (charts.monthly_transactions || []).map(m => monthLabel(m.month));

            makeOrUpdateChart('chartMonthlyTransactions', 'bar', {
                labels: months,
                datasets: [{ label: 'Transactions', data: (charts.monthly_transactions || []).map(m => m.count), backgroundColor: '#3b82f6' }]
            });

            makeOrUpdateChart('chartMonthlyCommission', 'bar', {
                labels: (charts.monthly_commission || []).map(m => monthLabel(m.month)),
                datasets: [{ label: 'Commission (TSh)', data: (charts.monthly_commission || []).map(m => m.total), backgroundColor: '#f59e0b' }]
            });

            makeOrUpdateChart('chartRevenue', 'line', {
                labels: (charts.monthly_revenue || []).map(m => monthLabel(m.month)),
                datasets: [{ label: 'Revenue (TSh)', data: (charts.monthly_revenue || []).map(m => m.total), borderColor: '#22c55e', backgroundColor: 'rgba(34,197,94,0.15)', fill: true, tension: 0.3 }]
            });

            const listings = charts.property_listings || [];
            makeOrUpdateChart('chartPropertyListings', 'doughnut', {
                labels: listings.map(r => r.status),
                datasets: [{ data: listings.map(r => r.count), backgroundColor: CHART_COLORS }]
            }, { maintainAspectRatio: false });

            const bookings = charts.bookings_by_status || [];
            makeOrUpdateChart('chartBookings', 'doughnut', {
                labels: bookings.map(r => r.status),
                datasets: [{ data: bookings.map(r => r.count), backgroundColor: CHART_COLORS }]
            }, { maintainAspectRatio: false });

            const payments = charts.payments_by_status || [];
            makeOrUpdateChart('chartPaymentStatus', 'doughnut', {
                labels: payments.map(r => r.status),
                datasets: [{ data: payments.map(r => r.count), backgroundColor: CHART_COLORS }]
            }, { maintainAspectRatio: false });

            const contracts = charts.contracts_by_status || [];
            makeOrUpdateChart('chartContracts', 'doughnut', {
                labels: contracts.map(r => r.status),
                datasets: [{ data: contracts.map(r => r.count), backgroundColor: CHART_COLORS }]
            }, { maintainAspectRatio: false });
        }

        // ========== ADMIN: PLATFORM REVENUE REPORT (commission report) ==========
        function commissionReportQuery() {
            const range = document.getElementById('commissionReportRange').value;
            const params = new URLSearchParams({ range });
            if (range === 'custom') {
                const from = document.getElementById('commissionReportFrom').value;
                const to = document.getElementById('commissionReportTo').value;
                if (from) params.set('from', from);
                if (to) params.set('to', to);
            }
            return params;
        }

        async function loadCommissionReport() {
            const summaryBox = document.getElementById('commissionReportSummary');
            if (!summaryBox) return;
            try {
                const params = commissionReportQuery();
                // Fetch directly to avoid clearing session on error
                const response = await fetch(`${API_BASE}admin/commission-report?${params.toString()}`, {
                    credentials: 'same-origin',
                    headers: { Accept: 'application/json' }
                });
                if (response.ok) {
                    const data = await response.json();
                    document.getElementById('crVolume').textContent = tsh(data.total_transaction_volume);
                    document.getElementById('crCommission').textContent = tsh(data.total_platform_commission);
                    document.getElementById('crLandlordPayouts').textContent = tsh(data.total_landlord_payouts);
                    document.getElementById('crPendingPayouts').textContent = tsh(data.pending_payouts);
                    document.getElementById('crSuccessful').textContent = data.successful_payments ?? 0;
                    document.getElementById('crFailed').textContent = data.failed_payments ?? 0;

                    const monthly = data.monthly_totals || [];
                    makeOrUpdateChart('chartCommissionReport', 'bar', {
                        labels: monthly.map(m => monthLabel(m.month)),
                        datasets: [
                            { label: 'Transaction Volume (TSh)', data: monthly.map(m => m.volume), backgroundColor: '#3b82f6' },
                            { label: 'Platform Commission (TSh)', data: monthly.map(m => m.commission), backgroundColor: '#f59e0b' },
                        ]
                    }, { plugins: { legend: { display: true } }, maintainAspectRatio: false });
                }
            } catch (err) {
                console.error('Failed to load commission report:', err);
            }
        }

        document.addEventListener('DOMContentLoaded', () => {
            const rangeSelect = document.getElementById('commissionReportRange');
            const fromInput = document.getElementById('commissionReportFrom');
            const toInput = document.getElementById('commissionReportTo');
            const csvBtn = document.getElementById('commissionReportCsvBtn');
            if (!rangeSelect) return; // element only exists on the admin page

            rangeSelect.addEventListener('change', () => {
                const isCustom = rangeSelect.value === 'custom';
                fromInput.style.display = isCustom ? 'inline-block' : 'none';
                toInput.style.display = isCustom ? 'inline-block' : 'none';
                if (!isCustom || (fromInput.value && toInput.value)) {
                    loadCommissionReport();
                }
            });
            fromInput.addEventListener('change', () => { if (toInput.value) loadCommissionReport(); });
            toInput.addEventListener('change', () => { if (fromInput.value) loadCommissionReport(); });
            csvBtn.addEventListener('click', () => {
                const params = commissionReportQuery();
                params.set('export', 'csv');
                // Direct navigation (not apiFetch) so the browser handles the
                // CSV response and Content-Disposition download prompt.
                window.open(`${API_BASE}admin/commission-report?${params.toString()}`, '_blank');
            });
        });

        // ========== CONTACT ==========
        document.getElementById('contactForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const name = document.getElementById('contactName').value.trim();
            const email = document.getElementById('contactEmail').value.trim();
            const phone = document.getElementById('contactPhone').value.trim();
            const message = document.getElementById('contactMessage').value.trim();
            if (!name || !email || !phone || !message) { showToast('Please fill all fields.', 'warning'); return; }
            apiFetch('messages', { method: 'POST', body: { name, email, phone, message } })
                .then(() => {
                    this.reset();
                    showToast('✅ Message sent! Admin will get back to you soon.', 'success');
                    if (isAdmin()) renderMessages();
                })
                .catch(err => showToast('Error: ' + err.message, 'error'));
        });

        function renderMessages() {
            const container = document.getElementById('messagesList');
            if (!container) return;
            if (messages.length === 0) {
                container.innerHTML = `<p style="color:var(--text-secondary);text-align:center;padding:40px 0;">No messages yet.</p>`;
                return;
            }
            container.innerHTML = messages.slice().reverse().map(msg => `
                <div class="message-item">
                    <div class="msg-header"><span class="name"><i class="fas fa-user"></i> ${escapeHtml(msg.name)}</span><span class="date"><i class="fas fa-clock"></i> ${new Date(msg.created_at).toLocaleString()}</span></div>
                    <div class="msg-contact"><i class="fas fa-envelope"></i> ${escapeHtml(msg.email)} &nbsp;|&nbsp; <i class="fas fa-phone"></i> ${escapeHtml(msg.phone)}</div>
                    <div class="msg-body">${escapeHtml(msg.message)}</div>
                </div>
            `).join('');
        }

        // ========== CONTRACTS ==========
        const CONTRACT_STATUS_LABELS = {
            'DRAFT': 'Draft',
            'PENDING_CUSTOMER': 'Awaiting your acceptance',
            'PENDING_LANDLORD': 'Awaiting landlord acceptance',
            'ACTIVE': 'Active',
            'EXPIRED': 'Expired',
            'CANCELLED': 'Cancelled',
            'TERMINATED': 'Terminated'
        };
        const CONTRACT_STATUS_COLORS = {
            'DRAFT': 'var(--text-secondary)',
            'PENDING_CUSTOMER': 'var(--gold)',
            'PENDING_LANDLORD': 'var(--gold)',
            'ACTIVE': 'var(--green, #22c55e)',
            'EXPIRED': 'var(--text-secondary)',
            'CANCELLED': 'var(--red)',
            'TERMINATED': 'var(--red)'
        };

        async function fetchAndRenderContracts() {
            const container = document.getElementById('contractsList');
            if (!container) return;
            container.innerHTML = `<p style="color:var(--text-secondary);text-align:center;padding:40px 0;">Loading contracts...</p>`;
            try {
                const contracts = await apiFetch('contracts');
                renderContracts(Array.isArray(contracts) ? contracts : []);
            } catch (err) {
                container.innerHTML = `<p style="color:var(--red);text-align:center;padding:40px 0;">Could not load contracts: ${escapeHtml(err.message)}</p>`;
            }
        }

        function renderContracts(contracts) {
            const container = document.getElementById('contractsList');
            if (!container) return;
            if (contracts.length === 0) {
                container.innerHTML = `<p style="color:var(--text-secondary);text-align:center;padding:40px 0;">No contracts yet. A contract is generated automatically once a landlord confirms your booking.</p>`;
                return;
            }
            const role = currentUser ? currentUser.type : null;
            container.innerHTML = contracts.map(c => {
                const statusLabel = CONTRACT_STATUS_LABELS[c.status] || c.status;
                const statusColor = CONTRACT_STATUS_COLORS[c.status] || 'var(--text-secondary)';
                const canAccept = (role === 'Customer' && c.status === 'PENDING_CUSTOMER') ||
                                   (role === 'Landlord' && c.status === 'PENDING_LANDLORD');
                const pdfUrl = API_BASE + 'contracts/' + c.id + '/pdf';
                return `
                <div class="card" style="padding:18px;margin-bottom:14px;">
                    <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:10px;">
                        <div>
                            <div style="font-weight:700;font-size:15px;">${escapeHtml(c.contract_number)}</div>
                            <div style="color:var(--text-secondary);font-size:13px;margin-top:4px;">
                                Landlord: ${escapeHtml(c.landlord_name) || '-'} &nbsp;|&nbsp; Customer: ${escapeHtml(c.customer_name) || '-'}
                            </div>
                            <div style="color:var(--text-secondary);font-size:13px;margin-top:2px;">
                                Rent: TZS ${Number(c.monthly_rent).toLocaleString()} / month
                                ${c.start_date ? ' &nbsp;|&nbsp; Start: ' + c.start_date : ''}
                                ${c.end_date ? ' &nbsp;|&nbsp; End: ' + c.end_date : ''}
                            </div>
                        </div>
                        <span style="font-size:12px;font-weight:600;color:${statusColor};border:1px solid ${statusColor};border-radius:20px;padding:4px 12px;white-space:nowrap;">${statusLabel}</span>
                    </div>
                    <div style="margin-top:14px;display:flex;gap:10px;flex-wrap:wrap;">
                        <a href="${pdfUrl}" target="_blank" rel="noopener" class="btn btn-outline-secondary" style="font-size:13px;padding:8px 14px;">
                            <i class="fas fa-file-pdf"></i> Download PDF
                        </a>
                        ${canAccept ? `<button type="button" class="btn btn-primary" style="font-size:13px;padding:8px 14px;" onclick="acceptContract(${c.id})">
                            <i class="fas fa-check"></i> Accept Contract
                        </button>` : ''}
                    </div>
                </div>`;
            }).join('');
        }

        async function acceptContract(id) {
            if (!confirm('I have read and agree to the rental agreement. Accept this contract?')) return;
            try {
                const result = await apiFetch('contracts/' + id + '/accept', { method: 'POST', body: { accept: true } });
                if (result && result.success) {
                    showToast('✅ Contract accepted.', 'success');
                    fetchAndRenderContracts();
                } else {
                    showToast('❌ ' + (result.error || result.message || 'Could not accept contract.'), 'error');
                }
            } catch (err) {
                showToast('❌ ' + err.message, 'error');
            }
        }

        // ========== LOGIN REQUIRED (NO POPUP) ==========
        // A guest attempting a protected action (Book, Order, etc.) is sent
        // to the SAME full-page login section used everywhere else in the
        // app - never a Bootstrap modal popup, never a new window/tab. Once
        // they log in (or sign up) via the normal loginPageForm /
        // customerSignupForm / landlordSignupForm handlers in init(), the
        // pending action is resumed automatically.
        function showLoginRequired(callback) {
            pendingAuthAction = callback || null;

            showLoginSection();
            switchLoginTab('login');

            const email = document.getElementById('loginPageEmail');
            if (email) email.focus();
        }

        // ========== PAYMENT DASHBOARD ==========
        function updatePaymentDateTime() {
            const now = new Date();
            const opts = { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' };
            const el = document.getElementById('paymentDateTime');
            if (el) el.textContent = now.toLocaleDateString('en-US', opts);
        }
        setInterval(updatePaymentDateTime, 1000);
        updatePaymentDateTime();

        let selectedRoomForPayment = null;

        function goToPaymentDashboard(room) {
            if (!isLoggedIn()) {
                showLoginRequired(() => { goToPaymentDashboard(room); });
                return;
            }
            selectedRoomForPayment = room;
            showSection('payment-dashboard');
            document.getElementById('cpRoomBadge').textContent = `Booking: ${room.title}`;
            document.getElementById('cpRoomImg').src = normalizeImageSrc(parsePropertyImages(room.image)[0]) || 'https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?w=400&h=300&fit=crop';
            document.getElementById('cpHouseId').textContent = room.house_id || '—';
            document.getElementById('cpRoomTitle').textContent = room.title;
            document.getElementById('cpApartment').textContent = `${room.title} Apartments`;
            document.getElementById('cpLandlord').textContent = 'Mr. Joseph';
            document.getElementById('cpLocation').textContent = room.location;
            document.getElementById('cpArea').textContent = room.area;
            document.getElementById('cpSize').textContent = `${room.size} sqft`;
            document.getElementById('cpPrice').textContent = `TSh ${Number(room.price||0).toLocaleString()}`;
            document.getElementById('cpTotal').textContent = `TSh ${Number(room.price||0).toLocaleString()}`;
            document.getElementById('cpBookingId').value = room.id;
            document.getElementById('cpAmount').value = room.price;
            if (currentUser) {
                document.getElementById('cpCustomerName').value = currentUser.name || '';
                document.getElementById('cpCustomerEmail').value = currentUser.email || '';
                document.getElementById('cpCustomerPhone').value = currentUser.phone || '';
            }
            document.getElementById('cpRecipientNumber').value = '';
            document.getElementById('cpSelectedProvider').value = '';
            document.querySelectorAll('#cpPaymentMethods .cp-method').forEach(m => {
                m.classList.remove('selected');
                m.style.borderColor = 'var(--border-color)';
                m.style.background = 'var(--bg-main)';
            });
            document.getElementById('cpMobileFields').classList.remove('show');
            document.getElementById('cpCardFields').classList.remove('show');
            document.getElementById('cpPaypalFields').classList.remove('show');
            document.getElementById('completePaymentSection').scrollIntoView({ behavior: 'smooth', block: 'start' });
            showToast(`📋 Prepare payment for "${room.title}"`, 'info');
        }

        function clearPaymentSelection() {
            selectedRoomForPayment = null;
            document.getElementById('cpRoomBadge').textContent = 'No room selected';
            document.getElementById('cpRoomTitle').textContent = 'Select a room to book';
            document.getElementById('cpApartment').textContent = '—';
            document.getElementById('cpLandlord').textContent = '—';
            document.getElementById('cpLocation').textContent = '—';
            document.getElementById('cpArea').textContent = '—';
            document.getElementById('cpSize').textContent = '—';
            document.getElementById('cpPrice').textContent = '—';
            document.getElementById('cpTotal').textContent = 'TSh 0';
            document.getElementById('cpBookingId').value = '';
            document.getElementById('cpAmount').value = '0';
            document.getElementById('cpCustomerName').value = '';
            document.getElementById('cpCustomerEmail').value = '';
            document.getElementById('cpCustomerPhone').value = '';
            document.getElementById('cpRecipientNumber').value = '';
            document.getElementById('cpSelectedProvider').value = '';
            document.querySelectorAll('#cpPaymentMethods .cp-method').forEach(m => {
                m.classList.remove('selected');
                m.style.borderColor = 'var(--border-color)';
                m.style.background = 'var(--bg-main)';
            });
            document.getElementById('cpMobileFields').classList.remove('show');
            document.getElementById('cpCardFields').classList.remove('show');
            document.getElementById('cpPaypalFields').classList.remove('show');
            showToast('Payment cancelled', 'info');
        }

        document.querySelectorAll('#cpPaymentMethods .cp-method').forEach(el => {
            el.addEventListener('click', function() {
                document.querySelectorAll('#cpPaymentMethods .cp-method').forEach(m => {
                    m.classList.remove('selected');
                    m.style.borderColor = 'var(--border-color)';
                    m.style.background = 'var(--bg-main)';
                });
                this.classList.add('selected');
                this.style.borderColor = 'var(--gold)';
                this.style.background = 'var(--bg-badge)';
                const provider = this.dataset.provider;
                const type = this.dataset.type;
                document.getElementById('cpSelectedProvider').value = provider;
                document.getElementById('cpMobileFields').classList.toggle('show', type === 'mobile');
                document.getElementById('cpCardFields').classList.toggle('show', type === 'card');
                document.getElementById('cpPaypalFields').classList.toggle('show', type === 'paypal');
                document.getElementById('cpVerificationGroup').style.display = 'block';
                document.getElementById('cpVerificationLabel').textContent = type === 'mobile' ? 'Payment PIN / OTP / Password' : type === 'card' ? 'Card Verification Code / Password' : 'PayPal Confirmation Password';
                document.getElementById('cpVerificationHint').textContent = type === 'mobile' ? 'Enter the confirmation PIN or OTP sent to your phone.' : type === 'card' ? 'Enter your card verification code or secure payment password.' : 'Enter your PayPal confirmation password.';
                document.getElementById('cpPhone').required = (type === 'mobile');
                document.getElementById('cpCardHolder').required = (type === 'card');
                document.getElementById('cpCardNumber').required = (type === 'card');
                document.getElementById('cpExpiry').required = (type === 'card');
                document.getElementById('cpCvv').required = (type === 'card');
            });
        });

        const procModal = new bootstrap.Modal(document.getElementById('paymentProcessingModal'), { backdrop: 'static', keyboard: false });
        const confirmModal = new bootstrap.Modal(document.getElementById('confirmPaymentModal'), { backdrop: 'static', keyboard: true });

        function normalizePhoneNumber(value) {
            if (!value) return '';
            return String(value).replace(/[^0-9+]/g, '').replace(/^\+255/, '0').replace(/^255/, '0');
        }

        function isTanzaniaPhoneNumber(value) {
            const cleaned = normalizePhoneNumber(value);
            if (!cleaned) return false;
            return /^(0(6[2-4]|6[5-8]|7[0-9]|7[5-9]|8[0-9]|9[0-9]))\d{7}$/.test(cleaned);
        }

        function getAllowedPrefixesForProvider(provider) {
            const map = {
                mpesa: ['075','076','078','079','062','063','064','065','067','068','074'],
                airtel: ['065','067','068'],
                mixx: ['065','067','068','075','076','078','079','074'],
                halopesa: ['074'],
            };
            return map[provider] || ['075','076','078','079','062','063','064','065','067','068','074'];
        }

        function validatePaymentDetails(provider, recipientNumber, customerPhone, senderPhone, confirmationCode) {
            const normalizedCustomerPhone = normalizePhoneNumber(customerPhone);
            const normalizedSenderPhone = normalizePhoneNumber(senderPhone);
            const normalizedRecipientPhone = normalizePhoneNumber(recipientNumber);
            if (!isTanzaniaPhoneNumber(normalizedCustomerPhone)) {
                return { valid: false, message: 'Please enter a valid Tanzanian phone number for the customer contact.' };
            }
            if (!confirmationCode || confirmationCode.length < 4) {
                return { valid: false, message: 'Please enter a payment confirmation PIN / OTP / password.' };
            }
            if (['mpesa', 'airtel', 'mixx', 'halopesa'].includes(provider)) {
                if (!isTanzaniaPhoneNumber(normalizedSenderPhone)) {
                    return { valid: false, message: 'Please enter a valid Tanzanian sender phone number for mobile money.' };
                }
                const prefixes = getAllowedPrefixesForProvider(provider);
                const matchesPrefix = prefixes.some(prefix => normalizedSenderPhone.startsWith(prefix));
                if (!matchesPrefix) {
                    return { valid: false, message: `Please use a Tanzanian number that matches ${provider.toUpperCase()} defaults such as 075..., 065..., 074..., or 067...` };
                }
                if (!isTanzaniaPhoneNumber(normalizedRecipientPhone)) {
                    return { valid: false, message: 'Please enter a valid Tanzanian recipient number for the receiver.' };
                }
                const recipientMatches = prefixes.some(prefix => normalizedRecipientPhone.startsWith(prefix));
                if (!recipientMatches) {
                    return { valid: false, message: 'The recipient number must also match a valid Tanzanian mobile prefix.' };
                }
            } else {
                if (!isTanzaniaPhoneNumber(normalizedRecipientPhone)) {
                    return { valid: false, message: 'Please enter a valid Tanzanian receiver number for the transaction.' };
                }
            }
            return { valid: true };
        }

        document.getElementById('cpPaymentForm').addEventListener('submit', function(e) {
            e.preventDefault();
            if (!isLoggedIn()) {
                showLoginRequired(() => { document.getElementById('cpPaymentForm').dispatchEvent(new Event('submit')); });
                return;
            }
            const roomId = parseInt(document.getElementById('cpBookingId').value);
            const room = roomsData.find(r => r.id === roomId);
            if (!room) {
                showToast('Please select a room first.', 'warning');
                return;
            }
            const customerName = document.getElementById('cpCustomerName').value.trim();
            const customerEmail = document.getElementById('cpCustomerEmail').value.trim();
            const customerPhone = document.getElementById('cpCustomerPhone').value.trim();
            const recipientNumber = document.getElementById('cpRecipientNumber').value.trim();
            if (!customerName || !customerEmail || !customerPhone || !recipientNumber) {
                showToast('Please fill in all customer details including Recipient Number.', 'warning');
                return;
            }
            const provider = document.getElementById('cpSelectedProvider').value;
            if (!provider) {
                showToast('Please select a payment method.', 'warning');
                return;
            }
            const senderPhone = document.getElementById('cpPhone').value.trim();
            const confirmationCode = document.getElementById('cpVerificationCode').value.trim();
            const validation = validatePaymentDetails(provider, recipientNumber, customerPhone, senderPhone, confirmationCode);
            if (!validation.valid) {
                showToast(validation.message, 'warning');
                return;
            }
            if (document.getElementById('cpMobileFields').classList.contains('show')) {
                const phone = senderPhone;
                if (!phone || !phone.match(/^[0-9]{9,15}$/)) {
                    showToast('Please enter a valid phone number for mobile money.', 'warning');
                    return;
                }
            }
            if (document.getElementById('cpCardFields').classList.contains('show')) {
                const card = document.getElementById('cpCardNumber').value.replace(/\s/g, '');
                if (!card.match(/^[0-9]{13,19}$/)) {
                    showToast('Please enter a valid card number.', 'warning');
                    return;
                }
                const expiry = document.getElementById('cpExpiry').value.trim();
                if (!expiry.match(/^(0[1-9]|1[0-2])\/[0-9]{2}$/)) {
                    showToast('Please enter expiry in MM/YY format.', 'warning');
                    return;
                }
                const cvv = document.getElementById('cpCvv').value.trim();
                if (!cvv.match(/^[0-9]{3,4}$/)) {
                    showToast('Please enter a valid CVV.', 'warning');
                    return;
                }
            }
            const amount = room.price;
            const customer = { name: customerName, email: customerEmail, phone: customerPhone, recipient: recipientNumber, senderPhone: senderPhone, confirmationCode: confirmationCode };
            startPaymentProcess(provider, amount, customer, room);
        });

        function startPaymentProcess(method, amount, customer, room) {
            document.getElementById('confirmAmount').textContent = `TSh ${amount.toLocaleString()}`;
            const methodNames = { mpesa: 'M-Pesa', airtel: 'Airtel Money', mixx: 'Mixx by Yas', halopesa: 'HaloPesa', visa: 'Visa', mastercard: 'Mastercard', paypal: 'PayPal' };
            document.getElementById('confirmMethod').textContent = methodNames[method] || method;
            window._currentPayment = { method, amount, customer, room };
            confirmModal.show();
        }

        document.getElementById('confirmPayBtn').addEventListener('click', function() {
            confirmModal.hide();
            const data = window._currentPayment;
            if (data) {
                processPayment(data.method, data.amount, data.customer, data.room);
            }
        });

        function processPayment(method, amount, customer, room) {
            const statusEl = document.getElementById('procStatus');
            const subEl = document.getElementById('procSub');
            const barEl = document.getElementById('procBar');
            const spinner = document.getElementById('procSpinner');
            const resultEl = document.getElementById('procResult');
            const resultIcon = document.getElementById('procResultIcon');
            const resultTitle = document.getElementById('procResultTitle');
            const resultSub = document.getElementById('procResultSub');

            resultEl.style.display = 'none';
            spinner.style.display = 'block';
            barEl.style.width = '0%';
            statusEl.textContent = 'Preparing Payment...';
            subEl.textContent = 'Please wait while we process your transaction.';
            procModal.show();

            const steps = [
                { pct: 10, status: 'Preparing Payment...', sub: 'Initializing secure connection...' },
                { pct: 25, status: 'Connecting to Payment Provider...', sub: 'Establishing secure channel...' },
                { pct: 45, status: 'Authorizing...', sub: 'Verifying your credentials...' },
                { pct: 65, status: 'Waiting for Sender Confirmation...', sub: 'Please confirm on your device...' },
                { pct: 80, status: 'Verifying Transaction...', sub: 'Checking transaction details...' },
                { pct: 95, status: 'Completing Payment...', sub: 'Finalizing your payment...' },
            ];
            let stepIndex = 0;

            function nextStep() {
                if (stepIndex < steps.length) {
                    const step = steps[stepIndex];
                    barEl.style.width = step.pct + '%';
                    statusEl.textContent = step.status;
                    subEl.textContent = step.sub;
                    stepIndex++;
                    setTimeout(nextStep, 600 + Math.random() * 400);
                } else {
                    // IMPORTANT: nothing above this point is a real payment
                    // confirmation - it is just a local progress animation
                    // while the customer's reference/confirmation code is
                    // sent to the server below. The result shown to the
                    // customer is decided entirely by the server's actual
                    // response, never assumed success in advance. The
                    // server itself always records this as 'pending' and
                    // only an Admin (checking the real mobile-money/bank
                    // statement) or a signed payment-provider webhook can
                    // ever move it to 'successful' - see
                    // PaymentController::verify()/webhook().
                    statusEl.textContent = 'Submitting Payment Reference...';
                    subEl.textContent = 'Sending your payment details for verification...';

                    const methodNames = { mpesa: 'M-Pesa', airtel: 'Airtel Money', mixx: 'Mixx by Yas', halopesa: 'HaloPesa', visa: 'Visa', mastercard: 'Mastercard', paypal: 'PayPal' };
                    const paymentRef = `TX-${String(Date.now()).slice(-6)}`;
                    const providerText = methodNames[method] || method;
                    const senderPhone = normalizePhoneNumber(customer.senderPhone || customer.phone);

                    const bookingData = {
                        room_id: room.id,
                        user_id: currentUser ? currentUser.id : null,
                        landlord_id: room.landlordId || null,
                        customer_name: customer.name,
                        customer_email: customer.email,
                        customer_phone: customer.phone,
                        amount: amount,
                        arrival_date: new Date(Date.now() + 7*24*60*60*1000).toISOString().split('T')[0],
                        payment_ref: paymentRef,
                        payment_method: providerText,
                        reference: paymentRef,
                        recipient_number: customer.recipient,
                    };

                    apiFetch('bookings', { method: 'POST', body: bookingData })
                        .then(bookingResult => {
                            barEl.style.width = '100%';
                            spinner.style.display = 'none';
                            resultEl.style.display = 'block';

                            if (bookingResult.success) {
                                // Server accepted the submission and is
                                // holding the room while it verifies the
                                // payment. This is NOT a success screen.
                                resultIcon.className = 'pm-result-icon pending';
                                resultIcon.innerHTML = '<i class="fas fa-hourglass-half"></i>';
                                resultTitle.textContent = 'Payment Submitted — Pending Verification';
                                resultSub.textContent = bookingResult.message || 'Your payment reference has been recorded and is awaiting verification. You will be notified once it is confirmed.';
                                statusEl.textContent = '⏳ Awaiting Payment Verification';
                                subEl.textContent = `Reference ${paymentRef} sent for verification.`;

                                const smsMessage = `Smart Rent: we received your payment reference ${paymentRef} for TSh ${amount.toLocaleString()}. It is pending verification - we'll notify you once confirmed.`;
                                apiFetch('sms', {
                                    method: 'POST',
                                    body: {
                                        to: senderPhone || customer.phone,
                                        message: smsMessage,
                                        provider: method === 'mpesa' ? 'africastalking' : 'twilio',
                                    }
                                })
                                    .then(() => {
                                        showToast(`📱 Confirmation SMS sent to ${senderPhone || customer.phone}.`, 'info');
                                    })
                                    .catch(err => {
                                        showToast(`⚠️ SMS gateway could not deliver the confirmation message: ${err.message}`, 'warning');
                                    });

                                showToast(`🔔 Room "${room.title}" is being held while your payment is verified.`, 'info');
                                showToast(`⏳ ${customer.name}, your payment reference has been submitted for verification.`, 'success');
                                Promise.all([applyFilters(), fetchBookings(), fetchOrders(), fetchPaymentHistory()])
                                    .then(() => {
                                        renderBookingsOrders();
                                        renderAdminRoomList();
                                        updateAdminStats();
                                        updatePaymentDashboard();
                                        renderPaymentHistory();
                                        if (isLandlord()) renderLandlordBookingsOrders();
                                        renderReports();
                                        clearPaymentSelection();
                                        setTimeout(() => {
                                            document.getElementById('receiptPreview').scrollIntoView({ behavior: 'smooth', block: 'center' });
                                        }, 500);
                                    });
                            } else {
                                showToast('Transaction failed: ' + (bookingResult.error || bookingResult.message || 'Unknown error') + '. The room remains available.', 'error');
                                resultIcon.className = 'pm-result-icon failed';
                                resultIcon.innerHTML = '<i class="fas fa-times-circle"></i>';
                                resultTitle.textContent = 'Transaction Failed';
                                resultSub.textContent = 'The room remains available. No charge was completed.';
                                statusEl.textContent = '❌ Transaction Failed';
                                subEl.textContent = 'The room remains available.';
                            }
                            document.getElementById('procModalClose').disabled = false;
                        })
                        .catch(err => {
                            barEl.style.width = '100%';
                            spinner.style.display = 'none';
                            resultEl.style.display = 'block';
                            showToast('❌ ' + err.message, 'error');
                            resultIcon.className = 'pm-result-icon failed';
                            resultIcon.innerHTML = '<i class="fas fa-times-circle"></i>';
                            resultTitle.textContent = 'Transaction Failed';
                            resultSub.textContent = err.message + ' The room remains available.';
                            statusEl.textContent = '❌ Transaction Failed';
                            subEl.textContent = err.message;
                            applyFilters();
                            document.getElementById('procModalClose').disabled = false;
                        });
                }
            }
            document.getElementById('procModalClose').disabled = true;
            nextStep();
        }

        function getVisiblePayments() {
            if (!Array.isArray(paymentHistory)) return [];
            if (!currentUser || isAdmin()) return paymentHistory;
            const currentEmail = (currentUser.email || '').trim().toLowerCase();
            const currentName = (currentUser.name || '').trim().toLowerCase();
            const currentId = String(currentUser.id || '');
            return paymentHistory.filter(tx => {
                const txEmail = (tx.customer_email || '').trim().toLowerCase();
                const txName = (tx.customer_name || '').trim().toLowerCase();
                const txId = String(tx.user_id || tx.customer_id || '');
                return txEmail === currentEmail || txName === currentName || txId === currentId;
            });
        }

        function getLatestSuccessfulReceipt() {
            return getVisiblePayments().find(tx => tx.status === 'successful') || null;
        }

        function renderPaymentHistory() {
            const tbody = document.getElementById('paymentHistoryBody');
            if (!tbody) return;
            const visiblePayments = getVisiblePayments();
            if (visiblePayments.length === 0) {
                tbody.innerHTML = `<tr><td colspan="9" style="text-align:center;color:var(--text-muted);padding:24px 0;">No payment history yet.</td></tr>`;
                return;
            }
            tbody.innerHTML = visiblePayments.map(tx => {
                const statusClass = tx.status === 'successful' ? 'success' : tx.status === 'failed' ? 'danger' : tx.status === 'cancelled' ? 'secondary' : 'warning';
                const statusLabel = tx.status.charAt(0).toUpperCase() + tx.status.slice(1);
                // Only an Admin can verify a pending payment (mirrors the
                // server-side check in PaymentController::verify() - these
                // buttons are just a shortcut into that same endpoint, the
                // authorization is enforced server-side regardless).
                const verifyActions = (isAdmin() && tx.status === 'pending') ? `
                        <button class="btn-receipt" style="background:var(--green);color:#fff;" onclick="verifyPaymentAction(${tx.id}, 'successful')"><i class="fas fa-check"></i> Confirm</button>
                        <button class="btn-receipt" style="background:var(--red);color:#fff;" onclick="verifyPaymentAction(${tx.id}, 'failed')"><i class="fas fa-times"></i> Reject</button>
                    ` : '';
                return `
                    <tr>
                        <td><strong>${escapeHtml(tx.reference)}</strong></td>
                        <td>${escapeHtml(tx.customer_name)}</td>
                        <td>${escapeHtml(tx.recipient_number) || '—'}</td>
                        <td>${escapeHtml(tx.room_name) || '—'}</td>
                        <td>${escapeHtml(tx.payment_method)}</td>
                        <td>TSh ${tx.amount.toLocaleString()}</td>
                        <td>${new Date(tx.created_at).toLocaleDateString()}</td>
                        <td><span class="status-badge-sm ${statusClass}">${statusLabel}</span></td>
                        <td><button class="btn-receipt" onclick="viewReceiptById(${tx.id})"><i class="fas fa-receipt"></i> View</button>${verifyActions}</td>
                    </tr>
                `;
            }).join('');
        }

        /**
         * Admin-only: confirm or reject a pending payment against
         * PUT /payments/{id}/verify - the same endpoint
         * PaymentController::verify() exposes. This is the real,
         * server-side genuine-verification step; nothing about a payment's
         * status is ever decided purely in the browser.
         */
        function verifyPaymentAction(paymentId, status) {
            const label = status === 'successful' ? 'confirm this payment as successful' : 'reject this payment as failed';
            if (!confirm(`Are you sure you want to ${label}? This cannot be undone.`)) return;
            apiFetch(`payments/${paymentId}/verify`, { method: 'PUT', body: { status } })
                .then(result => {
                    if (result && result.success) {
                        showToast(status === 'successful' ? '✅ Payment confirmed. Room marked as taken.' : '❌ Payment rejected. Room released back to available.', 'success');
                        Promise.all([applyFilters(), fetchBookings(), fetchOrders(), fetchPaymentHistory()])
                            .then(() => {
                                renderBookingsOrders();
                                renderAdminRoomList();
                                updateAdminStats();
                                updatePaymentDashboard();
                                renderPaymentHistory();
                                renderReports();
                            });
                    } else {
                        showToast('Error: ' + (result && (result.error || result.message) || 'Verification failed'), 'error');
                    }
                })
                .catch(err => showToast('❌ ' + err.message, 'error'));
        }

        function viewReceiptById(id) {
            const tx = getVisiblePayments().find(p => p.id === id) || paymentHistory.find(p => p.id === id);
            if (!tx) { showToast('Transaction not found.', 'error'); return; }
            updateReceiptPreview(tx);
            document.getElementById('receiptPreview').scrollIntoView({ behavior: 'smooth', block: 'center' });
            showToast(`📄 Receipt for ${tx.reference} loaded`, 'info');
        }

        function viewReceipt(ref) {
            const tx = getVisiblePayments().find(p => p.reference === ref) || paymentHistory.find(p => p.reference === ref);
            if (!tx) { showToast('Transaction not found.', 'error'); return; }
            updateReceiptPreview(tx);
            document.getElementById('receiptPreview').scrollIntoView({ behavior: 'smooth', block: 'center' });
            showToast(`📄 Receipt for ${ref} loaded`, 'info');
        }

        function updateReceiptPreview(paymentData) {
            const preview = document.getElementById('receiptPreview');
            if (!preview) return;

            if (!paymentData || paymentData.status !== 'successful') {
                preview.innerHTML = `
                    <div style="padding:24px 20px;border:1px dashed var(--border-color);border-radius:16px;text-align:center;color:var(--text-secondary);background:var(--bg-main);">
                        <i class="fas fa-receipt" style="font-size:32px;color:var(--gold);margin-bottom:10px;display:block;"></i>
                        <div style="font-weight:700;color:var(--text-primary);margin-bottom:6px;">No receipt available yet</div>
                        <div style="font-size:14px;">Your receipt will appear here after a successful booking payment.</div>
                    </div>
                    <div class="rp-footer" style="margin-top:16px;justify-content:flex-end;">
                        <div class="rp-actions">
                            <button class="btn-print" id="btnPrintReceipt" disabled style="opacity:0.6;cursor:not-allowed;"><i class="fas fa-print"></i> Print</button>
                            <button class="btn-download" id="btnDownloadReceipt" disabled style="opacity:0.6;cursor:not-allowed;"><i class="fas fa-download"></i> Download</button>
                        </div>
                    </div>`;
                return;
            }

            preview.innerHTML = `
                <div class="rp-header">
                    <div class="rp-brand">Smart<span>Rent</span></div>
                    <span class="rp-badge"><i class="fas fa-check-circle"></i> PAID</span>
                </div>
                <div class="rp-body">
                    <div class="rp-item"><span class="rp-label">Receipt #</span><span class="rp-value" id="rpReceiptNo">RCP-${escapeHtml(String(paymentData.reference).slice(-6))}</span></div>
                    <div class="rp-item"><span class="rp-label">Transaction Ref</span><span class="rp-value" id="rpTxRef">${escapeHtml(paymentData.reference)}</span></div>
                    <div class="rp-item"><span class="rp-label">Booking #</span><span class="rp-value" id="rpBookingNo">BK-${escapeHtml(paymentData.id) || '000'}</span></div>
                    <div class="rp-item"><span class="rp-label">Tenant</span><span class="rp-value" id="rpTenant">${escapeHtml(paymentData.customer_name) || '—'}</span></div>
                    <div class="rp-item"><span class="rp-label">Email</span><span class="rp-value" id="rpEmail">${escapeHtml(paymentData.customer_email) || '—'}</span></div>
                    <div class="rp-item"><span class="rp-label">Phone</span><span class="rp-value" id="rpPhone">${escapeHtml(paymentData.customer_phone) || '—'}</span></div>
                    <div class="rp-item"><span class="rp-label">Recipient</span><span class="rp-value" id="rpRecipient">${escapeHtml(paymentData.recipient_number) || '—'}</span></div>
                    <div class="rp-item"><span class="rp-label">Room</span><span class="rp-value" id="rpRoom">${escapeHtml(paymentData.room_name) || '—'}</span></div>
                    <div class="rp-item"><span class="rp-label">Apartment</span><span class="rp-value" id="rpApartment">${escapeHtml(paymentData.room_name || 'Room')} Apartments</span></div>
                    <div class="rp-item"><span class="rp-label">Landlord</span><span class="rp-value" id="rpLandlord">Mr. Joseph</span></div>
                    <div class="rp-item"><span class="rp-label">Location</span><span class="rp-value" id="rpLocation">${escapeHtml(paymentData.location) || 'Dar es Salaam'}</span></div>
                    <div class="rp-item"><span class="rp-label">Payment Method</span><span class="rp-value" id="rpMethod">${escapeHtml(paymentData.payment_method) || '—'}</span></div>
                    <div class="rp-item"><span class="rp-label">Amount Paid</span><span class="rp-value" id="rpAmount" style="font-weight:800;color:var(--gold);">TSh ${Number(paymentData.amount || 0).toLocaleString()}</span></div>
                    <div class="rp-item"><span class="rp-label">Date</span><span class="rp-value" id="rpDate">${new Date(paymentData.created_at).toLocaleDateString()}</span></div>
                    <div class="rp-item"><span class="rp-label">Status</span><span class="rp-value" style="color:var(--green);font-weight:700;" id="rpStatus">Successful</span></div>
                </div>
                <div class="rp-footer">
                    <div class="rp-qr"><i class="fas fa-qrcode"></i></div>
                    <div class="rp-actions">
                        <button class="btn-print" id="btnPrintReceipt"><i class="fas fa-print"></i> Print</button>
                        <button class="btn-download" id="btnDownloadReceipt"><i class="fas fa-download"></i> Download</button>
                    </div>
                </div>`;
        }

        function updatePaymentDashboard() {
            const visiblePayments = getVisiblePayments();
            const totalPayable = roomsData.reduce((sum, r) => sum + (r.status === 'booked' || r.status === 'ordered' ? r.price : 0), 0);
            const pending = roomsData.filter(r => r.status === 'ordered').length;
            const completed = visiblePayments.filter(p => p.status === 'successful').length;
            const failed = visiblePayments.filter(p => p.status === 'failed').length;
            document.getElementById('totalPayable').textContent = `TSh ${totalPayable.toLocaleString()}`;
            document.getElementById('pendingPayments').textContent = pending;
            document.getElementById('completedPayments').textContent = completed;
            document.getElementById('failedPayments').textContent = failed;
            const lastTx = visiblePayments.length > 0 ? visiblePayments[0] : null;
            document.getElementById('lastPaymentDate').textContent = lastTx ? new Date(lastTx.created_at).toLocaleDateString() : '—';
            const bookedOrOrdered = roomsData.filter(r => r.status === 'booked' || r.status === 'ordered');
            const displayRoom = bookedOrOrdered.length > 0 ? bookedOrOrdered[0] : roomsData[0];
            document.getElementById('selectedBooking').textContent = displayRoom ? displayRoom.title : '—';
            if (displayRoom) {
                document.getElementById('bookingRefDisplay').textContent = `Ref: BK-${String(displayRoom.id).padStart(6, '0')}`;
                document.getElementById('bsRoomImg').src = normalizeImageSrc(parsePropertyImages(displayRoom.image)[0]) || 'https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?w=240&h=240&fit=crop&crop=center';
                document.getElementById('bsRoomName').textContent = displayRoom.title;
                document.getElementById('bsApartment').textContent = `${displayRoom.title} Apartments`;
                document.getElementById('bsLandlord').textContent = 'Mr. Joseph';
                const parts = displayRoom.location.split(', ');
                document.getElementById('bsRegion').textContent = parts[0] || '—';
                document.getElementById('bsDistrict').textContent = parts[1] || '—';
                document.getElementById('bsStreet').textContent = `${parts[1] || '—'} St.`;
                document.getElementById('bsSize').textContent = `${displayRoom.size} sqft`;
                document.getElementById('bsDuration').textContent = '12 months';
                document.getElementById('bsMonthly').textContent = `TSh ${Number(displayRoom.price||0).toLocaleString()}`;
                document.getElementById('bsDeposit').textContent = `TSh ${(Number(displayRoom.price||0) * 0.5).toLocaleString()}`;
                document.getElementById('bsService').textContent = `TSh ${(Number(displayRoom.price||0) * 0.05).toLocaleString()}`;
                document.getElementById('bsDiscount').textContent = 'TSh 0';
                const dp = Number(displayRoom.price || 0);
                const total = dp + (dp * 0.5) + (dp * 0.05);
                document.getElementById('bsTotal').textContent = `TSh ${total.toLocaleString()}`;
            }
            if (lastTx && lastTx.status === 'successful') updateReceiptPreview(lastTx);
            else updateReceiptPreview(null);

            // NEW COUNTS
            const completedBookings = bookingRecords.filter(b => b.status === 'confirmed' || b.status === 'completed').length;
            const totalOrders = orderRecords.length;
            const cancelledPayments = visiblePayments.filter(p => p.status === 'cancelled' || p.status === 'failed').length;
            document.getElementById('completedBookings').textContent = completedBookings;
            document.getElementById('totalOrders').textContent = totalOrders;
            document.getElementById('cancelledPayments').textContent = cancelledPayments;
        }

        document.getElementById('btnPrintReceipt').addEventListener('click', function() {
            const printContent = document.getElementById('receiptPreview').cloneNode(true);
            const win = window.open('', '', 'width=600,height=600');
            win.document.write(`
                <html><head><title>Receipt</title>
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
                <style>
                    body { font-family: 'Inter', sans-serif; padding: 40px; background: #fff; }
                    .receipt-preview { max-width: 540px; margin: 0 auto; }
                    ${document.querySelector('style').innerHTML}
                </style>
                </head><body>
                ${printContent.outerHTML}
                <script>window.onload = function() { window.print(); window.close(); }<\/script>
                </body></html>
            `);
            win.document.close();
        });

        document.getElementById('btnDownloadReceipt').addEventListener('click', function() {
            const content = document.getElementById('receiptPreview').cloneNode(true);
            const html = `
                <html><head><title>Receipt</title>
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
                <style>
                    body { font-family: 'Inter', sans-serif; padding: 40px; background: #fff; }
                    .receipt-preview { max-width: 540px; margin: 0 auto; }
                    ${document.querySelector('style').innerHTML}
                </style>
                </head><body>
                ${content.outerHTML}
                </body></html>
            `;
            const blob = new Blob([html], { type: 'text/html' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `receipt-${Date.now()}.html`;
            a.click();
            URL.revokeObjectURL(url);
            showToast('📥 Receipt downloaded!', 'success');
        });

        // ========== LANDLORD ==========
        function savePropertyDraft() {
            const draft = {
                name: document.getElementById('propName').value,
                type: document.getElementById('propType').value,
                listingPurpose: document.getElementById('propListingPurpose').value,
                apartment: document.getElementById('propApartment').value,
                houseNo: document.getElementById('propHouseNo').value,
                region: document.getElementById('propRegion').value,
                district: document.getElementById('propDistrict').value,
                ward: document.getElementById('propWard').value,
                street: document.getElementById('propStreet').value,
                location: document.getElementById('propLocation').value,
                coords: document.getElementById('propCoords').value,
                description: document.getElementById('propDescription').value,
                bedrooms: document.getElementById('propBedrooms').value,
                bathrooms: document.getElementById('propBathrooms').value,
                kitchen: document.getElementById('propKitchen').checked,
                parking: document.getElementById('propParking').checked,
                wifi: document.getElementById('propWifi').checked,
                water: document.getElementById('propWater').checked,
                electricity: document.getElementById('propElectricity').checked,
                security: document.getElementById('propSecurity').checked,
                furnished: document.getElementById('propFurnished').value,
                roomSize: document.getElementById('propRoomSize').value,
                monthlyRent: document.getElementById('propMonthlyRent').value,
                deposit: document.getElementById('propDeposit').value,
                serviceCharge: document.getElementById('propServiceCharge').value,
                availability: document.getElementById('propAvailability').value,
                video: document.getElementById('propVideo').value,
                virtualTour: document.getElementById('propVirtualTour').value
            };
            localStorage.setItem('smartrent_property_draft', JSON.stringify(draft));
            showToast('📝 Draft saved locally. You can restore it later.', 'info');
        }

        function restorePropertyDraft() {
            const saved = localStorage.getItem('smartrent_property_draft');
            if (!saved) return;
            try {
                const draft = JSON.parse(saved);
                document.getElementById('propName').value = draft.name || '';
                document.getElementById('propType').value = draft.type || 'Apartment';
                document.getElementById('propListingPurpose').value = draft.listingPurpose || 'rental';
                document.getElementById('propApartment').value = draft.apartment || '';
                document.getElementById('propHouseNo').value = draft.houseNo || '';
                document.getElementById('propRegion').value = draft.region || 'Dar es Salaam';
                document.getElementById('propDistrict').value = draft.district || '';
                document.getElementById('propWard').value = draft.ward || '';
                document.getElementById('propStreet').value = draft.street || '';
                document.getElementById('propLocation').value = draft.location || '';
                document.getElementById('propCoords').value = draft.coords || '';
                document.getElementById('propDescription').value = draft.description || '';
                document.getElementById('propBedrooms').value = draft.bedrooms || '';
                document.getElementById('propBathrooms').value = draft.bathrooms || '';
                document.getElementById('propKitchen').checked = Boolean(draft.kitchen);
                document.getElementById('propParking').checked = Boolean(draft.parking);
                document.getElementById('propWifi').checked = Boolean(draft.wifi);
                document.getElementById('propWater').checked = Boolean(draft.water);
                document.getElementById('propElectricity').checked = Boolean(draft.electricity);
                document.getElementById('propSecurity').checked = Boolean(draft.security);
                document.getElementById('propFurnished').value = draft.furnished || 'Unfurnished';
                document.getElementById('propRoomSize').value = draft.roomSize || '';
                document.getElementById('propMonthlyRent').value = draft.monthlyRent || '';
                document.getElementById('propDeposit').value = draft.deposit || '';
                document.getElementById('propServiceCharge').value = draft.serviceCharge || '';
                document.getElementById('propAvailability').value = draft.availability || 'available';
                document.getElementById('propVideo').value = draft.video || '';
                document.getElementById('propVirtualTour').value = draft.virtualTour || '';
                showToast('📝 Draft restored. Re-select images if needed.', 'info');
            } catch (e) {
                localStorage.removeItem('smartrent_property_draft');
            }
        }

        function clearPropertyDraft() {
            localStorage.removeItem('smartrent_property_draft');
        }

        function updateLandlordDateTime() {
            const now = new Date();
            const opts = { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' };
            const text = now.toLocaleDateString('en-US', opts);
            const el = document.getElementById('landlordDateTime');
            if (el) el.textContent = text;
            // Same clock element also lives on the Admin Panel's hero
            // banner - keep both dashboards' headers in sync from one timer.
            const adminEl = document.getElementById('adminDateTime');
            if (adminEl) adminEl.textContent = text;
        }
        setInterval(updateLandlordDateTime, 1000);

        document.querySelectorAll('#landlordPropertyForm input, #landlordPropertyForm textarea, #landlordPropertyForm select').forEach(el => {
            el.addEventListener('input', savePropertyDraft);
            el.addEventListener('change', savePropertyDraft);
        });

        document.getElementById('propImages').addEventListener('change', function(e) {
            const preview = document.getElementById('propImagePreview');
            preview.innerHTML = '';
            const files = e.target.files;
            for (let i = 0; i < Math.min(files.length, 6); i++) {
                const reader = new FileReader();
                reader.onload = function(ev) {
                    const img = document.createElement('img');
                    img.src = ev.target.result;
                    preview.appendChild(img);
                };
                reader.readAsDataURL(files[i]);
            }
        });

        document.getElementById('propImageArea').addEventListener('click', function() {
            document.getElementById('propImages').click();
        });

        // 360° panorama file preview - shows the picked image and its
        // filename immediately, and lets the user clear it, so it never
        // looks like the selection silently "didn't upload".
        document.getElementById('propVirtualTourFile').addEventListener('change', function(e) {
            const file = e.target.files[0];
            let preview = document.getElementById('propVirtualTourPreview');
            if (!preview) {
                preview = document.createElement('div');
                preview.id = 'propVirtualTourPreview';
                preview.style.cssText = 'margin-top:8px;display:flex;align-items:center;gap:10px;';
                e.target.insertAdjacentElement('afterend', preview);
            }
            preview.innerHTML = '';
            if (!file) return;

            const reader = new FileReader();
            reader.onload = function(ev) {
                preview.innerHTML = `
                    <img src="${ev.target.result}" alt="360° tour preview" style="width:64px;height:64px;object-fit:cover;border-radius:10px;border:1px solid var(--border-color);">
                    <span style="font-size:12px;color:var(--text-secondary);">${escapeHtml(file.name)} selected — will upload with this property.</span>
                    <button type="button" id="propVirtualTourClearBtn" style="border:none;background:none;color:var(--red);cursor:pointer;font-size:12px;text-decoration:underline;">Remove</button>
                `;
                document.getElementById('propVirtualTourClearBtn').addEventListener('click', function() {
                    document.getElementById('propVirtualTourFile').value = '';
                    preview.innerHTML = '';
                });
            };
            reader.readAsDataURL(file);
        });

        // ============================================================
        // LANDLORD PROPERTY SUBMIT – with loading state and image handling
        // ============================================================
        document.getElementById('landlordPropertyForm').addEventListener('submit', function(e) {
            e.preventDefault();
            if (!isLandlord()) {
                showToast('Please login as a landlord first.', 'warning');
                return;
            }

            const uploadBtn = document.getElementById('uploadPropertyBtn');
            uploadBtn.disabled = true;
            uploadBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Uploading...';
            uploadBtn.classList.add('btn-upload-loading');

            const propName = document.getElementById('propName').value.trim();

            // Show the property in "My Properties" the moment you click
            // Upload - don't wait on the network round trip first. The
            // thumbnails in #propImagePreview are already rendered data:
            // URLs from the file picker's 'change' handler above, so we
            // reuse them directly; normalizeImageSrc()/parsePropertyImages()
            // already pass data: URLs straight through unchanged. This temp
            // card is replaced by the real, server-persisted property a
            // moment later once the upload confirms - it's a preview, not a
            // substitute for saving to the DB.
            const tempId = 'temp-' + Date.now();
            const previewImages = Array.from(document.querySelectorAll('#propImagePreview img')).map(img => img.src);
            const optimisticProperty = {
                id: tempId,
                landlord_id: currentUser.id,
                name: propName,
                type: document.getElementById('propType').value,
                listing_purpose: document.getElementById('propListingPurpose').value,
                location: document.getElementById('propLocation').value.trim(),
                region: document.getElementById('propRegion').value,
                district: document.getElementById('propDistrict').value.trim(),
                monthly_rent: parseFloat(document.getElementById('propMonthlyRent').value) || 0,
                availability: document.getElementById('propAvailability').value,
                images: previewImages,
                _optimistic: true
            };
            landlordProperties = [optimisticProperty, ...landlordProperties];
            renderLandlordProperties();

            const fd = new FormData();
            fd.append('name', propName);
            fd.append('type', document.getElementById('propType').value);
            fd.append('listing_purpose', document.getElementById('propListingPurpose').value);
            fd.append('apartment', document.getElementById('propApartment').value.trim());
            fd.append('houseNo', document.getElementById('propHouseNo').value.trim());
            fd.append('region', document.getElementById('propRegion').value);
            fd.append('district', document.getElementById('propDistrict').value.trim());
            fd.append('ward', document.getElementById('propWard').value.trim());
            fd.append('street', document.getElementById('propStreet').value.trim());
            fd.append('location', document.getElementById('propLocation').value.trim());
            fd.append('coords', document.getElementById('propCoords').value.trim());
            fd.append('description', document.getElementById('propDescription').value.trim());
            fd.append('bedrooms', parseInt(document.getElementById('propBedrooms').value) || 0);
            fd.append('bathrooms', parseInt(document.getElementById('propBathrooms').value) || 0);
            fd.append('amenities', JSON.stringify({
                kitchen: document.getElementById('propKitchen').checked,
                parking: document.getElementById('propParking').checked,
                wifi: document.getElementById('propWifi').checked,
                water: document.getElementById('propWater').checked,
                electricity: document.getElementById('propElectricity').checked,
                security: document.getElementById('propSecurity').checked
            }));
            fd.append('furnished', document.getElementById('propFurnished').value);
            fd.append('roomSize', parseFloat(document.getElementById('propRoomSize').value) || 0);
            fd.append('monthlyRent', parseFloat(document.getElementById('propMonthlyRent').value) || 0);
            fd.append('deposit', parseFloat(document.getElementById('propDeposit').value) || 0);
            fd.append('serviceCharge', parseFloat(document.getElementById('propServiceCharge').value) || 0);
            fd.append('availability', document.getElementById('propAvailability').value);
            fd.append('video', document.getElementById('propVideo').value.trim());
            fd.append('virtualTour', document.getElementById('propVirtualTour').value.trim());
            const tourFile = document.getElementById('propVirtualTourFile').files[0];
            if (tourFile) fd.append('virtualTourImage', tourFile);
            fd.append('landlord_id', currentUser.id);

            const imageFiles = document.getElementById('propImages').files;
            for (let i = 0; i < imageFiles.length; i++) {
                fd.append('images[]', imageFiles[i]);
            }

            apiFetch('properties', { method: 'POST', body: fd })
                .then(result => {
                    if (result.success) {
                        this.reset();
                        document.getElementById('propImagePreview').innerHTML = '';
                        const tourPreview = document.getElementById('propVirtualTourPreview');
                        if (tourPreview) tourPreview.innerHTML = '';
                        clearPropertyDraft();
                        // Replace the temp preview card with the real,
                        // server-persisted list (real id, real uploads/ paths).
                        return fetchLandlordProperties().then(() => {
                            renderLandlordProperties();
                            applyFilters();
                            showToast('✅ Property uploaded and room created!', 'success');
                        });
                    } else {
                        // Upload failed - remove the temp preview card so
                        // nothing is left on screen that wasn't actually saved.
                        landlordProperties = landlordProperties.filter(p => p.id !== tempId);
                        renderLandlordProperties();
                        showToast('❌ ' + result.message, 'error');
                    }
                })
                .catch(err => {
                    landlordProperties = landlordProperties.filter(p => p.id !== tempId);
                    renderLandlordProperties();
                    showToast('Error: ' + err.message, 'error');
                })
                .finally(() => {
                    uploadBtn.disabled = false;
                    uploadBtn.innerHTML = '<i class="fas fa-cloud-upload-alt"></i> Upload';
                    uploadBtn.classList.remove('btn-upload-loading');
                });
        });

        function renderLandlordProperties() {
            const container = document.getElementById('landlordPropertyList');
            if (!container) return;
            const myProps = landlordProperties.filter(p => String(p.landlord_id) === String(currentUser ? currentUser.id : -1));
            updateLandlordPortfolioStats(myProps);
            if (myProps.length === 0) {
                container.innerHTML = `<p style="grid-column:1/-1;color:var(--text-secondary);text-align:center;padding:30px 0;">You haven't uploaded any properties yet.</p>`;
                return;
            }
            container.innerHTML = myProps.map(p => {
                const images = parsePropertyImages(p.images);
                const img = images.length > 0 ? normalizeImageSrc(images[0]) : 'https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?w=400&h=300&fit=crop';
                return `
                    <div class="landlord-property-card" style="${p._optimistic ? 'opacity:0.65;' : ''}">
                        <img src="${img}" alt="${escapeHtml(p.name)}">
                        <div class="prop-title">${escapeHtml(p.name)}</div>
                        ${p.house_id ? `<div class="prop-location" style="font-family:monospace;"><i class="fas fa-fingerprint"></i> ${escapeHtml(p.house_id)}</div>` : ''}
                        <div class="prop-location"><i class="fas fa-map-pin"></i> ${escapeHtml(p.location) || escapeHtml(p.region)}, ${escapeHtml(p.district)}</div>
                        <div class="prop-price">TSh ${(p.monthly_rent || 0).toLocaleString()} / month</div>
                        <span style="display:inline-block;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:700;color:#fff;background:${p.listing_purpose === 'holiday' ? '#0891b2' : '#6d28d9'};margin-bottom:6px;">${p.listing_purpose === 'holiday' ? 'Holiday' : 'Rental'}</span>
                        ${p._optimistic
                            ? `<span class="prop-status available"><i class="fas fa-spinner fa-spin"></i> Saving...</span>`
                            : `<span class="prop-status ${p.availability || 'available'}">${(p.availability || 'available').charAt(0).toUpperCase() + (p.availability || 'available').slice(1)}</span>
                        <div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap;">
                            <button class="btn-details" style="padding:4px 12px;border:1px solid var(--border-color);border-radius:8px;background:var(--bg-main);color:var(--text-primary);cursor:pointer;" onclick="viewPropertyDetails(${JSON.stringify(p.house_id || '')}, ${JSON.stringify(p.name || '')})">View</button>
                            <button class="btn-details" style="padding:4px 12px;border:1px solid var(--border-color);border-radius:8px;background:var(--bg-main);color:var(--text-primary);cursor:pointer;" onclick="openImageManager('property', ${p.id})"><i class="fas fa-images"></i> Images</button>
                            <button class="btn-details" style="padding:4px 12px;border:1px solid var(--border-color);border-radius:8px;background:var(--bg-main);color:var(--text-primary);cursor:pointer;" onclick="openTourManager('property', ${p.id}, ${JSON.stringify(p.name)})"><i class="fas fa-street-view"></i> 360° Virtual Tour</button>
                            <button class="btn-delete" style="padding:4px 12px;border:none;border-radius:8px;background:var(--red);color:#fff;cursor:pointer;font-weight:600;" onclick="deleteLandlordProperty(${p.id})">Delete</button>
                        </div>`}
                    </div>
                `;
            }).join('');
        }

        /**
         * Updates the "Your Portfolio at a Glance" stat cards on the
         * Landlord Dashboard from whatever property list we currently have
         * client-side - mirrors the Admin Panel's live stat cards so both
         * dashboards feel like one consistent, professional product.
         */
        function updateLandlordPortfolioStats(myProps) {
            const totalEl = document.getElementById('lpTotalProperties');
            if (!totalEl) return; // Landlord dashboard not in the DOM yet.
            const real = myProps.filter(p => !p._optimistic);
            const available = real.filter(p => (p.availability || 'available') === 'available').length;
            const booked = real.filter(p => p.availability === 'booked').length;
            const taken = real.filter(p => p.availability === 'taken').length;
            const rentTotal = real.reduce((sum, p) => sum + (Number(p.monthly_rent) || 0), 0);

            totalEl.textContent = myProps.length;
            document.getElementById('lpAvailableProperties').textContent = available;
            document.getElementById('lpBookedProperties').textContent = booked;
            document.getElementById('lpTakenProperties').textContent = taken;
            document.getElementById('lpMonthlyRentTotal').textContent = 'TSh ' + rentTotal.toLocaleString();
        }

        function showPropertyToast(id) {
            const prop = landlordProperties.find(p => p.id === id);
            showToast('📋 Details for ' + (prop ? prop.name : 'property'), 'info');
        }

        function deleteLandlordProperty(id) {
            if (!isLandlord()) { showToast('Please login as a landlord.', 'warning'); return; }
            const prop = landlordProperties.find(p => p.id === id);
            if (!prop) return;
            if (confirm(`Delete "${prop.name}"?`)) {
                apiFetch('properties/' + id, { method: 'DELETE' })
                    .then(() => {
                        fetchLandlordProperties().then(() => {
                            renderLandlordProperties();
                            applyFilters();
                            showToast(`🗑️ "${prop.name}" deleted.`, 'success');
                        });
                    })
                    .catch(err => showToast('Error: ' + err.message, 'error'));
            }
        }

        // ========== SETTINGS: NOTIFICATIONS ==========
        function toggleNotification() {
            const toggle = document.getElementById('notifToggle');
            toggle.classList.toggle('active');
            const isOn = toggle.classList.contains('active');
            showToast(isOn ? '🔔 Notifications enabled' : '🔕 Notifications disabled', 'info');
            localStorage.setItem('smartrent_notif_enabled', isOn ? 'true' : 'false');
        }

        function toggleEmailNotifications() {
            const toggle = document.getElementById('emailToggle');
            toggle.classList.toggle('active');
            const isOn = toggle.classList.contains('active');
            showToast(isOn ? '📧 Email updates enabled' : '📧 Email updates disabled', 'info');
            localStorage.setItem('smartrent_email_enabled', isOn ? 'true' : 'false');
        }

        (function() {
            const notifState = localStorage.getItem('smartrent_notif_enabled');
            if (notifState === 'false') {
                const toggle = document.getElementById('notifToggle');
                if (toggle) toggle.classList.remove('active');
            }
            const emailState = localStorage.getItem('smartrent_email_enabled');
            if (emailState === 'false') {
                const toggle = document.getElementById('emailToggle');
                if (toggle) toggle.classList.remove('active');
            }
        })();

        // ========== SIDEBAR TOGGLE ==========
        function toggleMobileSidebar() {
            sidebar.classList.toggle('mobile-open');
            sidebarOverlay.classList.toggle('open');
            document.body.style.overflow = sidebar.classList.contains('mobile-open') ? 'hidden' : '';
        }
        mobileToggle.addEventListener('click', toggleMobileSidebar);
        sidebarOverlay.addEventListener('click', function() {
            sidebar.classList.remove('mobile-open');
            sidebarOverlay.classList.remove('open');
            document.body.style.overflow = '';
        });
        window.addEventListener('resize', function() {
            if (window.innerWidth > 768) {
                sidebar.classList.remove('mobile-open');
                sidebarOverlay.classList.remove('open');
                document.body.style.overflow = '';
            }
        });

        // ========== VIEW TOGGLES ==========
        gridViewBtn.addEventListener('click', function() {
            isGridView = true;
            gridViewBtn.classList.add('active');
            listViewBtn.classList.remove('active');
            renderRooms();
        });
        listViewBtn.addEventListener('click', function() {
            isGridView = false;
            listViewBtn.classList.add('active');
            gridViewBtn.classList.remove('active');
            renderRooms();
        });

        // ========== AVATAR CLICK LOGOUT ==========
        document.getElementById('userAvatar').addEventListener('click', function() {
            if (isLoggedIn()) {
                if (isAdmin() || isLandlord() || isCustomer()) {
                    if (confirm('Logout?')) {
                        logoutUser();
                    }
                }
            } else {
                showLoginSection();
            }
        });

        // ========== THEME & LANGUAGE TOGGLES ==========
        document.getElementById('themeToggle').addEventListener('click', function() {
            setTheme(currentTheme === 'dark' ? 'light' : 'dark');
        });
        document.getElementById('langToggle')?.addEventListener('click', function() {
            setLanguage(currentLang === 'en' ? 'sw' : 'en');
        });
        document.getElementById('accountSettingsToggle').addEventListener('click', function(e) {
            e.preventDefault();
            toggleAccountQuickCard();
        });

        // ========== LOGOUT LINK ==========
        document.getElementById('logoutLink').addEventListener('click', function(e) {
            e.preventDefault();
            if (isLoggedIn()) {
                if (confirm('Logout?')) {
                    logoutUser();
                }
            }
        });

        document.getElementById('profileUpdateForm')?.addEventListener('submit', function(e) {
            e.preventDefault();
            if (!isLoggedIn()) { showToast('Please login first.', 'warning'); return; }

            const name = document.getElementById('profileName').value.trim();
            const email = document.getElementById('profileEmail').value.trim();
            const phone = document.getElementById('profilePhone').value.trim();
            const msgEl = document.getElementById('profileUpdateMessage');

            if (!name || !email) {
                msgEl.innerHTML = '<span style="color:var(--red);">Name and email are required.</span>';
                return;
            }

            apiFetch('auth/update-profile', { method: 'POST', body: { name, email, phone } })
                .then(result => {
                    if (result.success) {
                        currentUser = result.user;
                        localStorage.setItem('smartrent_current_user', JSON.stringify(currentUser));
                        populateProfileForm();
                        populateAccountQuickForm();
                        msgEl.innerHTML = '<span style="color:var(--green);">✅ Profile updated successfully!</span>';
                    } else {
                        msgEl.innerHTML = '<span style="color:var(--red);">❌ ' + escapeHtml(result.message || 'Failed to update profile.') + '</span>';
                    }
                })
                .catch(err => {
                    msgEl.innerHTML = '<span style="color:var(--red);">Error: ' + escapeHtml(err.message) + '</span>';
                });
        });

        document.getElementById('accountProfileForm')?.addEventListener('submit', function(e) {
            e.preventDefault();
            if (!isLoggedIn()) { showToast('Please login first.', 'warning'); return; }
            const name = document.getElementById('accountProfileName').value.trim();
            const email = document.getElementById('accountProfileEmail').value.trim();
            const phone = document.getElementById('accountProfilePhone').value.trim();
            const msgEl = document.getElementById('accountQuickMessage');
            if (!name || !email) {
                msgEl.innerHTML = '<span style="color:var(--red);">Name and email are required.</span>';
                return;
            }
            apiFetch('auth/update-profile', { method: 'POST', body: { name, email, phone } })
                .then(result => {
                    if (result.success) {
                        currentUser = result.user;
                        localStorage.setItem('smartrent_current_user', JSON.stringify(currentUser));
                        populateProfileForm();
                        populateAccountQuickForm();
                        msgEl.innerHTML = '<span style="color:var(--green);">✅ Profile updated successfully!</span>';
                    } else {
                        msgEl.innerHTML = '<span style="color:var(--red);">❌ ' + escapeHtml(result.message || 'Failed to update profile.') + '</span>';
                    }
                })
                .catch(err => {
                    msgEl.innerHTML = '<span style="color:var(--red);">Error: ' + escapeHtml(err.message) + '</span>';
                });
        });

        document.getElementById('accountPasswordForm')?.addEventListener('submit', function(e) {
            e.preventDefault();
            if (!isLoggedIn()) { showToast('Please login first.', 'warning'); return; }
            const current = document.getElementById('accountCurrentPassword').value.trim();
            const newPass = document.getElementById('accountNewPassword').value.trim();
            const confirm = document.getElementById('accountConfirmPassword').value.trim();
            const msgEl = document.getElementById('accountQuickMessage');
            if (!current || !newPass || !confirm) {
                msgEl.innerHTML = '<span style="color:var(--red);">All password fields are required.</span>';
                return;
            }
            if (newPass !== confirm) {
                msgEl.innerHTML = '<span style="color:var(--red);">New passwords do not match.</span>';
                return;
            }
            const pwErrorChange = passwordPolicyError(newPass);
            if (pwErrorChange) {
                msgEl.innerHTML = '<span style="color:var(--red);">' + pwErrorChange + '</span>';
                return;
            }
            apiFetch('auth/change-password', { method: 'POST', body: { currentPassword: current, newPassword: newPass } })
                .then(result => {
                    if (result.success) {
                        msgEl.innerHTML = '<span style="color:var(--green);">✅ Password updated successfully!</span>';
                        this.reset();
                    } else {
                        msgEl.innerHTML = '<span style="color:var(--red);">❌ ' + escapeHtml(result.message || 'Failed to change password.') + '</span>';
                    }
                })
                .catch(err => {
                    msgEl.innerHTML = '<span style="color:var(--red);">Error: ' + escapeHtml(err.message) + '</span>';
                });
        });

        // ========== BACK TO HOME ==========
        document.getElementById('backToHomeLink').addEventListener('click', function(e) {
            e.preventDefault();
            if (isLoggedIn()) {
                hideLoginSection();
                const role = currentUser.type || 'Customer';
                if (role === 'Admin') { showSection('admin'); renderAdminRoomList(); updateAdminStats(); } else if (role === 'Landlord') { showSection('landlord'); renderLandlordProperties(); renderLandlordBookingsOrders(); } else { showSection('browse'); }
                showToast('Welcome back!', 'info');
            } else {
                hideLoginSection();
                showSection('browse');
                showToast('Browsing as guest. Sign in to book or pay.', 'info');
            }
        });

        // ========== FORGOT PASSWORD ==========
        document.getElementById('forgotPasswordLink').addEventListener('click', function(e) {
            e.preventDefault();
            document.querySelectorAll('.login-panel').forEach(p => p.classList.remove('active'));
            document.getElementById('forgotPasswordForm').classList.add('active');
            document.getElementById('loginPageError').classList.remove('show');
            document.getElementById('loginPageSuccess').classList.remove('show');
        });
        document.getElementById('backToLoginFromForgot').addEventListener('click', function() {
            document.getElementById('forgotPasswordForm').classList.remove('active');
            switchLoginTab('login');
        });
        document.getElementById('forgotPasswordForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const email = document.getElementById('forgotEmail').value.trim();
            if (!email) {
                document.getElementById('forgotPageErrorText').textContent = 'Please enter your email address.';
                document.getElementById('forgotPageError').classList.add('show');
                return;
            }
            document.getElementById('forgotPageError').classList.remove('show');
            document.getElementById('forgotPageSuccessText').textContent = 'Password reset link sent to ' + email;
            document.getElementById('forgotPageSuccess').classList.add('show');
            showToast('📧 Password reset link sent to ' + email, 'success');
            setTimeout(() => {
                document.getElementById('forgotPasswordForm').classList.remove('active');
                switchLoginTab('login');
                document.getElementById('forgotPageSuccess').classList.remove('show');
            }, 3000);
        });

        // ========== PASSWORD CHANGE ==========
        document.getElementById('changePasswordForm')?.addEventListener('submit', function(e) {
            e.preventDefault();
            if (!isLoggedIn()) { showToast('Please login first.', 'warning'); return; }

            const current = document.getElementById('currentPassword').value.trim();
            const newPass = document.getElementById('newPassword').value.trim();
            const confirm = document.getElementById('confirmNewPassword').value.trim();
            const msgEl = document.getElementById('passwordChangeMessage');

            if (!current || !newPass || !confirm) {
                msgEl.innerHTML = '<span style="color:var(--red);">All fields are required.</span>';
                return;
            }
            if (newPass !== confirm) {
                msgEl.innerHTML = '<span style="color:var(--red);">New passwords do not match.</span>';
                return;
            }
            const pwErrorChange = passwordPolicyError(newPass);
            if (pwErrorChange) {
                msgEl.innerHTML = '<span style="color:var(--red);">' + pwErrorChange + '</span>';
                return;
            }

            apiFetch('auth/change-password', { method: 'POST', body: { currentPassword: current, newPassword: newPass } })
                .then(result => {
                    if (result.success) {
                        msgEl.innerHTML = '<span style="color:var(--green);">✅ Password updated successfully!</span>';
                        this.reset();
                        if (currentUser) {
                            currentUser.password = newPass;
                            localStorage.setItem('smartrent_current_user', JSON.stringify(currentUser));
                        }
                    } else {
                        msgEl.innerHTML = '<span style="color:var(--red);">❌ ' + escapeHtml(result.message || 'Failed to change password.') + '</span>';
                    }
                })
                .catch(err => {
                    msgEl.innerHTML = '<span style="color:var(--red);">Error: ' + escapeHtml(err.message) + '</span>';
                });
        });

        // ========== NAVIGATION EVENTS ==========
        document.querySelectorAll('.sidebar-nav a, .sidebar-footer a').forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const nav = this.dataset.nav;
                if (nav) {
                    if ((nav === 'admin' || nav === 'messages' || nav === 'reports') && !isAdmin()) {
                        showToast('Please login as an agent to access this area.', 'warning');
                        return;
                    }
                    if (nav === 'landlord' && !isLandlord()) {
                        showToast('Please login as a landlord to access this area.', 'warning');
                        return;
                    }
                    if (nav === 'browse' || nav === 'bookings' || nav === 'orders' || nav === 'contracts' || nav === 'contact' || nav === 'help' || nav === 'settings' || nav === 'reports') {
                        if (nav === 'contracts' && !isLoggedIn()) {
                            showLoginRequired(() => { showSection(nav); });
                            return;
                        }
                        showSection(nav);
                        return;
                    }
                    if (nav === 'payment-dashboard' && !isLoggedIn()) {
                        showLoginRequired(() => { showSection(nav); });
                        return;
                    }
                    showSection(nav);
                }
            });
        });

        // ========== TAB SWITCHING ==========
        document.querySelectorAll('#loginTabs button').forEach(btn => {
            btn.addEventListener('click', function() { switchLoginTab(this.dataset.loginTab); });
        });
        document.getElementById('switchToCustomer').addEventListener('click', function(e) { e.preventDefault(); switchLoginTab('customer'); });
        document.getElementById('switchToLandlord').addEventListener('click', function(e) { e.preventDefault(); switchLoginTab('landlord'); });
        document.getElementById('switchToLoginFromCustomer').addEventListener('click', function(e) { e.preventDefault(); switchLoginTab('login'); });
        document.getElementById('switchToLoginFromLandlord').addEventListener('click', function(e) { e.preventDefault(); switchLoginTab('login'); });

        // ========== DATA FETCH FUNCTIONS ==========
        async function fetchMessages() {
            try {
                const msgs = await apiFetch('messages');
                messages = msgs;
                return msgs;
            } catch (e) {
                return [];
            }
        }

        async function fetchPaymentHistory() {
            try {
                const payments = await apiFetch('payments');
                paymentHistory = payments;
                return payments;
            } catch (e) {
                return [];
            }
        }

        async function fetchLandlordProperties() {
            try {
                const props = await apiFetch('properties');
                landlordProperties = props;
                return props;
            } catch (e) {
                return [];
            }
        }

        async function fetchBookings() {
            try {
                const bookings = await apiFetch('bookings');
                bookingRecords = bookings;
                return bookings;
            } catch (e) {
                return [];
            }
        }

        async function fetchOrders() {
            try {
                const orders = await apiFetch('orders');
                orderRecords = orders;
                return orders;
            } catch (e) {
                return [];
            }
        }

        function buildRoomOptions(rooms) {
            const unique = { locations: new Set(), areas: new Set(), types: new Set() };
            rooms.forEach(room => {
                if (room.location) unique.locations.add(room.location.trim());
                if (room.area) unique.areas.add(room.area.trim());
                if (room.type) unique.types.add(room.type.trim());
            });
            return {
                locations: Array.from(unique.locations).filter(v => v).sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' })),
                areas: Array.from(unique.areas).filter(v => v).sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' })),
                types: Array.from(unique.types).filter(v => v).sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' }))
            };
        }

        function setSelectOptions(select, options, placeholder) {
            if (!select) return;
            select.innerHTML = `<option value="">${placeholder}</option>` + options.map(value => `<option value="${escapeHtml(value)}">${escapeHtml(value)}</option>`).join('');
        }

        function setDatalistOptions(datalist, options) {
            if (!datalist) return;
            datalist.innerHTML = options.map(value => `<option value="${escapeHtml(value)}"></option>`).join('');
        }

        function updateRoomFilterOptions(options) {
            setSelectOptions(filterLocation, options.locations, 'All Locations');
            setSelectOptions(filterArea, options.areas, 'All Areas');
            setSelectOptions(filterRoomType, options.types, 'All Types');
            const roomLocationList = document.getElementById('roomLocationList');
            const roomTypeList = document.getElementById('roomTypeList');
            const propRegionList = document.getElementById('propRegionList');
            setDatalistOptions(roomLocationList, options.locations);
            setDatalistOptions(roomTypeList, options.types);
            setDatalistOptions(propRegionList, options.locations);
        }

        async function fetchRoomOptions() {
            try {
                const rooms = await apiFetch('rooms');
                allRoomOptions = buildRoomOptions(rooms);
                updateRoomFilterOptions(allRoomOptions);
                return rooms;
            } catch (e) {
                showToast('Failed to load room filter options: ' + e.message, 'error');
                return [];
            }
        }

        // ========== INIT ==========
        // ========== HOME / BACK NAVIGATION ==========
        document.getElementById('backBtn').addEventListener('click', function() {
            window.location.href = '/';
        });

        async function init() {
            roomGrid = document.getElementById('roomGrid');
            resultsCount = document.getElementById('resultsCount');
            searchInput = document.getElementById('searchInput');
            filterLocation = document.getElementById('filterLocation');
            filterArea = document.getElementById('filterArea');
            filterMaxPrice = document.getElementById('filterMaxPrice');
            filterMinSize = document.getElementById('filterMinSize');
            filterRoomType = document.getElementById('filterRoomType');
            filterSort = document.getElementById('filterSort');
            applyBtn = document.getElementById('applyFiltersBtn');
            clearBtn = document.getElementById('clearFiltersBtn');
            prevPageBtn = document.getElementById('prevPage');
            nextPageBtn = document.getElementById('nextPage');
            pagination = document.getElementById('pagination');
            gridViewBtn = document.getElementById('gridViewBtn');
            listViewBtn = document.getElementById('listViewBtn');
            mobileToggle = document.getElementById('mobileToggle');
            sidebar = document.getElementById('sidebar');
            sidebarOverlay = document.getElementById('sidebarOverlay');
            userAvatar = document.getElementById('userAvatar');
            adminBadge = document.getElementById('adminBadge');
            adminNav = document.querySelector('.admin-nav');
            messagesNav = document.querySelector('.messages-nav');
            reportsNav = document.querySelector('.reports-nav');
            adminForm = document.getElementById('adminForm');
            roomImageInput = document.getElementById('roomImage');
            adminRoomList = document.getElementById('adminRoomList');
            bookingsList = document.getElementById('bookingsList');
            ordersList = document.getElementById('ordersList');
            contactForm = document.getElementById('contactForm');
            messagesList = document.getElementById('messagesList');
            landlordNav = document.querySelector('.landlord-nav');

            setTheme(currentTheme);
            applyTranslations();
            await checkSession();

            await Promise.all([
                fetchRoomOptions().then(() => applyFilters()),
                fetchPaymentHistory().then(() => renderPaymentHistory()),
                fetchMessages().then(() => renderMessages()),
                fetchLandlordProperties().then(() => renderLandlordProperties()),
                Promise.all([fetchBookings(), fetchOrders()]).then(() => renderBookingsOrders())
            ]);
            renderReports();
            if (isLandlord()) renderLandlordBookingsOrders();
            updateAdminStats();
            updatePaymentDashboard();

            applyBtn.addEventListener('click', applyFilters);
            searchInput.addEventListener('keyup', (e) => { if (e.key === 'Enter') applyFilters(); });
            clearBtn.addEventListener('click', clearFilters);
            prevPageBtn.addEventListener('click', () => { if (currentPage > 1) goToPage(currentPage - 1); });
            nextPageBtn.addEventListener('click', () => {
                const totalPages = Math.ceil(filteredRooms.length / perPage) || 1;
                if (currentPage < totalPages) goToPage(currentPage + 1);
            });

            // ---- MAIN LOGIN & SIGNUP FORMS ----
            document.getElementById('loginPageForm').addEventListener('submit', async function(e) {
                e.preventDefault();
                const email = document.getElementById('loginPageEmail').value.trim();
                const password = document.getElementById('loginPagePassword').value.trim();
                const errorEl = document.getElementById('loginPageError');
                const successEl = document.getElementById('loginPageSuccess');

                errorEl.classList.remove('show');
                successEl.classList.remove('show');

                const result = await loginUser(email, password);
                if (result.success) {
                    successEl.querySelector('span').textContent = 'Welcome, ' + result.user.name + '!';
                    successEl.classList.add('show');
                    setTimeout(() => {
                        hideLoginSection();
                        updateAvatar();
                        const role = result.user.type || 'Customer';
                        if (role === 'Admin') { showSection('admin'); renderAdminRoomList(); updateAdminStats(); }
                        else if (role === 'Landlord') { showSection('landlord'); renderLandlordProperties(); renderLandlordBookingsOrders(); }
                        else { showSection('browse'); }
                        showToast('✅ Welcome back, ' + result.user.name + '!', 'success');
                        // Resume whatever guest action (Book, Order, etc.) triggered
                        // showLoginRequired(), if any. Consumed exactly once here so
                        // it can never run twice.
                        if (pendingAuthAction) { const action = pendingAuthAction; pendingAuthAction = null; action(); }
                    }, 500);
                } else {
                    errorEl.querySelector('span').textContent = result.message || 'Invalid credentials';
                    errorEl.classList.add('show');
                    document.getElementById('loginPagePassword').value = '';
                    document.getElementById('loginPagePassword').focus();
                }
            });

            document.getElementById('customerSignupForm').addEventListener('submit', async function(e) {
                e.preventDefault();
                const name = document.getElementById('customerName').value.trim();
                const email = document.getElementById('customerEmail').value.trim();
                const password = document.getElementById('customerPassword').value;
                const confirm = document.getElementById('customerConfirmPassword').value;
                const errorEl = document.getElementById('customerPageError');
                const successEl = document.getElementById('customerPageSuccess');

                errorEl.classList.remove('show');
                successEl.classList.remove('show');

                if (!name || !email || !password || !confirm) {
                    errorEl.querySelector('span').textContent = 'Please fill in all fields.';
                    errorEl.classList.add('show');
                    return;
                }
                if (password !== confirm) {
                    errorEl.querySelector('span').textContent = 'Passwords do not match.';
                    errorEl.classList.add('show');
                    return;
                }
                const pwErrorModal = passwordPolicyError(password);
                if (pwErrorModal) {
                    errorEl.querySelector('span').textContent = pwErrorModal;
                    errorEl.classList.add('show');
                    return;
                }

                const result = await signupUser(name, email, '', password, 'Customer');
                if (result.success) {
                    successEl.querySelector('span').textContent = 'Account created! Welcome ' + name + '.';
                    successEl.classList.add('show');
                    setTimeout(() => {
                        hideLoginSection();
                        updateAvatar();
                        showSection('browse');
                        showToast('✅ Welcome, ' + name + '!', 'success');
                        if (pendingAuthAction) { const action = pendingAuthAction; pendingAuthAction = null; action(); }
                    }, 500);
                } else {
                    errorEl.querySelector('span').textContent = result.message || 'Signup failed.';
                    errorEl.classList.add('show');
                }
            });

            document.getElementById('landlordSignupForm').addEventListener('submit', async function(e) {
                e.preventDefault();
                const name = document.getElementById('landlordName').value.trim();
                const email = document.getElementById('landlordEmail').value.trim();
                const password = document.getElementById('landlordPassword').value;
                const confirm = document.getElementById('landlordConfirmPassword').value;
                const errorEl = document.getElementById('landlordPageError');
                const successEl = document.getElementById('landlordPageSuccess');

                errorEl.classList.remove('show');
                successEl.classList.remove('show');

                if (!name || !email || !password || !confirm) {
                    errorEl.querySelector('span').textContent = 'Please fill in all fields.';
                    errorEl.classList.add('show');
                    return;
                }
                if (password !== confirm) {
                    errorEl.querySelector('span').textContent = 'Passwords do not match.';
                    errorEl.classList.add('show');
                    return;
                }
                const pwErrorModal = passwordPolicyError(password);
                if (pwErrorModal) {
                    errorEl.querySelector('span').textContent = pwErrorModal;
                    errorEl.classList.add('show');
                    return;
                }

                const result = await signupUser(name, email, '', password, 'Landlord');
                if (result.success) {
                    successEl.querySelector('span').textContent = 'Landlord account created! Welcome ' + name + '.';
                    successEl.classList.add('show');
                    setTimeout(() => {
                        hideLoginSection();
                        updateAvatar();
                        showSection('landlord');
                        renderLandlordProperties();
                        renderLandlordBookingsOrders();
                        showToast('✅ Welcome, Landlord ' + name + '!', 'success');
                        if (pendingAuthAction) { const action = pendingAuthAction; pendingAuthAction = null; action(); }
                    }, 500);
                } else {
                    errorEl.querySelector('span').textContent = result.message || 'Signup failed.';
                    errorEl.classList.add('show');
                }
            });

            if (isLoggedIn()) {
                hideLoginSection();
                const role = currentUser.type || 'Customer';
                if (role === 'Admin') { showSection('admin'); renderAdminRoomList(); updateAdminStats(); } else if (role === 'Landlord') { showSection('landlord'); renderLandlordProperties(); renderLandlordBookingsOrders(); } else { showSection('browse'); }
            } else {
                // Guests always land directly on Browse Rooms — no automatic
                // popping to a login page. Login only ever appears from an
                // explicit action: clicking the account/Sign In icon, or
                // trying to book/order a room.
                showSection('browse');
            }

            console.log('🏠 Smart Rent — Connected to API backend');
        }

        document.addEventListener('DOMContentLoaded', init);
    </script>
</body>
</html>