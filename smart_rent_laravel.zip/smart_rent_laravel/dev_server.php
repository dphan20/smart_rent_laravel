<?php
/**
 * Custom PHP built-in server router — LOCAL DEVELOPMENT ONLY.
 *
 * WHY THIS FILE EXISTS
 * ---------------------
 * `php artisan serve` uses a router script that, for any URL matching a
 * REAL file under public/ (e.g. public/uploads/property_123.jpg), just
 * tells PHP's built-in server "serve this file as-is" and skips this
 * project's code entirely — including the CORS headers set at the top of
 * public/backend/api.php. That script only ever runs for URLs that do
 * NOT map to a real file (e.g. /api/properties), which is why:
 *
 *   - Login, signup, and every /api/* JSON call worked fine (routed
 *     through api.php, which sets the CORS headers correctly).
 *   - Property photos, room photos, and 360° tour panoramas — plain
 *     static files under public/uploads — were served with NO CORS
 *     headers at all. The Flutter WEB build (running on a different
 *     origin/port than the API, e.g. http://localhost:5000 vs
 *     http://127.0.0.1:8000) had every one of those image requests
 *     silently blocked by the browser, which is why they showed a
 *     broken-image/house icon everywhere in the app despite the exact
 *     same URL opening fine when pasted directly into the address bar
 *     (a plain top-level navigation isn't subject to CORS at all).
 *   - Android and iOS were never affected — CORS is a browser-only
 *     restriction, not something native HTTP clients enforce.
 *
 * This router adds the same explicit-origin-whitelist CORS headers to
 * EVERY response, including real static files, before handing off to
 * the default "serve the file" behavior. Nothing about how images are
 * uploaded, stored, or referenced changes — only how they're served
 * during local development.
 *
 * USAGE — replace this:
 *   php artisan serve --no-reload
 * with this (same host, same port, nothing else changes):
 *   php -S 127.0.0.1:8000 -t public dev_server.php
 *
 * In production (a real Apache/Nginx deployment), this file is never
 * used — the web server's own config is responsible for CORS/static
 * file headers there, same as before.
 */

require_once __DIR__ . '/public/backend/config/env.php';

// Identical logic to the top of public/backend/api.php, applied here too
// so static files get the same treatment as API responses.
$allowedOriginsEnv = getenv('SMART_RENT_ALLOWED_ORIGINS') ?: '';
$allowedOrigins = array_filter(array_map('trim', explode(',', $allowedOriginsEnv)));
$requestOrigin = $_SERVER['HTTP_ORIGIN'] ?? '';
if ($requestOrigin !== '' && in_array($requestOrigin, $allowedOrigins, true)) {
    header('Access-Control-Allow-Origin: ' . $requestOrigin);
    header('Vary: Origin');
    header('Access-Control-Allow-Credentials: true');
}
// Browsers only send an Origin header for cross-origin requests, so this
// never fires for same-origin loads (e.g. Postman, curl, or the direct
// address-bar test) — nothing changes for those.

$uri = urldecode((string) parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));

// A real file (image, css, js, favicon, ...) under public/ — let PHP's
// built-in server send it as-is. The header() calls above still apply to
// this response even though this script returns without printing a body
// itself; PHP's built-in server sends whatever headers were queued.
if ($uri !== '/' && file_exists(__DIR__ . '/public' . $uri)) {
    return false;
}

// Anything else (every /api/* route, and the app shell itself) goes
// through Laravel exactly as it always has.
require_once __DIR__ . '/public/index.php';
