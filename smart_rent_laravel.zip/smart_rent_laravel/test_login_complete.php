<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'public/backend/config/database.php';
require_once 'public/backend/models/User.php';
require_once 'public/backend/helpers/functions.php';

echo "=== LOGIN SYSTEM VERIFICATION ===\n\n";

// Check if schema is initialized
echo "[1] Checking schema initialization...\n";
if (!file_exists('.schema_initialized')) {
    echo "    [*] Initializing schema...\n";
    initializeSchema($pdo);
    file_put_contents('.schema_initialized', '');
    echo "    [+] Schema initialized\n";
} else {
    echo "    [+] Schema already initialized\n";
}

// Check tables exist
echo "\n[2] Checking database tables...\n";
$stmt = $pdo->query("SHOW TABLES");
$tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
$authTables = array_filter($tables, function($t) { return strpos($t, 'auth_') === 0; });
echo "    Found tables: " . implode(', ', $tables) . "\n";
echo "    Auth tables: " . (count($authTables) > 0 ? implode(', ', $authTables) : 'NONE') . "\n";

// Test user lookup
echo "\n[3] Testing admin user lookup...\n";
$user = User::findByEmail('admin@smartrent.test');
if ($user) {
    echo "    [+] Admin user found\n";
    echo "        ID: " . $user['id'] . "\n";
    echo "        Name: " . $user['name'] . "\n";
    echo "        Email: " . $user['email'] . "\n";
    echo "        Type: " . $user['type'] . "\n";
} else {
    echo "    [-] Admin user NOT found - creating test user\n";
    // Create admin user: create($name, $email, $phone, $password, $role = 'Customer')
    $adminId = User::create(
        'Admin User',
        'admin@smartrent.test',
        '+255700000001',
        'Admin123!Test',
        'Admin'
    );
    echo "    [+] Created admin user with ID: " . $adminId . "\n";
}

// Test password verification
echo "\n[4] Testing password verification...\n";
$user = User::findByEmail('admin@smartrent.test');
if ($user) {
    $testPassword = 'Admin123!Test';
    if (password_verify($testPassword, $user['password_hash'])) {
        echo "    [+] Password verification works\n";
    } else {
        echo "    [-] Password verification FAILED\n";
    }
}

echo "\n[5] Testing session configuration...\n";
$sessionConfig = ini_get_all('session');
echo "    session.use_strict_mode: " . $sessionConfig['session.use_strict_mode']['local_value'] . "\n";
echo "    session.name: " . $sessionConfig['session.name']['local_value'] . "\n";
echo "    session.cookie_httponly: " . $sessionConfig['session.cookie_httponly']['local_value'] . "\n";

echo "\n=== VERIFICATION COMPLETE ===\n";
