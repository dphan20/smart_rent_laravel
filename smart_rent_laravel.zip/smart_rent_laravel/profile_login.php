<?php
// Profile login timing to find bottleneck
$startTotal = microtime(true);

// Time database connection
$startDb = microtime(true);
require_once __DIR__ . '/public/backend/config/database.php';
$dbTime = (microtime(true) - $startDb) * 1000;

// Prepare test data
$email = 'admin@smartrent.co.tz';
$password = 'Admin123!Test';

// Time user lookup
$startQuery = microtime(true);
$stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
$stmt->execute([$email]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
$queryTime = (microtime(true) - $startQuery) * 1000;

// Time password verification
$startPwd = microtime(true);
$verified = password_verify($password, $user['password_hash']);
$pwdTime = (microtime(true) - $startPwd) * 1000;

// Time session operations
$startSession = microtime(true);
session_start();
$_SESSION['user_id'] = $user['id'];
$_SESSION['user_type'] = 'Admin';
$sessionTime = (microtime(true) - $startSession) * 1000;

// Time auth security operations
$startAuth = microtime(true);
require_once __DIR__ . '/public/backend/models/AuthSecurity.php';
AuthSecurity::recordAttempt($email, '127.0.0.1', true);
AuthSecurity::registerSuccess($user['id']);
$authTime = (microtime(true) - $startAuth) * 1000;

$totalTime = (microtime(true) - $startTotal) * 1000;

echo "Login Timing Profile\n";
echo "====================\n";
echo "Database Connection: " . number_format($dbTime, 2) . "ms\n";
echo "User Query: " . number_format($queryTime, 2) . "ms\n";
echo "Password Verification: " . number_format($pwdTime, 2) . "ms\n";
echo "Session Init: " . number_format($sessionTime, 2) . "ms\n";
echo "Auth Security: " . number_format($authTime, 2) . "ms\n";
echo "---\n";
echo "TOTAL: " . number_format($totalTime, 2) . "ms\n";
