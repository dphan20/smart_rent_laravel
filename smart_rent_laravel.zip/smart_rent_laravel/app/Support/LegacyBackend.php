<?php

namespace App\Support;

use Illuminate\Http\Request;

class LegacyBackend
{
    /**
     * The legacy PHP backend's api.php URL.
     *
     * Prefers an explicit SMART_RENT_LEGACY_URL in .env. Otherwise derives
     * it from the CURRENT request (same host/port/folder the browser is
     * actually using) rather than a hardcoded default. backend/ lives
     * inside public/ (public/backend/api.php), so it is always reachable
     * at the exact same base URL Laravel itself is served from - this
     * works identically under `php artisan serve`, VS Code's PHP server,
     * and Apache/XAMPP, regardless of project folder name or port, since
     * `php artisan serve` can only ever see files inside public/.
     */
    public static function url(Request $request): string
    {
        $legacyUrl = env('SMART_RENT_LEGACY_URL');
        if ($legacyUrl) {
            return rtrim($legacyUrl, '/');
        }

        return rtrim($request->root(), '/') . '/backend/api.php';
    }

    /**
     * Converts Laravel's $request->files->all() - a tree of
     * Symfony\Component\HttpFoundation\File\UploadedFile OBJECTS - into the
     * classic array shape PHP itself builds for the $_FILES superglobal
     * (['name' => ..., 'type' => ..., 'tmp_name' => ..., 'error' => ...,
     * 'size' => ...], with PHP's parallel-array convention for
     * array-named fields like images[]).
     *
     * The legacy backend (RoomController, PropertyController,
     * UploadSecurity, ...) was written against the real PHP $_FILES
     * superglobal and does plain array access like $_FILES['image']['error']
     * or $_FILES['images']['tmp_name'][$i]. Assigning Laravel's UploadedFile
     * objects into $_FILES directly (as the catch-all route used to do)
     * makes every one of those array accesses throw "Cannot use object of
     * type Symfony\Component\HttpFoundation\File\UploadedFile as array" the
     * moment a file is actually attached - which is exactly why every
     * admin/landlord image upload failed with that exact exception while
     * every non-file request worked fine. This rebuilds the real thing so
     * the legacy code needs no changes at all.
     */
    public static function normalizeFilesArray(array $files): array
    {
        $result = [];
        foreach ($files as $key => $value) {
            $result[$key] = self::convertFileValue($value);
        }
        return $result;
    }

    private static function convertFileValue($value)
    {
        if ($value === null) {
            return null;
        }

        if ($value instanceof \Symfony\Component\HttpFoundation\File\UploadedFile) {
            return [
                'name' => $value->getClientOriginalName(),
                'type' => $value->getClientMimeType() ?: ($value->getMimeType() ?: ''),
                // getPathname() is the real temp file path PHP already
                // wrote to disk for this upload - move_uploaded_file()
                // works on it exactly as it would on a native $_FILES
                // tmp_name, since PHP's built-in server (and Apache/FPM)
                // still does the actual multipart upload itself; Symfony
                // just wraps the result in an object instead of an array.
                'tmp_name' => $value->getPathname(),
                'error' => $value->getError(),
                'size' => $value->getSize() ?: 0,
            ];
        }

        if (is_array($value)) {
            $converted = [];
            foreach ($value as $k => $v) {
                $converted[$k] = self::convertFileValue($v);
            }
            return self::transposeFileArray($converted);
        }

        return $value;
    }

    /**
     * Turns [0 => ['name'=>a,'tmp_name'=>b,...], 1 => ['name'=>c,...]] (one
     * map per file, natural from Symfony's structure) into
     * ['name'=>[0=>a,1=>c], 'tmp_name'=>[0=>b,...], ...] (PHP's actual
     * $_FILES convention for a multi-file input like images[]).
     */
    private static function transposeFileArray(array $converted): array
    {
        $nonNull = array_filter($converted, fn ($item) => $item !== null);
        if (empty($nonNull)) {
            return ['name' => [], 'type' => [], 'tmp_name' => [], 'error' => [], 'size' => []];
        }

        $sample = reset($nonNull);
        if (!is_array($sample) || !array_key_exists('tmp_name', $sample)) {
            // Not actually a file leaf (e.g. an array field the app sent
            // that happens to sit alongside file fields) - leave it as-is.
            return $converted;
        }

        $out = ['name' => [], 'type' => [], 'tmp_name' => [], 'error' => [], 'size' => []];
        foreach ($converted as $idx => $item) {
            $item = $item ?? ['name' => '', 'type' => '', 'tmp_name' => '', 'error' => UPLOAD_ERR_NO_FILE, 'size' => 0];
            foreach (['name', 'type', 'tmp_name', 'error', 'size'] as $subKey) {
                $out[$subKey][$idx] = $item[$subKey] ?? null;
            }
        }
        return $out;
    }
}
