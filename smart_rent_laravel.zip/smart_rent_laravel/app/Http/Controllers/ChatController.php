<?php

namespace App\Http\Controllers;

use App\Services\GroqService;
use App\Models\AIConversation;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http;

class ChatController extends Controller
{
    private $groqService;

    public function __construct(GroqService $groqService)
    {
        $this->groqService = $groqService;
    }

    /**
     * Who's logged in, according to the legacy PHP backend.
     *
     * Login/signup are handled entirely by the legacy backend (routes/api.php
     * proxies everything except /chat and /ai/* there), which tracks the
     * session via its own PHP session cookie (SMART_RENT_SESSID) — NOT
     * Laravel's own session/auth guard. So auth()->check() in this
     * controller is never true, even for a logged-in user. Instead, forward
     * the browser's cookies to the legacy /auth/check endpoint and ask it
     * who's logged in. Fails safe (treated as "not logged in") if the
     * legacy backend is unreachable.
     */
    private function currentLegacyUserId(Request $request): ?int
    {
        $legacyUrl = \App\Support\LegacyBackend::url($request);

        try {
            $response = Http::withHeaders([
                'Cookie' => (string) $request->header('cookie'),
                'Accept' => 'application/json',
            ])->timeout(5)->get(rtrim($legacyUrl, '/') . '/auth/check');

            if ($response->successful()) {
                $data = $response->json();
                if (($data['loggedIn'] ?? false) && isset($data['user']['id'])) {
                    return (int) $data['user']['id'];
                }
            }
        } catch (\Exception $e) {
            Log::warning('Legacy auth check failed: ' . $e->getMessage());
        }

        return null;
    }

    /**
     * Send a message to the AI chatbot
     * 
     * Public endpoint - no login required
     * Rate limited per IP address
     */
    public function sendMessage(Request $request)
    {
        // Validate input
        $validator = Validator::make($request->all(), [
            'message' => 'required|string|max:2000|min:1',
            'session_id' => 'nullable|string|max:100',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Invalid input. Please provide a valid message.',
            ], 422);
        }

        try {
            $message = trim($request->input('message'));
            $sessionId = $request->input('session_id') ?? Str::uuid();

            // Sanitize input to prevent any injection
            $message = strip_tags($message);

            // Additional security: limit message to reasonable length
            if (strlen($message) > 2000) {
                return response()->json([
                    'success' => false,
                    'message' => 'Message is too long.',
                ], 422);
            }

            // Get user ID if authenticated (optional for storing history)
            $userId = $this->currentLegacyUserId($request);

            // Call Groq service
            $response = $this->groqService->chat($message, $sessionId);

            // Defense in depth: GroqService::chat() always returns a
            // grounded, non-empty 'reply' now, but guarantee it here too so
            // the widget can never render a blank/undefined bubble even if
            // that contract is ever broken by a future change.
            if (empty(trim((string) ($response['reply'] ?? '')))) {
                $response['reply'] = $response['message']
                    ?? "Sorry, I couldn't find an answer to that right now. Try asking about a location, budget, or number of bedrooms.";
                $response['success'] = true;
            }

            // Store conversation history if user is authenticated
            if ($userId && ($response['success'] ?? false)) {
                try {
                    AIConversation::create([
                        'customer_id' => $userId,
                        'session_id' => $sessionId,
                        'message' => $message,
                        'response' => $response['reply'],
                    ]);
                } catch (\Exception $e) {
                    Log::warning('Failed to store conversation: ' . $e->getMessage());
                    // Don't fail the response if we can't store history
                }
            }

            return response()->json($response);
        } catch (\Exception $e) {
            Log::error('ChatController error: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Unable to process your request.',
            ], 500);
        }
    }

    public function match(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'query' => 'required|string|max:500|min:1',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Invalid search query.',
            ], 422);
        }

        $query = trim(strip_tags($request->input('query')));
        $response = $this->groqService->chat($query, Str::uuid());

        return response()->json([
            'success' => ($response['success'] ?? false),
            'reply' => $response['reply'] ?? null,
            'results' => $response['properties'] ?? [],
            'message' => $response['message'] ?? null,
        ]);
    }

    public function search(Request $request)
    {
        return $this->match($request);
    }

    public function askProperty(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'room_id' => 'required|integer|min:1',
            'question' => 'required|string|max:500|min:1',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Invalid property question.',
            ], 422);
        }

        $question = trim(strip_tags($request->input('question')));
        $roomId = (int) $request->input('room_id');

        // Pull the LIVE record for this exact property/room first. Without
        // this, the question was previously forwarded to the generic
        // chatbot with no idea which listing the user was even looking at.
        $listing = $this->groqService->getListingById($roomId);

        if (!$listing) {
            return response()->json([
                'success' => false,
                'reply' => 'I could not find that property in the current listings. It may have been removed.',
                'property' => null,
            ]);
        }

        $result = $this->groqService->askAboutListing($listing, $question, (string) Str::uuid());
        $reply = trim((string) ($result['reply'] ?? ''));

        try {
            $userId = $this->currentLegacyUserId($request);
            if ($userId) {
                AIConversation::create([
                    'customer_id' => $userId,
                    'session_id' => (string) Str::uuid(),
                    'message' => "[Property #{$roomId}] {$question}",
                    'response' => $reply,
                ]);
            }
        } catch (\Exception $e) {
            Log::warning('Failed to store property-question conversation: ' . $e->getMessage());
        }

        return response()->json([
            'success' => true,
            'reply' => $reply !== '' ? $reply : 'Sorry, I could not answer that question right now. Please try again.',
            'property' => $listing,
        ]);
    }

    /**
     * AI House Matchmaker — compare 2-6 specific listings side by side on
     * cost, size, bedrooms, bathrooms, and (when the caller supplies its
     * current GPS position and the listings have saved coordinates)
     * distance. Powers the mobile "Compare" action and any "compare these"
     * flow in the dashboard.
     */
    public function compare(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'room_ids' => 'required|array|min:2|max:6',
            'room_ids.*' => 'integer|min:1',
            'lat' => 'nullable|numeric|between:-90,90',
            'lng' => 'nullable|numeric|between:-180,180',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Provide at least 2 and at most 6 room_ids to compare.',
                'errors' => $validator->errors(),
            ], 422);
        }

        $roomIds = $request->input('room_ids');
        $lat = $request->has('lat') ? (float) $request->input('lat') : null;
        $lng = $request->has('lng') ? (float) $request->input('lng') : null;

        $result = $this->groqService->compareListings($roomIds, $lat, $lng);

        return response()->json([
            'success' => $result['success'] ?? false,
            'reply' => $result['reply'] ?? null,
            'listings' => $result['listings'] ?? [],
            'winners' => $result['winners'] ?? null,
            'not_found' => $result['not_found'] ?? [],
        ]);
    }

    public function similar(Request $request)
    {
        $roomId = $request->query('room_id');
        if (!$roomId) {
            return response()->json([
                'success' => false,
                'message' => 'room_id is required.',
            ], 422);
        }

        $listing = $this->groqService->getListingById((int) $roomId);
        if (!$listing) {
            return response()->json([
                'success' => true,
                'results' => [],
                'message' => 'That listing is no longer available.',
            ]);
        }

        $results = $this->groqService->findSimilarListings($listing, 6);

        return response()->json([
            'success' => true,
            'results' => $results,
        ]);
    }

    /**
     * Get conversation history for authenticated user
     */
    public function getHistory(Request $request)
    {
        $userId = $this->currentLegacyUserId($request);
        if (!$userId) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized',
            ], 401);
        }

        try {
            $limit = (int) $request->query('limit', 50);
            $limit = min($limit, 100); // Max 100 conversations

            $conversations = AIConversation::where('customer_id', $userId)
                ->orderBy('created_at', 'desc')
                ->limit($limit)
                ->get()
                ->map(function ($conv) {
                    return [
                        'session_id' => $conv->session_id,
                        'message' => $conv->message,
                        'response' => $conv->response,
                        'timestamp' => $conv->created_at->toIso8601String(),
                    ];
                });

            return response()->json([
                'success' => true,
                'conversations' => $conversations,
            ]);
        } catch (\Exception $e) {
            Log::error('Failed to retrieve conversation history: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Unable to retrieve conversation history.',
            ], 500);
        }
    }

    /**
     * Clear conversation history for authenticated user
     */
    public function clearHistory(Request $request)
    {
        $userId = $this->currentLegacyUserId($request);
        if (!$userId) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized',
            ], 401);
        }

        try {
            AIConversation::where('customer_id', $userId)->delete();

            return response()->json([
                'success' => true,
                'message' => 'Conversation history cleared.',
            ]);
        } catch (\Exception $e) {
            Log::error('Failed to clear conversation history: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Unable to clear conversation history.',
            ], 500);
        }
    }
}