<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AIConversation extends Model
{
    protected $table = 'ai_conversations';

    protected $fillable = [
        'customer_id',
        'session_id',
        'message',
        'response',
    ];

    public $timestamps = true;
    const UPDATED_AT = null;

    /**
     * Get the customer who had the conversation
     */
    public function customer()
    {
        return $this->belongsTo(User::class, 'customer_id');
    }
}
