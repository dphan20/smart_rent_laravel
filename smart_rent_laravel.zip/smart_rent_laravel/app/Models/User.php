<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Database\Factories\UserFactory;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    /** @use HasFactory<UserFactory> */
    use HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    // NOTE: this table is owned by the legacy PHP backend
    // (backend/controllers/AuthController.php handles real login/signup).
    // Laravel never writes to it directly; it only reads via Eloquent for
    // the AI feature's relationships. Columns below match the real schema
    // in backend/config/database.php, not Laravel's default scaffolding.
    protected $fillable = [
        'full_name',
        'email',
        'phone',
        'password_hash',
        'role',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password_hash',
        'remember_token',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
        ];
    }

    /**
     * Laravel's Authenticatable trait looks for a `password` column by
     * default. The real column is `password_hash` (bcrypt, set by the
     * legacy backend's password_hash()), so point Laravel at it in case
     * anything ever authenticates through Laravel's own guard.
     */
    public function getAuthPassword()
    {
        return $this->password_hash;
    }

    /**
     * Get rooms owned by this landlord
     */
    public function rooms()
    {
        return $this->hasMany(Room::class, 'landlord_id');
    }

    /**
     * Get bookings made by this user
     */
    public function bookings()
    {
        return $this->hasMany(Booking::class, 'user_id');
    }

    /**
     * Get AI conversations for this user
     */
    public function aiConversations()
    {
        return $this->hasMany(AIConversation::class, 'customer_id');
    }
}

