<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Booking extends Model
{
    protected $table = 'bookings';

    protected $fillable = [
        'room_id',
        'user_id',
        'landlord_id',
        'customer_name',
        'customer_email',
        'customer_phone',
        'amount',
        'arrival_date',
        'status',
        'payment_ref',
    ];

    protected $casts = [
        'amount' => 'decimal:2',
        'arrival_date' => 'date',
    ];

    public $timestamps = true;

    /**
     * Get the room for this booking
     */
    public function room()
    {
        return $this->belongsTo(Room::class, 'room_id');
    }

    /**
     * Get the user who made the booking
     */
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    /**
     * Get the landlord
     */
    public function landlord()
    {
        return $this->belongsTo(User::class, 'landlord_id');
    }
}
