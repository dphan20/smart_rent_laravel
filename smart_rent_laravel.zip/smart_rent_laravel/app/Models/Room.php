<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Room extends Model
{
    protected $table = 'rooms';
    
    protected $fillable = [
        'title',
        'location',
        'area',
        'price',
        'size',
        'type',
        'listing_purpose',
        'construction_status',
        'nearby_landmarks',
        'beds',
        'badge',
        'status',
        'image',
        'landlord_id',
        'virtual_tour',
    ];

    protected $casts = [
        'price' => 'decimal:2',
        'size' => 'integer',
        'beds' => 'integer',
        'nearby_landmarks' => 'array',
    ];

    public $timestamps = true;

    /**
     * Get the landlord who owns this room
     */
    public function landlord()
    {
        return $this->belongsTo(User::class, 'landlord_id');
    }

    /**
     * Get bookings for this room
     */
    public function bookings()
    {
        return $this->hasMany(Booking::class, 'room_id');
    }

    /**
     * Check if room is available
     */
    public function isAvailable()
    {
        return $this->status === 'available';
    }
}
