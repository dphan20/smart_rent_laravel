<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Rent AI - Find Your Perfect Room</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .container {
            background: white;
            border-radius: 12px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
            max-width: 600px;
            width: 100%;
            overflow: hidden;
        }

        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px 20px;
            text-align: center;
        }

        .header h1 {
            font-size: 28px;
            margin-bottom: 10px;
        }

        .header p {
            font-size: 14px;
            opacity: 0.9;
        }

        .chat-box {
            height: 400px;
            overflow-y: auto;
            padding: 20px;
            background: #f5f5f5;
            border-bottom: 1px solid #ddd;
        }

        .message {
            margin-bottom: 15px;
            display: flex;
            animation: slideIn 0.3s ease-out;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .message.user {
            justify-content: flex-end;
        }

        .message.bot {
            justify-content: flex-start;
        }

        .message-content {
            max-width: 80%;
            padding: 12px 15px;
            border-radius: 8px;
            word-wrap: break-word;
            font-size: 14px;
            line-height: 1.4;
        }

        .message.user .message-content {
            background: #667eea;
            color: white;
            border-bottom-right-radius: 2px;
        }

        .message.bot .message-content {
            background: #e0e0e0;
            color: #333;
            border-bottom-left-radius: 2px;
        }

        .properties-list {
            background: white;
            padding: 10px;
            margin-top: 10px;
            border-radius: 8px;
            border-left: 4px solid #667eea;
        }

        .property-item {
            padding: 10px;
            background: #f9f9f9;
            margin: 8px 0;
            border-radius: 4px;
            font-size: 13px;
        }

        .property-title {
            font-weight: bold;
            color: #333;
        }

        .property-details {
            color: #666;
            margin-top: 4px;
            font-size: 12px;
        }

        .input-area {
            padding: 20px;
            display: flex;
            gap: 10px;
        }

        .input-area input {
            flex: 1;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            font-family: inherit;
        }

        .input-area input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 2px rgba(102, 126, 234, 0.1);
        }

        .input-area button {
            padding: 12px 25px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: bold;
            transition: background 0.3s;
        }

        .input-area button:hover {
            background: #764ba2;
        }

        .input-area button:disabled {
            background: #ccc;
            cursor: not-allowed;
        }

        .loading {
            display: inline-block;
            width: 8px;
            height: 8px;
            background: #667eea;
            border-radius: 50%;
            margin: 0 2px;
            animation: bounce 1.4s infinite;
        }

        .loading:nth-child(2) {
            animation-delay: 0.2s;
        }

        .loading:nth-child(3) {
            animation-delay: 0.4s;
        }

        @keyframes bounce {
            0%, 80%, 100% {
                opacity: 0.5;
                transform: translateY(0);
            }
            40% {
                opacity: 1;
                transform: translateY(-10px);
            }
        }

        .error-message {
            color: #d32f2f;
            background: #ffebee;
            padding: 10px;
            border-radius: 4px;
            margin: 5px 0;
        }

        .info-text {
            font-size: 12px;
            color: #999;
            padding: 10px 20px;
            text-align: center;
            background: #fafafa;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🏠 Smart Rent AI</h1>
            <p>Find your perfect room in Tanzania</p>
        </div>

        <div class="chat-box" id="chatBox">
            <div class="message bot">
                <div class="message-content">
                    Hi! 👋 I'm your Smart Rent AI Assistant. Tell me what you're looking for:
                    <ul style="margin-top: 8px; padding-left: 20px;">
                        <li>"room with 2 beds in mbezi"</li>
                        <li>"apartment under 500,000 in dar"</li>
                        <li>"furnished house in kinondoni"</li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="input-area">
            <input type="text" id="messageInput" placeholder="Ask me about rooms and properties..." autocomplete="off">
            <button id="sendBtn" onclick="sendMessage()">Send</button>
        </div>

        <div class="info-text">
            Powered by Groq AI • No login required • Real data from database
        </div>
    </div>

    <script>
        const chatBox = document.getElementById('chatBox');
        const messageInput = document.getElementById('messageInput');
        const sendBtn = document.getElementById('sendBtn');
        let sessionId = generateSessionId();

        function generateSessionId() {
            return 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
        }

        function sendMessage() {
            const message = messageInput.value.trim();
            if (!message) return;

            // Add user message to chat
            addMessage(message, 'user');
            messageInput.value = '';
            sendBtn.disabled = true;

            // Show loading indicator
            const loadingMsg = document.createElement('div');
            loadingMsg.className = 'message bot';
            loadingMsg.innerHTML = '<div class="message-content"><div class="loading"></div><div class="loading"></div><div class="loading"></div></div>';
            chatBox.appendChild(loadingMsg);
            chatBox.scrollTop = chatBox.scrollHeight;

            // Send to API
            fetch('/api/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': document.querySelector('meta[name="csrf-token"]')?.content || ''
                },
                body: JSON.stringify({
                    message: message,
                    session_id: sessionId
                })
            })
            .then(response => response.json())
            .then(data => {
                loadingMsg.remove();

                if (data.success) {
                    addMessage(data.reply, 'bot');

                    // Add properties if available
                    if (data.properties && data.properties.length > 0) {
                        const propertiesHtml = data.properties.map(prop => {
                            const price = prop.monthly_rent ? `TZS ${Number(prop.monthly_rent).toLocaleString()}` : 'N/A';
                            const beds = prop.bedrooms ? `${prop.bedrooms} bed(s)` : 'N/A';
                            const title = prop.name || prop.title || 'Property';

                            return `
                                <div class="property-item">
                                    <div class="property-title">${title}</div>
                                    <div class="property-details">
                                        📍 ${prop.location} • 💰 ${price} • 🛏️ ${beds}
                                    </div>
                                </div>
                            `;
                        }).join('');

                        const propertiesMsg = document.createElement('div');
                        propertiesMsg.className = 'message bot';
                        propertiesMsg.innerHTML = `<div class="message-content"><div class="properties-list">${propertiesHtml}</div></div>`;
                        chatBox.appendChild(propertiesMsg);
                    }
                } else {
                    addMessage('Error: ' + (data.message || 'Failed to get response'), 'error');
                }

                chatBox.scrollTop = chatBox.scrollHeight;
                sendBtn.disabled = false;
                messageInput.focus();
            })
            .catch(error => {
                loadingMsg.remove();
                addMessage('Connection error: ' + error.message, 'error');
                sendBtn.disabled = false;
            });
        }

        function addMessage(text, type) {
            const messageDiv = document.createElement('div');
            messageDiv.className = `message ${type}`;

            const contentDiv = document.createElement('div');
            contentDiv.className = 'message-content';

            if (type === 'error') {
                contentDiv.innerHTML = `<div class="error-message">${escapeHtml(text)}</div>`;
            } else {
                contentDiv.textContent = text;
            }

            messageDiv.appendChild(contentDiv);
            chatBox.appendChild(messageDiv);
            chatBox.scrollTop = chatBox.scrollHeight;
        }

        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        // Allow sending with Enter key
        messageInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
            }
        });

        // Add CSRF token meta tag
        if (!document.querySelector('meta[name="csrf-token"]')) {
            const meta = document.createElement('meta');
            meta.name = 'csrf-token';
            meta.content = '{{ csrf_token() }}';
            document.head.appendChild(meta);
        }

        messageInput.focus();
    </script>
</body>
</html>
