import os

PATH = "resources/views/app.blade.php"

def main():
    if not os.path.isfile(PATH):
        raise SystemExit(
            "FILE NOT FOUND: " + PATH +
            "\nRun this from your Laravel project root (the folder that contains "
            "'resources/views/app.blade.php')."
        )
    with open(PATH, "r", encoding="utf-8") as f:
        data = f.read()

    if "auth-only-nav" in data:
        print("SKIP: already patched earlier.")
        return

    def do(old, new, label):
        nonlocal data
        c = data.count(old)
        if c != 1:
            raise SystemExit("ANCHOR NOT FOUND/UNIQUE (%dx) for: %s" % (c, label))
        data = data.replace(old, new)
        print("patched:", label)

    do(
        '.sidebar-nav .admin-nav,.sidebar-nav .messages-nav,.sidebar-nav .reports-nav { display:none; }',
        '.sidebar-nav .admin-nav,.sidebar-nav .messages-nav,.sidebar-nav .reports-nav,.sidebar-nav .auth-only-nav { display:none; }',
        "css hide rule",
    )
    do(
        '.sidebar-nav .admin-nav.show,.sidebar-nav .messages-nav.show,.sidebar-nav .reports-nav.show { display:flex; }',
        '.sidebar-nav .admin-nav.show,.sidebar-nav .messages-nav.show,.sidebar-nav .reports-nav.show,.sidebar-nav .auth-only-nav.show { display:flex; }',
        "css show rule",
    )

    links = [
        ('<a href="#" data-nav="bookings"><i class="fas fa-calendar-check"></i> <span data-i18n="nav_bookings">Bookings</span></a>',
         '<a href="#" class="auth-only-nav" data-nav="bookings"><i class="fas fa-calendar-check"></i> <span data-i18n="nav_bookings">Bookings</span></a>'),
        ('<a href="#" data-nav="orders"><i class="fas fa-clipboard-list"></i> <span data-i18n="nav_orders">Orders</span></a>',
         '<a href="#" class="auth-only-nav" data-nav="orders"><i class="fas fa-clipboard-list"></i> <span data-i18n="nav_orders">Orders</span></a>'),
        ('<a href="#" data-nav="contracts"><i class="fas fa-file-signature"></i> <span data-i18n="nav_contracts">My Contracts</span></a>',
         '<a href="#" class="auth-only-nav" data-nav="contracts"><i class="fas fa-file-signature"></i> <span data-i18n="nav_contracts">My Contracts</span></a>'),
        ('<a href="#" data-nav="my-messages"><i class="fas fa-inbox"></i> <span data-i18n="nav_messages">Messages</span></a>',
         '<a href="#" class="auth-only-nav" data-nav="my-messages"><i class="fas fa-inbox"></i> <span data-i18n="nav_messages">Messages</span></a>'),
        ('<a href="#" data-nav="payment-dashboard"><i class="fas fa-wallet"></i> <span data-i18n="nav_payment_dashboard">Payment Dashboard</span></a>',
         '<a href="#" class="auth-only-nav" data-nav="payment-dashboard"><i class="fas fa-wallet"></i> <span data-i18n="nav_payment_dashboard">Payment Dashboard</span></a>'),
    ]
    for old, new in links:
        do(old, new, "nav link: " + old[:45])

    do(
        "avatarLabel.textContent = currentUser.name.charAt(0).toUpperCase();",
        "avatarLabel.textContent = currentUser.name.charAt(0).toUpperCase();\n"
        "                document.querySelectorAll('.auth-only-nav').forEach(function(el){ el.classList.add('show'); });",
        "show auth-only-nav on login",
    )

    do(
        "document.querySelector('.admin-nav').classList.remove('show');\n"
        "                document.querySelector('.messages-nav').classList.remove('show');\n"
        "                document.querySelector('.reports-nav').classList.remove('show');\n"
        "                if (landlordNav) landlordNav.style.display = 'none';\n"
        "                if (logoutLink) logoutLink.style.display = 'none';",
        "document.querySelector('.admin-nav').classList.remove('show');\n"
        "                document.querySelector('.messages-nav').classList.remove('show');\n"
        "                document.querySelector('.reports-nav').classList.remove('show');\n"
        "                document.querySelectorAll('.auth-only-nav').forEach(function(el){ el.classList.remove('show'); });\n"
        "                if (landlordNav) landlordNav.style.display = 'none';\n"
        "                if (logoutLink) logoutLink.style.display = 'none';",
        "hide auth-only-nav for guests",
    )

    do(
        "function showSection(section) {\n"
        "            document.querySelectorAll('.content-section').forEach(el => el.classList.remove('active'));",
        "function showSection(section) {\n"
        "            const authOnlySections = ['bookings', 'orders', 'contracts', 'my-messages', 'payment-dashboard'];\n"
        "            if (authOnlySections.includes(section) && !isLoggedIn()) {\n"
        "                section = 'browse';\n"
        "            }\n"
        "            document.querySelectorAll('.content-section').forEach(el => el.classList.remove('active'));",
        "guard showSection() against direct/console access",
    )

    with open(PATH, "w", encoding="utf-8") as f:
        f.write(data)
    print("DONE. Bookings, Orders, My Contracts, Messages, and Payment Dashboard are now hidden from guests and blocked from direct access until login.")

main()
