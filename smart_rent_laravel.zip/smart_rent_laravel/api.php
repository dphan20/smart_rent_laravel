<?php
require_once __DIR__ . '/config/env.php';

// --- CORS: explicit whitelist instead of reflecting any Origin -------------
// SMART_RENT_ALLOWED_ORIGINS is a comma-separated list, e.g.
// "https://smartrent.co.tz,https://www.smartrent.co.tz". If unset, defaults
// to same-origin only (no Access-Control-Allow-Origin header at all), which
// is what you want unless the frontend is genuinely served from a different
// origin than this API.
$allowedOriginsEnv = getenv('SMART_RENT_ALLOWED_ORIGINS') ?: '';
$allowedOrigins = array_filter(array_map('trim', explode(',', $allowedOriginsEnv)));
$requestOrigin = $_SERVER['HTTP_ORIGIN'] ?? '';
if ($requestOrigin !== '' && in_array($requestOrigin, $allowedOrigins, true)) {
    header('Access-Control-Allow-Origin: ' . $requestOrigin);
    header('Vary: Origin');
    header('Access-Control-Allow-Credentials: true');
}
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-CSRF-Token');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Baseline hardening headers on every API response.
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: strict-origin-when-cross-origin');

require_once __DIR__ . '/config/session.php';
require_once __DIR__ . '/helpers/functions.php';
require_once __DIR__ . '/helpers/Logger.php';
require_once __DIR__ . '/helpers/RateLimiter.php';

$method = $_SERVER['REQUEST_METHOD'];
$path = isset($_SERVER['PATH_INFO']) ? ltrim($_SERVER['PATH_INFO'], '/') : '';
$parts = explode('/', $path);
$resource = $parts[0] ?? '';
$id = $parts[1] ?? null;
$action = $parts[2] ?? null;
$subId = $parts[3] ?? null;
$clientIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

// --- Rate limiting -----------------------------------------------------
// Two tiers: a tight limit on auth endpoints (they're the most valuable to
// brute-force/abuse) and a looser general limit on everything else.
if ($resource === 'auth' && in_array($id, ['login', 'signup', 'request-password-reset', 'reset-password'], true)) {
    if (!RateLimiter::allow('auth:' . $clientIp, 10, 60)) {
        Logger::api('rate limit exceeded (auth)', ['resource' => $resource, 'id' => $id]);
        sendJSON(['error' => 'Too many requests. Please slow down and try again shortly.'], 429);
    }
} elseif (!RateLimiter::allow('api:' . $clientIp, 120, 60)) {
    Logger::api('rate limit exceeded (general)', ['resource' => $resource, 'id' => $id]);
    sendJSON(['error' => 'Too many requests. Please slow down and try again shortly.'], 429);
}

if ($method !== 'OPTIONS' && in_array($resource, ['auth','rooms','messages','payments','properties','bookings','orders','sms','contracts','payouts','admin','ai','tours'], true)) {
    if ($method !== 'GET' && $method !== 'OPTIONS') {
        $isAuthLoginOrSignup = ($resource === 'auth' && ($id === 'login' || $id === 'signup'));
        $isPaymentWebhook = ($resource === 'payments' && $id === 'webhook');
        if (!$isAuthLoginOrSignup && !$isPaymentWebhook) {
            $token = trim((string) ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''));
            if ($token === '') {
                $token = trim((string) ($_SERVER['HTTP_X_CSRFTOKEN'] ?? ''));
            }
            if ($token === '') {
                $token = trim((string) ($_POST['csrf_token'] ?? ''));
            }
            if (!verifyCsrfToken($token)) {
                Logger::api('CSRF token rejected', ['resource' => $resource, 'id' => $id]);
                sendJSON(['error' => 'Invalid CSRF token'], 403);
            }
        }
    }
}

require_once __DIR__ . '/controllers/AuthController.php';
require_once __DIR__ . '/controllers/RoomController.php';
require_once __DIR__ . '/controllers/MessageController.php';
require_once __DIR__ . '/controllers/ChatMessageController.php';
require_once __DIR__ . '/controllers/PaymentController.php';
require_once __DIR__ . '/controllers/PropertyController.php';
require_once __DIR__ . '/controllers/BookingController.php';
require_once __DIR__ . '/controllers/OrderController.php';
require_once __DIR__ . '/controllers/SmsController.php';
require_once __DIR__ . '/controllers/ContractController.php';
require_once __DIR__ . '/controllers/PayoutController.php';
require_once __DIR__ . '/controllers/AdminController.php';
require_once __DIR__ . '/controllers/Tour360Controller.php';

// Transparent remember-me login for requests with no active session but a
// valid remember cookie. Must run after AuthController is loaded and before
// dispatch, so requireAuth() in the handlers below sees the restored session.
AuthController::attemptRememberMeLogin();

Logger::api('request', ['resource' => $resource, 'id' => $id]);

try {
    switch ($resource) {
    case 'auth':
        switch ($method) {
            case 'POST':
                if ($id === 'login') AuthController::login();
                elseif ($id === 'signup') AuthController::signup();
                elseif ($id === 'logout') AuthController::logout();
                elseif ($id === 'change-password') AuthController::changePassword();
                elseif ($id === 'update-profile') AuthController::updateProfile();
                elseif ($id === 'request-password-reset') AuthController::requestPasswordReset();
                elseif ($id === 'reset-password') AuthController::resetPassword();
                elseif ($id === 'verify-email') AuthController::verifyEmail();
                elseif ($id === 'resend-verification') AuthController::resendVerification();
                else sendJSON(['error' => 'Not found'], 404);
                break;
            case 'GET':
                if ($id === 'check') AuthController::check();
                elseif ($id === 'csrf') sendJSON(['csrf_token' => getCsrfToken()]);
                elseif ($id === 'verify-email') AuthController::verifyEmail();
                else sendJSON(['error' => 'Not found'], 404);
                break;
            default: sendJSON(['error' => 'Method not allowed'], 405);
        }
        break;

    // Room image gallery sub-resource:
    //   POST   /rooms/{id}/images          add one or more images
    //   DELETE /rooms/{id}/images/{index}  remove a single image by position
    case 'rooms':
        switch ($method) {
            case 'GET':
                if ($id) RoomController::getOne($id);
                else RoomController::getAll();
                break;
            case 'POST':
                if ($id && $action === 'images') RoomController::addImages($id);
                elseif (!$id) RoomController::create();
                else sendJSON(['error' => 'Not found'], 404);
                break;
            case 'PUT':
                if ($id) RoomController::update($id);
                else sendJSON(['error' => 'ID required'], 400);
                break;
            case 'DELETE':
                if ($id && $action === 'images' && $subId !== null) RoomController::deleteImage($id, $subId);
                elseif ($id && !$action) RoomController::delete($id);
                else sendJSON(['error' => 'ID required'], 400);
                break;
            default: sendJSON(['error' => 'Method not allowed'], 405);
        }
        break;

    case 'chat':
        switch ($id) {
            case 'conversations': ChatMessageController::conversations(); break;
            case 'contacts': ChatMessageController::contacts(); break;
            case 'thread': ChatMessageController::thread($action); break;
            case 'send': ChatMessageController::send(); break;
            default: sendJSON(['error' => 'Not found'], 404);
        }
        break;

    case 'messages':        switch ($method) {
            case 'GET': MessageController::getAll(); break;
            case 'POST': MessageController::create(); break;
            default: sendJSON(['error' => 'Method not allowed'], 405);
        }
        break;

    case 'payments':
        switch ($method) {
            case 'GET': PaymentController::getAll(); break;
            case 'POST':
                if ($id === 'webhook') PaymentController::webhook();
                else PaymentController::create();
                break;
            case 'PUT':
                if ($id && $action === 'verify') PaymentController::verify($id);
                else sendJSON(['error' => 'ID required'], 400);
                break;
            case 'DELETE':
                if ($id) PaymentController::delete($id);
                else sendJSON(['error' => 'ID required'], 400);
                break;
            default: sendJSON(['error' => 'Method not allowed'], 405);
        }
        break;

    // Property image gallery sub-resource (mirrors rooms/{id}/images above):
    //   POST   /properties/{id}/images          add one or more images
    //   DELETE /properties/{id}/images/{index}  remove a single image by position
    case 'properties':
        switch ($method) {
            case 'GET': PropertyController::getAll(); break;
            case 'POST':
                if ($id && $action === 'images') PropertyController::addImages($id);
                elseif (!$id) PropertyController::create();
                else sendJSON(['error' => 'Not found'], 404);
                break;
            case 'DELETE':
                if ($id && $action === 'images' && $subId !== null) PropertyController::deleteImage($id, $subId);
                elseif ($id && !$action) PropertyController::delete($id);
                else sendJSON(['error' => 'ID required'], 400);
                break;
            default: sendJSON(['error' => 'Method not allowed'], 405);
        }
        break;

    // 360° virtual tour scenes + hotspots for a room or property. Scene
    // listing/viewing is public (GET); creating/editing/deleting a scene
    // or hotspot requires the owning Landlord or an Admin — enforced
    // inside Tour360Controller via Tour360::userCanManageListing(), never
    // trusted from the request body.
    //   GET    /tours?listing_type=&listing_id=      list scenes+hotspots
    //   GET    /tours/{tourId}                       one scene+hotspots
    //   POST   /tours                                 create scene (multipart)
    //   PUT    /tours/{tourId}                        update scene
    //   DELETE /tours/{tourId}                        delete scene
    //   POST   /tours/{tourId}/hotspots                create hotspot
    //   PUT    /tours/hotspot/{hotspotId}              update hotspot
    //   DELETE /tours/hotspot/{hotspotId}              delete hotspot
    case 'tours':
        switch ($method) {
            case 'GET':
                if ($id) Tour360Controller::getOne($id);
                else Tour360Controller::listForListing();
                break;
            case 'POST':
                if ($id && $action === 'hotspots') Tour360Controller::createHotspot($id);
                elseif (!$id) Tour360Controller::createScene();
                else sendJSON(['error' => 'Not found'], 404);
                break;
            case 'PUT':
                if ($id === 'hotspot' && $action) Tour360Controller::updateHotspot($action);
                elseif ($id) Tour360Controller::updateScene($id);
                else sendJSON(['error' => 'ID required'], 400);
                break;
            case 'DELETE':
                if ($id === 'hotspot' && $action) Tour360Controller::deleteHotspot($action);
                elseif ($id) Tour360Controller::deleteScene($id);
                else sendJSON(['error' => 'ID required'], 400);
                break;
            default: sendJSON(['error' => 'Method not allowed'], 405);
        }
        break;

    case 'bookings':
        switch ($method) {
            case 'GET': BookingController::getAll(); break;
            case 'POST': BookingController::create(); break;
            case 'PUT':
                if ($id) BookingController::update($id);
                else sendJSON(['error' => 'ID required'], 400);
                break;
            case 'DELETE':
                if ($id) BookingController::delete($id);
                else sendJSON(['error' => 'ID required'], 400);
                break;
            default: sendJSON(['error' => 'Method not allowed'], 405);
        }
        break;

    case 'orders':
        switch ($method) {
            case 'GET': OrderController::getAll(); break;
            case 'POST': OrderController::create(); break;
            case 'PUT':
                if ($id) OrderController::update($id);
                else sendJSON(['error' => 'ID required'], 400);
                break;
            case 'DELETE':
                if ($id) OrderController::delete($id);
                else sendJSON(['error' => 'ID required'], 400);
                break;
            default: sendJSON(['error' => 'Method not allowed'], 405);
        }
        break;

    case 'contracts':
        switch ($method) {
            case 'GET':
                if ($id && $action === 'pdf') ContractController::getPdf($id);
                elseif ($id) ContractController::getOne($id);
                else ContractController::getAll();
                break;
            case 'POST':
                if ($id && $action === 'accept') ContractController::accept($id);
                else ContractController::create();
                break;
            default: sendJSON(['error' => 'Method not allowed'], 405);
        }
        break;

    case 'admin':
        switch ($method) {
            case 'GET':
                if ($id === 'dashboard') AdminController::dashboard();
                elseif ($id === 'commission-report') AdminController::commissionReport();
                else sendJSON(['error' => 'Not found'], 404);
                break;
            default: sendJSON(['error' => 'Method not allowed'], 405);
        }
        break;

    case 'payouts':
        switch ($method) {
            case 'GET':
                if ($id === 'settings') PayoutController::getSettings();
                else PayoutController::getAll();
                break;
            case 'PUT':
                if ($id === 'settings') PayoutController::updateSettings();
                elseif ($id) PayoutController::updateStatus($id);
                else sendJSON(['error' => 'ID required'], 400);
                break;
            default: sendJSON(['error' => 'Method not allowed'], 405);
        }
        break;

    // ROOT CAUSE FIX — 360° virtual tour panoramas failing to load in
    // Chrome/Web (property/room photos in flat lists were fixed by
    // switching the Flutter web build to the HTML renderer, but that
    // trick only works for plain <img>-style display; the panorama
    // viewer needs the actual decoded pixel bytes to map onto its sphere,
    // which the browser will only hand to JavaScript for a cross-origin
    // request if the response itself carries an Access-Control-Allow-
    // Origin header). Uploaded files under public/uploads/ were being
    // served directly by the PHP dev server as plain static files, which
    // never runs this script and therefore never gets a CORS header. This
    // 'media' resource re-serves the same physical files THROUGH this
    // script instead, so they inherit the exact CORS handling already
    // enforced above for every other endpoint (same SMART_RENT_ALLOWED_
    // ORIGINS whitelist, same credentials handling — nothing duplicated).
    // The Flutter app's ApiConfig.resolveMediaUrl now points at
    // /api/media/... instead of the raw /uploads/... path.
    case 'media':
        if ($method !== 'GET') {
            sendJSON(['error' => 'Method not allowed'], 405);
            break;
        }
        // $id/$action/$subId only capture the first 3 path segments, but a
        // filename never contains '/', so a single segment is always
        // enough here — re-join is only needed if PATH_INFO ever nests.
        $relative = implode('/', array_filter([$id, $action, $subId], fn($p) => $p !== null));
        // Reject any attempt to escape the uploads directory (../, encoded
        // variants, absolute paths) BEFORE touching the filesystem.
        if ($relative === '' || str_contains($relative, '..') || str_starts_with($relative, '/')) {
            sendJSON(['error' => 'Not found'], 404);
            break;
        }
        $uploadsRoot = realpath(__DIR__ . '/../uploads');
        $fullPath = $uploadsRoot ? realpath($uploadsRoot . '/' . $relative) : false;
        // realpath() also fails closed for symlink escapes / non-existent
        // files, and the prefix check ensures the resolved path is still
        // physically inside uploads/ even after symlink resolution.
        if ($uploadsRoot === false || $fullPath === false || !str_starts_with($fullPath, $uploadsRoot) || !is_file($fullPath)) {
            sendJSON(['error' => 'Not found'], 404);
            break;
        }
        $mime = match (strtolower(pathinfo($fullPath, PATHINFO_EXTENSION))) {
            'jpg', 'jpeg', 'jfif' => 'image/jpeg',
            'png' => 'image/png',
            'gif' => 'image/gif',
            'webp' => 'image/webp',
            'svg' => 'image/svg+xml',
            default => 'application/octet-stream',
        };
        header('Content-Type: ' . $mime);
        header('Cache-Control: public, max-age=86400');
        header('Content-Length: ' . filesize($fullPath));
        readfile($fullPath);
        break;

    default:
        sendJSON(['error' => 'Not found'], 404);
    }
} catch (Throwable $e) {
    Logger::error('unhandled exception', [
        'resource' => $resource,
        'id' => $id,
        'exception' => get_class($e),
        'message' => $e->getMessage(),
        'file' => $e->getFile(),
        'line' => $e->getLine(),
    ]);
    error_log('Unhandled API exception: ' . $e->getMessage());
    $appEnv = getenv('APP_ENV') ?: 'development';
    $body = ['error' => 'An unexpected error occurred. Please try again.'];
    if ($appEnv !== 'production') {
        // Detail is useful in development but must never reach a public
        // production response - it can leak schema, paths, or query text.
        $body['debug'] = $e->getMessage();
    }
    sendJSON($body, 500);
}
