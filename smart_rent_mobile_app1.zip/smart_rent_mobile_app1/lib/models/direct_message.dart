class DirectMessage {
  final int id;
  final int senderId;
  final int receiverId;
  final String body;
  final String? listingType;
  final int? listingId;
  final String? readAt;
  final String createdAt;

  DirectMessage({
    required this.id,
    required this.senderId,
    required this.receiverId,
    required this.body,
    this.listingType,
    this.listingId,
    this.readAt,
    required this.createdAt,
  });

  factory DirectMessage.fromJson(Map<String, dynamic> json) {
    return DirectMessage(
      id: json["id"] is int ? json["id"] : int.tryParse("${json["id"]}") ?? 0,
      senderId: json["sender_id"] is int ? json["sender_id"] : int.tryParse("${json["sender_id"]}") ?? 0,
      receiverId: json["receiver_id"] is int ? json["receiver_id"] : int.tryParse("${json["receiver_id"]}") ?? 0,
      body: json["body"]?.toString() ?? "",
      listingType: json["listing_type"]?.toString(),
      listingId: json["listing_id"] == null ? null : (json["listing_id"] is int ? json["listing_id"] : int.tryParse("${json["listing_id"]}")),
      readAt: json["read_at"]?.toString(),
      createdAt: json["created_at"]?.toString() ?? "",
    );
  }
}
