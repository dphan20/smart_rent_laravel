class Conversation {
  final int otherId;
  final String otherName;
  final String otherRole;
  final String lastMessage;
  final String? lastMessageAt;
  final bool lastMessageIsMine;
  final int unreadCount;

  Conversation({
    required this.otherId,
    required this.otherName,
    required this.otherRole,
    required this.lastMessage,
    this.lastMessageAt,
    required this.lastMessageIsMine,
    required this.unreadCount,
  });

  factory Conversation.fromJson(Map<String, dynamic> json) {
    return Conversation(
      otherId: json["other_id"] is int ? json["other_id"] : int.tryParse("${json["other_id"]}") ?? 0,
      otherName: json["other_name"]?.toString() ?? "Unknown",
      otherRole: json["other_role"]?.toString() ?? "",
      lastMessage: json["last_message"]?.toString() ?? "",
      lastMessageAt: json["last_message_at"]?.toString(),
      lastMessageIsMine: json["last_message_is_mine"] == true,
      unreadCount: json["unread_count"] is int ? json["unread_count"] : int.tryParse("${json["unread_count"]}") ?? 0,
    );
  }
}

class ChatContact {
  final int id;
  final String name;
  final String role;

  ChatContact({required this.id, required this.name, required this.role});

  factory ChatContact.fromJson(Map<String, dynamic> json) {
    return ChatContact(
      id: json["id"] is int ? json["id"] : int.tryParse("${json["id"]}") ?? 0,
      name: json["name"]?.toString() ?? "Unknown",
      role: json["role"]?.toString() ?? "",
    );
  }
}
