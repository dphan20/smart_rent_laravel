import "../core/utils/json_parsing.dart";

enum UserRole { admin, landlord, customer, agent }

UserRole roleFromString(String? value) {
  switch ((value ?? "Customer").toLowerCase()) {
    case "admin":
      return UserRole.admin;
    case "landlord":
      return UserRole.landlord;
    case "agent":
      return UserRole.agent;
    default:
      return UserRole.customer;
  }
}

String roleToLabel(UserRole role) {
  switch (role) {
    case UserRole.admin:
      return "Admin";
    case UserRole.landlord:
      return "Landlord";
    case UserRole.agent:
      return "Agent";
    case UserRole.customer:
      return "Customer";
  }
}

/// Mirrors exactly what getCurrentUser()/AuthController::login() return:
/// {id, name, email, phone, type}. Note the backend aliases `full_name` to
/// `name` and `role` to `type` at the SQL layer (see functions.php
/// getCurrentUser()), so those are the JSON keys actually sent over the
/// wire — not full_name/role.
class AppUser {
  final int id;
  final String name;
  final String email;
  final String? phone;
  final UserRole role;

  AppUser({
    required this.id,
    required this.name,
    required this.email,
    this.phone,
    required this.role,
  });

  factory AppUser.fromJson(Map<String, dynamic> json) {
    return AppUser(
      id: parseInt(json["id"]) ?? 0,
      name: parseString(json["name"]) ?? "",
      email: parseString(json["email"]) ?? "",
      phone: parseString(json["phone"]),
      role: roleFromString(parseString(json["type"])),
    );
  }

  AppUser copyWith({String? name, String? email, String? phone}) {
    return AppUser(
      id: id,
      name: name ?? this.name,
      email: email ?? this.email,
      phone: phone ?? this.phone,
      role: role,
    );
  }
}
