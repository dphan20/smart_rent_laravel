import "../core/utils/json_parsing.dart";

/// Mirrors `contracts` joined with landlord_name/customer_name (see
/// Contract::find()/getAllForUser()).
class Contract {
  final int id;
  final String contractNumber;
  final int? bookingId;
  final int? propertyId;
  final int? roomId;
  final int landlordId;
  final int customerId;
  final double monthlyRent;
  final double deposit;
  final String? startDate;
  final String? endDate;
  final String? paymentTerms;
  final String? responsibilities;
  final String? terminationConditions;
  final String? otherTerms;
  final String status; // DRAFT | PENDING_CUSTOMER | ACTIVE | ...
  final String? customerAcceptedAt;
  final String? landlordAcceptedAt;
  final String? createdAt;
  final String? landlordName;
  final String? customerName;

  Contract({
    required this.id,
    required this.contractNumber,
    this.bookingId,
    this.propertyId,
    this.roomId,
    required this.landlordId,
    required this.customerId,
    required this.monthlyRent,
    required this.deposit,
    this.startDate,
    this.endDate,
    this.paymentTerms,
    this.responsibilities,
    this.terminationConditions,
    this.otherTerms,
    required this.status,
    this.customerAcceptedAt,
    this.landlordAcceptedAt,
    this.createdAt,
    this.landlordName,
    this.customerName,
  });

  factory Contract.fromJson(Map<String, dynamic> json) {
    return Contract(
      id: parseInt(json["id"]) ?? 0,
      contractNumber: parseString(json["contract_number"]) ?? "",
      bookingId: parseInt(json["booking_id"]),
      propertyId: parseInt(json["property_id"]),
      roomId: parseInt(json["room_id"]),
      landlordId: parseInt(json["landlord_id"]) ?? 0,
      customerId: parseInt(json["customer_id"]) ?? 0,
      monthlyRent: parseDouble(json["monthly_rent"]) ?? 0,
      deposit: parseDouble(json["deposit"]) ?? 0,
      startDate: parseString(json["start_date"]),
      endDate: parseString(json["end_date"]),
      paymentTerms: parseString(json["payment_terms"]),
      responsibilities: parseString(json["responsibilities"]),
      terminationConditions: parseString(json["termination_conditions"]),
      otherTerms: parseString(json["other_terms"]),
      status: parseString(json["status"]) ?? "DRAFT",
      customerAcceptedAt: parseString(json["customer_accepted_at"]),
      landlordAcceptedAt: parseString(json["landlord_accepted_at"]),
      createdAt: parseString(json["created_at"]),
      landlordName: parseString(json["landlord_name"]),
      customerName: parseString(json["customer_name"]),
    );
  }
}
