import "../core/utils/json_parsing.dart";

/// Mirrors the `payments` table as returned by Payment::getAll()/findById()
/// (includes the joined landlord_id, room_name, location columns).
class Payment {
  final int id;
  final int? bookingId;
  final int? orderId;
  final int? userId;
  final int? landlordId;
  final int? roomId;
  final double amount;
  final double? commissionRate;
  final double? commissionAmount;
  final double? landlordAmount;
  final String paymentMethod;
  final String reference;
  final String status; // pending | successful | failed | cancelled | refunded
  final String? recipientNumber;
  final String? customerName;
  final String? customerEmail;
  final String? customerPhone;
  final String? createdAt;
  final String? roomName;
  final String? location;

  Payment({
    required this.id,
    this.bookingId,
    this.orderId,
    this.userId,
    this.landlordId,
    this.roomId,
    required this.amount,
    this.commissionRate,
    this.commissionAmount,
    this.landlordAmount,
    required this.paymentMethod,
    required this.reference,
    required this.status,
    this.recipientNumber,
    this.customerName,
    this.customerEmail,
    this.customerPhone,
    this.createdAt,
    this.roomName,
    this.location,
  });

  factory Payment.fromJson(Map<String, dynamic> json) {
    return Payment(
      id: parseInt(json["id"]) ?? 0,
      bookingId: parseInt(json["booking_id"]),
      orderId: parseInt(json["order_id"]),
      userId: parseInt(json["user_id"]),
      landlordId: parseInt(json["landlord_id"]),
      roomId: parseInt(json["room_id"]),
      amount: parseDouble(json["amount"]) ?? 0,
      commissionRate: parseDouble(json["commission_rate"]),
      commissionAmount: parseDouble(json["commission_amount"]),
      landlordAmount: parseDouble(json["landlord_amount"]),
      paymentMethod: parseString(json["payment_method"]) ?? "",
      reference: parseString(json["reference"]) ?? "",
      status: parseString(json["status"]) ?? "pending",
      recipientNumber: parseString(json["recipient_number"]),
      customerName: parseString(json["customer_name"]),
      customerEmail: parseString(json["customer_email"]),
      customerPhone: parseString(json["customer_phone"]),
      createdAt: parseString(json["created_at"]),
      roomName: parseString(json["room_name"]),
      location: parseString(json["location"]),
    );
  }
}

/// Payment methods actually wired up in PaymentController/backend config —
/// the app must never invent a method the backend cannot process.
class PaymentMethods {
  PaymentMethods._();
  static const mpesa = "mpesa";
  static const airtelMoney = "airtel_money";
  static const tigoPesa = "tigo_pesa";
  static const haloPesa = "halopesa";
  static const card = "card";

  static const List<Map<String, String>> all = [
    {"value": mpesa, "label": "M-Pesa"},
    {"value": airtelMoney, "label": "Airtel Money"},
    {"value": tigoPesa, "label": "Mixx by Yas / Tigo Pesa"},
    {"value": haloPesa, "label": "HaloPesa"},
    {"value": card, "label": "Visa / Mastercard"},
  ];
}
