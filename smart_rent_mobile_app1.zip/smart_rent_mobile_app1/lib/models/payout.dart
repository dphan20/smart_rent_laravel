import "../core/utils/json_parsing.dart";

/// Mirrors `payouts` (see Payout model / PayoutController). A ledger entry
/// recording money owed (PENDING) or confirmed sent (PAID) to a landlord —
/// this system does not itself move money (see PayoutController docblock).
class Payout {
  final int id;
  final int landlordId;
  final int? paymentId;
  final double amount;
  final String status; // PENDING | PAID | ...
  final String? payoutMethod;
  final String? payoutReference;
  final String? notes;
  final String? createdAt;
  final String? updatedAt;

  Payout({
    required this.id,
    required this.landlordId,
    this.paymentId,
    required this.amount,
    required this.status,
    this.payoutMethod,
    this.payoutReference,
    this.notes,
    this.createdAt,
    this.updatedAt,
  });

  factory Payout.fromJson(Map<String, dynamic> json) {
    return Payout(
      id: parseInt(json["id"]) ?? 0,
      landlordId: parseInt(json["landlord_id"]) ?? 0,
      paymentId: parseInt(json["payment_id"]),
      amount: parseDouble(json["amount"]) ?? 0,
      status: parseString(json["status"]) ?? "PENDING",
      payoutMethod: parseString(json["payout_method"]),
      payoutReference: parseString(json["payout_reference"]),
      notes: parseString(json["notes"]),
      createdAt: parseString(json["created_at"]),
      updatedAt: parseString(json["updated_at"]),
    );
  }

  static const List<String> validStatuses = ["PENDING", "PAID", "FAILED", "CANCELLED"];
}
