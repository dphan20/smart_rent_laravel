/// One turn in the AI chat/matchmaker widget (ChatController::sendMessage,
/// /api/chat and /api/ai/*). Kept local/in-memory + optionally rehydrated
/// from GET /chat/history — the backend is the source of truth for
/// history, this is just the UI-facing shape.
class ChatMessage {
  final String text;
  final bool isUser;
  final DateTime timestamp;
  final List<Map<String, dynamic>>? properties; // AI-matched listings, if any

  ChatMessage({
    required this.text,
    required this.isUser,
    DateTime? timestamp,
    this.properties,
  }) : timestamp = timestamp ?? DateTime.now();
}
