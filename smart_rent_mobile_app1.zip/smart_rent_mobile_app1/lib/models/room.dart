import "dart:convert";

import "../core/config/api_config.dart";
import "../core/utils/json_parsing.dart";

/// Mirrors the `rooms` table exactly (SELECT * FROM rooms — see
/// public/backend/models/Room.php). A "room" is Smart Rents core listing
/// unit; every property also has a matching auto-generated room row (see
/// PropertyController::create()).
///
/// `rooms.image` is a legacy single-path TEXT column that was later
/// overloaded to also carry a JSON-encoded array of paths (multi-image
/// galleries — see Room::saveImageList() / Room::parseImageList() on the
/// backend). Both shapes can be present depending on when the row was
/// created, so this model must accept either — see _decodeImageList below.
/// Treating the column as always-a-single-path (the old behaviour) is why
/// listings saved with a gallery (e.g. multiple photos) rendered with no
/// image at all: the raw JSON-array string ("[\"uploads/...\"]") was passed
/// straight to Image.network() as if it were one file path.
class Room {
  final int id;
  final String? houseId;
  final String title;
  final String location;
  final String? area;
  final double price;
  final int? size;
  final String? type;
  final String rentalMode;
  final int beds;
  final String? badge;
  final String status; // available | booked | ordered | taken
  final List<String> images;
  final int? landlordId;
  final String? virtualTour;
  final String? createdAt;
  final String? updatedAt;

  Room({
    required this.id,
    this.houseId,
    required this.title,
    required this.location,
    this.area,
    required this.price,
    this.size,
    this.type,
    this.rentalMode = "rent",
    required this.beds,
    this.badge,
    required this.status,
    required this.images,
    this.landlordId,
    this.virtualTour,
    this.createdAt,
    this.updatedAt,
  });

  List<String> get imageUrls => images
      .map((i) => ApiConfig.resolveMediaUrl(i))
      .whereType<String>()
      .toList();

  /// Cover photo shown on listing cards (customer home, search, etc).
  String? get imageUrl => imageUrls.isNotEmpty ? imageUrls.first : null;

  bool get isAvailable => status == "available";

  static List<String> _decodeImageList(dynamic raw) {
    if (raw == null) return [];
    if (raw is List) return raw.map((e) => e.toString()).toList();
    if (raw is String) {
      final trimmed = raw.trim();
      if (trimmed.isEmpty) return [];
      if (trimmed.startsWith('[')) {
        try {
          final decoded = jsonDecode(trimmed);
          if (decoded is List) {
            return decoded
                .map((e) => e.toString())
                .where((s) => s.trim().isNotEmpty)
                .toList();
          }
        } catch (_) {
          // Not valid JSON despite the leading '[' — fall through and
          // treat it as a literal (unlikely) path.
        }
      }
      return [trimmed];
    }
    return [];
  }

  factory Room.fromJson(Map<String, dynamic> json) {
    return Room(
      id: parseInt(json["id"]) ?? 0,
      houseId: parseString(json["house_id"]),
      title: parseString(json["title"]) ?? "Untitled listing",
      location: parseString(json["location"]) ?? "",
      area: parseString(json["area"]),
      price: parseDouble(json["price"]) ?? 0,
      size: parseInt(json["size"]),
      type: parseString(json["type"]),
      rentalMode: parseString(json["rental_mode"]) ?? "rent",
      beds: parseInt(json["beds"]) ?? 1,
      badge: parseString(json["badge"]),
      status: parseString(json["status"]) ?? "available",
      images: _decodeImageList(json["image"]),
      landlordId: parseInt(json["landlord_id"]),
      virtualTour: parseString(json["virtual_tour"]),
      createdAt: parseString(json["created_at"]),
      updatedAt: parseString(json["updated_at"]),
    );
  }
}
