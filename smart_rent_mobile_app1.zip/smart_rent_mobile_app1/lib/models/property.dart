import "dart:convert";

import "../core/config/api_config.dart";
import "../core/utils/json_parsing.dart";

/// Mirrors the `properties` table (SELECT * FROM properties — see
/// PropertyController/Property model). `images` and `amenities` are stored
/// as JSON-encoded TEXT columns, so they arrive as JSON *strings* that
/// need a second decode step, not as native JSON arrays/objects.
class Property {
  final int id;
  final String? sri;
  final String? houseId;
  final int landlordId;
  final String name;
  final String? type;
  final String rentalMode;
  final String? apartment;
  final String? houseNo;
  final String? region;
  final String? district;
  final String? ward;
  final String? street;
  final String? location;
  final String? coords;
  final String? description;
  final int bedrooms;
  final int bathrooms;
  final Map<String, dynamic> amenities;
  final String? furnished;
  final int? roomSize;
  final double monthlyRent;
  final double? deposit;
  final double? serviceCharge;
  final String availability; // available | booked | taken
  final List<String> images;
  final String? video;
  final String? virtualTour;
  final String? createdAt;

  Property({
    required this.id,
    this.sri,
    this.houseId,
    required this.landlordId,
    required this.name,
    this.type,
    this.rentalMode = "rent",
    this.apartment,
    this.houseNo,
    this.region,
    this.district,
    this.ward,
    this.street,
    this.location,
    this.coords,
    this.description,
    required this.bedrooms,
    required this.bathrooms,
    required this.amenities,
    this.furnished,
    this.roomSize,
    required this.monthlyRent,
    this.deposit,
    this.serviceCharge,
    required this.availability,
    required this.images,
    this.video,
    this.virtualTour,
    this.createdAt,
  });

  List<String> get imageUrls => images
      .map((i) => ApiConfig.resolveMediaUrl(i))
      .whereType<String>()
      .toList();

  String? get coverImageUrl => imageUrls.isNotEmpty ? imageUrls.first : null;

  String get fullAddress => [region, district, ward, street]
      .where((e) => e != null && e.trim().isNotEmpty)
      .join(", ");

  static List<String> _decodeStringList(dynamic raw) {
    if (raw == null) return [];
    if (raw is List) return raw.map((e) => e.toString()).toList();
    if (raw is String && raw.trim().isNotEmpty) {
      try {
        final decoded = jsonDecode(raw);
        if (decoded is List) return decoded.map((e) => e.toString()).toList();
      } catch (_) {
        // Not JSON — ignore rather than crash on a malformed legacy value.
      }
    }
    return [];
  }

  static Map<String, dynamic> _decodeAmenities(dynamic raw) {
    if (raw == null) return {};
    if (raw is Map) return Map<String, dynamic>.from(raw);
    if (raw is String && raw.trim().isNotEmpty) {
      try {
        final decoded = jsonDecode(raw);
        if (decoded is Map) return Map<String, dynamic>.from(decoded);
        // Some legacy rows store amenities as a plain JSON array of
        // strings (e.g. ["parking","security"]) instead of a map of
        // booleans — normalize both shapes into {key: true}.
        if (decoded is List) {
          return {for (final item in decoded) item.toString(): true};
        }
      } catch (_) {}
    }
    return {};
  }

  factory Property.fromJson(Map<String, dynamic> json) {
    return Property(
      id: parseInt(json["id"]) ?? 0,
      sri: parseString(json["sri"]),
      houseId: parseString(json["house_id"]),
      landlordId: parseInt(json["landlord_id"]) ?? 0,
      name: parseString(json["name"]) ?? "Untitled property",
      type: parseString(json["type"]),
      rentalMode: parseString(json["rental_mode"]) ?? "rent",
      apartment: parseString(json["apartment"]),
      houseNo: parseString(json["house_no"]),
      region: parseString(json["region"]),
      district: parseString(json["district"]),
      ward: parseString(json["ward"]),
      street: parseString(json["street"]),
      location: parseString(json["location"]),
      coords: parseString(json["coords"]),
      description: parseString(json["description"]),
      bedrooms: parseInt(json["bedrooms"]) ?? 0,
      bathrooms: parseInt(json["bathrooms"]) ?? 0,
      amenities: _decodeAmenities(json["amenities"]),
      furnished: parseString(json["furnished"]),
      roomSize: parseInt(json["room_size"]),
      monthlyRent: parseDouble(json["monthly_rent"]) ?? 0,
      deposit: parseDouble(json["deposit"]),
      serviceCharge: parseDouble(json["service_charge"]),
      availability: parseString(json["availability"]) ?? "available",
      images: _decodeStringList(json["images"]),
      video: parseString(json["video"]),
      virtualTour: parseString(json["virtual_tour"]),
      createdAt: parseString(json["created_at"]),
    );
  }
}
