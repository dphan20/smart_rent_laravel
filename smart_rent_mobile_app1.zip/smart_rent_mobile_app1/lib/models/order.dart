import "../core/utils/json_parsing.dart";

/// Mirrors `orders` — an unpaid reservation request a Landlord/Admin must
/// confirm before it becomes a Contract (see OrderController::update(),
/// which auto-generates a Contract on status="confirmed").
class RoomOrder {
  final int id;
  final int roomId;
  final int? userId;
  final int? landlordId;
  final String? customerName;
  final String? customerEmail;
  final String? customerPhone;
  final String? arrivalDate;
  final String status; // ordered | confirmed | cancelled
  final String? createdAt;

  RoomOrder({
    required this.id,
    required this.roomId,
    this.userId,
    this.landlordId,
    this.customerName,
    this.customerEmail,
    this.customerPhone,
    this.arrivalDate,
    required this.status,
    this.createdAt,
  });

  factory RoomOrder.fromJson(Map<String, dynamic> json) {
    return RoomOrder(
      id: parseInt(json["id"]) ?? 0,
      roomId: parseInt(json["room_id"]) ?? 0,
      userId: parseInt(json["user_id"]),
      landlordId: parseInt(json["landlord_id"]),
      customerName: parseString(json["customer_name"]),
      customerEmail: parseString(json["customer_email"]),
      customerPhone: parseString(json["customer_phone"]),
      arrivalDate: parseString(json["arrival_date"]),
      status: parseString(json["status"]) ?? "ordered",
      createdAt: parseString(json["created_at"]),
    );
  }
}
