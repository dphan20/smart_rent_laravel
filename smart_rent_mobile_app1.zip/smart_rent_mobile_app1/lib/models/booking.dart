import "../core/utils/json_parsing.dart";

/// Mirrors `bookings` joined with room title/location/price (see
/// Booking::getAll() — LEFT JOIN rooms). A booking in this system always
/// represents an already-paid reservation (see BookingController::create()
/// docblock); an unpaid interest is instead an Order.
class Booking {
  final int id;
  final int roomId;
  final int? userId;
  final int? landlordId;
  final String? customerName;
  final String? customerEmail;
  final String? customerPhone;
  final double? amount;
  final String? arrivalDate;
  final String rentalMode;
  final String status; // pending | confirmed | cancelled
  final String? paymentRef;
  final String? createdAt;
  final String? roomTitle;
  final String? roomLocation;
  final double? roomPrice;

  Booking({
    required this.id,
    required this.roomId,
    this.userId,
    this.landlordId,
    this.customerName,
    this.customerEmail,
    this.customerPhone,
    this.amount,
    this.arrivalDate,
    this.rentalMode = "holiday",
    required this.status,
    this.paymentRef,
    this.createdAt,
    this.roomTitle,
    this.roomLocation,
    this.roomPrice,
  });

  factory Booking.fromJson(Map<String, dynamic> json) {
    return Booking(
      id: parseInt(json["id"]) ?? 0,
      roomId: parseInt(json["room_id"]) ?? 0,
      userId: parseInt(json["user_id"]),
      landlordId: parseInt(json["landlord_id"]),
      customerName: parseString(json["customer_name"]),
      customerEmail: parseString(json["customer_email"]),
      customerPhone: parseString(json["customer_phone"]),
      amount: parseDouble(json["amount"]),
      arrivalDate: parseString(json["arrival_date"]),
      rentalMode: parseString(json["rental_mode"]) ?? "holiday",
      status: parseString(json["status"]) ?? "pending",
      paymentRef: parseString(json["payment_ref"]),
      createdAt: parseString(json["created_at"]),
      roomTitle: parseString(json["room_title"]),
      roomLocation: parseString(json["room_location"]),
      roomPrice: parseDouble(json["room_price"]),
    );
  }
}
