import "../core/config/api_config.dart";
import "../core/utils/json_parsing.dart";

enum HotspotType { navigation, viewpoint, info }

HotspotType hotspotTypeFromString(String? value) {
  switch (value) {
    case "navigation":
      return HotspotType.navigation;
    case "viewpoint":
      return HotspotType.viewpoint;
    default:
      return HotspotType.info;
  }
}

String hotspotTypeToString(HotspotType type) {
  switch (type) {
    case HotspotType.navigation:
      return "navigation";
    case HotspotType.viewpoint:
      return "viewpoint";
    case HotspotType.info:
      return "info";
  }
}

/// One hotspot marker placed on a Tour360Scene panorama. Mirrors
/// `property_360_hotspots` exactly (see Tour360Controller/Tour360 model).
///
/// - navigation: tapping it loads targetTourId as the new active scene.
/// - viewpoint: tapping it re-orients the SAME panorama to
///   (targetYaw, targetPitch, targetHfov) instead of loading a new scene.
/// - info: shown as a plain label/tooltip, no navigation action.
class Tour360Hotspot {
  final int id;
  final int tourId;
  final int? targetTourId;
  final double? targetYaw;
  final double? targetPitch;
  final double? targetHfov;
  final HotspotType type;
  final double yaw;
  final double pitch;
  final String? title;
  final String? description;

  Tour360Hotspot({
    required this.id,
    required this.tourId,
    this.targetTourId,
    this.targetYaw,
    this.targetPitch,
    this.targetHfov,
    required this.type,
    required this.yaw,
    required this.pitch,
    this.title,
    this.description,
  });

  factory Tour360Hotspot.fromJson(Map<String, dynamic> json) {
    return Tour360Hotspot(
      id: parseInt(json["id"]) ?? 0,
      tourId: parseInt(json["tour_id"]) ?? 0,
      targetTourId: parseInt(json["target_tour_id"]),
      targetYaw: parseDouble(json["target_yaw"]),
      targetPitch: parseDouble(json["target_pitch"]),
      targetHfov: parseDouble(json["target_hfov"]),
      type: hotspotTypeFromString(parseString(json["type"])),
      yaw: parseDouble(json["yaw"]) ?? 0,
      pitch: parseDouble(json["pitch"]) ?? 0,
      title: parseString(json["title"]),
      description: parseString(json["description"]),
    );
  }
}

/// One 360° panorama scene, belonging to a room or property. Mirrors
/// `property_360_tours` (see Tour360Controller::listForListing() /
/// Tour360::fullTourForListing(), which embeds `hotspots` on each scene).
class Tour360Scene {
  final int id;
  final String listingType; // "room" | "property"
  final int listingId;
  final String name;
  final String image;
  final String? description;
  final bool isPrimary;
  final int? createdBy;
  final List<Tour360Hotspot> hotspots;

  Tour360Scene({
    required this.id,
    required this.listingType,
    required this.listingId,
    required this.name,
    required this.image,
    this.description,
    required this.isPrimary,
    this.createdBy,
    required this.hotspots,
  });

  String? get imageUrl => ApiConfig.resolveMediaUrl(image);

  factory Tour360Scene.fromJson(Map<String, dynamic> json) {
    final rawHotspots = json["hotspots"];
    return Tour360Scene(
      id: parseInt(json["id"]) ?? 0,
      listingType: parseString(json["listing_type"]) ?? "room",
      listingId: parseInt(json["listing_id"]) ?? 0,
      name: parseString(json["name"]) ?? "Scene",
      image: parseString(json["image"]) ?? "",
      description: parseString(json["description"]),
      isPrimary: parseBool(json["is_primary"]),
      createdBy: parseInt(json["created_by"]),
      hotspots: rawHotspots is List
          ? rawHotspots
              .map((h) => Tour360Hotspot.fromJson(Map<String, dynamic>.from(h)))
              .toList()
          : <Tour360Hotspot>[],
    );
  }
}
