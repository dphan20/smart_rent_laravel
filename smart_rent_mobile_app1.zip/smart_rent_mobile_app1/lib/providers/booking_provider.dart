import "package:flutter/foundation.dart";

import "../core/network/api_exception.dart";
import "../models/booking.dart";
import "../repositories/booking_repository.dart";
import "view_state.dart";

class BookingProvider extends ChangeNotifier {
  final BookingRepository _repo;
  BookingProvider(this._repo);

  ViewStatus status = ViewStatus.initial;
  List<Booking> bookings = [];
  String? errorMessage;
  bool isSubmitting = false;

  Future<void> load() async {
    status = ViewStatus.loading;
    notifyListeners();
    try {
      final result = await _repo.getAll();
      bookings = result;
      status = result.isEmpty ? ViewStatus.empty : ViewStatus.loaded;
    } on ApiException catch (e) {
      errorMessage = e.message;
      status = ViewStatus.error;
    } finally {
      notifyListeners();
    }
  }

  Future<Map<String, dynamic>?> submitBooking({
    required int roomId,
    required String customerName,
    required String customerEmail,
    required String customerPhone,
    required double amount,
    String? paymentMethod,
    String? reference,
    String? recipientNumber,
    String? arrivalDate,
    String rentalMode = "holiday",
    String? paymentTerms,
    String? responsibilities,
    String? terminationConditions,
    String? otherTerms,
  }) async {
    isSubmitting = true;
    errorMessage = null;
    notifyListeners();
    try {
      final result = await _repo.create(
        roomId: roomId,
        customerName: customerName,
        customerEmail: customerEmail,
        customerPhone: customerPhone,
        amount: amount,
        paymentMethod: paymentMethod,
        reference: reference,
        recipientNumber: recipientNumber,
        arrivalDate: arrivalDate,
        rentalMode: rentalMode,
        paymentTerms: paymentTerms,
        responsibilities: responsibilities,
        terminationConditions: terminationConditions,
        otherTerms: otherTerms,
      );
      return result;
    } on ApiException catch (e) {
      errorMessage = e.message;
      return null;
    } finally {
      isSubmitting = false;
      notifyListeners();
    }
  }
}
