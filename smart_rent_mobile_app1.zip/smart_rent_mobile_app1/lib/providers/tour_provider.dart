import "package:flutter/foundation.dart";

import "../core/network/api_exception.dart";
import "../models/tour360.dart";
import "../repositories/tour_repository.dart";
import "view_state.dart";

/// Backs the 360° Virtual Tour viewer AND the Admin/Landlord tour+hotspot
/// manager (they share this provider since both operate on the exact same
/// real backend records — requirement #46/#47 cross-platform consistency).
class TourProvider extends ChangeNotifier {
  final TourRepository _repo;
  TourProvider(this._repo);

  ViewStatus status = ViewStatus.initial;
  List<Tour360Scene> scenes = [];
  String? errorMessage;
  int? _activeSceneId;

  int? get activeSceneId => _activeSceneId;
  Tour360Scene? get activeScene {
    if (scenes.isEmpty) return null;
    if (_activeSceneId == null) {
      return scenes.firstWhere((s) => s.isPrimary, orElse: () => scenes.first);
    }
    return scenes.firstWhere((s) => s.id == _activeSceneId, orElse: () => scenes.first);
  }

  Future<void> load({required String listingType, required int listingId}) async {
    status = ViewStatus.loading;
    _activeSceneId = null;
    notifyListeners();
    try {
      final result = await _repo.getTourForListing(listingType: listingType, listingId: listingId);
      scenes = result;
      status = result.isEmpty ? ViewStatus.empty : ViewStatus.loaded;
    } on ApiException catch (e) {
      errorMessage = e.message;
      status = ViewStatus.error;
    } finally {
      notifyListeners();
    }
  }

  /// Called when the customer taps a navigation hotspot: stays inside the
  /// SAME viewer, just swaps which real backend scene is displayed
  /// (requirement #15 — never a fake dialog/demo scene/unrelated redirect).
  void goToScene(int tourId) {
    if (scenes.any((s) => s.id == tourId)) {
      _activeSceneId = tourId;
      notifyListeners();
    }
  }

  Future<void> refreshAfterEdit({required String listingType, required int listingId}) =>
      load(listingType: listingType, listingId: listingId);
}
