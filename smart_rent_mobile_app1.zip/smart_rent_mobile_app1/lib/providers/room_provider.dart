import "package:flutter/foundation.dart";

import "../core/network/api_exception.dart";
import "../models/room.dart";
import "../repositories/room_repository.dart";
import "view_state.dart";

/// Backs the customer Home / Properties / Rooms / Search screens. Always
/// loads real rows from RoomController — never static demo data
/// (requirement #9).
class RoomProvider extends ChangeNotifier {
  final RoomRepository _repo;
  RoomProvider(this._repo);

  ViewStatus status = ViewStatus.initial;
  List<Room> rooms = [];
  String? errorMessage;

  // Current filter/search state, so re-fetching (e.g. pull-to-refresh)
  // reapplies whatever the user last searched for.
  String? search;
  String? type;
  double? maxPrice;
  String? sort;

  Future<void> load({bool silent = false}) async {
    if (!silent) status = ViewStatus.loading;
    notifyListeners();
    try {
      final result = await _repo.getAll(
        search: search,
        type: type,
        maxPrice: maxPrice,
        sort: sort,
      );
      rooms = result;
      status = result.isEmpty ? ViewStatus.empty : ViewStatus.loaded;
    } on ApiException catch (e) {
      errorMessage = e.message;
      status = ViewStatus.error;
    } finally {
      notifyListeners();
    }
  }

  Future<void> applyFilters({String? search, String? type, double? maxPrice, String? sort}) async {
    this.search = search;
    this.type = type;
    this.maxPrice = maxPrice;
    this.sort = sort;
    await load();
  }

  Future<Room> loadOne(int id) => _repo.getOne(id);
}
