import "package:flutter/foundation.dart";

import "../core/network/api_exception.dart";
import "../core/storage/local_prefs.dart";
import "../models/user.dart";
import "../repositories/auth_repository.dart";

enum AuthStatus { unknown, authenticated, unauthenticated }

/// Single source of truth for "who is logged in" across the whole app.
/// AuthStatus.unknown is the state while restoring the session on launch
/// (requirement #37) — screens should show a splash/loading UI, not assume
/// logged-out, while this is unknown.
class AuthProvider extends ChangeNotifier {
  final AuthRepository _repo;
  AuthProvider(this._repo);

  AuthStatus status = AuthStatus.unknown;
  AppUser? user;
  String? error;
  bool isBusy = false;

  bool get isLoggedIn => status == AuthStatus.authenticated && user != null;
  UserRole? get role => user?.role;

  Future<void> restoreSession() async {
    // A single dropped/slow request (a common first-request-after-reload
    // hiccup, especially on web) must not be treated the same as the
    // backend genuinely saying "you're not logged in" — that conflation is
    // what was logging users out on every page refresh. Retry transient
    // failures a couple of times before accepting defeat; only an explicit
    // "not logged in" response (or repeated failure) clears the session.
    const maxAttempts = 3;
    for (var attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        final restoredUser = await _repo.checkSession();
        if (restoredUser != null) {
          user = restoredUser;
          status = AuthStatus.authenticated;
          await LocalPrefs.setLastKnownRole(roleToLabel(restoredUser.role));
        } else {
          // The backend responded and explicitly said "not logged in" —
          // this is a real logout, not a network hiccup.
          status = AuthStatus.unauthenticated;
        }
        notifyListeners();
        return;
      } catch (_) {
        if (attempt == maxAttempts) {
          status = AuthStatus.unauthenticated;
          notifyListeners();
          return;
        }
        await Future.delayed(Duration(milliseconds: 400 * attempt));
      }
    }
  }

  Future<bool> login(String email, String password, {bool remember = true}) async {
    isBusy = true;
    error = null;
    notifyListeners();
    try {
      final loggedInUser = await _repo.login(email: email, password: password, remember: remember);
      user = loggedInUser;
      status = AuthStatus.authenticated;
      await LocalPrefs.setRememberedEmail(email);
      await LocalPrefs.setLastKnownRole(roleToLabel(loggedInUser.role));
      return true;
    } on ApiException catch (e) {
      error = e.message;
      return false;
    } finally {
      isBusy = false;
      notifyListeners();
    }
  }

  Future<bool> signup({
    required String name,
    required String email,
    required String password,
    String? phone,
    required String type,
  }) async {
    isBusy = true;
    error = null;
    notifyListeners();
    try {
      final newUser = await _repo.signup(name: name, email: email, password: password, phone: phone, type: type);
      user = newUser;
      status = AuthStatus.authenticated;
      await LocalPrefs.setRememberedEmail(email);
      await LocalPrefs.setLastKnownRole(roleToLabel(newUser.role));
      return true;
    } on ApiException catch (e) {
      error = e.message;
      return false;
    } finally {
      isBusy = false;
      notifyListeners();
    }
  }

  Future<void> logout() async {
    isBusy = true;
    notifyListeners();
    try {
      await _repo.logout();
    } catch (_) {
      // Even if the network call fails, clear local state — the user
      // explicitly asked to log out and must not be stuck "logged in" on
      // this device.
    } finally {
      user = null;
      status = AuthStatus.unauthenticated;
      await LocalPrefs.clearAll();
      isBusy = false;
      notifyListeners();
    }
  }

  Future<bool> updateProfile({required String name, required String email, String? phone}) async {
    isBusy = true;
    error = null;
    notifyListeners();
    try {
      user = await _repo.updateProfile(name: name, email: email, phone: phone);
      return true;
    } on ApiException catch (e) {
      error = e.message;
      return false;
    } finally {
      isBusy = false;
      notifyListeners();
    }
  }

  Future<bool> changePassword(String current, String newPass) async {
    isBusy = true;
    error = null;
    notifyListeners();
    try {
      await _repo.changePassword(currentPassword: current, newPassword: newPass);
      return true;
    } on ApiException catch (e) {
      error = e.message;
      return false;
    } finally {
      isBusy = false;
      notifyListeners();
    }
  }
}
