import "dart:async";
import "package:flutter/foundation.dart";

import "../core/network/api_exception.dart";
import "../models/conversation.dart";
import "../models/direct_message.dart";
import "../repositories/messaging_repository.dart";
import "view_state.dart";

class ConversationsProvider extends ChangeNotifier {
  final MessagingRepository _repo;
  ConversationsProvider(this._repo);

  ViewStatus status = ViewStatus.initial;
  List<Conversation> conversations = [];
  String? errorMessage;
  Timer? _pollTimer;

  int get totalUnread => conversations.fold(0, (sum, c) => sum + c.unreadCount);

  Future<void> load({bool silent = false}) async {
    if (!silent) status = ViewStatus.loading;
    notifyListeners();
    try {
      final result = await _repo.getConversations();
      conversations = result;
      status = result.isEmpty ? ViewStatus.empty : ViewStatus.loaded;
    } on ApiException catch (e) {
      errorMessage = e.message;
      status = ViewStatus.error;
    } finally {
      notifyListeners();
    }
  }

  void startPolling({Duration interval = const Duration(seconds: 8)}) {
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(interval, (_) => load(silent: true));
  }

  void stopPolling() {
    _pollTimer?.cancel();
    _pollTimer = null;
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    super.dispose();
  }
}

class ChatThreadProvider extends ChangeNotifier {
  final MessagingRepository _repo;
  final int otherId;
  ChatThreadProvider(this._repo, this.otherId);

  ViewStatus status = ViewStatus.initial;
  List<DirectMessage> messages = [];
  String? errorMessage;
  bool isSending = false;
  Timer? _pollTimer;

  Future<void> load({bool silent = false}) async {
    if (!silent) status = ViewStatus.loading;
    notifyListeners();
    try {
      final result = await _repo.getThread(otherId);
      messages = result;
      status = ViewStatus.loaded;
    } on ApiException catch (e) {
      errorMessage = e.message;
      status = ViewStatus.error;
    } finally {
      notifyListeners();
    }
  }

  Future<bool> send(String text, {String? listingType, int? listingId}) async {
    if (text.trim().isEmpty) return false;
    isSending = true;
    notifyListeners();
    try {
      await _repo.sendMessage(
        receiverId: otherId,
        message: text.trim(),
        listingType: listingType,
        listingId: listingId,
      );
      await load(silent: true);
      return true;
    } on ApiException catch (e) {
      errorMessage = e.message;
      return false;
    } finally {
      isSending = false;
      notifyListeners();
    }
  }

  void startPolling({Duration interval = const Duration(seconds: 4)}) {
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(interval, (_) => load(silent: true));
  }

  void stopPolling() {
    _pollTimer?.cancel();
    _pollTimer = null;
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    super.dispose();
  }
}
