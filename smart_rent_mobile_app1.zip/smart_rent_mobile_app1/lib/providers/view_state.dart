/// Every API-driven screen must show Loading / Success / Empty / Error
/// (requirement #28) — this enum plus AsyncListProvider give every screen
/// the same four states instead of reinventing them.
enum ViewStatus { initial, loading, loaded, empty, error }
