import "package:flutter/foundation.dart";

import "../core/network/api_exception.dart";
import "../models/property.dart";
import "../repositories/property_repository.dart";
import "view_state.dart";

class PropertyProvider extends ChangeNotifier {
  final PropertyRepository _repo;
  PropertyProvider(this._repo);

  ViewStatus status = ViewStatus.initial;
  List<Property> properties = [];
  String? errorMessage;

  Future<void> load({int? landlordId, bool silent = false}) async {
    if (!silent) status = ViewStatus.loading;
    notifyListeners();
    try {
      final result = await _repo.getAll(landlordId: landlordId);
      properties = result;
      status = result.isEmpty ? ViewStatus.empty : ViewStatus.loaded;
    } on ApiException catch (e) {
      errorMessage = e.message;
      status = ViewStatus.error;
    } finally {
      notifyListeners();
    }
  }
}
