import "dart:async";

import "package:flutter/foundation.dart";

import "../core/network/network_info.dart";

/// Tracks device connectivity app-wide so screens can show an offline
/// banner instead of misreporting the backend as broken (requirement #29).
class ConnectivityProvider extends ChangeNotifier {
  bool isOnline = true;
  StreamSubscription<bool>? _sub;

  ConnectivityProvider() {
    _init();
  }

  Future<void> _init() async {
    isOnline = await NetworkInfo.isConnected;
    notifyListeners();
    _sub = NetworkInfo.onStatusChange.listen((online) {
      isOnline = online;
      notifyListeners();
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }
}
