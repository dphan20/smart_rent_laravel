import "package:flutter/material.dart";

import "../../../core/theme/app_theme.dart";
import "../../../core/utils/formatters.dart";
import "../../../models/contract.dart";
import "../../../repositories/contract_repository.dart";
import "../../../widgets/state_views.dart";

class ContractsScreen extends StatefulWidget {
  const ContractsScreen({super.key});

  @override
  State<ContractsScreen> createState() => _ContractsScreenState();
}

class _ContractsScreenState extends State<ContractsScreen> {
  final _repo = ContractRepository();
  late Future<List<Contract>> _future;

  @override
  void initState() {
    super.initState();
    _future = _repo.getAll();
  }

  void _reload() => setState(() => _future = _repo.getAll());

  Future<void> _approve(Contract contract) async {
    try {
      await _repo.accept(contract.id);
      if (!mounted) return;
      _reload();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Contract approval recorded")),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error.toString())),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Contracts")),
      body: FutureBuilder<List<Contract>>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const LoadingView(message: "Loading contracts...");
          }
          if (snapshot.hasError) {
            return ErrorView(message: snapshot.error.toString(), onRetry: _reload);
          }
          final contracts = snapshot.data ?? const <Contract>[];
          if (contracts.isEmpty) {
            return const EmptyView(message: "No rental contracts yet.", icon: Icons.description_outlined);
          }
          return RefreshIndicator(
            onRefresh: () async => _reload(),
            child: ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: contracts.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (context, index) {
                final contract = contracts[index];
                final awaitingApproval = contract.status == "PENDING_CUSTOMER" || contract.status == "PENDING_LANDLORD";
                return Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(contract.contractNumber, style: const TextStyle(fontWeight: FontWeight.w700)),
                            ),
                            Text(contract.status, style: const TextStyle(color: AppTheme.primary, fontWeight: FontWeight.w700, fontSize: 12)),
                          ],
                        ),
                        const SizedBox(height: 10),
                        _row("Monthly rent", Formatters.money(contract.monthlyRent)),
                        _row("Deposit", Formatters.money(contract.deposit)),
                        _row("Start", contract.startDate ?? "Not set"),
                        _row("End", contract.endDate ?? "Not set"),
                        _row("Landlord", contract.landlordName ?? "Not available"),
                        _row("Tenant", contract.customerName ?? "Not available"),
                        if (contract.paymentTerms != null && contract.paymentTerms!.trim().isNotEmpty)
                          _row("Payment terms", contract.paymentTerms!),
                        if (awaitingApproval) ...[
                          const SizedBox(height: 10),
                          SizedBox(
                            width: double.infinity,
                            child: ElevatedButton.icon(
                              onPressed: () => _approve(contract),
                              icon: const Icon(Icons.draw_outlined),
                              label: const Text("Approve contract"),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }

  Widget _row(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Text("$label: $value", style: const TextStyle(fontSize: 12)),
    );
  }
}
