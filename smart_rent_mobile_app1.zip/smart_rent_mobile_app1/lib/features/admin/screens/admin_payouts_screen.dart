import "package:flutter/material.dart";

import "../../../core/network/api_exception.dart";
import "../../../core/theme/app_theme.dart";
import "../../../core/utils/formatters.dart";
import "../../../models/payout.dart";
import "../../../repositories/payout_repository.dart";
import "../../../widgets/state_views.dart";
import "../../../widgets/status_badge.dart";

/// Admin ledger view over PayoutController — updates status via the real
/// PUT /payouts/{id} endpoint. This system only records what is owed/paid;
/// it never moves money itself (matching PayoutController\u0027s own docblock).
class AdminPayoutsScreen extends StatefulWidget {
  const AdminPayoutsScreen({super.key});

  @override
  State<AdminPayoutsScreen> createState() => _AdminPayoutsScreenState();
}

class _AdminPayoutsScreenState extends State<AdminPayoutsScreen> {
  final _repo = PayoutRepository();
  late Future<List<Payout>> _future;

  @override
  void initState() {
    super.initState();
    _future = _repo.getAll();
  }

  void _reload() => setState(() => _future = _repo.getAll());

  Future<void> _markPaid(Payout payout) async {
    try {
      await _repo.updateStatus(payout.id, status: "PAID");
      _reload();
    } on ApiException catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Payouts")),
      body: RefreshIndicator(
        color: AppTheme.primary,
        onRefresh: () async => _reload(),
        child: FutureBuilder<List<Payout>>(
          future: _future,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) return const LoadingView();
            if (snapshot.hasError) {
              final message = snapshot.error is ApiException ? (snapshot.error as ApiException).message : "Unable to load payouts.";
              return ListView(children: [const SizedBox(height: 80), ErrorView(message: message, onRetry: _reload)]);
            }
            final payouts = snapshot.data ?? [];
            if (payouts.isEmpty) {
              return ListView(children: const [SizedBox(height: 80), EmptyView(message: "No payouts recorded yet.", icon: Icons.payments_outlined)]);
            }
            return ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: payouts.length,
              itemBuilder: (context, index) {
                final payout = payouts[index];
                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text("Landlord #${payout.landlordId}", style: const TextStyle(fontWeight: FontWeight.w700)),
                              const SizedBox(height: 4),
                              Text(Formatters.money(payout.amount), style: const TextStyle(color: AppTheme.primary, fontWeight: FontWeight.w600)),
                            ],
                          ),
                        ),
                        StatusBadge(status: payout.status),
                        if (payout.status.toUpperCase() == "PENDING") ...[
                          const SizedBox(width: 8),
                          TextButton(onPressed: () => _markPaid(payout), child: const Text("Mark paid")),
                        ],
                      ],
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
