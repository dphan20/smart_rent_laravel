import "package:flutter/material.dart";

import "../../../core/network/api_exception.dart";
import "../../../core/theme/app_theme.dart";
import "../../../core/utils/formatters.dart";
import "../../../repositories/admin_repository.dart";
import "../../../widgets/state_views.dart";

class AdminDashboardScreen extends StatefulWidget {
  const AdminDashboardScreen({super.key});

  @override
  State<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen> {
  final _repo = AdminRepository();
  late Future<Map<String, dynamic>> _future;

  @override
  void initState() {
    super.initState();
    _future = _repo.getDashboard();
  }

  void _reload() => setState(() => _future = _repo.getDashboard());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Admin Dashboard")),
      body: RefreshIndicator(
        color: AppTheme.primary,
        onRefresh: () async => _reload(),
        child: FutureBuilder<Map<String, dynamic>>(
          future: _future,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) return const LoadingView();
            if (snapshot.hasError) {
              final message = snapshot.error is ApiException ? (snapshot.error as ApiException).message : "Unable to load dashboard.";
              return ListView(children: [const SizedBox(height: 80), ErrorView(message: message, onRetry: _reload)]);
            }
            final data = snapshot.data ?? {};
            return GridView.count(
              padding: const EdgeInsets.all(16),
              crossAxisCount: 2,
              mainAxisSpacing: 14,
              crossAxisSpacing: 14,
              childAspectRatio: 1.4,
              children: [
                _kpi("Total Users", data["users_count"] ?? data["total_users"] ?? "—", Icons.people_rounded),
                _kpi("Properties", data["properties_count"] ?? data["total_properties"] ?? "—", Icons.apartment_rounded),
                _kpi("Rooms", data["rooms_count"] ?? data["total_rooms"] ?? "—", Icons.meeting_room_rounded),
                _kpi("Bookings", data["bookings_count"] ?? data["total_bookings"] ?? "—", Icons.event_note_rounded),
                _kpi("Revenue", Formatters.money(_asNum(data["total_revenue"] ?? data["gross_revenue"])), Icons.attach_money_rounded),
                _kpi("Commission earned", Formatters.money(_asNum(data["total_commission"] ?? data["commission_earned"])), Icons.percent_rounded),
              ],
            );
          },
        ),
      ),
    );
  }

  num? _asNum(dynamic v) => v is num ? v : num.tryParse(v?.toString() ?? "");

  Widget _kpi(String label, dynamic value, IconData icon) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: AppTheme.primary),
            const Spacer(),
            Text("$value", style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Text(label, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
          ],
        ),
      ),
    );
  }
}
