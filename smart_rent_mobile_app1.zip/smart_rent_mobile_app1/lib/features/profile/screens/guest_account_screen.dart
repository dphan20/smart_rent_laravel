import "package:flutter/material.dart";

import "../../../core/theme/app_theme.dart";
import "../../../core/theme/brand_mark.dart";
import "../../authentication/screens/login_screen.dart";
import "../../authentication/screens/signup_screen.dart";

/// Shown in the "Account" tab for guests (requirement #17/#32) — browsing
/// never requires an account, but there must still be an obvious, always
/// visible way to sign in or register instead of authentication being
/// forced up front. Reaching a protected action (Book Now, etc.) as a
/// guest goes through core/utils/auth_gate.dart instead of this screen.
class GuestAccountScreen extends StatelessWidget {
  const GuestAccountScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Account")),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const BrandMark(size: 56),
              const SizedBox(height: 20),
              const Text(
                "You're browsing as a guest",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: AppTheme.textPrimary),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              const Text(
                "Sign in or create a free account to book rooms, message landlords, and track your bookings.",
                style: TextStyle(color: AppTheme.textSecondary, fontSize: 14),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 28),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const LoginScreen()),
                  ),
                  child: const Text("Sign In"),
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const SignupScreen()),
                  ),
                  child: const Text("Create Account"),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
