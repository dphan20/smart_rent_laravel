import "package:flutter/material.dart";

import "../../../core/config/api_config.dart";
import "../../../core/network/api_exception.dart";
import "../../../core/theme/app_theme.dart";
import "../../../core/utils/formatters.dart";
import "../../../models/chat_message.dart";
import "../../../repositories/ai_repository.dart";
import "../../../widgets/network_image_widget.dart";
import "../../properties/screens/property_detail_screen.dart";
import "../../rooms/screens/room_detail_screen.dart";

/// Smart Rent AI / House Matchmaker chat (requirement #25) — talks to the
/// real /api/chat and /api/ai/match endpoints (ChatController + GroqService).
/// If the API errors, the failure is shown as-is; nothing here fabricates a
/// fake assistant reply or invents listings that weren't actually returned.
class AiChatScreen extends StatefulWidget {
  const AiChatScreen({super.key});

  @override
  State<AiChatScreen> createState() => _AiChatScreenState();
}

class _AiChatScreenState extends State<AiChatScreen> {
  final _repo = AiRepository();
  final _inputCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();
  final List<ChatMessage> _messages = [
    ChatMessage(
      text: "Hi! I am the Smart Rent AI assistant. Tell me what kind of place you are looking for — budget, area, number of bedrooms — and I will help you find it. Or tap \"House Matchmaker\" above to describe your ideal place in one go.",
      isUser: false,
    ),
  ];
  bool _sending = false;

  Future<void> _send() async {
    final text = _inputCtrl.text.trim();
    if (text.isEmpty || _sending) return;
    setState(() {
      _messages.add(ChatMessage(text: text, isUser: true));
      _sending = true;
    });
    _inputCtrl.clear();
    _scrollToBottom();
    try {
      final response = await _repo.sendMessage(text);
      final reply = response["reply"]?.toString() ?? response["message"]?.toString() ?? "…";
      final properties = (response["properties"] as List?)?.map((e) => Map<String, dynamic>.from(e)).toList();
      setState(() => _messages.add(ChatMessage(text: reply, isUser: false, properties: properties)));
    } on ApiException catch (e) {
      setState(() => _messages.add(ChatMessage(text: "⚠️ ${e.message}", isUser: false)));
    } finally {
      setState(() => _sending = false);
      _scrollToBottom();
    }
  }

  /// AI House Matchmaker — a focused, one-shot version of the chat: the
  /// user describes their ideal place in a single free-text prompt and
  /// gets back real, currently-available matching listings (mirrors the
  /// web app's "AI House Matchmaker" card, backed by the same /ai/match
  /// endpoint that already existed in AiRepository but had no UI entry
  /// point on mobile).
  Future<void> _openMatchmaker() async {
    final queryCtrl = TextEditingController();
    final query = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (sheetContext) {
        return Padding(
          padding: EdgeInsets.only(
            left: 20, right: 20, top: 20,
            bottom: 20 + MediaQuery.of(sheetContext).viewInsets.bottom,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: const [
                  Icon(Icons.auto_awesome_rounded, color: AppTheme.primary),
                  SizedBox(width: 8),
                  Text("AI House Matchmaker", style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
                ],
              ),
              const SizedBox(height: 6),
              const Text(
                "Describe what you're looking for in your own words — we'll match it against real, currently available listings.",
                style: TextStyle(color: AppTheme.textSecondary, fontSize: 13),
              ),
              const SizedBox(height: 14),
              TextField(
                controller: queryCtrl,
                autofocus: true,
                maxLines: 3,
                decoration: const InputDecoration(
                  hintText: 'e.g. "A two bedroom house in Mbezi under 600,000 with parking and security"',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: () => Navigator.of(sheetContext).pop(queryCtrl.text.trim()),
                  icon: const Icon(Icons.search_rounded),
                  label: const Text("Find My Match"),
                ),
              ),
            ],
          ),
        );
      },
    );

    if (query == null || query.isEmpty || !mounted) return;

    setState(() {
      _messages.add(ChatMessage(text: query, isUser: true));
      _sending = true;
    });
    _scrollToBottom();
    try {
      final response = await _repo.match(query);
      final reply = response["reply"]?.toString() ?? response["message"]?.toString() ?? "Here's what I found.";
      final results = (response["results"] as List?)?.map((e) => Map<String, dynamic>.from(e)).toList();
      setState(() => _messages.add(ChatMessage(text: reply, isUser: false, properties: results)));
    } on ApiException catch (e) {
      setState(() => _messages.add(ChatMessage(text: "⚠️ ${e.message}", isUser: false)));
    } finally {
      setState(() => _sending = false);
      _scrollToBottom();
    }
  }

  void _openListing(Map<String, dynamic> listing) {
    final rawId = listing["room_id"] ?? listing["id"];
    final id = rawId is int ? rawId : int.tryParse(rawId?.toString() ?? "");
    if (id == null) return;
    final sourceType = (listing["source_type"] ?? "room").toString();
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => sourceType == "property" ? PropertyDetailScreen(propertyId: id) : RoomDetailScreen(roomId: id),
    ));
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(_scrollCtrl.position.maxScrollExtent, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      }
    });
  }

  @override
  void dispose() {
    _inputCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Smart Rent AI"),
        actions: [
          TextButton.icon(
            onPressed: _sending ? null : _openMatchmaker,
            icon: const Icon(Icons.auto_awesome_rounded, size: 18),
            label: const Text("Matchmaker"),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              controller: _scrollCtrl,
              padding: const EdgeInsets.all(16),
              itemCount: _messages.length + (_sending ? 1 : 0),
              itemBuilder: (context, index) {
                if (index >= _messages.length) {
                  return const Align(alignment: Alignment.centerLeft, child: Padding(
                    padding: EdgeInsets.symmetric(vertical: 8),
                    child: SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)),
                  ));
                }
                final message = _messages[index];
                return Align(
                  alignment: message.isUser ? Alignment.centerRight : Alignment.centerLeft,
                  child: Column(
                    crossAxisAlignment: message.isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: const EdgeInsets.symmetric(vertical: 6),
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
                        decoration: BoxDecoration(
                          color: message.isUser ? AppTheme.primary : AppTheme.surface,
                          borderRadius: BorderRadius.circular(16),
                          border: message.isUser ? null : Border.all(color: const Color(0xFFE5E7EB)),
                        ),
                        child: Text(message.text, style: TextStyle(color: message.isUser ? Colors.white : AppTheme.textPrimary)),
                      ),
                      if (!message.isUser && message.properties != null && message.properties!.isNotEmpty)
                        ...message.properties!.map((listing) => _buildListingCard(listing)),
                    ],
                  ),
                );
              },
            ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _inputCtrl,
                      textInputAction: TextInputAction.send,
                      onSubmitted: (_) => _send(),
                      decoration: const InputDecoration(hintText: "Ask about listings, areas, prices…"),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    onPressed: _sending ? null : _send,
                    icon: const Icon(Icons.send_rounded),
                    style: IconButton.styleFrom(backgroundColor: AppTheme.primary),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildListingCard(Map<String, dynamic> listing) {
    final imageUrl = ApiConfig.resolveMediaUrl(listing["image"]?.toString());
    final name = listing["name"]?.toString() ?? "Listing";
    final location = listing["location"]?.toString() ?? "";
    final rent = listing["monthly_rent"];
    final houseId = listing["house_id"]?.toString();
    return Padding(
      padding: const EdgeInsets.only(top: 4, bottom: 6),
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: () => _openListing(listing),
          child: Card(
            clipBehavior: Clip.antiAlias,
            margin: EdgeInsets.zero,
            child: Row(
              children: [
                SizedBox(
                  width: 64,
                  height: 64,
                  child: AppNetworkImage(url: imageUrl, width: 64, height: 64),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                        Text(location, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 11)),
                        Text(Formatters.money(rent is num ? rent : num.tryParse(rent?.toString() ?? "")), style: const TextStyle(color: AppTheme.primary, fontWeight: FontWeight.w700, fontSize: 12)),
                        if (houseId != null && houseId.isNotEmpty)
                          Text("ID: $houseId", maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 9)),
                      ],
                    ),
                  ),
                ),
                const Padding(
                  padding: EdgeInsets.only(right: 8),
                  child: Icon(Icons.chevron_right_rounded, color: AppTheme.textSecondary),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
