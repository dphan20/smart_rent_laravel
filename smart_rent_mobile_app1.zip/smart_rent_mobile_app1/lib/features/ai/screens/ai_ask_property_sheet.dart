import "package:flutter/material.dart";

import "../../../core/network/api_exception.dart";
import "../../../core/theme/app_theme.dart";
import "../../../repositories/ai_repository.dart";

/// "Ask AI About This Property" (requirement #25) — grounded in the real
/// live listing via /api/ai/ask-property.
class AiAskPropertySheet extends StatefulWidget {
  final int roomId;
  final String roomTitle;
  const AiAskPropertySheet({super.key, required this.roomId, required this.roomTitle});

  @override
  State<AiAskPropertySheet> createState() => _AiAskPropertySheetState();
}

class _AiAskPropertySheetState extends State<AiAskPropertySheet> {
  final _repo = AiRepository();
  final _ctrl = TextEditingController();
  bool _loading = false;
  String? _answer;
  String? _error;

  Future<void> _ask() async {
    final question = _ctrl.text.trim();
    if (question.isEmpty) return;
    setState(() {
      _loading = true;
      _error = null;
      _answer = null;
    });
    try {
      final response = await _repo.askAboutProperty(roomId: widget.roomId, question: question);
      setState(() => _answer = response["answer"]?.toString() ?? response["reply"]?.toString());
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } finally {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom, left: 20, right: 20, top: 20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Ask AI about", style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
          Text(widget.roomTitle, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
          const SizedBox(height: 16),
          TextField(
            controller: _ctrl,
            maxLines: 2,
            decoration: const InputDecoration(hintText: "e.g. Is this room near a bus stop?"),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _loading ? null : _ask,
              child: _loading
                  ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Text("Ask"),
            ),
          ),
          if (_answer != null) ...[
            const SizedBox(height: 16),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: AppTheme.primary.withValues(alpha: 0.06), borderRadius: BorderRadius.circular(12)),
              child: Text(_answer!),
            ),
          ],
          if (_error != null) ...[
            const SizedBox(height: 16),
            Text(_error!, style: const TextStyle(color: AppTheme.danger)),
          ],
          const SizedBox(height: 24),
        ],
      ),
    );
  }
}
