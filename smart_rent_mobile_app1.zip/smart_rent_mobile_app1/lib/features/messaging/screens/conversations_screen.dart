import "package:flutter/material.dart";
import "package:provider/provider.dart";

import "../../../core/theme/app_theme.dart";
import "../../../providers/messaging_provider.dart";
import "../../../providers/view_state.dart";
import "../../../repositories/messaging_repository.dart";
import "../../../widgets/state_views.dart";
import "chat_thread_screen.dart";
import "new_conversation_screen.dart";

class ConversationsScreen extends StatefulWidget {
  const ConversationsScreen({super.key});

  @override
  State<ConversationsScreen> createState() => _ConversationsScreenState();
}

class _ConversationsScreenState extends State<ConversationsScreen> {
  late final ConversationsProvider _provider;

  @override
  void initState() {
    super.initState();
    _provider = ConversationsProvider(MessagingRepository());
    _provider.load();
    _provider.startPolling();
  }

  @override
  void dispose() {
    _provider.stopPolling();
    _provider.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider.value(
      value: _provider,
      child: Scaffold(
        appBar: AppBar(
          title: const Text("Messages"),
          actions: [
            IconButton(
              icon: const Icon(Icons.add_comment_rounded),
              tooltip: "New message",
              onPressed: () async {
                await Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => const NewConversationScreen(),
                ));
                if (mounted) _provider.load(silent: true);
              },
            ),
          ],
        ),
        body: Consumer<ConversationsProvider>(
          builder: (context, provider, _) {
            switch (provider.status) {
              case ViewStatus.initial:
              case ViewStatus.loading:
                return const LoadingView();
              case ViewStatus.error:
                return ErrorView(
                  message: provider.errorMessage ?? "Unable to load messages.",
                  onRetry: provider.load,
                );
              case ViewStatus.empty:
                return const EmptyView(
                  message: "No conversations yet. Tap + to message Admin.",
                  icon: Icons.chat_bubble_outline_rounded,
                );
              case ViewStatus.loaded:
                return RefreshIndicator(
                  color: AppTheme.primary,
                  onRefresh: () => provider.load(silent: true),
                  child: ListView.separated(
                    itemCount: provider.conversations.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (context, index) {
                      final c = provider.conversations[index];
                      return ListTile(
                        leading: CircleAvatar(
                          backgroundColor: AppTheme.primary.withOpacity(0.12),
                          child: Text(
                            c.otherName.isNotEmpty ? c.otherName[0].toUpperCase() : "?",
                            style: const TextStyle(color: AppTheme.primary, fontWeight: FontWeight.bold),
                          ),
                        ),
                        title: Text(c.otherName, style: const TextStyle(fontWeight: FontWeight.w600)),
                        subtitle: Text(
                          c.lastMessageIsMine ? "You: ${c.lastMessage}" : c.lastMessage,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: c.unreadCount > 0 ? AppTheme.textPrimary : AppTheme.textSecondary,
                            fontWeight: c.unreadCount > 0 ? FontWeight.w600 : FontWeight.normal,
                          ),
                        ),
                        trailing: c.unreadCount > 0
                            ? CircleAvatar(
                                radius: 11,
                                backgroundColor: AppTheme.primary,
                                child: Text("${c.unreadCount}", style: const TextStyle(color: Colors.white, fontSize: 11)),
                              )
                            : null,
                        onTap: () async {
                          await Navigator.of(context).push(MaterialPageRoute(
                            builder: (_) => ChatThreadScreen(otherId: c.otherId, otherName: c.otherName),
                          ));
                          if (mounted) _provider.load(silent: true);
                        },
                      );
                    },
                  ),
                );
            }
          },
        ),
      ),
    );
  }
}
