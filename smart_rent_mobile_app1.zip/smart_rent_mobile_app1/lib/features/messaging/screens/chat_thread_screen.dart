import "package:flutter/material.dart";
import "package:provider/provider.dart";

import "../../../core/theme/app_theme.dart";
import "../../../providers/auth_provider.dart";
import "../../../providers/messaging_provider.dart";
import "../../../providers/view_state.dart";
import "../../../repositories/messaging_repository.dart";
import "../../../widgets/state_views.dart";

class ChatThreadScreen extends StatefulWidget {
  final int otherId;
  final String otherName;
  final String? listingType;
  final int? listingId;

  const ChatThreadScreen({
    super.key,
    required this.otherId,
    required this.otherName,
    this.listingType,
    this.listingId,
  });

  @override
  State<ChatThreadScreen> createState() => _ChatThreadScreenState();
}

class _ChatThreadScreenState extends State<ChatThreadScreen> {
  late final ChatThreadProvider _provider;
  final _textCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();

  @override
  void initState() {
    super.initState();
    _provider = ChatThreadProvider(MessagingRepository(), widget.otherId);
    _provider.load();
    _provider.startPolling();
  }

  @override
  void dispose() {
    _provider.stopPolling();
    _provider.dispose();
    _textCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    if (!_scrollCtrl.hasClients) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _send() async {
    final text = _textCtrl.text;
    if (text.trim().isEmpty) return;
    _textCtrl.clear();
    final ok = await _provider.send(text, listingType: widget.listingType, listingId: widget.listingId);
    if (ok) _scrollToBottom();
  }

  @override
  Widget build(BuildContext context) {
    final myId = context.read<AuthProvider>().user?.id;

    return ChangeNotifierProvider.value(
      value: _provider,
      child: Scaffold(
        appBar: AppBar(title: Text(widget.otherName)),
        body: Column(
          children: [
            Expanded(
              child: Consumer<ChatThreadProvider>(
                builder: (context, provider, _) {
                  if (provider.status == ViewStatus.loading || provider.status == ViewStatus.initial) {
                    return const LoadingView();
                  }
                  if (provider.status == ViewStatus.error) {
                    return ErrorView(
                      message: provider.errorMessage ?? "Unable to load conversation.",
                      onRetry: provider.load,
                    );
                  }
                  if (provider.messages.isEmpty) {
                    return const EmptyView(
                      message: "Say hello - start the conversation.",
                      icon: Icons.waving_hand_rounded,
                    );
                  }
                  _scrollToBottom();
                  return ListView.builder(
                    controller: _scrollCtrl,
                    padding: const EdgeInsets.all(12),
                    itemCount: provider.messages.length,
                    itemBuilder: (context, index) {
                      final m = provider.messages[index];
                      final isMine = m.senderId == myId;
                      return Align(
                        alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
                        child: Container(
                          margin: const EdgeInsets.symmetric(vertical: 4),
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
                          decoration: BoxDecoration(
                            color: isMine ? AppTheme.primary : AppTheme.surface,
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: Text(m.body, style: TextStyle(color: isMine ? Colors.white : AppTheme.textPrimary)),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _textCtrl,
                        minLines: 1,
                        maxLines: 4,
                        textInputAction: TextInputAction.send,
                        onSubmitted: (_) => _send(),
                        decoration: InputDecoration(
                          hintText: "Type a message...",
                          filled: true,
                          fillColor: AppTheme.surface,
                          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Consumer<ChatThreadProvider>(
                      builder: (context, provider, _) => IconButton.filled(
                        onPressed: provider.isSending ? null : _send,
                        icon: provider.isSending
                            ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                            : const Icon(Icons.send_rounded),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
