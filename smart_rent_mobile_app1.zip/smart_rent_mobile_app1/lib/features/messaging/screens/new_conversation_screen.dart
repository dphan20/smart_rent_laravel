import "package:flutter/material.dart";

import "../../../core/theme/app_theme.dart";
import "../../../models/conversation.dart";
import "../../../repositories/messaging_repository.dart";
import "../../../widgets/state_views.dart";
import "chat_thread_screen.dart";

class NewConversationScreen extends StatefulWidget {
  const NewConversationScreen({super.key});

  @override
  State<NewConversationScreen> createState() => _NewConversationScreenState();
}

class _NewConversationScreenState extends State<NewConversationScreen> {
  final _repo = MessagingRepository();
  late Future<List<ChatContact>> _future;

  @override
  void initState() {
    super.initState();
    _future = _repo.getContacts();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("New message")),
      body: FutureBuilder<List<ChatContact>>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const LoadingView();
          }
          if (snapshot.hasError) {
            return ErrorView(
              message: snapshot.error.toString(),
              onRetry: () => setState(() => _future = _repo.getContacts()),
            );
          }
          final contacts = snapshot.data ?? [];
          if (contacts.isEmpty) {
            return const EmptyView(message: "No contacts available.", icon: Icons.people_outline_rounded);
          }
          return ListView.separated(
            itemCount: contacts.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (context, index) {
              final c = contacts[index];
              return ListTile(
                leading: CircleAvatar(
                  backgroundColor: AppTheme.primary.withOpacity(0.12),
                  child: Text(c.name.isNotEmpty ? c.name[0].toUpperCase() : "?", style: const TextStyle(color: AppTheme.primary, fontWeight: FontWeight.bold)),
                ),
                title: Text(c.name),
                subtitle: Text(c.role),
                onTap: () {
                  Navigator.of(context).pushReplacement(MaterialPageRoute(
                    builder: (_) => ChatThreadScreen(otherId: c.id, otherName: c.name),
                  ));
                },
              );
            },
          );
        },
      ),
    );
  }
}
