import "package:flutter/material.dart";

import "../../../core/theme/app_theme.dart";
import "../../../core/utils/formatters.dart";
import "../../../models/room.dart";
import "../../../repositories/room_repository.dart";
import "../../../widgets/network_image_widget.dart";
import "../../../widgets/state_views.dart";
import "../../../widgets/status_badge.dart";
import "../../ai/screens/ai_ask_property_sheet.dart";
import "../../virtual_tour/screens/tour_viewer_screen.dart";

class RoomDetailScreen extends StatefulWidget {
  final int roomId;
  const RoomDetailScreen({super.key, required this.roomId});

  @override
  State<RoomDetailScreen> createState() => _RoomDetailScreenState();
}

class _RoomDetailScreenState extends State<RoomDetailScreen> {
  final _repo = RoomRepository();
  late Future<Room> _future;
  int _galleryIndex = 0;

  @override
  void initState() {
    super.initState();
    _future = _repo.getOne(widget.roomId);
  }

  void _reload() => setState(() => _future = _repo.getOne(widget.roomId));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder<Room>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const LoadingView();
          if (snapshot.hasError) return ErrorView(message: snapshot.error.toString(), onRetry: _reload);
          final room = snapshot.data!;
          final galleryUrls = room.imageUrls;
          return Stack(
            children: [
              CustomScrollView(
                slivers: [
                  SliverAppBar(
                    expandedHeight: 260,
                    pinned: true,
                    backgroundColor: AppTheme.surface,
                    foregroundColor: AppTheme.textPrimary,
                    flexibleSpace: FlexibleSpaceBar(
                      // Every photo uploaded for this room (see
                      // Room._decodeImageList) — not just a single cover
                      // shot — swipeable exactly like the property gallery.
                      background: galleryUrls.isEmpty
                          ? const AppNetworkImage(url: null)
                          : Stack(
                              fit: StackFit.expand,
                              children: [
                                PageView(
                                  onPageChanged: (i) => setState(() => _galleryIndex = i),
                                  children: galleryUrls
                                      .map((url) => AppNetworkImage(url: url, fit: BoxFit.cover))
                                      .toList(),
                                ),
                                if (galleryUrls.length > 1)
                                  Positioned(
                                    bottom: 10,
                                    left: 0,
                                    right: 0,
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: List.generate(
                                        galleryUrls.length,
                                        (i) => Container(
                                          margin: const EdgeInsets.symmetric(horizontal: 3),
                                          width: i == _galleryIndex ? 8 : 6,
                                          height: i == _galleryIndex ? 8 : 6,
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            color: (i == _galleryIndex ? Colors.white : Colors.white54),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                              ],
                            ),
                    ),
                  ),
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(20, 20, 20, 100),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(children: [
                            Expanded(child: Text(room.title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
                            StatusBadge(status: room.status),
                          ]),
                          const SizedBox(height: 6),
                          Row(children: [
                            const Icon(Icons.location_on_outlined, size: 16, color: AppTheme.textSecondary),
                            const SizedBox(width: 4),
                            Expanded(child: Text(room.location, style: const TextStyle(color: AppTheme.textSecondary))),
                          ]),
                          if (room.houseId != null && room.houseId!.trim().isNotEmpty) ...[
                            const SizedBox(height: 6),
                            Row(children: [
                              const Icon(Icons.badge_outlined, size: 16, color: AppTheme.textSecondary),
                              const SizedBox(width: 4),
                              Text("House ID: ${room.houseId}",
                                  style: const TextStyle(color: AppTheme.textSecondary, fontWeight: FontWeight.w600)),
                            ]),
                          ],
                          const SizedBox(height: 16),
                          Text(Formatters.money(room.price),
                              style: const TextStyle(color: AppTheme.primary, fontSize: 22, fontWeight: FontWeight.bold)),
                          const Text("per month", style: TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
                          const SizedBox(height: 20),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              _spec(Icons.bed_outlined, "${room.beds} beds"),
                              if (room.size != null) _spec(Icons.square_foot_outlined, "${room.size} m²"),
                              if (room.type != null) _spec(Icons.category_outlined, room.type!),
                              if (room.area != null) _spec(Icons.map_outlined, room.area!),
                            ],
                          ),
                          const SizedBox(height: 24),
                          SizedBox(
                            width: double.infinity,
                            child: OutlinedButton.icon(
                              icon: const Icon(Icons.threesixty_rounded),
                              label: const Text("View 360° Virtual Tour"),
                              onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                                builder: (_) => TourViewerScreen(
                                  listingType: "room",
                                  listingId: room.id,
                                  title: room.title,
                                ),
                              )),
                            ),
                          ),
                          const SizedBox(height: 12),
                          SizedBox(
                            width: double.infinity,
                            child: OutlinedButton.icon(
                              icon: const Icon(Icons.smart_toy_outlined),
                              label: const Text("Ask AI about this room"),
                              onPressed: () => showModalBottomSheet(
                                context: context,
                                isScrollControlled: true,
                                builder: (_) => AiAskPropertySheet(roomId: room.id, roomTitle: room.title),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _spec(IconData icon, String label) => Column(children: [
        Icon(icon, color: AppTheme.primary),
        const SizedBox(height: 4),
        Text(label, style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
      ]);
}
