import "package:flutter/material.dart";
import "package:image_picker/image_picker.dart";
import "package:provider/provider.dart";

import "../../../core/network/api_exception.dart";
import "../../../core/theme/app_theme.dart";
import "../../../models/tour360.dart";
import "../../../providers/tour_provider.dart";
import "../../../providers/view_state.dart";
import "../../../repositories/tour_repository.dart";
import "../../../widgets/network_image_widget.dart";
import "../../../widgets/state_views.dart";

/// Shared by Landlord AND Admin (requirement #18/#21 — identical
/// capability for both roles, same real Tour360Controller endpoints).
/// Lets the manager: upload new panorama scenes, delete scenes, and
/// add/edit/delete hotspots on a scene — writing directly to the same
/// database the web app and customer app read from (never local-only
/// state, requirement #21).
class TourManagerScreen extends StatefulWidget {
  final String listingType; // "room" | "property"
  final int listingId;
  final String listingTitle;

  const TourManagerScreen({super.key, required this.listingType, required this.listingId, required this.listingTitle});

  @override
  State<TourManagerScreen> createState() => _TourManagerScreenState();
}

class _TourManagerScreenState extends State<TourManagerScreen> {
  late final TourProvider _provider;
  final _repo = TourRepository();
  final _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    _provider = TourProvider(_repo);
    _provider.load(listingType: widget.listingType, listingId: widget.listingId);
  }

  @override
  void dispose() {
    _provider.dispose();
    super.dispose();
  }

  Future<void> _addScene() async {
    final image = await _picker.pickImage(source: ImageSource.gallery);
    if (image == null || !mounted) return;
    final nameCtrl = TextEditingController();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text("Name this panorama"),
        content: TextField(controller: nameCtrl, decoration: const InputDecoration(hintText: "e.g. Living room")),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text("Cancel")),
          TextButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text("Upload")),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    try {
      await _repo.createScene(
        listingType: widget.listingType,
        listingId: widget.listingId,
        name: nameCtrl.text.trim().isEmpty ? "Scene" : nameCtrl.text.trim(),
        isPrimary: _provider.scenes.isEmpty,
        panoramaImage: image,
      );
      await _provider.refreshAfterEdit(listingType: widget.listingType, listingId: widget.listingId);
    } on ApiException catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  Future<void> _deleteScene(Tour360Scene scene) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text("Delete this panorama?"),
        content: Text("\"${scene.name}\" and its hotspots will be permanently removed."),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text("Cancel")),
          TextButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text("Delete")),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    try {
      await _repo.deleteScene(scene.id);
      await _provider.refreshAfterEdit(listingType: widget.listingType, listingId: widget.listingId);
    } on ApiException catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  Future<void> _addHotspot(Tour360Scene scene) async {
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => _HotspotEditorSheet(
        scene: scene,
        allScenes: _provider.scenes,
        onSaved: () => _provider.refreshAfterEdit(listingType: widget.listingType, listingId: widget.listingId),
      ),
    );
  }

  Future<void> _deleteHotspot(Tour360Hotspot hotspot) async {
    try {
      await _repo.deleteHotspot(hotspot.id);
      await _provider.refreshAfterEdit(listingType: widget.listingType, listingId: widget.listingId);
    } on ApiException catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider.value(
      value: _provider,
      child: Scaffold(
        appBar: AppBar(
          title: Text("360° Tour · ${widget.listingTitle}"),
          actions: [IconButton(icon: const Icon(Icons.add_a_photo_outlined), onPressed: _addScene)],
        ),
        body: Consumer<TourProvider>(
          builder: (context, provider, _) {
            switch (provider.status) {
              case ViewStatus.initial:
              case ViewStatus.loading:
                return const LoadingView();
              case ViewStatus.error:
                return ErrorView(
                  message: provider.errorMessage ?? "Unable to load the tour.",
                  onRetry: () => provider.load(listingType: widget.listingType, listingId: widget.listingId),
                );
              case ViewStatus.empty:
                return EmptyView(
                  message: "No panoramas uploaded yet.",
                  icon: Icons.threesixty_rounded,
                  action: ElevatedButton.icon(icon: const Icon(Icons.add_a_photo_outlined), label: const Text("Upload first panorama"), onPressed: _addScene),
                );
              case ViewStatus.loaded:
                return ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: provider.scenes.length,
                  itemBuilder: (context, index) {
                    final scene = provider.scenes[index];
                    return Card(
                      margin: const EdgeInsets.only(bottom: 16),
                      clipBehavior: Clip.antiAlias,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Stack(
                            children: [
                              AppNetworkImage(url: scene.imageUrl, height: 150, width: double.infinity),
                              Positioned(
                                top: 8, right: 8,
                                child: IconButton.filled(
                                  icon: const Icon(Icons.delete_outline, size: 18),
                                  style: IconButton.styleFrom(backgroundColor: Colors.black54),
                                  onPressed: () => _deleteScene(scene),
                                ),
                              ),
                              if (scene.isPrimary)
                                Positioned(
                                  top: 8, left: 8,
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                    decoration: BoxDecoration(color: AppTheme.primary, borderRadius: BorderRadius.circular(8)),
                                    child: const Text("Primary", style: TextStyle(color: Colors.white, fontSize: 11)),
                                  ),
                                ),
                            ],
                          ),
                          Padding(
                            padding: const EdgeInsets.all(12),
                            child: Row(
                              children: [
                                Expanded(child: Text(scene.name, style: const TextStyle(fontWeight: FontWeight.w700))),
                                TextButton.icon(
                                  icon: const Icon(Icons.add_location_alt_outlined, size: 18),
                                  label: const Text("Add hotspot"),
                                  onPressed: () => _addHotspot(scene),
                                ),
                              ],
                            ),
                          ),
                          if (scene.hotspots.isNotEmpty)
                            Padding(
                              padding: const EdgeInsets.only(left: 12, right: 12, bottom: 12),
                              child: Column(
                                children: scene.hotspots.map((hotspot) {
                                  return ListTile(
                                    dense: true,
                                    contentPadding: EdgeInsets.zero,
                                    leading: Icon(
                                      hotspot.type == HotspotType.navigation ? Icons.arrow_forward_rounded : Icons.visibility_rounded,
                                      color: AppTheme.primary,
                                    ),
                                    title: Text(hotspot.title?.isNotEmpty == true ? hotspot.title! : hotspotTypeToString(hotspot.type)),
                                    subtitle: Text(hotspot.type == HotspotType.navigation
                                        ? "Goes to: ${provider.scenes.firstWhere((s) => s.id == hotspot.targetTourId, orElse: () => scene).name}"
                                        : "Re-orients view within this scene"),
                                    trailing: IconButton(icon: const Icon(Icons.close, size: 18), onPressed: () => _deleteHotspot(hotspot)),
                                  );
                                }).toList(),
                              ),
                            ),
                        ],
                      ),
                    );
                  },
                );
            }
          },
        ),
      ),
    );
  }
}

class _HotspotEditorSheet extends StatefulWidget {
  final Tour360Scene scene;
  final List<Tour360Scene> allScenes;
  final VoidCallback onSaved;
  const _HotspotEditorSheet({required this.scene, required this.allScenes, required this.onSaved});

  @override
  State<_HotspotEditorSheet> createState() => _HotspotEditorSheetState();
}

class _HotspotEditorSheetState extends State<_HotspotEditorSheet> {
  final _repo = TourRepository();
  final _titleCtrl = TextEditingController();
  HotspotType _type = HotspotType.navigation;
  int? _targetSceneId;
  double _yaw = 0;
  double _pitch = 0;
  bool _saving = false;

  List<Tour360Scene> get _otherScenes => widget.allScenes.where((s) => s.id != widget.scene.id).toList();

  Future<void> _save() async {
    if (_type == HotspotType.navigation && _targetSceneId == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Choose a target panorama")));
      return;
    }
    setState(() => _saving = true);
    try {
      await _repo.createHotspot(
        tourId: widget.scene.id,
        type: _type,
        yaw: _yaw,
        pitch: _pitch,
        title: _titleCtrl.text.trim().isEmpty ? null : _titleCtrl.text.trim(),
        targetTourId: _type == HotspotType.navigation ? _targetSceneId : null,
        targetYaw: _type == HotspotType.viewpoint ? 0 : null,
        targetPitch: _type == HotspotType.viewpoint ? 0 : null,
      );
      widget.onSaved();
      if (mounted) Navigator.pop(context);
    } on ApiException catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom, left: 20, right: 20, top: 20),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("Add hotspot", style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
            const SizedBox(height: 16),
            SegmentedButton<HotspotType>(
              segments: const [
                ButtonSegment(value: HotspotType.navigation, label: Text("Go to scene"), icon: Icon(Icons.arrow_forward_rounded)),
                ButtonSegment(value: HotspotType.viewpoint, label: Text("Look here"), icon: Icon(Icons.visibility_rounded)),
              ],
              selected: {_type},
              onSelectionChanged: (s) => setState(() => _type = s.first),
            ),
            const SizedBox(height: 16),
            TextField(controller: _titleCtrl, decoration: const InputDecoration(labelText: "Label (optional)")),
            const SizedBox(height: 16),
            if (_type == HotspotType.navigation) ...[
              if (_otherScenes.isEmpty)
                const Text("Upload another panorama first to link to it.", style: TextStyle(color: AppTheme.textSecondary))
              else
                DropdownButtonFormField<int>(
                  initialValue: _targetSceneId,
                  decoration: const InputDecoration(labelText: "Target panorama"),
                  items: _otherScenes.map((s) => DropdownMenuItem(value: s.id, child: Text(s.name))).toList(),
                  onChanged: (v) => setState(() => _targetSceneId = v),
                ),
              const SizedBox(height: 16),
            ],
            const Text("Position on the panorama", style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
            const SizedBox(height: 8),
            Text("Horizontal (yaw): ${_yaw.toStringAsFixed(0)}°", style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
            Slider(value: _yaw, min: -180, max: 180, onChanged: (v) => setState(() => _yaw = v)),
            Text("Vertical (pitch): ${_pitch.toStringAsFixed(0)}°", style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
            Slider(value: _pitch, min: -90, max: 90, onChanged: (v) => setState(() => _pitch = v)),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _saving ? null : _save,
                child: _saving
                    ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : const Text("Save hotspot"),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
