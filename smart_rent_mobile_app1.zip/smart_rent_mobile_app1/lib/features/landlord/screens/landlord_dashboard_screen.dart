import "package:flutter/material.dart";

import "../../../core/network/api_exception.dart";
import "../../../core/theme/app_theme.dart";
import "../../../core/utils/formatters.dart";
import "../../../repositories/landlord_repository.dart";
import "../../../widgets/state_views.dart";
import "../../ai/screens/ai_chat_screen.dart";

/// Landlord dashboard — pulls LandlordController's dashboard endpoint,
/// scoped server-side to just this landlord's own properties, rooms,
/// bookings and earnings (see LandlordController::dashboard()). This used
/// to call the Admin-only /admin/dashboard endpoint directly, which always
/// rejected landlords with "Forbidden - admin only".
class LandlordDashboardScreen extends StatefulWidget {
  const LandlordDashboardScreen({super.key});

  @override
  State<LandlordDashboardScreen> createState() => _LandlordDashboardScreenState();
}

class _LandlordDashboardScreenState extends State<LandlordDashboardScreen> {
  final _repo = LandlordRepository();
  late Future<Map<String, dynamic>> _future;

  @override
  void initState() {
    super.initState();
    _future = _repo.getDashboard();
  }

  void _reload() => setState(() => _future = _repo.getDashboard());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Dashboard")),
      body: RefreshIndicator(
        color: AppTheme.primary,
        onRefresh: () async => _reload(),
        child: FutureBuilder<Map<String, dynamic>>(
          future: _future,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) return const LoadingView();
            if (snapshot.hasError) {
              final message = snapshot.error is ApiException ? (snapshot.error as ApiException).message : "Unable to load dashboard.";
              return ListView(children: [const SizedBox(height: 80), ErrorView(message: message, onRetry: _reload)]);
            }
            final data = snapshot.data ?? {};
            final charts = Map<String, dynamic>.from(data["charts"] ?? {});
            final bookingsByStatus = (charts["bookings_by_status"] as List? ?? [])
                .map((e) => Map<String, dynamic>.from(e))
                .toList();
            final monthlyEarnings = (charts["monthly_earnings"] as List? ?? [])
                .map((e) => Map<String, dynamic>.from(e))
                .toList();

            return ListView(
              padding: const EdgeInsets.all(16),
              children: [
                GridView.count(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisCount: 2,
                  mainAxisSpacing: 14,
                  crossAxisSpacing: 14,
                  childAspectRatio: 1.4,
                  children: [
                    _kpiCard("Properties", data["properties_count"] ?? data["total_properties"] ?? "—", Icons.apartment_rounded),
                    _kpiCard("Rooms", data["rooms_count"] ?? data["total_rooms"] ?? "—", Icons.meeting_room_rounded),
                    _kpiCard("Bookings", data["bookings_count"] ?? data["total_bookings"] ?? "—", Icons.event_note_rounded),
                    _kpiCard(
                      "Earnings",
                      Formatters.money(_asNum(data["landlord_earnings"] ?? data["total_earnings"])),
                      Icons.payments_rounded,
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                Card(
                  color: AppTheme.primary.withOpacity(0.06),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(12),
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const AiChatScreen()),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Row(
                        children: [
                          Container(
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(
                              color: AppTheme.primary,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: const Icon(Icons.smart_toy_rounded, color: Colors.white),
                          ),
                          const SizedBox(width: 14),
                          const Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Smart Rent AI Assistant",
                                  style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
                                ),
                                SizedBox(height: 4),
                                Text(
                                  "Ask about your listings, bookings, orders, payments, or find a house by its House ID.",
                                  style: TextStyle(color: AppTheme.textSecondary, fontSize: 12),
                                ),
                              ],
                            ),
                          ),
                          const Icon(Icons.chevron_right_rounded, color: AppTheme.textSecondary),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        const Icon(Icons.hourglass_top_rounded, color: AppTheme.primary),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                Formatters.money(_asNum(data["pending_payouts"])),
                                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                              ),
                              const Text("Pending payouts", style: TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                if (bookingsByStatus.isNotEmpty) ...[
                  const SizedBox(height: 20),
                  const Text("Bookings by status", style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                  const SizedBox(height: 10),
                  Card(
                    child: Column(
                      children: bookingsByStatus
                          .map((row) => ListTile(
                                dense: true,
                                title: Text("${row["status"] ?? "—"}"),
                                trailing: Text(
                                  "${row["count"] ?? 0}",
                                  style: const TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ))
                          .toList(),
                    ),
                  ),
                ],
                if (monthlyEarnings.isNotEmpty) ...[
                  const SizedBox(height: 20),
                  const Text("Earnings — last 6 months", style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                  const SizedBox(height: 10),
                  Card(
                    child: Column(
                      children: monthlyEarnings
                          .map((row) => ListTile(
                                dense: true,
                                title: Text("${row["month"] ?? "—"}"),
                                trailing: Text(
                                  Formatters.money(_asNum(row["total"])),
                                  style: const TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ))
                          .toList(),
                    ),
                  ),
                ],
              ],
            );
          },
        ),
      ),
    );
  }

  num? _asNum(dynamic v) => v is num ? v : num.tryParse(v?.toString() ?? "");

  Widget _kpiCard(String label, dynamic value, IconData icon) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: AppTheme.primary),
            const Spacer(),
            Text("$value", style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            Text(label, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
          ],
        ),
      ),
    );
  }
}
