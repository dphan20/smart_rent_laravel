import "dart:typed_data";

import "package:flutter/material.dart";
import "package:image_picker/image_picker.dart";

import "../../../core/network/api_exception.dart";
import "../../../core/theme/app_theme.dart";
import "../../../core/utils/validators.dart";
import "../../../repositories/property_repository.dart";

/// Landlord property creation, using the EXISTING PropertyController create
/// endpoint (requirement #19/#20). The backend auto-creates a matching
/// `rooms` row and, per PropertyController, prefers an uploaded
/// virtualTourImage over a pasted virtualTour URL — this form offers both,
/// same as the web admin.
class AddPropertyScreen extends StatefulWidget {
  const AddPropertyScreen({super.key});

  @override
  State<AddPropertyScreen> createState() => _AddPropertyScreenState();
}

class _AddPropertyScreenState extends State<AddPropertyScreen> {
  final _formKey = GlobalKey<FormState>();
  final _repo = PropertyRepository();
  final _picker = ImagePicker();

  final _nameCtrl = TextEditingController();
  final _regionCtrl = TextEditingController();
  final _districtCtrl = TextEditingController();
  final _wardCtrl = TextEditingController();
  final _streetCtrl = TextEditingController();
  final _bedroomsCtrl = TextEditingController(text: "1");
  final _bathroomsCtrl = TextEditingController(text: "1");
  final _roomSizeCtrl = TextEditingController();
  final _rentCtrl = TextEditingController();
  final _depositCtrl = TextEditingController();
  final _tourUrlCtrl = TextEditingController();

  String _type = "apartment";
  String _rentalMode = "rent";
  String _furnished = "unfurnished";
  final List<XFile> _images = [];
  XFile? _tourImage;
  bool _submitting = false;

  @override
  void dispose() {
    for (final c in [
      _nameCtrl, _regionCtrl, _districtCtrl, _wardCtrl, _streetCtrl,
      _bedroomsCtrl, _bathroomsCtrl, _roomSizeCtrl, _rentCtrl, _depositCtrl, _tourUrlCtrl,
    ]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _pickImages() async {
    final picked = await _picker.pickMultiImage();
    if (picked.isNotEmpty) setState(() => _images.addAll(picked));
  }

  Future<void> _pickTourImage() async {
    final picked = await _picker.pickImage(source: ImageSource.gallery);
    if (picked != null) setState(() => _tourImage = picked);
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_images.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Add at least one photo")));
      return;
    }
    setState(() => _submitting = true);
    try {
      await _repo.create(
        name: _nameCtrl.text.trim(),
        type: _type,
        rentalMode: _rentalMode,
        region: _regionCtrl.text.trim(),
        district: _districtCtrl.text.trim(),
        ward: _wardCtrl.text.trim(),
        street: _streetCtrl.text.trim(),
        bedrooms: int.tryParse(_bedroomsCtrl.text) ?? 1,
        bathrooms: int.tryParse(_bathroomsCtrl.text) ?? 1,
        furnished: _furnished,
        roomSize: int.tryParse(_roomSizeCtrl.text) ?? 0,
        monthlyRent: double.tryParse(_rentCtrl.text) ?? 0,
        deposit: double.tryParse(_depositCtrl.text),
        images: _images,
        virtualTourImage: _tourImage,
        virtualTourUrl: _tourUrlCtrl.text.trim().isEmpty ? null : _tourUrlCtrl.text.trim(),
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Property listed successfully")));
      Navigator.of(context).pop(true);
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Add property")),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextFormField(controller: _nameCtrl, decoration: const InputDecoration(labelText: "Property name"), validator: (v) => Validators.required(v)),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(
                  child: DropdownButtonFormField<String>(
                    initialValue: _type,
                    decoration: const InputDecoration(labelText: "Type"),
                    items: const [
                      DropdownMenuItem(value: "apartment", child: Text("Apartment")),
                      DropdownMenuItem(value: "self_contained", child: Text("Self-contained")),
                      DropdownMenuItem(value: "single", child: Text("Single room")),
                      DropdownMenuItem(value: "house", child: Text("House")),
                    ],
                    onChanged: (v) => setState(() => _type = v ?? _type),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    initialValue: _furnished,
                    decoration: const InputDecoration(labelText: "Furnished"),
                    items: const [
                      DropdownMenuItem(value: "furnished", child: Text("Furnished")),
                      DropdownMenuItem(value: "unfurnished", child: Text("Unfurnished")),
                      DropdownMenuItem(value: "semi_furnished", child: Text("Semi-furnished")),
                    ],
                    onChanged: (v) => setState(() => _furnished = v ?? _furnished),
                  ),
                ),
              ]),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                initialValue: _rentalMode,
                decoration: const InputDecoration(labelText: "Listing purpose"),
                items: const [
                  DropdownMenuItem(value: "rent", child: Text("Long-term rent (contract required)")),
                  DropdownMenuItem(value: "holiday", child: Text("Holiday stay (no contract)")),
                ],
                onChanged: (v) => setState(() => _rentalMode = v ?? _rentalMode),
              ),
              const SizedBox(height: 12),
              TextFormField(controller: _regionCtrl, decoration: const InputDecoration(labelText: "Region"), validator: (v) => Validators.required(v)),
              const SizedBox(height: 12),
              TextFormField(controller: _districtCtrl, decoration: const InputDecoration(labelText: "District"), validator: (v) => Validators.required(v)),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(child: TextFormField(controller: _wardCtrl, decoration: const InputDecoration(labelText: "Ward"))),
                const SizedBox(width: 12),
                Expanded(child: TextFormField(controller: _streetCtrl, decoration: const InputDecoration(labelText: "Street"))),
              ]),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(child: TextFormField(controller: _bedroomsCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: "Bedrooms"))),
                const SizedBox(width: 12),
                Expanded(child: TextFormField(controller: _bathroomsCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: "Bathrooms"))),
              ]),
              const SizedBox(height: 12),
              TextFormField(controller: _roomSizeCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: "Room size (m²)")),
              const SizedBox(height: 12),
              TextFormField(controller: _rentCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: "Monthly rent (TZS)"), validator: (v) => Validators.required(v, field: "Monthly rent")),
              const SizedBox(height: 12),
              TextFormField(controller: _depositCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: "Deposit (TZS, optional)")),
              const SizedBox(height: 20),
              const Text("Photos", style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8, runSpacing: 8,
                children: [
                  // Image.memory + readAsBytes() (not Image.file(File(path)))
                  // so previews work on every platform, including web where
                  // XFile.path is a blob: URL that Image.file can't open.
                  for (final image in _images)
                    ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: FutureBuilder<Uint8List>(
                        future: image.readAsBytes(),
                        builder: (context, snapshot) {
                          if (!snapshot.hasData) {
                            return const SizedBox(
                              width: 72,
                              height: 72,
                              child: Center(child: CircularProgressIndicator(strokeWidth: 2)),
                            );
                          }
                          return Image.memory(
                            snapshot.data!,
                            width: 72,
                            height: 72,
                            fit: BoxFit.cover,
                          );
                        },
                      ),
                    ),
                  InkWell(
                    onTap: _pickImages,
                    child: Container(
                      width: 72, height: 72,
                      decoration: BoxDecoration(border: Border.all(color: AppTheme.textSecondary), borderRadius: BorderRadius.circular(10)),
                      child: const Icon(Icons.add_a_photo_outlined, color: AppTheme.textSecondary),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              const Text("360° Virtual Tour (optional)", style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              OutlinedButton.icon(
                onPressed: _pickTourImage,
                icon: const Icon(Icons.threesixty_rounded),
                label: Text(_tourImage == null ? "Upload panorama photo" : "Panorama selected ✓"),
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: _tourUrlCtrl,
                decoration: const InputDecoration(labelText: "Or paste an existing tour URL"),
                enabled: _tourImage == null,
              ),
              const SizedBox(height: 28),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _submitting ? null : _submit,
                  child: _submitting
                      ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      : const Text("List property"),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
