import "package:flutter/material.dart";
import "package:provider/provider.dart";

import "../../../core/theme/app_theme.dart";
import "../../../core/utils/formatters.dart";
import "../../../providers/auth_provider.dart";
import "../../../providers/property_provider.dart";
import "../../../providers/view_state.dart";
import "../../../widgets/network_image_widget.dart";
import "../../../widgets/state_views.dart";
import "../../properties/screens/property_detail_screen.dart";
import "add_property_screen.dart";
import "manage_photos_screen.dart";
import "tour_manager_screen.dart";

/// Landlord\u0027s own properties only — the backend scopes GET /properties by
/// landlord_id when called by a Landlord (requirement #19), so this simply
/// asks for "my" properties rather than filtering client-side.
class LandlordPropertiesScreen extends StatefulWidget {
  const LandlordPropertiesScreen({super.key});

  @override
  State<LandlordPropertiesScreen> createState() => _LandlordPropertiesScreenState();
}

class _LandlordPropertiesScreenState extends State<LandlordPropertiesScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  void _load() {
    final userId = context.read<AuthProvider>().user?.id;
    context.read<PropertyProvider>().load(landlordId: userId);
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<PropertyProvider>();
    return Scaffold(
      appBar: AppBar(
        title: const Text("My Properties"),
        actions: [
          IconButton(
            icon: const Icon(Icons.add_rounded),
            onPressed: () async {
              final created = await Navigator.of(context).push<bool>(
                MaterialPageRoute(builder: (_) => const AddPropertyScreen()),
              );
              if (created == true) _load();
            },
          ),
        ],
      ),
      body: RefreshIndicator(color: AppTheme.primary, onRefresh: () async => _load(), child: _body(provider)),
    );
  }

  Widget _body(PropertyProvider provider) {
    switch (provider.status) {
      case ViewStatus.initial:
      case ViewStatus.loading:
        return const LoadingView();
      case ViewStatus.error:
        return ListView(children: [const SizedBox(height: 80), ErrorView(message: provider.errorMessage ?? "Unable to load properties.", onRetry: _load)]);
      case ViewStatus.empty:
        return ListView(children: [
          const SizedBox(height: 80),
          EmptyView(
            message: "You have not listed any properties yet.",
            icon: Icons.apartment_outlined,
            action: ElevatedButton.icon(
              icon: const Icon(Icons.add),
              label: const Text("Add property"),
              onPressed: () async {
                final created = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => const AddPropertyScreen()));
                if (created == true) _load();
              },
            ),
          ),
        ]);
      case ViewStatus.loaded:
        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: provider.properties.length,
          itemBuilder: (context, index) {
            final property = provider.properties[index];
            return Card(
              margin: const EdgeInsets.only(bottom: 12),
              clipBehavior: Clip.antiAlias,
              child: ListTile(
                contentPadding: const EdgeInsets.all(10),
                leading: ClipRRect(borderRadius: BorderRadius.circular(10), child: AppNetworkImage(url: property.coverImageUrl, width: 64, height: 64)),
                title: Text(property.name, style: const TextStyle(fontWeight: FontWeight.w600)),
                subtitle: Text("${property.availability} • ${Formatters.money(property.monthlyRent)}/mo"),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.add_photo_alternate_outlined, color: AppTheme.primary),
                      tooltip: "Upload / manage photos",
                      onPressed: () async {
                        await Navigator.of(context).push(MaterialPageRoute(
                          builder: (_) => ManagePhotosScreen(
                            listingType: "property",
                            listingId: property.id,
                            listingTitle: property.name,
                            initialImageUrls: property.imageUrls,
                          ),
                        ));
                        _load();
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.threesixty_rounded, color: AppTheme.primary),
                      tooltip: "Manage 360° tour",
                      onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                        builder: (_) => TourManagerScreen(listingType: "property", listingId: property.id, listingTitle: property.name),
                      )),
                    ),
                  ],
                ),
                onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => PropertyDetailScreen(propertyId: property.id))),
              ),
            );
          },
        );
    }
  }
}
