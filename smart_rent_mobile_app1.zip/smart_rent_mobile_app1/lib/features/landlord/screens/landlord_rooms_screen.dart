import "package:flutter/material.dart";
import "package:provider/provider.dart";

import "../../../core/theme/app_theme.dart";
import "../../../core/utils/formatters.dart";
import "../../../providers/room_provider.dart";
import "../../../providers/view_state.dart";
import "../../../widgets/network_image_widget.dart";
import "../../../widgets/state_views.dart";
import "../../../widgets/status_badge.dart";
import "tour_manager_screen.dart";
import "manage_photos_screen.dart";

/// Landlord\u0027s own rooms, with direct access to 360° panorama + hotspot
/// management per room (requirements #19-21).
class LandlordRoomsScreen extends StatefulWidget {
  const LandlordRoomsScreen({super.key});

  @override
  State<LandlordRoomsScreen> createState() => _LandlordRoomsScreenState();
}

class _LandlordRoomsScreenState extends State<LandlordRoomsScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final provider = context.read<RoomProvider>();
      if (provider.status == ViewStatus.initial) provider.load();
    });
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<RoomProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text("My Rooms")),
      body: RefreshIndicator(color: AppTheme.primary, onRefresh: () => provider.load(silent: true), child: _body(provider)),
    );
  }

  Widget _body(RoomProvider provider) {
    switch (provider.status) {
      case ViewStatus.initial:
      case ViewStatus.loading:
        return const LoadingView();
      case ViewStatus.error:
        return ListView(children: [const SizedBox(height: 80), ErrorView(message: provider.errorMessage ?? "Unable to load rooms.", onRetry: provider.load)]);
      case ViewStatus.empty:
        return ListView(children: const [SizedBox(height: 80), EmptyView(message: "No rooms yet.", icon: Icons.meeting_room_outlined)]);
      case ViewStatus.loaded:
        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: provider.rooms.length,
          itemBuilder: (context, index) {
            final room = provider.rooms[index];
            return Card(
              margin: const EdgeInsets.only(bottom: 12),
              clipBehavior: Clip.antiAlias,
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: Row(
                  children: [
                    ClipRRect(borderRadius: BorderRadius.circular(10), child: AppNetworkImage(url: room.imageUrl, width: 64, height: 64)),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(room.title, style: const TextStyle(fontWeight: FontWeight.w600)),
                          Text(Formatters.money(room.price), style: const TextStyle(color: AppTheme.primary, fontSize: 12)),
                          const SizedBox(height: 4),
                          StatusBadge(status: room.status),
                        ],
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.add_photo_alternate_outlined, color: AppTheme.primary),
                      tooltip: "Upload / manage photos",
                      onPressed: () async {
                        await Navigator.of(context).push(MaterialPageRoute(
                          builder: (_) => ManagePhotosScreen(
                            listingType: "room",
                            listingId: room.id,
                            listingTitle: room.title,
                            initialImageUrls: room.imageUrls,
                          ),
                        ));
                        provider.load(silent: true);
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.threesixty_rounded, color: AppTheme.primary),
                      tooltip: "Manage 360° tour",
                      onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                        builder: (_) => TourManagerScreen(listingType: "room", listingId: room.id, listingTitle: room.title),
                      )),
                    ),
                  ],
                ),
              ),
            );
          },
        );
    }
  }
}
