import "package:flutter/material.dart";
import "package:image_picker/image_picker.dart";

import "../../../core/network/api_exception.dart";
import "../../../core/theme/app_theme.dart";
import "../../../repositories/property_repository.dart";
import "../../../repositories/room_repository.dart";
import "../../../widgets/network_image_widget.dart";
import "../../../widgets/state_views.dart";

/// Upload/manage the photo gallery for one existing room or property.
/// Backed directly by RoomController::addImages()/deleteImage() and
/// PropertyController::addImages()/deleteImage() — those endpoints already
/// existed and worked, this screen was the missing piece that let a
/// landlord actually reach them.
class ManagePhotosScreen extends StatefulWidget {
  final String listingType; // "room" | "property"
  final int listingId;
  final String listingTitle;
  final List<String> initialImageUrls;

  const ManagePhotosScreen({
    super.key,
    required this.listingType,
    required this.listingId,
    required this.listingTitle,
    required this.initialImageUrls,
  });

  @override
  State<ManagePhotosScreen> createState() => _ManagePhotosScreenState();
}

class _ManagePhotosScreenState extends State<ManagePhotosScreen> {
  final _roomRepo = RoomRepository();
  final _propertyRepo = PropertyRepository();
  final _picker = ImagePicker();

  late List<String> _imageUrls;
  bool _uploading = false;
  int? _deletingIndex;
  String? _error;

  bool get _isRoom => widget.listingType == "room";

  @override
  void initState() {
    super.initState();
    _imageUrls = List.of(widget.initialImageUrls);
  }

  Future<void> _pickAndUpload() async {
    final picked = await _picker.pickMultiImage(imageQuality: 85);
    if (picked.isEmpty) return;

    setState(() {
      _uploading = true;
      _error = null;
    });

    try {
      if (_isRoom) {
        await _roomRepo.addImages(widget.listingId, picked);
      } else {
        await _propertyRepo.addImages(widget.listingId, picked);
      }
      await _refresh();
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _uploading = false);
    }
  }

  Future<void> _refresh() async {
    if (_isRoom) {
      final room = await _roomRepo.getOne(widget.listingId);
      setState(() => _imageUrls = room.imageUrls);
    } else {
      final property = await _propertyRepo.getOne(widget.listingId);
      setState(() => _imageUrls = property.imageUrls);
    }
  }

  Future<void> _deleteAt(int index) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Remove photo?"),
        content: const Text("This photo will be permanently removed from this listing."),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text("Cancel")),
          TextButton(onPressed: () => Navigator.of(context).pop(true), child: const Text("Remove")),
        ],
      ),
    );
    if (confirmed != true) return;

    setState(() {
      _deletingIndex = index;
      _error = null;
    });
    try {
      if (_isRoom) {
        await _roomRepo.deleteImage(widget.listingId, index);
      } else {
        await _propertyRepo.deleteImage(widget.listingId, index);
      }
      await _refresh();
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _deletingIndex = null);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Photos — ${widget.listingTitle}")),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _uploading ? null : _pickAndUpload,
        icon: _uploading
            ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
            : const Icon(Icons.add_photo_alternate_outlined),
        label: Text(_uploading ? "Uploading…" : "Upload photos"),
      ),
      body: Column(
        children: [
          if (_error != null)
            Container(
              width: double.infinity,
              color: AppTheme.danger.withValues(alpha: 0.1),
              padding: const EdgeInsets.all(12),
              child: Text(_error!, style: const TextStyle(color: AppTheme.danger)),
            ),
          Expanded(
            child: _imageUrls.isEmpty
                ? EmptyView(
                    message: "No photos uploaded yet. Tap \"Upload photos\" to add some.",
                    icon: Icons.photo_library_outlined,
                  )
                : GridView.builder(
                    padding: const EdgeInsets.all(12),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      mainAxisSpacing: 10,
                      crossAxisSpacing: 10,
                      childAspectRatio: 1,
                    ),
                    itemCount: _imageUrls.length,
                    itemBuilder: (context, index) {
                      return Stack(
                        fit: StackFit.expand,
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(12),
                            child: AppNetworkImage(url: _imageUrls[index], fit: BoxFit.cover),
                          ),
                          Positioned(
                            top: 6,
                            right: 6,
                            child: Material(
                              color: Colors.black54,
                              shape: const CircleBorder(),
                              child: InkWell(
                                customBorder: const CircleBorder(),
                                onTap: _deletingIndex == index ? null : () => _deleteAt(index),
                                child: Padding(
                                  padding: const EdgeInsets.all(6),
                                  child: _deletingIndex == index
                                      ? const SizedBox(
                                          width: 16,
                                          height: 16,
                                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                                        )
                                      : const Icon(Icons.delete_outline, color: Colors.white, size: 18),
                                ),
                              ),
                            ),
                          ),
                        ],
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
