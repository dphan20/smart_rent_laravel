import "package:flutter/material.dart";
import "package:provider/provider.dart";

import "../../../core/theme/app_theme.dart";
import "../../../core/utils/formatters.dart";
import "../../../providers/auth_provider.dart";
import "../../../providers/room_provider.dart";
import "../../../providers/view_state.dart";
import "../../../widgets/network_image_widget.dart";
import "../../../widgets/state_views.dart";
import "../../rooms/screens/room_detail_screen.dart";
import "../../search/screens/search_screen.dart";

/// Customer home: real featured/available rooms straight from RoomController
/// (requirement #9 — never static demo data).
class CustomerHomeScreen extends StatefulWidget {
  const CustomerHomeScreen({super.key});

  @override
  State<CustomerHomeScreen> createState() => _CustomerHomeScreenState();
}

class _CustomerHomeScreenState extends State<CustomerHomeScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final provider = context.read<RoomProvider>();
      if (provider.status == ViewStatus.initial) provider.load();
    });
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final roomProvider = context.watch<RoomProvider>();

    return Scaffold(
      appBar: AppBar(
        title: Text("Hi, ${auth.user?.name.split(" ").first ?? "there"} \u{1F44B}"),
        actions: [
          IconButton(
            icon: const Icon(Icons.search_rounded),
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SearchScreen())),
          ),
        ],
      ),
      body: RefreshIndicator(
        color: AppTheme.primary,
        onRefresh: () => context.read<RoomProvider>().load(silent: true),
        child: _buildBody(roomProvider),
      ),
    );
  }

  Widget _buildBody(RoomProvider provider) {
    switch (provider.status) {
      case ViewStatus.initial:
      case ViewStatus.loading:
        return const LoadingView(message: "Loading available rooms…");
      case ViewStatus.error:
        return ListView(children: [
          const SizedBox(height: 80),
          ErrorView(message: provider.errorMessage ?? "Unable to load rooms.", onRetry: provider.load),
        ]);
      case ViewStatus.empty:
        return ListView(children: const [
          SizedBox(height: 80),
          EmptyView(message: "No rooms available right now.", icon: Icons.meeting_room_outlined),
        ]);
      case ViewStatus.loaded:
        final rooms = provider.rooms;
        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: rooms.length,
          itemBuilder: (context, index) {
            final room = rooms[index];
            return Padding(
              padding: const EdgeInsets.only(bottom: 14),
              child: InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: () => Navigator.of(context)
                    .push(MaterialPageRoute(builder: (_) => RoomDetailScreen(roomId: room.id))),
                child: Card(
                  clipBehavior: Clip.antiAlias,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Stack(
                        children: [
                          AppNetworkImage(url: room.imageUrl, height: 170, width: double.infinity),
                          if (room.virtualTour != null || room.status == "available")
                            Positioned(
                              top: 10, left: 10,
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                decoration: BoxDecoration(
                                  color: Colors.black.withValues(alpha: 0.6),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: const Row(mainAxisSize: MainAxisSize.min, children: [
                                  Icon(Icons.threesixty_rounded, color: Colors.white, size: 14),
                                  SizedBox(width: 4),
                                  Text("360°", style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600)),
                                ]),
                              ),
                            ),
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.all(14),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(room.title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                            const SizedBox(height: 4),
                            Row(children: [
                              const Icon(Icons.location_on_outlined, size: 14, color: AppTheme.textSecondary),
                              const SizedBox(width: 4),
                              Expanded(child: Text(room.location, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13))),
                            ]),
                            const SizedBox(height: 8),
                            Text(
                              "${Formatters.money(room.price)} / month",
                              style: const TextStyle(color: AppTheme.primary, fontWeight: FontWeight.w700),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
    }
  }
}
