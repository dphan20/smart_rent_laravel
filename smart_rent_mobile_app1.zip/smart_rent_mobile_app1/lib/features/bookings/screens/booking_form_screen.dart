import "package:flutter/material.dart";
import "package:provider/provider.dart";

import "../../../core/theme/app_theme.dart";
import "../../../core/utils/formatters.dart";
import "../../../core/utils/validators.dart";
import "../../../models/payment.dart";
import "../../../models/room.dart";
import "../../../providers/auth_provider.dart";
import "../../../providers/booking_provider.dart";
import "../../../repositories/booking_repository.dart";

/// Starts either a holiday booking or a rental contract workflow. Rent does
/// not submit payment until the contract has been approved by both parties.
class BookingFormScreen extends StatefulWidget {
  final Room room;
  const BookingFormScreen({super.key, required this.room});

  @override
  State<BookingFormScreen> createState() => _BookingFormScreenState();
}

class _BookingFormScreenState extends State<BookingFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _nameCtrl;
  late final TextEditingController _emailCtrl;
  late final TextEditingController _phoneCtrl;
  final _referenceCtrl = TextEditingController();
  final _recipientCtrl = TextEditingController();
  final _paymentTermsCtrl = TextEditingController(text: "Rent is due monthly in advance.");
  final _responsibilitiesCtrl = TextEditingController();
  final _terminationCtrl = TextEditingController();
  final _otherTermsCtrl = TextEditingController();
  String _method = PaymentMethods.mpesa;
  late String _rentalMode;
  DateTime? _arrivalDate;
  late final BookingProvider _provider;

  @override
  void initState() {
    super.initState();
    _provider = BookingProvider(BookingRepository());
    final user = context.read<AuthProvider>().user;
    _nameCtrl = TextEditingController(text: user?.name ?? "");
    _emailCtrl = TextEditingController(text: user?.email ?? "");
    _phoneCtrl = TextEditingController(text: user?.phone ?? "");
    _rentalMode = widget.room.rentalMode == "holiday" ? "holiday" : "rent";
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _emailCtrl.dispose();
    _phoneCtrl.dispose();
    _referenceCtrl.dispose();
    _recipientCtrl.dispose();
    _paymentTermsCtrl.dispose();
    _responsibilitiesCtrl.dispose();
    _terminationCtrl.dispose();
    _otherTermsCtrl.dispose();
    _provider.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    final result = await _provider.submitBooking(
      roomId: widget.room.id,
      customerName: _nameCtrl.text.trim(),
      customerEmail: _emailCtrl.text.trim(),
      customerPhone: _phoneCtrl.text.trim(),
      amount: widget.room.price,
      paymentMethod: _rentalMode == "holiday" ? _method : null,
      reference: _rentalMode == "holiday" ? _referenceCtrl.text.trim() : null,
      recipientNumber: _rentalMode == "holiday" && _recipientCtrl.text.trim().isNotEmpty ? _recipientCtrl.text.trim() : null,
      arrivalDate: _arrivalDate?.toIso8601String().split("T").first,
      rentalMode: _rentalMode,
      paymentTerms: _rentalMode == "rent" ? _paymentTermsCtrl.text.trim() : null,
      responsibilities: _rentalMode == "rent" ? _responsibilitiesCtrl.text.trim() : null,
      terminationConditions: _rentalMode == "rent" ? _terminationCtrl.text.trim() : null,
      otherTerms: _rentalMode == "rent" ? _otherTermsCtrl.text.trim() : null,
    );
    if (!mounted) return;
    if (result != null) {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => AlertDialog(
            title: Text(_rentalMode == "rent" ? "Contract submitted" : "Booking submitted"),
            content: Text(_rentalMode == "rent"
              ? "Your rental contract is waiting for approval from you and the landlord. Payment remains locked until both sides approve the terms."
              : "Your holiday booking and payment reference have been recorded for verification."),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.of(context).pop();
              },
              child: const Text("Done"),
            ),
          ],
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(_provider.errorMessage ?? "Booking failed. Please try again.")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider.value(
      value: _provider,
      child: Scaffold(
        appBar: AppBar(title: const Text("Book room")),
        body: Consumer<BookingProvider>(
          builder: (context, provider, _) {
            return SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(widget.room.title, style: const TextStyle(fontWeight: FontWeight.w700)),
                                  Text(widget.room.location, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
                                ],
                              ),
                            ),
                            Text(Formatters.money(widget.room.price),
                                style: const TextStyle(color: AppTheme.primary, fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    const Text("Booking purpose", style: TextStyle(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 8),
                    SegmentedButton<String>(
                      segments: const [
                        ButtonSegment(value: "rent", label: Text("Rent"), icon: Icon(Icons.home_work_outlined)),
                        ButtonSegment(value: "holiday", label: Text("Holiday"), icon: Icon(Icons.beach_access_outlined)),
                      ],
                      selected: {_rentalMode},
                      onSelectionChanged: (value) => setState(() => _rentalMode = value.first),
                    ),
                    const SizedBox(height: 20),
                    const Text("Your details", style: TextStyle(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _nameCtrl,
                      decoration: const InputDecoration(labelText: "Full name"),
                      validator: (v) => Validators.required(v, field: "Name"),
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _emailCtrl,
                      decoration: const InputDecoration(labelText: "Email"),
                      validator: Validators.email,
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _phoneCtrl,
                      decoration: const InputDecoration(labelText: "Phone number"),
                      validator: Validators.phone,
                    ),
                    const SizedBox(height: 12),
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text(_arrivalDate == null ? "Select move-in date" : Formatters.date(_arrivalDate!.toIso8601String())),
                      trailing: const Icon(Icons.calendar_today_outlined),
                      onTap: () async {
                        final picked = await showDatePicker(
                          context: context,
                          initialDate: DateTime.now().add(const Duration(days: 1)),
                          firstDate: DateTime.now(),
                          lastDate: DateTime.now().add(const Duration(days: 365)),
                        );
                        if (picked != null) setState(() => _arrivalDate = picked);
                      },
                    ),
                    if (_rentalMode == "rent") ...[
                      const SizedBox(height: 20),
                      const Text("Rental contract terms", style: TextStyle(fontWeight: FontWeight.w700)),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _paymentTermsCtrl,
                        maxLines: 3,
                        decoration: const InputDecoration(labelText: "Payment terms"),
                        validator: (v) => Validators.required(v, field: "Payment terms"),
                      ),
                      const SizedBox(height: 12),
                      TextFormField(controller: _responsibilitiesCtrl, maxLines: 3, decoration: const InputDecoration(labelText: "Responsibilities")),
                      const SizedBox(height: 12),
                      TextFormField(controller: _terminationCtrl, maxLines: 3, decoration: const InputDecoration(labelText: "Termination conditions")),
                      const SizedBox(height: 12),
                      TextFormField(controller: _otherTermsCtrl, maxLines: 3, decoration: const InputDecoration(labelText: "Other terms")),
                    ],
                    if (_rentalMode == "holiday") ...[
                    const SizedBox(height: 20),
                    const Text("Payment method", style: TextStyle(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 12),
                    ...PaymentMethods.all.map((m) => RadioListTile<String>(
                          contentPadding: EdgeInsets.zero,
                          value: m["value"]!,
                          groupValue: _method,
                          onChanged: (v) => setState(() => _method = v!),
                          title: Text(m["label"]!),
                          activeColor: AppTheme.primary,
                        )),
                    if (_method != PaymentMethods.card) ...[
                      const SizedBox(height: 8),
                      TextFormField(
                        controller: _recipientCtrl,
                        keyboardType: TextInputType.phone,
                        decoration: const InputDecoration(labelText: "Mobile money number used"),
                      ),
                    ],
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _referenceCtrl,
                      decoration: const InputDecoration(
                        labelText: "Transaction reference",
                        helperText: "The confirmation code from your mobile money / card payment",
                      ),
                      validator: (v) => Validators.required(v, field: "Reference"),
                    ),
                    ],
                    const SizedBox(height: 28),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: provider.isSubmitting ? null : _submit,
                        child: provider.isSubmitting
                            ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                            : Text(_rentalMode == "rent" ? "Submit contract for approval" : "Confirm & pay ${Formatters.money(widget.room.price)}"),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
