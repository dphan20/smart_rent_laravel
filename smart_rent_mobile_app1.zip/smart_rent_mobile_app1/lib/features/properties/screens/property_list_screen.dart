import "package:flutter/material.dart";
import "package:provider/provider.dart";

import "../../../core/theme/app_theme.dart";
import "../../../core/utils/formatters.dart";
import "../../../providers/property_provider.dart";
import "../../../providers/view_state.dart";
import "../../../widgets/network_image_widget.dart";
import "../../../widgets/state_views.dart";
import "property_detail_screen.dart";

class PropertyListScreen extends StatefulWidget {
  const PropertyListScreen({super.key});

  @override
  State<PropertyListScreen> createState() => _PropertyListScreenState();
}

class _PropertyListScreenState extends State<PropertyListScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final provider = context.read<PropertyProvider>();
      if (provider.status == ViewStatus.initial) provider.load();
    });
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<PropertyProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text("Properties")),
      body: RefreshIndicator(
        color: AppTheme.primary,
        onRefresh: () => context.read<PropertyProvider>().load(silent: true),
        child: _buildBody(provider),
      ),
    );
  }

  Widget _buildBody(PropertyProvider provider) {
    switch (provider.status) {
      case ViewStatus.initial:
      case ViewStatus.loading:
        return const LoadingView(message: "Loading properties…");
      case ViewStatus.error:
        return ListView(children: [
          const SizedBox(height: 80),
          ErrorView(message: provider.errorMessage ?? "Unable to load properties.", onRetry: provider.load),
        ]);
      case ViewStatus.empty:
        return ListView(children: const [
          SizedBox(height: 80),
          EmptyView(message: "No properties available right now.", icon: Icons.apartment_outlined),
        ]);
      case ViewStatus.loaded:
        final properties = provider.properties;
        return GridView.builder(
          padding: const EdgeInsets.all(16),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 14,
            crossAxisSpacing: 14,
            childAspectRatio: 0.72,
          ),
          itemCount: properties.length,
          itemBuilder: (context, index) {
            final property = properties[index];
            return InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: () => Navigator.of(context)
                  .push(MaterialPageRoute(builder: (_) => PropertyDetailScreen(propertyId: property.id))),
              child: Card(
                clipBehavior: Clip.antiAlias,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: 108,
                      width: double.infinity,
                      child: AppNetworkImage(
                        url: property.coverImageUrl,
                        width: double.infinity,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(property.name,
                              maxLines: 1, overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                          const SizedBox(height: 2),
                          if (property.sri != null && property.sri!.trim().isNotEmpty)
                            Text(
                              property.sri!,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: AppTheme.primary,
                                fontSize: 10,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          Text(property.fullAddress.isEmpty ? (property.location ?? "") : property.fullAddress,
                              maxLines: 1, overflow: TextOverflow.ellipsis,
                              style: const TextStyle(color: AppTheme.textSecondary, fontSize: 11)),
                          const SizedBox(height: 6),
                          Text(Formatters.money(property.monthlyRent),
                              style: const TextStyle(color: AppTheme.primary, fontWeight: FontWeight.w700, fontSize: 13)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
    }
  }
}
