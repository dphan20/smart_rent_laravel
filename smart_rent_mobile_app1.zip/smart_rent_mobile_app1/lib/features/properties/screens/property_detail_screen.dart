import "package:flutter/material.dart";

import "../../../core/theme/app_theme.dart";
import "../../../core/utils/formatters.dart";
import "../../../models/contract.dart";
import "../../../models/property.dart";
import "../../../repositories/booking_repository.dart";
import "../../../repositories/contract_repository.dart";
import "../../../repositories/property_repository.dart";
import "../../../widgets/network_image_widget.dart";
import "../../../widgets/state_views.dart";
import "../../virtual_tour/screens/tour_viewer_screen.dart";

class PropertyDetailScreen extends StatefulWidget {
  final int propertyId;
  const PropertyDetailScreen({super.key, required this.propertyId});

  @override
  State<PropertyDetailScreen> createState() => _PropertyDetailScreenState();
}

class _PropertyDetailScreenState extends State<PropertyDetailScreen> {
  final _repo = PropertyRepository();
  final _contractRepo = ContractRepository();
  final _bookingRepo = BookingRepository();
  late Future<Property> _future;
  late Future<List<Contract>> _contractFuture;

  @override
  void initState() {
    super.initState();
    _future = _repo.getOne(widget.propertyId);
    _contractFuture = _contractRepo.getAll();
  }

  void _reload() => setState(() => _future = _repo.getOne(widget.propertyId));

  Future<void> _acceptContract(int contractId) async {
    try {
      await _contractRepo.accept(contractId);
      if (!mounted) return;
      setState(() => _contractFuture = _contractRepo.getAll());
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Contract approval recorded")),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error.toString())),
      );
    }
  }

  Future<void> _payRent(Contract contract) async {
    final referenceController = TextEditingController();
    final methodController = TextEditingController(text: "mpesa");
    final submitted = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text("Pay approved rent"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: methodController,
              decoration: const InputDecoration(labelText: "Payment method"),
            ),
            TextField(
              controller: referenceController,
              decoration: const InputDecoration(labelText: "Transaction reference"),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text("Cancel")),
          ElevatedButton(
            onPressed: () async {
              if (referenceController.text.trim().isEmpty) return;
              try {
                await _bookingRepo.pay(
                  bookingId: contract.bookingId!,
                  amount: contract.monthlyRent,
                  paymentMethod: methodController.text.trim(),
                  reference: referenceController.text.trim(),
                );
                if (dialogContext.mounted) Navigator.pop(dialogContext, true);
              } catch (error) {
                if (dialogContext.mounted) {
                  ScaffoldMessenger.of(dialogContext).showSnackBar(SnackBar(content: Text(error.toString())));
                }
              }
            },
            child: const Text("Submit payment"),
          ),
        ],
      ),
    );
    referenceController.dispose();
    methodController.dispose();
    if (submitted == true && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Payment submitted for verification")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder<Property>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const LoadingView();
          }

          if (snapshot.hasError) {
            return ErrorView(
              message: snapshot.error.toString(),
              onRetry: _reload,
            );
          }

          final property = snapshot.data!;

          final propertyDetails = <String, String>{
            if (property.type != null && property.type!.trim().isNotEmpty)
              "Type": property.type!,
            if (property.houseNo != null && property.houseNo!.trim().isNotEmpty)
              "House No.": property.houseNo!,
            if (property.availability.trim().isNotEmpty)
              "Availability": property.availability,
            if (property.furnished != null && property.furnished!.trim().isNotEmpty)
              "Furnishing": property.furnished!,
            if (property.roomSize != null) "Size": "${property.roomSize} m²",
          };

          return CustomScrollView(
            slivers: [
              SliverAppBar(
                expandedHeight: 260,
                pinned: true,
                backgroundColor: AppTheme.surface,
                foregroundColor: AppTheme.textPrimary,
                flexibleSpace: FlexibleSpaceBar(
                  background: property.imageUrls.isEmpty
                      ? AppNetworkImage(url: null)
                      : PageView(
                          children: property.imageUrls
                              .map(
                                (url) => AppNetworkImage(
                                  url: url,
                                  fit: BoxFit.cover,
                                ),
                              )
                              .toList(),
                        ),
                ),
              ),

              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Property name + House Number
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              property.name,
                              style: const TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          if (property.houseNo != null &&
                              property.houseNo!.trim().isNotEmpty)
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 5,
                              ),
                              decoration: BoxDecoration(
                                color: AppTheme.primary.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(
                                "House No. ${property.houseNo}",
                                style: const TextStyle(
                                  color: AppTheme.primary,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                        ],
                      ),

                      const SizedBox(height: 4),

                      // Smart Rental Identifier (SRI) — the permanent public
                      // identifier for this property, following the required
                      // TZ-[CITY]-[8 DIGIT NUMBER] pattern.
                      Text(
                        property.sri != null && property.sri!.trim().isNotEmpty
                            ? "SRI: ${property.sri}"
                            : (property.houseId != null && property.houseId!.trim().isNotEmpty
                                ? "House ID: ${property.houseId}"
                                : "Property ID: SR-${property.id.toString().padLeft(5, '0')}"),
                        style: const TextStyle(
                          color: AppTheme.textSecondary,
                          fontSize: 12,
                        ),
                      ),

                      const SizedBox(height: 6),

                      if (propertyDetails.isNotEmpty) ...[
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(14),
                          margin: const EdgeInsets.only(bottom: 14),
                          decoration: BoxDecoration(
                            color: AppTheme.surface,
                            border: Border.all(
                              color: AppTheme.textSecondary.withOpacity(0.15),
                            ),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                "Property details",
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 15,
                                ),
                              ),
                              const SizedBox(height: 10),
                              Wrap(
                                spacing: 8,
                                runSpacing: 8,
                                children: propertyDetails.entries
                                    .map(
                                      (entry) => Container(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 10,
                                          vertical: 6,
                                        ),
                                        decoration: BoxDecoration(
                                          color: AppTheme.primary.withOpacity(0.08),
                                          borderRadius: BorderRadius.circular(999),
                                        ),
                                        child: Text(
                                          "${entry.key}: ${entry.value}",
                                          style: const TextStyle(
                                            color: AppTheme.primary,
                                            fontSize: 11,
                                            fontWeight: FontWeight.w700,
                                          ),
                                        ),
                                      ),
                                    )
                                    .toList(),
                              ),
                            ],
                          ),
                        ),
                      ],

                      // Location
                      Row(
                        children: [
                          const Icon(
                            Icons.location_on_outlined,
                            size: 16,
                            color: AppTheme.textSecondary,
                          ),
                          const SizedBox(width: 4),
                          Expanded(
                            child: Text(
                              property.fullAddress.isEmpty
                                  ? (property.location ?? "")
                                  : property.fullAddress,
                              style: const TextStyle(
                                color: AppTheme.textSecondary,
                              ),
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 16),

                      Text(
                        Formatters.money(property.monthlyRent),
                        style: const TextStyle(
                          color: AppTheme.primary,
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                        ),
                      ),

                      const Text(
                        "per month",
                        style: TextStyle(
                          color: AppTheme.textSecondary,
                          fontSize: 12,
                        ),
                      ),

                      const SizedBox(height: 20),

                      _specsRow(property),

                      FutureBuilder<List<Contract>>(
                        future: _contractFuture,
                        builder: (context, contractSnapshot) {
                          if (contractSnapshot.connectionState == ConnectionState.waiting) {
                            return const Padding(
                              padding: EdgeInsets.only(top: 20),
                              child: SizedBox(
                                height: 52,
                                child: Center(
                                  child: SizedBox(
                                    width: 16,
                                    height: 16,
                                    child: CircularProgressIndicator(strokeWidth: 2),
                                  ),
                                ),
                              ),
                            );
                          }

                          final contracts = contractSnapshot.data ?? const <Contract>[];
                          final relatedContracts = contracts
                              .where(
                                (contract) =>
                                    contract.propertyId == property.id,
                              )
                              .toList();

                          if (relatedContracts.isEmpty) {
                            return const SizedBox.shrink();
                          }

                          final contract = relatedContracts.first;
                          return Padding(
                            padding: const EdgeInsets.only(top: 20),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  "Contract",
                                  style: TextStyle(
                                    fontWeight: FontWeight.w700,
                                    fontSize: 16,
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Container(
                                  width: double.infinity,
                                  padding: const EdgeInsets.all(14),
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(12),
                                    color: AppTheme.surface,
                                    border: Border.all(
                                      color: AppTheme.textSecondary.withOpacity(0.12),
                                    ),
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      _infoRow("Contract number", contract.contractNumber),
                                      _infoRow("Status", contract.status),
                                      _infoRow("Monthly rent", Formatters.money(contract.monthlyRent)),
                                      _infoRow("Deposit", Formatters.money(contract.deposit)),
                                      _infoRow("Start date", contract.startDate ?? "—"),
                                      _infoRow("End date", contract.endDate ?? "—"),
                                      _infoRow("Landlord", contract.landlordName ?? "—"),
                                      _infoRow("Tenant", contract.customerName ?? "—"),
                                      if (contract.paymentTerms != null && contract.paymentTerms!.trim().isNotEmpty)
                                        _infoRow("Payment terms", contract.paymentTerms!),
                                      if (contract.status == "PENDING_CUSTOMER" || contract.status == "PENDING_LANDLORD") ...[
                                        const SizedBox(height: 8),
                                        SizedBox(
                                          width: double.infinity,
                                          child: ElevatedButton.icon(
                                            onPressed: () => _acceptContract(contract.id),
                                            icon: const Icon(Icons.draw_outlined),
                                            label: Text(contract.status == "PENDING_CUSTOMER"
                                                ? "Approve contract"
                                                : "Approve as landlord"),
                                          ),
                                        ),
                                      ],
                                      if (contract.status == "ACTIVE" && contract.bookingId != null) ...[
                                        const SizedBox(height: 8),
                                        SizedBox(
                                          width: double.infinity,
                                          child: ElevatedButton.icon(
                                            onPressed: () => _payRent(contract),
                                            icon: const Icon(Icons.payments_outlined),
                                            label: const Text("Pay approved rent"),
                                          ),
                                        ),
                                      ],
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),

                      const SizedBox(height: 20),

                      // Always reachable; TourViewerScreen shows a graceful empty state
                      // when no panorama scenes have been uploaded yet.
                      SizedBox(
                        width: double.infinity,
                        child: OutlinedButton.icon(
                          icon: const Icon(Icons.threesixty_rounded),
                          label: const Text("View 360° Virtual Tour"),
                          onPressed: () => Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) => TourViewerScreen(
                                listingType: "property",
                                listingId: property.id,
                                title: property.name,
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),

                      if (property.description != null &&
                          property.description!.isNotEmpty) ...[
                        const Text(
                          "Description",
                          style: TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 16,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          property.description!,
                          style: const TextStyle(
                            color: AppTheme.textSecondary,
                            height: 1.5,
                          ),
                        ),
                        const SizedBox(height: 20),
                      ],

                      if (property.amenities.isNotEmpty) ...[
                        const Text(
                          "Amenities",
                          style: TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 16,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: property.amenities.entries
                              .where(
                                (e) =>
                                    e.value == true ||
                                    e.value == 1 ||
                                    e.value == "1",
                              )
                              .map(
                                (e) => Chip(
                                  label: Text(e.key),
                                  backgroundColor:
                                      AppTheme.primary.withValues(alpha: 0.08),
                                ),
                              )
                              .toList(),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _specsRow(Property property) {
    Widget spec(IconData icon, String label) => Column(
          children: [
            Icon(icon, color: AppTheme.primary),
            const SizedBox(height: 4),
            Text(
              label,
              style: const TextStyle(
                fontSize: 12,
                color: AppTheme.textSecondary,
              ),
            ),
          ],
        );

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        spec(Icons.bed_outlined, "${property.bedrooms} beds"),
        spec(Icons.bathtub_outlined, "${property.bathrooms} baths"),
        if (property.roomSize != null)
          spec(
            Icons.square_foot_outlined,
            "${property.roomSize} m²",
          ),
        spec(
          Icons.chair_outlined,
          property.furnished ?? "—",
        ),
      ],
    );
  }

  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 110,
            child: Text(
              label,
              style: const TextStyle(
                fontSize: 12,
                color: AppTheme.textSecondary,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: AppTheme.textPrimary,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
