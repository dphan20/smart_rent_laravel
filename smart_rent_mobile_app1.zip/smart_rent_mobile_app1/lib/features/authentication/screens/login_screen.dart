import "package:flutter/material.dart";
import "package:provider/provider.dart";

import "../../../core/storage/local_prefs.dart";
import "../../../core/settings/server_settings_screen.dart";
import "../../../core/theme/app_theme.dart";
import "../../../core/theme/brand_mark.dart";
import "../../../core/utils/validators.dart";
import "../../../navigation/root_shell.dart";
import "../../../providers/auth_provider.dart";
import "signup_screen.dart";

/// Single login form for Customer, Landlord and Admin (requirement #6):
/// the backend alone determines the role from the account, so there is
/// deliberately no role picker here — just email + password.
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  bool _obscure = true;
  bool _remember = true;

  @override
  void initState() {
    super.initState();
    LocalPrefs.getRememberedEmail().then((email) {
      if (email != null && mounted) setState(() => _emailCtrl.text = email);
    });
  }

  @override
  void dispose() {
    _emailCtrl.dispose();
    _passwordCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    final auth = context.read<AuthProvider>();
    final ok = await auth.login(_emailCtrl.text.trim(), _passwordCtrl.text, remember: _remember);
    if (!mounted) return;
    if (ok) {
      // Reached two ways: (a) as a full-screen entry point (e.g. from the
      // guest "Account" tab, with nothing to pop to) or (b) pushed on top
      // of whatever the guest was already doing when a protected action
      // asked them to sign in (see core/utils/auth_gate.dart). In case
      // (b) we must pop back to that screen — not blow away the stack —
      // so the user's place in the app (a room they were viewing, etc.)
      // isn't lost. Only fall back to replacing the stack when this is
      // truly the root (nothing to return to).
      if (Navigator.of(context).canPop()) {
        Navigator.of(context).pop(true);
      } else {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const RootShell()),
          (route) => false,
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(auth.error ?? "Login failed")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_ethernet, color: AppTheme.textSecondary),
            tooltip: "Server settings",
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const ServerSettingsScreen()),
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 24),
                // Same "SR" gold-gradient mark as the web app's login card
                // (.login-brand .brand-icon-lg in app.blade.php) instead of
                // a generic Material icon.
                const BrandMark(size: 60),
                const SizedBox(height: 16),
                const BrandWordmark(fontSize: 24),
                const SizedBox(height: 16),
                const Text("Welcome back",
                    style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: AppTheme.textPrimary)),
                const SizedBox(height: 6),
                const Text(
                  "Sign in to your Smart Rent account",
                  style: TextStyle(color: AppTheme.textSecondary, fontSize: 15),
                ),
                const SizedBox(height: 32),
                TextFormField(
                  controller: _emailCtrl,
                  keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(labelText: "Email", prefixIcon: Icon(Icons.email_outlined)),
                  validator: Validators.email,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _passwordCtrl,
                  obscureText: _obscure,
                  decoration: InputDecoration(
                    labelText: "Password",
                    prefixIcon: const Icon(Icons.lock_outline),
                    suffixIcon: IconButton(
                      icon: Icon(_obscure ? Icons.visibility_off_outlined : Icons.visibility_outlined),
                      onPressed: () => setState(() => _obscure = !_obscure),
                    ),
                  ),
                  validator: Validators.password,
                  onFieldSubmitted: (_) => _submit(),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Checkbox(
                          value: _remember,
                          onChanged: (v) => setState(() => _remember = v ?? true),
                          activeColor: AppTheme.primary,
                        ),
                        const Text("Remember me"),
                      ],
                    ),
                    TextButton(onPressed: () {}, child: const Text("Forgot password?")),
                  ],
                ),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: auth.isBusy ? null : _submit,
                    child: auth.isBusy
                        ? const SizedBox(
                            height: 20, width: 20,
                            child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                        : const Text("Sign In"),
                  ),
                ),
                const SizedBox(height: 20),
                Center(
                  child: TextButton(
                    onPressed: () async {
                      // SignupScreen pops(true) on success. Propagate that
                      // straight through so a guest who reached this screen
                      // via ensureAuthenticated (see core/utils/auth_gate.dart)
                      // and then chose "Sign up" instead of "Sign in" still
                      // lands back on their original screen, not stuck here.
                      final signedUp = await Navigator.of(context).push<bool>(
                        MaterialPageRoute(builder: (_) => const SignupScreen()),
                      );
                      if (signedUp == true && context.mounted && Navigator.of(context).canPop()) {
                        Navigator.of(context).pop(true);
                      }
                    },
                    child: const Text.rich(
                      TextSpan(
                        text: "Don\u0027t have an account? ",
                        style: TextStyle(color: AppTheme.textSecondary),
                        children: [
                          TextSpan(text: "Sign up", style: TextStyle(color: AppTheme.primary, fontWeight: FontWeight.w600)),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
