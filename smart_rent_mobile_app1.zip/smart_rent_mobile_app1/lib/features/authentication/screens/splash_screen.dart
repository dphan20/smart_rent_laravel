import "package:flutter/material.dart";
import "package:provider/provider.dart";

import "../../../core/theme/app_theme.dart";
import "../../../core/theme/brand_mark.dart";
import "../../../navigation/root_shell.dart";
import "../../../providers/auth_provider.dart";

/// Shown only while AuthProvider.status == AuthStatus.unknown, i.e. while
/// we are asking the backend whether the restored session cookie is still
/// valid (requirement #37). Never assumes logged-out during this window.
class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<AuthProvider>(
      builder: (context, auth, _) {
        if (auth.status == AuthStatus.unknown) {
          // Dark navy background + the same gold "SR" mark used on the
          // web app's sidebar/login card (see .brand-icon in
          // resources/views/app.blade.php), not a generic teal + icon.
          return Scaffold(
            backgroundColor: AppTheme.navy,
            body: const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  BrandMark(size: 72),
                  SizedBox(height: 18),
                  BrandWordmark(fontSize: 30, color: Colors.white),
                  SizedBox(height: 28),
                  CircularProgressIndicator(color: AppTheme.gold),
                ],
              ),
            ),
          );
        }
        // Critical architecture fix (requirement #10/#17): Smart Rent must
        // NEVER open as a login-only app. Whether the session restore came
        // back authenticated or not, the very first thing the user sees is
        // the same RootShell — it just renders the public guest browsing
        // experience (real rooms/properties, no login wall) when there is
        // no logged-in user. Authentication is only ever requested later,
        // and only for actions that actually need an account (see
        // core/utils/auth_gate.dart).
        return const RootShell();
      },
    );
  }
}
