import "package:flutter/material.dart";
import "package:provider/provider.dart";

import "../../../core/theme/app_theme.dart";
import "../../../core/utils/formatters.dart";
import "../../../providers/room_provider.dart";
import "../../../providers/view_state.dart";
import "../../../repositories/room_repository.dart";
import "../../../widgets/network_image_widget.dart";
import "../../../widgets/state_views.dart";
import "../../rooms/screens/room_detail_screen.dart";

/// Uses the EXISTING server-side search/filter query params on GET /rooms
/// (requirement #22) — never a fake client-only filter over already-loaded
/// data.
class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  late final RoomProvider _provider;
  final _searchCtrl = TextEditingController();
  String? _type;
  String? _sort;
  double? _maxPrice;

  @override
  void initState() {
    super.initState();
    _provider = RoomProvider(RoomRepository());
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    _provider.dispose();
    super.dispose();
  }

  void _runSearch() {
    _provider.applyFilters(
      search: _searchCtrl.text.trim().isEmpty ? null : _searchCtrl.text.trim(),
      type: _type,
      maxPrice: _maxPrice,
      sort: _sort,
    );
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider.value(
      value: _provider,
      child: Scaffold(
        appBar: AppBar(title: const Text("Search")),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  TextField(
                    controller: _searchCtrl,
                    textInputAction: TextInputAction.search,
                    onSubmitted: (_) => _runSearch(),
                    decoration: InputDecoration(
                      hintText: "Search by title, location…",
                      prefixIcon: const Icon(Icons.search_rounded),
                      suffixIcon: IconButton(icon: const Icon(Icons.arrow_forward_rounded), onPressed: _runSearch),
                    ),
                  ),
                  const SizedBox(height: 10),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        _filterChip("Single room", "single", (v) => setState(() => _type = v)),
                        _filterChip("Self-contained", "self_contained", (v) => setState(() => _type = v)),
                        _filterChip("Apartment", "apartment", (v) => setState(() => _type = v)),
                        const SizedBox(width: 8),
                        _filterChip("Price: Low-High", "price-low", (v) => setState(() => _sort = v), isSort: true),
                        _filterChip("Price: High-Low", "price-high", (v) => setState(() => _sort = v), isSort: true),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Consumer<RoomProvider>(
                builder: (context, provider, _) {
                  switch (provider.status) {
                    case ViewStatus.initial:
                      return const EmptyView(message: "Search for a room by name, location or filters.", icon: Icons.search_rounded);
                    case ViewStatus.loading:
                      return const LoadingView();
                    case ViewStatus.error:
                      return ErrorView(message: provider.errorMessage ?? "Search failed.", onRetry: _runSearch);
                    case ViewStatus.empty:
                      return const EmptyView(message: "No rooms match your search.", icon: Icons.search_off_rounded);
                    case ViewStatus.loaded:
                      return ListView.builder(
                        padding: const EdgeInsets.all(16),
                        itemCount: provider.rooms.length,
                        itemBuilder: (context, index) {
                          final room = provider.rooms[index];
                          return Card(
                            margin: const EdgeInsets.only(bottom: 12),
                            clipBehavior: Clip.antiAlias,
                            child: ListTile(
                              contentPadding: const EdgeInsets.all(10),
                              leading: ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: AppNetworkImage(url: room.imageUrl, width: 64, height: 64),
                              ),
                              title: Text(room.title, style: const TextStyle(fontWeight: FontWeight.w600)),
                              subtitle: Text("${room.location}\n${Formatters.money(room.price)}/mo"),
                              isThreeLine: true,
                              onTap: () => Navigator.of(context)
                                  .push(MaterialPageRoute(builder: (_) => RoomDetailScreen(roomId: room.id))),
                            ),
                          );
                        },
                      );
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _filterChip(String label, String value, ValueChanged<String?> onPick, {bool isSort = false}) {
    final selected = isSort ? _sort == value : _type == value;
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        label: Text(label, style: const TextStyle(fontSize: 12)),
        selected: selected,
        onSelected: (isSelected) {
          onPick(isSelected ? value : null);
          _runSearch();
        },
        selectedColor: AppTheme.primary.withValues(alpha: 0.15),
      ),
    );
  }
}
