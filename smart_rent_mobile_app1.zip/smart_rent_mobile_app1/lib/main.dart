import "package:flutter/material.dart";
import "package:provider/provider.dart";

import "core/config/api_config.dart";
import "core/network/dio_client.dart";
import "core/theme/app_theme.dart";
import "navigation/root_shell.dart";
import "providers/auth_provider.dart";
import "providers/connectivity_provider.dart";
import "providers/property_provider.dart";
import "providers/room_provider.dart";
import "repositories/auth_repository.dart";
import "repositories/property_repository.dart";
import "repositories/room_repository.dart";
import "features/authentication/screens/splash_screen.dart";

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Must happen before DioClient.init() builds the Dio instance (which
  // reads ApiConfig.baseUrl once, at construction time) — otherwise a
  // manually-saved server address (see Server Settings screen) would be
  // ignored on this launch and only take effect after a second restart.
  await ApiConfig.loadManualOverride();
  // Must finish before any screen can call the API — this is what loads
  // the persisted cookie jar from disk so a still-valid session survives
  // an app restart (requirement #37).
  await DioClient.instance.init();
  runApp(const SmartRentApp());
}

class SmartRentApp extends StatelessWidget {
  const SmartRentApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider(AuthRepository())..restoreSession()),
        ChangeNotifierProvider(create: (_) => ConnectivityProvider()),
        ChangeNotifierProvider(create: (_) => RoomProvider(RoomRepository())),
        ChangeNotifierProvider(create: (_) => PropertyProvider(PropertyRepository())),
      ],
      child: MaterialApp(
        title: "Smart Rent",
        debugShowCheckedModeBanner: false,
        theme: AppTheme.light,
        home: const SplashScreen(),
      ),
    );
  }
}

/// Placeholder kept for clarity of the app entry flow:
/// SplashScreen -> (session restored) -> RootShell picks the UI by role.
class AppEntry {
  static Widget resolve() => const RootShell();
}
