import "package:dio/dio.dart";

import "../core/network/dio_client.dart";
import "../models/booking.dart";

/// Talks to BookingController (/api/bookings). A booking here always
/// represents an ALREADY-PAID reservation — see BookingController::create()
/// docblock: it atomically creates the booking, payment, payout and
/// receipt rows, and marks the room "taken", all server-side in one
/// transaction. The Flutter client must supply payment_method/reference/
/// amount together with the booking details; it never talks to a payment
/// gateway directly (requirement #24 — no secrets on the client).
class BookingRepository {
  final Dio _dio = DioClient.instance.dio;

  Future<List<Booking>> getAll() async {
    return DioClient.instance.guard(() async {
      final response = await _dio.get("/bookings");
      DioClient.instance.throwIfError(response);
      final list = (response.data as List).cast<Map>();
      return list.map((e) => Booking.fromJson(Map<String, dynamic>.from(e))).toList();
    });
  }

  Future<Map<String, dynamic>> create({
    required int roomId,
    required String customerName,
    required String customerEmail,
    required String customerPhone,
    required double amount,
    String? paymentMethod,
    String? reference,
    String? recipientNumber,
    String? arrivalDate,
    String rentalMode = "holiday",
    String? paymentTerms,
    String? responsibilities,
    String? terminationConditions,
    String? otherTerms,
  }) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.post("/bookings", data: {
        "room_id": roomId,
        "customer_name": customerName,
        "customer_email": customerEmail,
        "customer_phone": customerPhone,
        "amount": amount,
        if (paymentMethod != null) "payment_method": paymentMethod,
        if (reference != null) "reference": reference,
        if (recipientNumber != null) "recipient_number": recipientNumber,
        if (arrivalDate != null) "arrival_date": arrivalDate,
        "rental_mode": rentalMode,
        if (paymentTerms != null) "payment_terms": paymentTerms,
        if (responsibilities != null) "responsibilities": responsibilities,
        if (terminationConditions != null) "termination_conditions": terminationConditions,
        if (otherTerms != null) "other_terms": otherTerms,
      });
      DioClient.instance.throwIfError(response);
      return Map<String, dynamic>.from(response.data);
    });
  }

  Future<Map<String, dynamic>> pay({
    required int bookingId,
    required double amount,
    required String paymentMethod,
    required String reference,
    String? recipientNumber,
  }) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.post("/bookings/$bookingId/pay", data: {
        "amount": amount,
        "payment_method": paymentMethod,
        "reference": reference,
        if (recipientNumber != null) "recipient_number": recipientNumber,
      });
      DioClient.instance.throwIfError(response);
      return Map<String, dynamic>.from(response.data);
    });
  }

  Future<void> update(int id, Map<String, dynamic> fields) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.put("/bookings/$id", data: fields);
      DioClient.instance.throwIfError(response);
    });
  }

  Future<void> delete(int id) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.delete("/bookings/$id");
      DioClient.instance.throwIfError(response);
    });
  }
}
