import "package:dio/dio.dart";

import "../core/network/dio_client.dart";
import "../models/conversation.dart";
import "../models/direct_message.dart";

class MessagingRepository {
  final Dio _dio = DioClient.instance.dio;

  Future<List<Conversation>> getConversations() async {
    return DioClient.instance.guard(() async {
      final response = await _dio.get("/chat-messages/conversations");
      DioClient.instance.throwIfError(response);
      final list = (response.data as List).cast<Map>();
      return list.map((e) => Conversation.fromJson(Map<String, dynamic>.from(e))).toList();
    });
  }

  Future<List<ChatContact>> getContacts() async {
    return DioClient.instance.guard(() async {
      final response = await _dio.get("/chat-messages/contacts");
      DioClient.instance.throwIfError(response);
      final list = (response.data as List).cast<Map>();
      return list.map((e) => ChatContact.fromJson(Map<String, dynamic>.from(e))).toList();
    });
  }

  Future<List<DirectMessage>> getThread(int otherId) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.get("/chat-messages/thread/$otherId");
      DioClient.instance.throwIfError(response);
      final list = (response.data as List).cast<Map>();
      return list.map((e) => DirectMessage.fromJson(Map<String, dynamic>.from(e))).toList();
    });
  }

  Future<void> sendMessage({
    required int receiverId,
    required String message,
    String? listingType,
    int? listingId,
  }) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.post("/chat-messages/send", data: {
        "receiver_id": receiverId,
        "message": message,
        if (listingType != null) "listing_type": listingType,
        if (listingId != null) "listing_id": listingId,
      });
      DioClient.instance.throwIfError(response);
    });
  }
}
