import "package:dio/dio.dart";

import "../core/network/dio_client.dart";
import "../models/payout.dart";

/// Talks to PayoutController (/api/payouts). Landlord sees only their own;
/// Admin sees all and can update status / the platform commission rate.
class PayoutRepository {
  final Dio _dio = DioClient.instance.dio;

  Future<List<Payout>> getAll() async {
    return DioClient.instance.guard(() async {
      final response = await _dio.get("/payouts");
      DioClient.instance.throwIfError(response);
      final list = (response.data as List).cast<Map>();
      return list.map((e) => Payout.fromJson(Map<String, dynamic>.from(e))).toList();
    });
  }

  /// Admin only.
  Future<void> updateStatus(
    int id, {
    required String status,
    String? payoutMethod,
    String? payoutReference,
    String? notes,
  }) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.put("/payouts/$id", data: {
        "status": status,
        if (payoutMethod != null) "payout_method": payoutMethod,
        if (payoutReference != null) "payout_reference": payoutReference,
        if (notes != null) "notes": notes,
      });
      DioClient.instance.throwIfError(response);
    });
  }

  /// Admin only.
  Future<double> getCommissionRate() async {
    return DioClient.instance.guard(() async {
      final response = await _dio.get("/payouts/settings");
      DioClient.instance.throwIfError(response);
      final rate = response.data["platform_commission_rate"];
      return (rate is num) ? rate.toDouble() : double.tryParse(rate.toString()) ?? 0;
    });
  }

  /// Admin only.
  Future<void> updateCommissionRate(double rate) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.put("/payouts/settings", data: {
        "platform_commission_rate": rate,
      });
      DioClient.instance.throwIfError(response);
    });
  }
}
