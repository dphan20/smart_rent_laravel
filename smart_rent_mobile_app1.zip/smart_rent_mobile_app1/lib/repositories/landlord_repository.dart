import "package:dio/dio.dart";

import "../core/network/dio_client.dart";

/// Talks to LandlordController (/api/landlord) — dashboard KPI cards for
/// the signed-in landlord, scoped server-side to just their own
/// properties/rooms/bookings/earnings. Previously the landlord dashboard
/// called AdminRepository (/admin/dashboard), which is intentionally
/// Admin-only and always returned "Forbidden - admin only" for a landlord.
class LandlordRepository {
  final Dio _dio = DioClient.instance.dio;

  Future<Map<String, dynamic>> getDashboard() async {
    return DioClient.instance.guard(() async {
      final response = await _dio.get("/landlord/dashboard");
      DioClient.instance.throwIfError(response);
      return Map<String, dynamic>.from(response.data);
    });
  }
}
