import "package:dio/dio.dart";

import "../core/network/dio_client.dart";
import "../models/order.dart";

/// Talks to OrderController (/api/orders) — an unpaid reservation request.
/// Landlord/Admin confirming it auto-generates a Contract server-side.
class OrderRepository {
  final Dio _dio = DioClient.instance.dio;

  Future<List<RoomOrder>> getAll() async {
    return DioClient.instance.guard(() async {
      final response = await _dio.get("/orders");
      DioClient.instance.throwIfError(response);
      final list = (response.data as List).cast<Map>();
      return list.map((e) => RoomOrder.fromJson(Map<String, dynamic>.from(e))).toList();
    });
  }

  Future<int> create({
    required int roomId,
    required String customerName,
    required String customerEmail,
    required String customerPhone,
    String? arrivalDate,
  }) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.post("/orders", data: {
        "room_id": roomId,
        "customer_name": customerName,
        "customer_email": customerEmail,
        "customer_phone": customerPhone,
        if (arrivalDate != null) "arrival_date": arrivalDate,
      });
      DioClient.instance.throwIfError(response);
      return response.data["id"] as int;
    });
  }

  /// Landlord/Admin only for status="confirmed"/"cancelled" transitions.
  Future<void> update(int id, Map<String, dynamic> fields) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.put("/orders/$id", data: fields);
      DioClient.instance.throwIfError(response);
    });
  }

  Future<void> delete(int id) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.delete("/orders/$id");
      DioClient.instance.throwIfError(response);
    });
  }
}
