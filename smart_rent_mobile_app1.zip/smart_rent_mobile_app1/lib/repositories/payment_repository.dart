import "package:dio/dio.dart";

import "../core/network/dio_client.dart";
import "../models/payment.dart";

/// Talks to PaymentController (/api/payments). Standalone payment records
/// created here (as opposed to through BookingRepository.create, which
/// bundles booking+payment atomically) always start as "pending" — the
/// backend never trusts a client-claimed "successful" status
/// (see PaymentController::create() docblock). Only an Admin
/// (PUT /payments/{id}/verify) or a signed payment-gateway webhook can
/// move a payment to successful/failed.
class PaymentRepository {
  final Dio _dio = DioClient.instance.dio;

  Future<List<Payment>> getAll() async {
    return DioClient.instance.guard(() async {
      final response = await _dio.get("/payments");
      DioClient.instance.throwIfError(response);
      final list = (response.data as List).cast<Map>();
      return list.map((e) => Payment.fromJson(Map<String, dynamic>.from(e))).toList();
    });
  }

  Future<int> create({
    required double amount,
    required String paymentMethod,
    required String reference,
    int? roomId,
    String? recipientNumber,
  }) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.post("/payments", data: {
        "amount": amount,
        "payment_method": paymentMethod,
        "reference": reference,
        if (roomId != null) "room_id": roomId,
        if (recipientNumber != null) "recipient_number": recipientNumber,
      });
      DioClient.instance.throwIfError(response);
      return response.data["id"] as int;
    });
  }

  /// Admin only.
  Future<void> verify(int id, {required bool successful}) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.put("/payments/$id/verify", data: {
        "status": successful ? "successful" : "failed",
      });
      DioClient.instance.throwIfError(response);
    });
  }

  Future<void> delete(int id) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.delete("/payments/$id");
      DioClient.instance.throwIfError(response);
    });
  }
}
