import "package:dio/dio.dart";
import "package:image_picker/image_picker.dart";

import "../core/network/dio_client.dart";
import "../models/room.dart";

/// Talks to RoomController (/api/rooms). GET is public; create/update/
/// delete require auth and are scoped server-side to Admin/Landlord (and,
/// for a Landlord, only their own rooms — never trust a client-supplied
/// landlord_id).
class RoomRepository {
  final Dio _dio = DioClient.instance.dio;

  Future<List<Room>> getAll({
    String? search,
    String? location,
    String? area,
    double? maxPrice,
    int? minSize,
    String? type,
    String? sort, // price-low | price-high | size-low | size-high
  }) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.get("/rooms", queryParameters: {
        if (search != null && search.isNotEmpty) "search": search,
        if (location != null && location.isNotEmpty) "location": location,
        if (area != null && area.isNotEmpty) "area": area,
        if (maxPrice != null) "max_price": maxPrice,
        if (minSize != null) "min_size": minSize,
        if (type != null && type.isNotEmpty) "type": type,
        if (sort != null) "sort": sort,
      });
      DioClient.instance.throwIfError(response);
      final list = (response.data as List).cast<Map>();
      return list.map((e) => Room.fromJson(Map<String, dynamic>.from(e))).toList();
    });
  }

  Future<Room> getOne(int id) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.get("/rooms/$id");
      DioClient.instance.throwIfError(response);
      return Room.fromJson(Map<String, dynamic>.from(response.data));
    });
  }

  /// Landlord/Admin only. `image` is required by the backend.
  Future<int> create({
    required String title,
    required String location,
    required String area,
    required double price,
    required int size,
    required String type,
    required int beds,
    String? badge,
    XFile? image,
    int? landlordId, // Admin-only override; Landlord is forced server-side
  }) async {
    return DioClient.instance.guard(() async {
      final formMap = <String, dynamic>{
        "title": title,
        "location": location,
        "area": area,
        "price": price,
        "size": size,
        "type": type,
        "beds": beds,
        if (badge != null) "badge": badge,
        if (landlordId != null) "landlord_id": landlordId,
      };
      if (image != null) {
        // readAsBytes() (not fromFile(image.path)) so this works on web too,
        // where XFile.path is a blob: URL rather than a real file path.
        formMap["image"] = MultipartFile.fromBytes(await image.readAsBytes(), filename: image.name);
      }
      final response = await _dio.post("/rooms", data: FormData.fromMap(formMap));
      DioClient.instance.throwIfError(response);
      return response.data["id"] as int;
    });
  }

  Future<void> update(int id, Map<String, dynamic> fields) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.put("/rooms/$id", data: fields);
      DioClient.instance.throwIfError(response);
    });
  }

  Future<void> delete(int id) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.delete("/rooms/$id");
      DioClient.instance.throwIfError(response);
    });
  }

  /// Appends one or more photos to this room's existing gallery without
  /// disturbing the images already there (RoomController::addImages()).
  Future<void> addImages(int id, List<XFile> images) async {
    return DioClient.instance.guard(() async {
      final formMap = <String, dynamic>{
        "images[]": await Future.wait(images.map(
          (img) async => MultipartFile.fromBytes(await img.readAsBytes(), filename: img.name),
        )),
      };
      final response = await _dio.post("/rooms/$id/images", data: FormData.fromMap(formMap));
      DioClient.instance.throwIfError(response);
    });
  }

  /// Removes a single photo by its position in the gallery
  /// (RoomController::deleteImage()).
  Future<void> deleteImage(int id, int index) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.delete("/rooms/$id/images/$index");
      DioClient.instance.throwIfError(response);
    });
  }
}
