import "package:dio/dio.dart";
import "package:image_picker/image_picker.dart";

import "../core/network/dio_client.dart";
import "../models/property.dart";

/// Talks to PropertyController (/api/properties). Creating a property is
/// Landlord-only and, per PropertyController::create(), ALSO auto-creates a
/// matching `rooms` row on the backend — the mobile client does not need to
/// (and must not) create that room row itself.
class PropertyRepository {
  final Dio _dio = DioClient.instance.dio;

  Future<List<Property>> getAll({int? landlordId}) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.get("/properties", queryParameters: {
        if (landlordId != null) "landlord_id": landlordId,
      });
      DioClient.instance.throwIfError(response);
      final list = (response.data as List).cast<Map>();
      return list.map((e) => Property.fromJson(Map<String, dynamic>.from(e))).toList();
    });
  }

  Future<Property> getOne(int id) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.get("/properties/$id");
      DioClient.instance.throwIfError(response);
      return Property.fromJson(Map<String, dynamic>.from(response.data));
    });
  }

  Future<Property> getBySri(String sri) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.get("/properties/sri/$sri");
      DioClient.instance.throwIfError(response);
      return Property.fromJson(Map<String, dynamic>.from(response.data));
    });
  }

  /// Landlord only. `images` requires at least one file. `virtualTourImage`
  /// is optional — an uploaded 360° panorama photo takes priority over a
  /// pasted `virtualTourUrl` if both are somehow provided, exactly like the
  /// backend does (see PropertyController::create()).
  Future<Map<String, dynamic>> create({
    required String name,
    required String type,
    String? apartment,
    String? houseNo,
    required String region,
    required String district,
    String? ward,
    String? street,
    required int bedrooms,
    required int bathrooms,
    Map<String, bool>? amenities,
    required String furnished,
    required int roomSize,
    required double monthlyRent,
    double? deposit,
    double? serviceCharge,
    String availability = "available",
    required List<XFile> images,
    XFile? virtualTourImage,
    String? virtualTourUrl,
    String rentalMode = "rent",
  }) async {
    return DioClient.instance.guard(() async {
      final formMap = <String, dynamic>{
        "name": name,
        "type": type,
        "rental_mode": rentalMode,
        if (apartment != null) "apartment": apartment,
        if (houseNo != null) "house_no": houseNo,
        "region": region,
        "district": district,
        if (ward != null) "ward": ward,
        if (street != null) "street": street,
        "bedrooms": bedrooms,
        "bathrooms": bathrooms,
        if (amenities != null) "amenities": _amenitiesToJson(amenities),
        "furnished": furnished,
        "roomSize": roomSize,
        "monthlyRent": monthlyRent,
        if (deposit != null) "deposit": deposit,
        if (serviceCharge != null) "service_charge": serviceCharge,
        "availability": availability,
        // MultipartFile.fromFile(img.path) only works where XFile.path is a
        // real filesystem path (Android/iOS/desktop). On web, XFile.path is
        // a blob: URL that dart:io can't open, so it must be read as bytes
        // instead — readAsBytes() works identically on every platform.
        "images[]": [
          for (final img in images)
            MultipartFile.fromBytes(await img.readAsBytes(), filename: img.name),
        ],
      };
      if (virtualTourImage != null) {
        formMap["virtualTourImage"] = MultipartFile.fromBytes(
          await virtualTourImage.readAsBytes(),
          filename: virtualTourImage.name,
        );
      } else if (virtualTourUrl != null && virtualTourUrl.isNotEmpty) {
        formMap["virtualTour"] = virtualTourUrl;
      }

      final response = await _dio.post("/properties", data: FormData.fromMap(formMap));
      DioClient.instance.throwIfError(response);
      return Map<String, dynamic>.from(response.data);
    });
  }

  Future<void> delete(int id) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.delete("/properties/$id");
      DioClient.instance.throwIfError(response);
    });
  }

  /// Appends one or more photos to this property's existing gallery
  /// (PropertyController::addImages()).
  Future<void> addImages(int id, List<XFile> images) async {
    return DioClient.instance.guard(() async {
      final formMap = <String, dynamic>{
        "images[]": await Future.wait(images.map(
          (img) async => MultipartFile.fromBytes(await img.readAsBytes(), filename: img.name),
        )),
      };
      final response = await _dio.post("/properties/$id/images", data: FormData.fromMap(formMap));
      DioClient.instance.throwIfError(response);
    });
  }

  /// Removes a single photo by its position in the gallery
  /// (PropertyController::deleteImage()).
  Future<void> deleteImage(int id, int index) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.delete("/properties/$id/images/$index");
      DioClient.instance.throwIfError(response);
    });
  }

  String _amenitiesToJson(Map<String, bool> amenities) {
    final buffer = StringBuffer("{");
    var first = true;
    amenities.forEach((key, value) {
      if (!first) buffer.write(",");
      buffer.write("\"$key\":$value");
      first = false;
    });
    buffer.write("}");
    return buffer.toString();
  }
}
