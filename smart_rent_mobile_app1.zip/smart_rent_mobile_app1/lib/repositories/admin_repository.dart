import "package:dio/dio.dart";

import "../core/network/dio_client.dart";

/// Talks to AdminController (/api/admin) — dashboard KPI cards + chart
/// series, Admin-only, computed entirely server-side from real MySQL rows.
class AdminRepository {
  final Dio _dio = DioClient.instance.dio;

  Future<Map<String, dynamic>> getDashboard() async {
    return DioClient.instance.guard(() async {
      final response = await _dio.get("/admin/dashboard");
      DioClient.instance.throwIfError(response);
      return Map<String, dynamic>.from(response.data);
    });
  }

  Future<Map<String, dynamic>> getCommissionReport() async {
    return DioClient.instance.guard(() async {
      final response = await _dio.get("/admin/commission-report");
      DioClient.instance.throwIfError(response);
      return Map<String, dynamic>.from(response.data);
    });
  }
}
