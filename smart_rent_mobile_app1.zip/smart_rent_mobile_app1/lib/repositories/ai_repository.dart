import "package:dio/dio.dart";

import "../core/network/dio_client.dart";

/// Talks to ChatController (real Laravel routes: /api/chat, /api/ai/*,
/// /api/chat/history) — the AI Smart Rent chatbot, matchmaker, and
/// per-listing Q&A. Genuinely backed by GroqService server-side; the
/// mobile client never fabricates a response if the API errors.
class AiRepository {
  final Dio _dio = DioClient.instance.dio;

  Future<Map<String, dynamic>> sendMessage(String message, {String? sessionId}) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.post("/chat", data: {
        "message": message,
        if (sessionId != null) "session_id": sessionId,
      });
      DioClient.instance.throwIfError(response);
      return Map<String, dynamic>.from(response.data);
    });
  }

  /// AI House Matchmaker — free-text query, returns matching listings.
  Future<Map<String, dynamic>> match(String query) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.post("/ai/match", data: {"query": query});
      DioClient.instance.throwIfError(response);
      return Map<String, dynamic>.from(response.data);
    });
  }

  /// "Ask AI About This Property" — grounded in the live listing record.
  Future<Map<String, dynamic>> askAboutProperty({required int roomId, required String question}) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.post("/ai/ask-property", data: {
        "room_id": roomId,
        "question": question,
      });
      DioClient.instance.throwIfError(response);
      return Map<String, dynamic>.from(response.data);
    });
  }

  Future<List<Map<String, dynamic>>> similarListings(int roomId) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.get("/ai/similar", queryParameters: {"room_id": roomId});
      DioClient.instance.throwIfError(response);
      final results = (response.data["results"] as List?) ?? [];
      return results.map((e) => Map<String, dynamic>.from(e)).toList();
    });
  }

  Future<List<Map<String, dynamic>>> getHistory({int limit = 50}) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.get("/chat/history", queryParameters: {"limit": limit});
      DioClient.instance.throwIfError(response);
      final conversations = (response.data["conversations"] as List?) ?? [];
      return conversations.map((e) => Map<String, dynamic>.from(e)).toList();
    });
  }

  Future<void> clearHistory() async {
    return DioClient.instance.guard(() async {
      final response = await _dio.delete("/chat/history");
      DioClient.instance.throwIfError(response);
    });
  }
}
