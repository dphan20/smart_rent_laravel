import "package:dio/dio.dart";
import "package:image_picker/image_picker.dart";

import "../core/network/dio_client.dart";
import "../models/tour360.dart";

/// Talks to Tour360Controller (/api/tours). This is the CRITICAL feature
/// per the project brief: every panorama and hotspot must come from these
/// exact endpoints, matching the web/admin systems 360° tour data 1:1.
///
///   GET    /tours?listing_type=&listing_id=   list scenes+hotspots (public)
///   GET    /tours/{tourId}                    one scene+hotspots (public)
///   POST   /tours                             create scene (multipart, auth)
///   PUT    /tours/{tourId}                    update scene (auth)
///   DELETE /tours/{tourId}                    delete scene (auth)
///   POST   /tours/{tourId}/hotspots           create hotspot (auth)
///   PUT    /tours/hotspot/{hotspotId}         update hotspot (auth)
///   DELETE /tours/hotspot/{hotspotId}         delete hotspot (auth)
class TourRepository {
  final Dio _dio = DioClient.instance.dio;

  /// Fetches every scene (with hotspots embedded) for a room or property.
  /// listingType must be exactly "room" or "property".
  Future<List<Tour360Scene>> getTourForListing({
    required String listingType,
    required int listingId,
  }) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.get("/tours", queryParameters: {
        "listing_type": listingType,
        "listing_id": listingId,
      });
      DioClient.instance.throwIfError(response);
      final scenes = (response.data["scenes"] as List).cast<Map>();
      return scenes.map((e) => Tour360Scene.fromJson(Map<String, dynamic>.from(e))).toList();
    });
  }

  Future<Tour360Scene> getScene(int tourId) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.get("/tours/$tourId");
      DioClient.instance.throwIfError(response);
      return Tour360Scene.fromJson(Map<String, dynamic>.from(response.data));
    });
  }

  /// Admin or the owning Landlord only (enforced server-side via
  /// Tour360::userCanManageListing() — never trust a client-side check).
  Future<int> createScene({
    required String listingType,
    required int listingId,
    required String name,
    String? description,
    bool isPrimary = false,
    required XFile panoramaImage,
  }) async {
    return DioClient.instance.guard(() async {
      final formMap = <String, dynamic>{
        "listing_type": listingType,
        "listing_id": listingId,
        "name": name,
        if (description != null) "description": description,
        if (isPrimary) "is_primary": 1,
        // readAsBytes() (not fromFile(path)) so this works on web too, where
        // XFile.path is a blob: URL rather than a real file path.
        "image": MultipartFile.fromBytes(await panoramaImage.readAsBytes(), filename: panoramaImage.name),
      };
      final response = await _dio.post("/tours", data: FormData.fromMap(formMap));
      DioClient.instance.throwIfError(response);
      return response.data["id"] as int;
    });
  }

  Future<void> updateScene(int tourId, {String? name, String? description, bool? isPrimary}) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.put("/tours/$tourId", data: {
        if (name != null) "name": name,
        if (description != null) "description": description,
        if (isPrimary != null) "is_primary": isPrimary,
      });
      DioClient.instance.throwIfError(response);
    });
  }

  Future<void> deleteScene(int tourId) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.delete("/tours/$tourId");
      DioClient.instance.throwIfError(response);
    });
  }

  /// type must be "navigation" (jump to targetTourId) or "viewpoint"
  /// (re-orient within the same scene to targetYaw/targetPitch/targetHfov).
  Future<int> createHotspot({
    required int tourId,
    required HotspotType type,
    required double yaw,
    required double pitch,
    String? title,
    String? description,
    int? targetTourId,
    double? targetYaw,
    double? targetPitch,
    double? targetHfov,
  }) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.post("/tours/$tourId/hotspots", data: {
        "type": hotspotTypeToString(type),
        "yaw": yaw,
        "pitch": pitch,
        if (title != null) "title": title,
        if (description != null) "description": description,
        if (type == HotspotType.navigation) "target_tour_id": targetTourId,
        if (type == HotspotType.viewpoint) "target_yaw": targetYaw,
        if (type == HotspotType.viewpoint) "target_pitch": targetPitch,
        if (type == HotspotType.viewpoint && targetHfov != null) "target_hfov": targetHfov,
      });
      DioClient.instance.throwIfError(response);
      return response.data["id"] as int;
    });
  }

  Future<void> updateHotspot(int hotspotId, Map<String, dynamic> fields) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.put("/tours/hotspot/$hotspotId", data: fields);
      DioClient.instance.throwIfError(response);
    });
  }

  Future<void> deleteHotspot(int hotspotId) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.delete("/tours/hotspot/$hotspotId");
      DioClient.instance.throwIfError(response);
    });
  }
}
