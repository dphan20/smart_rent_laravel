import "package:dio/dio.dart";

import "../core/network/dio_client.dart";
import "../models/contract.dart";

/// Talks to ContractController (/api/contracts).
class ContractRepository {
  final Dio _dio = DioClient.instance.dio;

  Future<List<Contract>> getAll() async {
    return DioClient.instance.guard(() async {
      final response = await _dio.get("/contracts");
      DioClient.instance.throwIfError(response);
      final list = (response.data as List).cast<Map>();
      return list.map((e) => Contract.fromJson(Map<String, dynamic>.from(e))).toList();
    });
  }

  Future<Contract> getOne(int id) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.get("/contracts/$id");
      DioClient.instance.throwIfError(response);
      return Contract.fromJson(Map<String, dynamic>.from(response.data));
    });
  }

  /// Landlord/Admin only, and only for their own confirmed order.
  Future<int> create({required int orderId, Map<String, dynamic>? overrides}) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.post("/contracts", data: {
        "order_id": orderId,
        ...?overrides,
      });
      DioClient.instance.throwIfError(response);
      return response.data["id"] as int;
    });
  }

  Future<void> accept(int contractId) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.post("/contracts/$contractId/accept", data: {"accept": true});
      DioClient.instance.throwIfError(response);
    });
  }
}
