import "package:dio/dio.dart";

import "../core/network/dio_client.dart";
import "../models/user.dart";

/// Talks to AuthController (public/backend/controllers/AuthController.php)
/// through the /api/auth/* passthrough. This is the ONLY place in the app
/// that touches login/signup/logout/session — every other repository just
/// relies on the shared cookie jar already being authenticated.
class AuthRepository {
  final Dio _dio = DioClient.instance.dio;

  Future<AppUser> login({
    required String email,
    required String password,
    bool remember = true,
  }) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.post("/auth/login", data: {
        "email": email,
        "password": password,
        "remember": remember,
      });
      DioClient.instance.throwIfError(response);
      // Session was just regenerated server-side on login — refresh our
      // cached CSRF token so the next state-changing request does not 403.
      await DioClient.instance.refreshCsrfToken();
      final userJson = Map<String, dynamic>.from(response.data["user"]);
      return AppUser.fromJson(userJson);
    });
  }

  Future<AppUser> signup({
    required String name,
    required String email,
    required String password,
    String? phone,
    String type = "customer", // "customer" | "landlord" only — see backend
  }) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.post("/auth/signup", data: {
        "name": name,
        "email": email,
        "password": password,
        "phone": phone ?? "",
        "type": type,
      });
      DioClient.instance.throwIfError(response);
      await DioClient.instance.refreshCsrfToken();
      final userJson = Map<String, dynamic>.from(response.data["user"]);
      return AppUser.fromJson(userJson);
    });
  }

  /// Restores session on app start (requirement #37): asks the backend
  /// whether the cookie jar we loaded from disk is still a valid, logged-in
  /// session. Never assumes — the server is always the source of truth.
  Future<AppUser?> checkSession() async {
    return DioClient.instance.guard(() async {
      final response = await _dio.get("/auth/check");
      if (response.statusCode != 200) return null;
      final data = response.data;
      if (data is Map && data["loggedIn"] == true && data["user"] != null) {
        return AppUser.fromJson(Map<String, dynamic>.from(data["user"]));
      }
      return null;
    });
  }

  Future<void> logout() async {
    return DioClient.instance.guard(() async {
      final response = await _dio.post("/auth/logout");
      DioClient.instance.throwIfError(response);
      await DioClient.instance.clearSession();
    });
  }

  Future<void> changePassword({
    required String currentPassword,
    required String newPassword,
  }) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.post("/auth/change-password", data: {
        "currentPassword": currentPassword,
        "newPassword": newPassword,
      });
      DioClient.instance.throwIfError(response);
    });
  }

  Future<AppUser> updateProfile({
    required String name,
    required String email,
    String? phone,
  }) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.post("/auth/update-profile", data: {
        "name": name,
        "email": email,
        "phone": phone ?? "",
      });
      DioClient.instance.throwIfError(response);
      return AppUser.fromJson(Map<String, dynamic>.from(response.data["user"]));
    });
  }

  Future<void> requestPasswordReset(String email) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.post("/auth/request-password-reset", data: {"email": email});
      DioClient.instance.throwIfError(response);
    });
  }

  Future<void> resetPassword({required String token, required String newPassword}) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.post("/auth/reset-password", data: {
        "token": token,
        "newPassword": newPassword,
      });
      DioClient.instance.throwIfError(response);
    });
  }
}
