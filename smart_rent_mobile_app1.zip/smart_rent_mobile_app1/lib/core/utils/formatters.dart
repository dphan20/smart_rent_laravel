import "package:intl/intl.dart";

class Formatters {
  Formatters._();

  static final NumberFormat _tzs = NumberFormat.currency(
    locale: "en_US",
    symbol: "TZS ",
    decimalDigits: 0,
  );

  static String money(num? value) {
    if (value == null) return "TZS 0";
    return _tzs.format(value);
  }

  static final DateFormat _date = DateFormat("d MMM yyyy");
  static String date(String? isoDate) {
    if (isoDate == null || isoDate.isEmpty) return "—";
    try {
      return _date.format(DateTime.parse(isoDate));
    } catch (_) {
      return isoDate;
    }
  }

  static final DateFormat _dateTime = DateFormat("d MMM yyyy, h:mm a");
  static String dateTime(String? isoDate) {
    if (isoDate == null || isoDate.isEmpty) return "—";
    try {
      return _dateTime.format(DateTime.parse(isoDate));
    } catch (_) {
      return isoDate;
    }
  }
}
