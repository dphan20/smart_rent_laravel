import "package:flutter/material.dart";
import "package:provider/provider.dart";

import "../../features/authentication/screens/login_screen.dart";
import "../../providers/auth_provider.dart";

/// Requirement #18/#20 — guest browsing is allowed everywhere, but a
/// protected action (Book Now, viewing "My Bookings", opening the AI
/// concierge from a guest context, etc.) must prompt sign-in instead of
/// silently failing or being hidden entirely.
///
/// Returns true if the caller is now authenticated (either already was, or
/// just signed in/registered successfully) — callers should proceed with
/// the original action only when this resolves to true. Never pops the
/// caller's own screen, so the user lands back exactly where they were.
Future<bool> ensureAuthenticated(
  BuildContext context, {
  String message = "Please sign in or create an account to continue.",
}) async {
  final auth = context.read<AuthProvider>();
  if (auth.isLoggedIn) return true;

  final shouldSignIn = await showDialog<bool>(
    context: context,
    builder: (dialogContext) => AlertDialog(
      title: const Text("Sign in required"),
      content: Text(message),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(dialogContext).pop(false),
          child: const Text("Not now"),
        ),
        ElevatedButton(
          onPressed: () => Navigator.of(dialogContext).pop(true),
          child: const Text("Sign In"),
        ),
      ],
    ),
  );

  if (shouldSignIn != true || !context.mounted) return false;

  // LoginScreen (and, from there, SignupScreen) pop(true) on success instead
  // of clearing the stack, so we land back on whatever screen called this —
  // e.g. the room detail page the guest was already looking at.
  final result = await Navigator.of(context).push<bool>(
    MaterialPageRoute(builder: (_) => const LoginScreen()),
  );
  return result == true;
}
