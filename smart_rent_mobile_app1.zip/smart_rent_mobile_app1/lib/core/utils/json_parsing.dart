/// PDO returns DECIMAL/INT columns as PHP strings unless explicitly cast,
/// and json_encode() then serializes them as JSON strings (e.g. "400000.00"
/// instead of 400000). These helpers parse either shape safely so a model
/// never crashes on a field the backend happens to emit as a string.
double? parseDouble(dynamic value) {
  if (value == null) return null;
  if (value is num) return value.toDouble();
  if (value is String) {
    if (value.trim().isEmpty) return null;
    return double.tryParse(value.trim());
  }
  return null;
}

int? parseInt(dynamic value) {
  if (value == null) return null;
  if (value is int) return value;
  if (value is num) return value.toInt();
  if (value is String) {
    if (value.trim().isEmpty) return null;
    return int.tryParse(value.trim()) ?? double.tryParse(value.trim())?.toInt();
  }
  return null;
}

bool parseBool(dynamic value) {
  if (value == null) return false;
  if (value is bool) return value;
  if (value is num) return value != 0;
  if (value is String) {
    final v = value.trim().toLowerCase();
    return v == "1" || v == "true" || v == "yes";
  }
  return false;
}

String? parseString(dynamic value) {
  if (value == null) return null;
  return value.toString();
}
