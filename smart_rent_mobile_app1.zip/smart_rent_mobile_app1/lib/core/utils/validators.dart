class Validators {
  Validators._();

  static String? email(String? value) {
    if (value == null || value.trim().isEmpty) return "Email is required";
    final regex = RegExp(r"^[^@\s]+@[^@\s]+\.[^@\s]+$");
    if (!regex.hasMatch(value.trim())) return "Enter a valid email address";
    return null;
  }

  static String? password(String? value) {
    if (value == null || value.isEmpty) return "Password is required";
    if (value.length < 6) return "Password must be at least 6 characters";
    return null;
  }

  static String? required(String? value, {String field = "This field"}) {
    if (value == null || value.trim().isEmpty) return "$field is required";
    return null;
  }

  static String? phone(String? value) {
    if (value == null || value.trim().isEmpty) return "Phone number is required";
    final digits = value.replaceAll(RegExp(r"[^0-9+]"), "");
    if (digits.length < 9) return "Enter a valid phone number";
    return null;
  }
}
