import 'package:shared_preferences/shared_preferences.dart';

/// Everything stored here is disposable client convenience state —
/// NEVER the authoritative record of who is logged in (that lives in the
/// session cookie, see core/network/dio_client.dart) and NEVER a password.
/// Losing this data should only cost the user a little typing, never their
/// account state.
class LocalPrefs {
  LocalPrefs._();

  static const _kRememberedEmail = 'remembered_email';
  static const _kLanguageCode = 'language_code';
  static const _kLastKnownRole = 'last_known_role'; // UI hint only, never trusted for auth decisions
  static const _kServerHostOverride = 'server_host_override'; // e.g. "http://192.168.1.21:8000"

  static Future<void> setRememberedEmail(String? email) async {
    final prefs = await SharedPreferences.getInstance();
    if (email == null || email.isEmpty) {
      await prefs.remove(_kRememberedEmail);
    } else {
      await prefs.setString(_kRememberedEmail, email);
    }
  }

  static Future<String?> getRememberedEmail() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_kRememberedEmail);
  }

  static Future<void> setLanguageCode(String code) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kLanguageCode, code);
  }

  static Future<String> getLanguageCode() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_kLanguageCode) ?? 'en';
  }

  static Future<void> setLastKnownRole(String? role) async {
    final prefs = await SharedPreferences.getInstance();
    if (role == null) {
      await prefs.remove(_kLastKnownRole);
    } else {
      await prefs.setString(_kLastKnownRole, role);
    }
  }

  static Future<String?> getLastKnownRole() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_kLastKnownRole);
  }

  static Future<void> clearAll() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_kLastKnownRole);
    // Deliberately keep remembered email + language — logging out shouldn't
    // make the user retype their email next time.
  }

  /// The server address the app was last manually pointed at (see
  /// ApiConfig.serverRoot / the "Server settings" screen). This is what
  /// lets the app follow the phone onto a different Wi-Fi network without
  /// a rebuild — whoever installs the app just types the new address in
  /// once instead of us hard-coding an IP that breaks the moment the
  /// network changes.
  static Future<void> setServerHostOverride(String? host) async {
    final prefs = await SharedPreferences.getInstance();
    if (host == null || host.trim().isEmpty) {
      await prefs.remove(_kServerHostOverride);
    } else {
      await prefs.setString(_kServerHostOverride, host.trim());
    }
  }

  static Future<String?> getServerHostOverride() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_kServerHostOverride);
  }
}
