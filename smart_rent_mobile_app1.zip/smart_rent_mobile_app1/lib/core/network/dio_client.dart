import 'dart:io' show SocketException;

import 'package:cookie_jar/cookie_jar.dart';
import 'package:dio/dio.dart';
import 'package:dio_cookie_manager/dio_cookie_manager.dart';
import 'package:flutter/foundation.dart' show kIsWeb;

import '../config/api_config.dart';
import 'api_exception.dart';
import 'cookie_store.dart';

/// One shared Dio instance for the entire app.
///
/// This backend authenticates with cookies (SMART_RENT_SESSID +
/// smart_rent_remember — see public/backend/config/session.php and
/// AuthController), NOT a bearer token, because Sanctum/Passport are not
/// installed. `SMART_RENT_SESSID` is httpOnly, which only blocks *browser
/// JavaScript* from reading it — a native HTTP client like Dio can still
/// receive it via Set-Cookie and resend it via Cookie on every request, as
/// long as we keep a PersistCookieJar. That cookie jar is what makes
/// "session restore after app restart" (requirement #37) work: it is
/// written to disk and reloaded on next launch, so a still-valid session
/// silently keeps the user logged in without storing the password anywhere.
///
/// State-changing requests (POST/PUT/DELETE, except login/signup and the
/// payment webhook) also require an `X-CSRF-Token` header taken from
/// `GET /auth/csrf`. DioClient fetches and caches that token and attaches
/// it automatically, refreshing once if a request comes back 403 with an
/// "Invalid CSRF token" body (the token rotates when the PHP session is
/// regenerated, e.g. right after login).
class DioClient {
  DioClient._internal();
  static final DioClient instance = DioClient._internal();

  late final Dio dio;
  // CookieJar (not PersistCookieJar) because the web variant returned by
  // buildCookieJar() is an in-memory CookieJar — see cookie_store_web.dart.
  CookieJar? _cookieJar;
  String? _csrfToken;
  bool _initialized = false;

  /// Re-points the already-constructed Dio instance at a new server
  /// address without needing an app restart — called by the Server
  /// Settings screen right after ApiConfig.setManualOverride() saves the
  /// new address. Without this, only NEW Dio instances would notice the
  /// change (there are none — it's a singleton), so the change would
  /// silently do nothing until the app was killed and relaunched.
  void applyServerRootChange() {
    if (_initialized) {
      dio.options.baseUrl = ApiConfig.baseUrl;
    }
  }

  /// Must be awaited once (e.g. in main()) before the app makes any
  /// network calls, so the cookie jar is ready (loaded from disk on
  /// Android/iOS/desktop; a fresh in-memory jar on web).
  Future<void> init() async {
    if (_initialized) return;

    // Platform-specific: file-backed jar on Android/iOS/desktop, in-memory
    // jar on web (see cookie_store_io.dart / cookie_store_web.dart). This
    // used to call path_provider + FileStorage unconditionally, which
    // crashed here in main() — before runApp() ever ran — on web, because
    // neither has a real file system to use. That crash, happening before
    // the first frame, is what showed up as a blank white page in Chrome.
    _cookieJar = await buildCookieJar();

    dio = Dio(
      BaseOptions(
        baseUrl: ApiConfig.baseUrl,
        connectTimeout: ApiConfig.connectTimeout,
        receiveTimeout: ApiConfig.receiveTimeout,
        sendTimeout: ApiConfig.sendTimeout,
        headers: {
          'Accept': 'application/json',
        },
        // We inspect status codes ourselves in every repository call
        // rather than letting Dio throw for 4xx, so server-provided
        // validation messages / field errors can be surfaced properly.
        validateStatus: (_) => true,
      ),
    );

    // dio_cookie_manager's CookieManager explicitly refuses to be
    // constructed on web (it asserts !kIsWeb internally) — the browser
    // already attaches/stores cookies on its own for every request, which
    // is exactly what enableBrowserCredentials() below switches on. Adding
    // this interceptor unconditionally is what was crashing the app right
    // after it started rendering (visible in the browser console as
    // "Assertion failed ... Don't use the manager in Web environments").
    if (!kIsWeb) {
      dio.interceptors.add(CookieManager(_cookieJar!));
    }
    // No-op on native; on web this turns on withCredentials so the
    // browser actually sends/receives the SMART_RENT_SESSID cookie
    // cross-origin (see cookie_store_web.dart for the backend
    // requirements this depends on).
    enableBrowserCredentials(dio);

    dio.interceptors.add(
      InterceptorsWrapper(
        onRequest: (options, handler) async {
          final method = options.method.toUpperCase();
          final needsCsrf = method != 'GET' &&
              method != 'HEAD' &&
              method != 'OPTIONS' &&
              !_isCsrfExemptPath(options.path);
          if (needsCsrf) {
            final token = await _ensureCsrfToken();
            if (token != null) {
              options.headers['X-CSRF-Token'] = token;
            }
          }
          handler.next(options);
        },
      ),
    );

    _initialized = true;
  }

  bool _isCsrfExemptPath(String path) {
    final p = path.startsWith('/') ? path.substring(1) : path;
    // Exact-match only for the AI-bot endpoints — NOT a prefix match.
    // `p.startsWith('chat')` used to also match every `/chat-messages/*`
    // call (send, thread, etc.), which is a completely different,
    // CSRF-protected resource on the backend (see api.php's CSRF block —
    // 'chat-messages' has no exemption there). That meant every human
    // chat message POST silently went out with no X-CSRF-Token header,
    // the backend rejected it with 403 "Invalid CSRF token", and nothing
    // was ever persisted — which is exactly why conversations always
    // showed empty for every role, even right after "sending" a message.
    return p == 'auth/login' ||
        p == 'auth/signup' ||
        p == 'payments/webhook' ||
        p == 'chat' ||
        p == 'chat/history' ||
        p.startsWith('ai/');
  }

  Future<String?> _ensureCsrfToken({bool forceRefresh = false}) async {
    if (_csrfToken != null && !forceRefresh) return _csrfToken;
    try {
      final response = await dio.get(
        '/auth/csrf',
        options: Options(headers: {'Accept': 'application/json'}),
      );
      if (response.statusCode == 200 && response.data is Map) {
        _csrfToken = response.data['csrf_token'] as String?;
      }
    } catch (_) {
      // Fails silently — the actual request will surface a clearer error
      // (e.g. "no internet") than a failed CSRF pre-fetch would.
    }
    return _csrfToken;
  }

  /// Called by AuthRepository right after a successful login/signup/logout,
  /// since the legacy backend regenerates the session (and therefore the
  /// CSRF token bound to it) at those points.
  Future<void> refreshCsrfToken() => _ensureCsrfToken(forceRefresh: true);

  Future<void> clearSession() async {
    await _cookieJar?.deleteAll();
    _csrfToken = null;
  }

  /// Wraps any Dio call so every repository gets the same typed exceptions
  /// instead of hand-rolling try/catch everywhere.
  Future<T> guard<T>(Future<T> Function() call) async {
    try {
      return await call();
    } on SocketException {
      throw ApiException.network();
    } on DioException catch (e) {
      if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.sendTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        throw ApiException.timeout();
      }
      if (e.type == DioExceptionType.connectionError) {
        throw ApiException.network();
      }
      rethrow;
    }
  }

  /// Inspects a raw Response and throws ApiException for any non-2xx
  /// status, extracting the server's own message/errors where present.
  /// Every repository method should call this immediately after a request.
  void throwIfError(Response response) {
    final status = response.statusCode ?? 0;
    if (status >= 200 && status < 300) return;

    String? message;
    Map<String, dynamic>? fieldErrors;
    final data = response.data;
    if (data is Map) {
      message = (data['error'] ?? data['message'])?.toString();
      final errors = data['errors'];
      if (errors is Map) {
        fieldErrors = Map<String, dynamic>.from(errors);
      }
    }

    throw ApiException.fromStatusCode(status, message, fieldErrors: fieldErrors);
  }
}
