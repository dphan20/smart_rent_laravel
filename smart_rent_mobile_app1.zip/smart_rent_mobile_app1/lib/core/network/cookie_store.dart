/// Conditional export: picks the file-system-backed cookie jar on
/// Android/iOS/desktop, and the in-memory/browser-credentials version on
/// web, WITHOUT either variant's imports (dart:io-based path_provider vs
/// dart:html-based dio/browser.dart) ever being compiled for the wrong
/// target. This is what makes it safe for dio_client.dart to just call
/// buildCookieJar()/enableBrowserCredentials() without caring which
/// platform it's running on.
export 'cookie_store_io.dart' if (dart.library.html) 'cookie_store_web.dart';
