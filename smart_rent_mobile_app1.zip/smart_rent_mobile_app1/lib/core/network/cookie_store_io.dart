import 'package:cookie_jar/cookie_jar.dart';
import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';

/// Real implementation — used on Android, iOS, Windows, macOS, Linux.
///
/// Persists the session cookie (SMART_RENT_SESSID + smart_rent_remember)
/// to a file on disk so a still-valid login survives an app restart
/// (requirement #37). This is the ONLY variant allowed to touch
/// path_provider / dart:io file storage — the web variant in
/// cookie_store_web.dart has neither available.
Future<CookieJar> buildCookieJar() async {
  final dir = await getApplicationDocumentsDirectory();
  return PersistCookieJar(
    storage: FileStorage('${dir.path}/.smart_rent_cookies/'),
    ignoreExpires: false,
  );
}

/// No-op on native platforms: Dio's native (io) HttpClientAdapter always
/// sends cookies attached by CookieManager regardless of this flag, so
/// there is nothing to configure here. Only the browser adapter needs it.
void enableBrowserCredentials(Dio dio) {}
