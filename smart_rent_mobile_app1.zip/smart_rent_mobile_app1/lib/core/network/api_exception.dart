import 'package:flutter/foundation.dart' show kIsWeb;

/// A single, typed exception shape every repository throws, so every screen
/// can handle errors the same way instead of parsing raw DioException /
/// PHP error bodies itself. Never surfaces a raw stack trace or PHP error
/// string to the user.
class ApiException implements Exception {
  final String message;
  final int? statusCode;
  final Map<String, dynamic>? fieldErrors;
  final ApiErrorType type;

  ApiException(
    this.message, {
    this.statusCode,
    this.fieldErrors,
    this.type = ApiErrorType.unknown,
  });

  factory ApiException.fromStatusCode(int? statusCode, String? serverMessage,
      {Map<String, dynamic>? fieldErrors}) {
    switch (statusCode) {
      case 400:
      case 422:
        return ApiException(
          serverMessage ?? 'Some of the information provided is invalid.',
          statusCode: statusCode,
          fieldErrors: fieldErrors,
          type: ApiErrorType.validation,
        );
      case 401:
        return ApiException(
          serverMessage ?? 'Please sign in to continue.',
          statusCode: statusCode,
          type: ApiErrorType.unauthorized,
        );
      case 403:
        return ApiException(
          serverMessage ?? 'You do not have permission to do that.',
          statusCode: statusCode,
          type: ApiErrorType.forbidden,
        );
      case 404:
        return ApiException(
          serverMessage ?? 'We could not find what you were looking for.',
          statusCode: statusCode,
          type: ApiErrorType.notFound,
        );
      case 409:
        return ApiException(
          serverMessage ?? 'This action conflicts with the current state. Please refresh and try again.',
          statusCode: statusCode,
          type: ApiErrorType.conflict,
        );
      case 423:
        return ApiException(
          serverMessage ?? 'This account is temporarily locked. Please try again later.',
          statusCode: statusCode,
          type: ApiErrorType.locked,
        );
      case 429:
        return ApiException(
          serverMessage ?? 'Too many requests. Please slow down and try again shortly.',
          statusCode: statusCode,
          type: ApiErrorType.rateLimited,
        );
      case 500:
      case 502:
      case 503:
        return ApiException(
          serverMessage ?? 'Something went wrong on our end. Please try again.',
          statusCode: statusCode,
          type: ApiErrorType.server,
        );
      default:
        return ApiException(
          serverMessage ?? 'Unable to complete this request.',
          statusCode: statusCode,
          type: ApiErrorType.unknown,
        );
    }
  }

  /// A Dio "connectionError" can mean the device is genuinely offline, but
  /// on web (kIsWeb) it just as often means the browser silently blocked a
  /// cross-origin request that never even reached the network — e.g. the
  /// backend isn't running, or this tab's origin (host:port) isn't in the
  /// backend's SMART_RENT_ALLOWED_ORIGINS whitelist (see api_config.dart
  /// and README.md "Running for Chrome / Web"). Dio/the browser fetch API
  /// deliberately don't expose *why* a CORS request failed (that's a
  /// browser security restriction, not something this app can detect), so
  /// the web message below lists the real, common causes instead of
  /// falsely claiming "no internet" when the device may be online.
  factory ApiException.network() => ApiException(
        kIsWeb
            ? 'Could not reach the Smart Rent server. If you are running this in '
                'a browser: 1) make sure the Laravel backend is running '
                '(php artisan serve), and 2) make sure this page\'s address is '
                'allowed in the backend\'s SMART_RENT_ALLOWED_ORIGINS setting — '
                'run this app with scripts/run_web.sh (or the "Smart Rent '
                '(Chrome)" launch config) so its address stays consistent.'
            : 'No internet connection. Please check your network and try again.',
        type: ApiErrorType.network,
      );

  factory ApiException.timeout() => ApiException(
        'The request timed out. Please try again.',
        type: ApiErrorType.timeout,
      );

  @override
  String toString() => message;
}

enum ApiErrorType {
  network,
  timeout,
  validation,
  unauthorized,
  forbidden,
  notFound,
  conflict,
  locked,
  rateLimited,
  server,
  unknown,
}
