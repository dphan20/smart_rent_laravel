import "package:connectivity_plus/connectivity_plus.dart";

/// Lets the app distinguish "device has no internet" from "the backend
/// itself is broken" (requirement #29) so it never falsely blames the
/// Laravel API for a problem that is actually the phones Wi-Fi/data.
class NetworkInfo {
  NetworkInfo._();
  static final Connectivity _connectivity = Connectivity();

  static Future<bool> get isConnected async {
    final result = await _connectivity.checkConnectivity();
    return !result.contains(ConnectivityResult.none);
  }

  static Stream<bool> get onStatusChange => _connectivity.onConnectivityChanged
      .map((results) => !results.contains(ConnectivityResult.none));
}
