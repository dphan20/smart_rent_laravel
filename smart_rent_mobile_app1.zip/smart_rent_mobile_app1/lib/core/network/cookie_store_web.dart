import 'package:cookie_jar/cookie_jar.dart';
import 'package:dio/browser.dart';
import 'package:dio/dio.dart';

/// Web implementation — used when running in Chrome/Edge/any browser.
///
/// There is no file system to persist to (path_provider/dart:io are not
/// available), and it isn't needed anyway: the browser itself already
/// stores the Set-Cookie response for SMART_RENT_SESSID and
/// smart_rent_remember and re-attaches it on every request to the same
/// backend, exactly like the existing web admin does. An in-memory jar is
/// enough to keep dio_cookie_manager happy for the lifetime of the tab.
Future<CookieJar> buildCookieJar() async => CookieJar();

/// On web, Dio's BrowserHttpClientAdapter does NOT send/receive cookies
/// on cross-origin requests unless withCredentials is explicitly turned
/// on. The Flutter web app (served from one origin, e.g. localhost:PORT
/// via `flutter run -d chrome`) and the Laravel backend (127.0.0.1:8000)
/// are different origins, so without this line every login would silently
/// fail to persist its session cookie.
///
/// NOTE: this also requires the Laravel backend to send
/// `Access-Control-Allow-Credentials: true` and a specific (not `*`)
/// `Access-Control-Allow-Origin`, and the session cookie itself to be set
/// with `SameSite=None; Secure` — that is backend configuration, not
/// something fixable from the Flutter side.
void enableBrowserCredentials(Dio dio) {
  final adapter = dio.httpClientAdapter;
  if (adapter is BrowserHttpClientAdapter) {
    adapter.withCredentials = true;
  }
}
