import "package:dio/dio.dart";
import "package:flutter/material.dart";

import "../config/api_config.dart";
import "../network/dio_client.dart";
import "../theme/app_theme.dart";

/// Lets the app follow the phone (or the PC running the backend) onto a
/// different Wi-Fi network WITHOUT a rebuild. Previously the server
/// address was hard-coded in ApiConfig and baked into the APK at build
/// time — every network change meant editing the Dart source and running
/// `flutter build apk` again. Now it's just a value saved on-device
/// (see LocalPrefs.setServerHostOverride / ApiConfig.setManualOverride)
/// that takes effect immediately, no restart needed.
class ServerSettingsScreen extends StatefulWidget {
  const ServerSettingsScreen({super.key});

  @override
  State<ServerSettingsScreen> createState() => _ServerSettingsScreenState();
}

class _ServerSettingsScreenState extends State<ServerSettingsScreen> {
  late final TextEditingController _controller;
  bool _testing = false;
  bool _saving = false;
  String? _statusMessage;
  bool? _statusOk;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: ApiConfig.effectiveServerRoot);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  String get _typedHost => _controller.text.trim();

  Future<void> _testConnection() async {
    if (_typedHost.isEmpty) return;
    setState(() {
      _testing = true;
      _statusMessage = null;
      _statusOk = null;
    });
    try {
      // A lightweight, unauthenticated GET that exists on every
      // deployment of this backend — just proves the host is reachable
      // and actually speaking the Smart Rent API, not just "something"
      // on that address/port.
      final response = await DioClient.instance.dio.get(
        "${_normalize(_typedHost)}/api/auth/csrf",
        options: Options(
          sendTimeout: const Duration(seconds: 6),
          receiveTimeout: const Duration(seconds: 6),
        ),
      );
      final ok = response.statusCode != null && response.statusCode! < 500;
      setState(() {
        _statusOk = ok;
        _statusMessage = ok
            ? "Server reachable."
            : "Server responded, but with an unexpected error (HTTP ${response.statusCode}).";
      });
    } catch (e) {
      setState(() {
        _statusOk = false;
        _statusMessage = "Could not reach that address. Check the IP, the port, and that "
            "both devices are on the same Wi-Fi network.";
      });
    } finally {
      if (mounted) setState(() => _testing = false);
    }
  }

  String _normalize(String host) {
    var h = host.trim();
    if (!h.startsWith("http://") && !h.startsWith("https://")) h = "http://$h";
    return h.endsWith("/") ? h.substring(0, h.length - 1) : h;
  }

  Future<void> _save() async {
    if (_typedHost.isEmpty) return;
    setState(() => _saving = true);
    await ApiConfig.setManualOverride(_typedHost);
    DioClient.instance.applyServerRootChange();
    if (mounted) {
      setState(() => _saving = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Server address saved — the app will use it right away.")),
      );
      Navigator.of(context).maybePop();
    }
  }

  Future<void> _resetToDefault() async {
    await ApiConfig.setManualOverride(null);
    DioClient.instance.applyServerRootChange();
    setState(() {
      _controller.text = ApiConfig.effectiveServerRoot;
      _statusMessage = null;
      _statusOk = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Server settings")),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Point this app at the computer running the Smart Rent server. "
              "Both this phone and that computer must be on the same Wi-Fi network. "
              "You only need to change this when your network changes — no reinstall needed.",
              style: TextStyle(color: AppTheme.textSecondary),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: _controller,
              keyboardType: TextInputType.url,
              decoration: const InputDecoration(
                labelText: "Server address",
                hintText: "e.g. 192.168.1.21:8000 or http://192.168.1.21:8000",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            if (_statusMessage != null)
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: (_statusOk == true ? Colors.green : AppTheme.danger).withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    Icon(
                      _statusOk == true ? Icons.check_circle_outline : Icons.error_outline,
                      color: _statusOk == true ? Colors.green : AppTheme.danger,
                      size: 20,
                    ),
                    const SizedBox(width: 8),
                    Expanded(child: Text(_statusMessage!)),
                  ],
                ),
              ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: _testing ? null : _testConnection,
                    child: _testing
                        ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                        : const Text("Test connection"),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: _saving ? null : _save,
                    child: _saving
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                          )
                        : const Text("Save"),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Center(
              child: TextButton(
                onPressed: _resetToDefault,
                child: const Text("Reset to built-in default"),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
