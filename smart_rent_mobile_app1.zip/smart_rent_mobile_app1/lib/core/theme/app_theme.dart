import "package:flutter/material.dart";
import "package:google_fonts/google_fonts.dart";

/// Smart Rent visual identity, copied directly from the existing web app's
/// :root CSS variables in resources/views/app.blade.php — NOT invented
/// separately. Every color/radius/font below has a matching line there:
///   --gold:#f59e0b  --gold-dark:#d97706  (--gradient-gold)
///   --bg-body:#f4f7fb  --bg-card:#ffffff  --bg-sidebar:#0f172a
///   --text-primary:#0f172a  --text-secondary:#64748b  --text-muted:#94a3b8
///   --border-color:#eef2f6
///   --green:#22c55e  --red:#ef4444  --blue:#3b82f6
///   font-family: 'Inter'  |  .room-card border-radius:20px
///   buttons/inputs border-radius: 12-14px  |  badges: pill (fully rounded)
class AppTheme {
  AppTheme._();

  // --- Brand ---------------------------------------------------------
  static const Color gold = Color(0xFFF59E0B);
  static const Color goldDark = Color(0xFFD97706);
  static const LinearGradient goldGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [gold, goldDark],
  );

  // Gold is the app's one primary action color everywhere in the web app
  // (buttons, checkboxes, the avatar, the brand mark) — not a muted teal.
  static const Color primary = gold;
  static const Color primaryDark = goldDark;
  // Blue doubles as the secondary/info accent in the web app's status pills.
  static const Color accent = Color(0xFF3B82F6);

  // --- Surfaces / text -------------------------------------------------
  static const Color navy = Color(0xFF0F172A); // sidebar bg + text-primary
  static const Color background = Color(0xFFF4F7FB);
  static const Color surface = Colors.white;
  static const Color border = Color(0xFFEEF2F6);
  static const Color textPrimary = navy;
  static const Color textSecondary = Color(0xFF64748B);
  static const Color textMuted = Color(0xFF94A3B8);

  // --- Status colors ---------------------------------------------------
  static const Color danger = Color(0xFFEF4444);
  static const Color success = Color(0xFF22C55E);
  static const Color warning = goldDark;
  static const Color info = accent;

  // --- Radii, matching the web app's rounded, pill-heavy look ----------
  static const double radiusCard = 20;
  static const double radiusControl = 14;
  static const double radiusPill = 999;

  static ThemeData get light {
    final base = ThemeData.light(useMaterial3: true);
    final textTheme = GoogleFonts.interTextTheme(base.textTheme).apply(
      bodyColor: textPrimary,
      displayColor: textPrimary,
    );

    return base.copyWith(
      scaffoldBackgroundColor: background,
      textTheme: textTheme,
      colorScheme: base.colorScheme.copyWith(
        primary: primary,
        onPrimary: navy, // gold is light — dark text/icons sit on top of it, same as the web app's buttons/avatar
        secondary: accent,
        error: danger,
        surface: surface,
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: surface,
        foregroundColor: textPrimary,
        elevation: 0,
        centerTitle: false,
        surfaceTintColor: Colors.transparent,
        titleTextStyle: GoogleFonts.inter(
          color: textPrimary,
          fontSize: 20,
          fontWeight: FontWeight.w700,
        ),
      ),
      cardTheme: CardThemeData(
        color: surface,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(radiusCard),
          side: const BorderSide(color: border),
        ),
        margin: EdgeInsets.zero,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: primary,
          foregroundColor: navy,
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radiusControl)),
          textStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
          elevation: 0,
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: textPrimary,
          side: const BorderSide(color: border),
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radiusControl)),
          textStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(foregroundColor: primary),
      ),
      checkboxTheme: CheckboxThemeData(
        fillColor: WidgetStateProperty.resolveWith(
          (states) => states.contains(WidgetState.selected) ? gold : Colors.transparent,
        ),
        checkColor: const WidgetStatePropertyAll(navy),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: background,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        labelStyle: const TextStyle(color: textSecondary),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(radiusControl),
          borderSide: const BorderSide(color: border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(radiusControl),
          borderSide: const BorderSide(color: border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(radiusControl),
          borderSide: const BorderSide(color: gold, width: 1.5),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(radiusControl),
          borderSide: const BorderSide(color: danger),
        ),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: surface,
        selectedItemColor: goldDark,
        unselectedItemColor: textMuted,
        type: BottomNavigationBarType.fixed,
        elevation: 8,
      ),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: navy,
        contentTextStyle: const TextStyle(color: Colors.white),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radiusControl)),
      ),
      dividerTheme: const DividerThemeData(color: border, thickness: 1),
    );
  }
}
