import "package:flutter/material.dart";

import "app_theme.dart";

/// The "SR" gold-gradient logo badge used throughout the existing web app
/// (see .brand-icon / .brand-icon-lg in resources/views/app.blade.php,
/// e.g. the sidebar and the login card) — a rounded square with the gold
/// gradient and bold navy "SR" lettering.
class BrandMark extends StatelessWidget {
  const BrandMark({super.key, this.size = 42});

  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        gradient: AppTheme.goldGradient,
        borderRadius: BorderRadius.circular(size * 0.28),
        boxShadow: [
          BoxShadow(
            color: AppTheme.gold.withOpacity(0.3),
            blurRadius: size * 0.3,
            offset: Offset(0, size * 0.1),
          ),
        ],
      ),
      child: Text(
        "SR",
        style: TextStyle(
          color: AppTheme.navy,
          fontWeight: FontWeight.w800,
          fontSize: size * 0.38,
        ),
      ),
    );
  }
}

/// "Smart" + thin gold "Rent" wordmark, matching the <h1>/<h2> markup next
/// to the brand icon in the web app (.sidebar-brand h1 span is gold and
/// font-weight:300 — see app.blade.php).
class BrandWordmark extends StatelessWidget {
  const BrandWordmark({super.key, this.fontSize = 22, this.color = AppTheme.navy});

  final double fontSize;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return RichText(
      text: TextSpan(
        style: TextStyle(
          fontSize: fontSize,
          fontWeight: FontWeight.w800,
          letterSpacing: -0.5,
          color: color,
        ),
        children: [
          const TextSpan(text: "Smart"),
          TextSpan(text: "Rent", style: TextStyle(color: AppTheme.gold, fontWeight: FontWeight.w300)),
        ],
      ),
    );
  }
}
