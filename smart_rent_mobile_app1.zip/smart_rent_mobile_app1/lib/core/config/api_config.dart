import 'package:flutter/foundation.dart' show kIsWeb, TargetPlatform, defaultTargetPlatform;

import '../storage/local_prefs.dart';

/// Central place for every URL the app needs. Nothing else in the codebase
/// should hard-code an http(s):// string — change environments here only.
///
/// IMPORTANT — how this backend actually works (inspected directly from the
/// shipped Laravel project, not assumed):
///   routes/api.php forwards every request under /api/* (except /api/chat
///   and /api/ai/*, which are real Laravel routes backed by GroqService)
///   straight into public/backend/api.php — a legacy, session-based PHP
///   REST API. That legacy API is the actual source of truth for auth,
///   rooms, properties, bookings, orders, payments, contracts, payouts,
///   and the 360° tour/hotspot system. It authenticates with a PHP session
///   cookie named SMART_RENT_SESSID (see public/backend/config/session.php)
///   plus a `smart_rent_remember` persistent cookie for "stay logged in",
///   and requires an `X-CSRF-Token` header (fetched from GET /auth/csrf)
///   on every non-GET request except login/signup/the payment webhook.
///
/// This is why the Flutter client below authenticates with a cookie jar
/// (see core/network/dio_client.dart) instead of a bearer token — Sanctum/
/// Passport are not installed, and a bearer-token client would simply not
/// be recognized by this backend.
enum AppEnvironment { development, physicalDevice, production }

class ApiConfig {
  ApiConfig._();

  /// Preferred override: `flutter run --dart-define=API_HOST=http://...`.
  /// Left blank (the default) falls back to the per-platform/per-environment
  /// logic below, so nobody has to edit Dart source just to point the app
  /// at a different machine — only `current` below needs to change to pick
  /// production vs. physical-device defaults, and even that is skippable
  /// once API_HOST is passed explicitly.
  static const String _apiHostOverride = String.fromEnvironment('API_HOST');

  /// Flip this to switch which built-in default applies when API_HOST is
  /// NOT passed via --dart-define. In a real CI/CD pipeline this would also
  /// come from --dart-define instead of a hard-coded constant; left simple
  /// here so a developer only has to touch one file when they don't want
  /// to pass API_HOST every run.
  static const AppEnvironment current = AppEnvironment.physicalDevice;

  /// Set at startup by `loadManualOverride()` (see main.dart) from whatever
  /// was last saved on THIS device via the "Server settings" screen. Once
  /// set, this wins over everything below — including the hard-coded
  /// `physicalDevice` IP — which is what lets the same installed APK keep
  /// working after the phone (or the PC running the backend) moves to a
  /// different Wi-Fi network: instead of rebuilding the app with a new
  /// hard-coded IP every time, the user just opens Server settings and
  /// types the new one in.
  static String? _manualOverride;

  /// Must be awaited once, before the first Dio client is built (see
  /// DioClient.init(), called from main() before runApp()) — otherwise the
  /// very first requests would go out using the stale hard-coded IP.
  static Future<void> loadManualOverride() async {
    final saved = await LocalPrefs.getServerHostOverride();
    if (saved != null && saved.trim().isNotEmpty) {
      _manualOverride = _normalizeHost(saved);
    }
  }

  /// Called by the "Server settings" screen when the user saves a new
  /// address. Takes effect immediately for every request made after this
  /// call returns — no app restart, no rebuild.
  static Future<void> setManualOverride(String? host) async {
    final normalized = (host == null || host.trim().isEmpty) ? null : _normalizeHost(host);
    _manualOverride = normalized;
    await LocalPrefs.setServerHostOverride(normalized);
  }

  /// Whatever is currently in effect — the manual override if one has been
  /// set on this device, otherwise the built-in default. Shown back to the
  /// user by the settings screen as the current value.
  static String get effectiveServerRoot => _manualOverride ?? serverRoot;

  static String _normalizeHost(String host) {
    var h = host.trim();
    if (!h.startsWith('http://') && !h.startsWith('https://')) {
      h = 'http://$h';
    }
    return h.endsWith('/') ? h.substring(0, h.length - 1) : h;
  }

  /// Base "server root" (no /api suffix). Needed because uploaded images
  /// (property/room/panorama photos) are served as plain static files from
  /// Laravel's public/uploads directory, e.g. "uploads/room_123.jpg" — they
  /// are NOT under /api.
  static String get serverRoot {
    if (_manualOverride != null) return _manualOverride!;
    if (_apiHostOverride.isNotEmpty) {
      // Strip any trailing slash so baseUrl/resolveMediaUrl below never
      // accidentally produce a double slash or .../api/api/... (see PART 3
      // requirement: never produce http://host/api/api/rooms).
      return _apiHostOverride.endsWith('/')
          ? _apiHostOverride.substring(0, _apiHostOverride.length - 1)
          : _apiHostOverride;
    }
    switch (current) {
      case AppEnvironment.development:
        // Four different runtimes resolve "the host machine running
        // `php artisan serve`" differently, so this MUST branch per
        // platform or some of them will silently fail to connect:
        //   - Chrome/Edge/any browser (kIsWeb): the browser IS the host
        //     machine's network stack, so localhost/127.0.0.1 is correct.
        //     Checked FIRST because dart:io's Platform class does not
        //     exist on web — calling it there throws immediately and
        //     crashes the app before a single frame renders (this is the
        //     white/blank-page bug). defaultTargetPlatform must never be
        //     read to make this decision on web, since on some browsers
        //     it reports the phone/desktop OS underneath, not "web".
        //   - Android emulator: 10.0.2.2 is its special alias for the host
        //     machine's localhost. Plain localhost/127.0.0.1 from inside
        //     the emulator means the emulator itself, not the host.
        //   - iOS Simulator: shares the Mac's network stack directly, so
        //     localhost/127.0.0.1 IS the host machine. 10.0.2.2 resolves
        //     to nothing on iOS and every request would just time out.
        // A physical iPhone still needs AppEnvironment.physicalDevice
        // (real LAN IP) below, same as a physical Android device.
        // NOTE: this only sets which HOST the app talks to. On web, the
        // browser also enforces CORS based on which host:PORT the app
        // ITSELF is served from — that's a separate whitelist
        // (SMART_RENT_ALLOWED_ORIGINS) on the Laravel side. Always launch
        // web via scripts/run_web.sh / run_web.bat (or the "Smart Rent
        // (Chrome)" VS Code launch config) so that origin stays pinned and
        // matches the whitelist — see README.md "Running for Chrome / Web".
        if (kIsWeb) return 'http://127.0.0.1:8000';
        return defaultTargetPlatform == TargetPlatform.android
            ? 'http://10.0.2.2:8000'
            : 'http://127.0.0.1:8000';
      case AppEnvironment.physicalDevice:
        // Replace with the machine running `php artisan serve`'s LAN IP.
        // Both devices must be on the same Wi-Fi network. Same value for
        // a physical Android phone or a physical iPhone.
        return 'http://192.168.100.37:8000';
      case AppEnvironment.production:
        // Replace with the real deployed Smart Rent domain.
        return 'https://smartrent.co.tz';
    }
  }

  /// Every legacy-backend REST endpoint lives under /api on this project
  /// (routes/api.php's catch-all forwards it), so this is just serverRoot
  /// + "/api".
  static String get baseUrl => '$serverRoot/api';

  /// Resolves a possibly-relative path returned by the API (e.g.
  /// "uploads/room_172_abc.jpg") into an absolute, loadable image URL.
  /// Returns null for empty/missing paths so callers can show a
  /// placeholder instead of crashing on Image.network(null).
  static String? resolveMediaUrl(String? path) {
    if (path == null || path.trim().isEmpty) return null;
    final trimmed = path.trim();
    if (trimmed.startsWith('http://') || trimmed.startsWith('https://')) {
      return trimmed;
    }
    final cleanPath = trimmed.startsWith('/') ? trimmed.substring(1) : trimmed;
    return '$serverRoot/$cleanPath';
  }

  static const Duration connectTimeout = Duration(seconds: 15);
  static const Duration receiveTimeout = Duration(seconds: 20);
  static const Duration sendTimeout = Duration(seconds: 60); // multipart uploads
}

