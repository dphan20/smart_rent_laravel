import "package:flutter/material.dart";

import "../core/theme/app_theme.dart";

class StatusBadge extends StatelessWidget {
  final String status;
  const StatusBadge({super.key, required this.status});

  Color _color() {
    switch (status.toLowerCase()) {
      case "available":
      case "confirmed":
      case "successful":
      case "active":
      case "paid":
        return AppTheme.success;
      case "pending":
      case "ordered":
      case "booked":
        return AppTheme.warning;
      case "taken":
      case "cancelled":
      case "failed":
      case "rejected":
        return AppTheme.danger;
      default:
        return AppTheme.textSecondary;
    }
  }

  @override
  Widget build(BuildContext context) {
    final color = _color();
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        status[0].toUpperCase() + status.substring(1),
        style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w600),
      ),
    );
  }
}
