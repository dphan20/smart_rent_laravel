import "package:cached_network_image/cached_network_image.dart";
import "package:flutter/material.dart";
import "package:shimmer/shimmer.dart";

import "../core/theme/app_theme.dart";

/// Every image in the app must go through this widget instead of a raw
/// Image.network — it never crashes on a null/missing/broken URL
/// (requirement #11) and always shows a loading + failure state.
class AppNetworkImage extends StatelessWidget {
  final String? url;
  final double? width;
  final double? height;
  final BoxFit fit;
  final BorderRadius? borderRadius;

  const AppNetworkImage({
    super.key,
    required this.url,
    this.width,
    this.height,
    this.fit = BoxFit.cover,
    this.borderRadius,
  });

  @override
  Widget build(BuildContext context) {
    final radius = borderRadius ?? BorderRadius.zero;
    if (url == null || url!.isEmpty) {
      return ClipRRect(
        borderRadius: radius,
        child: _placeholder(width, height),
      );
    }
    return ClipRRect(
      borderRadius: radius,
      child: CachedNetworkImage(
        imageUrl: url!,
        width: width,
        height: height,
        fit: fit,
        placeholder: (context, _) => Shimmer.fromColors(
          baseColor: const Color(0xFFE5E7EB),
          highlightColor: const Color(0xFFF3F4F6),
          child: Container(width: width, height: height, color: Colors.white),
        ),
        errorWidget: (context, _, __) => _placeholder(width, height),
      ),
    );
  }

  Widget _placeholder(double? w, double? h) {
    return Container(
      width: w,
      height: h,
      color: const Color(0xFFF1F5F9),
      alignment: Alignment.center,
      child: const Icon(Icons.home_rounded, color: AppTheme.textSecondary, size: 32),
    );
  }
}
