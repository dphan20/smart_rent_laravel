@echo off
REM Launches the Flutter web build on a FIXED port (5000) so its origin
REM matches the Laravel backend's SMART_RENT_ALLOWED_ORIGINS whitelist.
REM See scripts/run_web.sh for the full explanation.
set PORT=5000
echo Starting Smart Rent web app on http://localhost:%PORT%
echo Make sure the Laravel backend is running (php artisan serve --no-reload)
echo and that SMART_RENT_ALLOWED_ORIGINS in its .env includes http://localhost:%PORT%
flutter run -d chrome --web-port=%PORT% %*
