#!/usr/bin/env bash
# Launches the Flutter web build on a FIXED port (5000).
#
# Why this matters: the Laravel backend only allows CORS + the auth cookie
# for origins listed in SMART_RENT_ALLOWED_ORIGINS (public/backend/api.php,
# configured in the Laravel project's .env). `flutter run -d chrome` picks
# a random port every run unless told otherwise, so the very next run could
# land on a port the backend has never heard of -> the browser blocks every
# API call -> this app shows "No internet connection" even though the
# server is up. Always run web through this script (or the "Smart Rent
# (Chrome)" launch config in .vscode/launch.json) so the origin stays
# http://localhost:5000, matching the backend's default whitelist:
#   SMART_RENT_ALLOWED_ORIGINS=http://localhost:5000,http://127.0.0.1:5000
#
# If you need a different port, change PORT below AND add the matching
# http://localhost:PORT entry to SMART_RENT_ALLOWED_ORIGINS in the Laravel
# project's .env, then restart `php artisan serve`.
set -e
PORT=5000
echo "Starting Smart Rent web app on http://localhost:$PORT"
echo "Make sure the Laravel backend is running (php artisan serve --no-reload)"
echo "and that SMART_RENT_ALLOWED_ORIGINS in its .env includes http://localhost:$PORT"
flutter run -d chrome --web-port=$PORT "$@"
