@echo off
echo ==========================================
echo SMART RENT MOBILE - CLEAN REBUILD
echo ==========================================

cd /d E:\smart_rent_mobile_app

echo.
echo [1/6] Cleaning Flutter...
call flutter clean

echo.
echo [2/6] Removing Dart build cache...
if exist ".dart_tool" rmdir /s /q ".dart_tool"

echo.
echo [3/6] Removing Android Gradle cache...
if exist "android\.gradle" rmdir /s /q "android\.gradle"

echo.
echo [4/6] Getting Flutter packages...
call flutter pub get

echo.
echo [5/6] Checking Flutter installation...
call flutter doctor -v

echo.
echo [6/6] Running Smart Rent...
call flutter run

echo.
echo ==========================================
echo PROCESS FINISHED
echo ==========================================
pause
