# Smart Rent — Flutter Mobile Client

A real Flutter mobile client for the **existing** Smart Rent Laravel/legacy-PHP
backend and MySQL database supplied in `smart_rent_laravel_360_virtual_tour.rar`
and `smartrent.sql`. No second backend, no second database, no demo data —
every screen reads and writes the same records the web app uses.

## What the analysis found (read this first)

This project is **not** a plain Laravel REST API. Inspecting the shipped
source directly (not guessed):

- **Laravel 12** exists mostly as a thin shell. `routes/api.php` forwards
  almost everything under `/api/*` straight into an in-process legacy PHP
  script, `public/backend/api.php` — that script (with its own
  `controllers/`, `models/`, `helpers/` folders) is the *real* REST API:
  Auth, Room, Property, **Tour360** (the 360° tour system), Booking, Order,
  Payment, Contract, Payout and Admin controllers all live there.
- Only `/api/chat` and `/api/ai/*` are genuine Laravel routes
  (`app/Http/Controllers/ChatController.php`, backed by a `GroqService`).
- **Authentication is PHP-session/cookie-based, not token-based.** There is
  no Sanctum/Passport installed. `AuthController::login()` starts a session
  and sets the `SMART_RENT_SESSID` cookie (see
  `public/backend/config/session.php`) plus, when "remember" is checked, a
  long-lived `smart_rent_remember` cookie. Every non-GET request also needs
  an `X-CSRF-Token` header obtained from `GET /auth/csrf`. This is why the
  Flutter client authenticates with a **persistent cookie jar**
  (`lib/core/network/dio_client.dart`) instead of a bearer token — a
  bearer-token client simply would not be recognized by this backend.
- The 360° tour system uses two tables, `property_360_tours` (panorama
  scenes) and `property_360_hotspots` (markers on a scene), with two
  hotspot behaviours: `navigation` (jump to another scene) and `viewpoint`
  (re-orient within the same panorama) — both fully implemented here.
- Every Dart model's field names were taken directly from
  `smartrent.sql` and the PHP models (`SELECT *` with no aliasing in most
  cases), including quirks like PDO returning decimals as strings and
  `amenities`/`images` being JSON-encoded `TEXT` columns.

## Project structure

```
lib/
  core/
    config/api_config.dart       ← the ONLY place base URLs live
    network/dio_client.dart      ← cookie-jar + CSRF auth, typed errors
    network/api_exception.dart
    network/network_info.dart    ← online/offline detection
    storage/local_prefs.dart     ← non-authoritative local prefs only
    theme/app_theme.dart
    utils/
  models/                        ← one file per backend table/shape
  repositories/                  ← one per controller, talks to Dio only
  providers/                     ← ChangeNotifier state (single approach)
  navigation/root_shell.dart     ← picks UI by the ROLE THE BACKEND RETURNED
  widgets/                       ← shared loading/error/empty/image widgets
  features/
    authentication/  home/  properties/  rooms/  search/
    virtual_tour/     ← the 360° viewer (critical feature)
    bookings/  payments(inline in booking)/  profile/  ai/
    landlord/         ← dashboard, properties, rooms, tour+hotspot manager
    admin/            ← dashboard, payouts (reuses landlord's tour manager)
```

## Before you build

1. **Point it at your backend.** Open `lib/core/config/api_config.dart` and
   set `ApiConfig.current`, then fill in the matching URL:
   - `development` → platform-aware automatically: `http://10.0.2.2:8000` on
     the Android emulator, `http://127.0.0.1:8000` on the iOS Simulator
     (both point at `php artisan serve` running on your computer — the
     two simulators just resolve "my computer's localhost" differently,
     so this branches on `Platform.isAndroid` rather than being a single
     hard-coded value).
   - `physicalDevice` → `http://YOUR_COMPUTER_LAN_IP:8000` (phone and
     computer on the same Wi-Fi) — same value for a physical Android phone
     or a physical iPhone.
   - `production` → your real `https://` Smart Rent domain.
2. **Install packages** (needs internet access to pub.dev, which this
   sandbox did not have, so this has not been run/verified here):
   ```
   flutter pub get
   ```
3. **Android:** fill in `android/local.properties` with your real `sdk.dir`
   and `flutter.sdk` paths (a placeholder file is included).
4. **iOS:** install CocoaPods dependencies once, after step 2:
   ```
   cd ios && pod install && cd ..
   ```
   Then open `ios/Runner.xcworkspace` (not `Runner.xcodeproj`) in Xcode if
   you want to run on a physical iPhone or change the signing team —
   `flutter run`/`flutter build ios` handle the simulator without opening
   Xcode at all. Minimum iOS version is 13.0 (set in `ios/Podfile` and the
   Xcode project); bundle identifier is `com.smartrent.mobile`, matching
   Android's `applicationId` in `android/app/build.gradle.kts`.
5. **Run it:**
   ```
   flutter run                      # picks whichever simulator/device is connected
   flutter run -d ios                # explicitly iOS Simulator/device
   flutter run -d android            # explicitly Android emulator/device
   ```
   For Chrome/Web, see **"Running for Chrome / Web"** below — it needs one
   extra step or you'll hit the "No internet connection" bug.

## Running for Chrome / Web

**Root cause of the "No internet connection" error in Chrome:** this
backend authenticates with a session cookie (`SMART_RENT_SESSID`), not a
bearer token, so the Laravel legacy backend (`public/backend/api.php`)
only allows cross-origin requests + that cookie from an **explicit
whitelist** — `SMART_RENT_ALLOWED_ORIGINS` in the Laravel project's
`.env`. Plain `flutter run -d chrome` picks a **random port every run**
(e.g. `localhost:61443`) unless you pin one, so the very next run can land
on a port the backend's whitelist has never heard of. The browser then
silently blocks the request before Dio ever gets a real response, and Dio
reports that as a generic connection error — which is exactly the
misleading "No internet connection" message, shown even though the device
is online and the backend is running.

**Fix — always run web on a fixed, whitelisted port:**
```
scripts/run_web.sh          # macOS/Linux — launches on http://localhost:5000
scripts\run_web.bat         # Windows     — launches on http://localhost:5000
```
or in VS Code, use the **"Smart Rent (Chrome)"** launch configuration
(`.vscode/launch.json`) — it does the same thing. This matches the
backend's default:
```
SMART_RENT_ALLOWED_ORIGINS=http://localhost:5000,http://127.0.0.1:5000
```
in the Laravel project's `.env`. If you want a different port, change the
`PORT` value in `scripts/run_web.sh`/`run_web.bat` (or your own
`--web-port=` flag) **and** add the matching `http://localhost:PORT` entry
to `SMART_RENT_ALLOWED_ORIGINS`, then restart `php artisan serve`.

**Also required before Chrome will connect at all:**
1. The Laravel backend must actually be running — `php artisan serve
   --no-reload` (the `--no-reload` flag is required, see the Laravel
   project's `SETUP.md`) — or served via XAMPP/Apache.
2. The database (`smartrent.sql`) must be imported into a MySQL database
   named `smartrent`.
3. `api_config.dart`'s web default already points at
   `http://127.0.0.1:8000` — change it (or pass
   `--dart-define=API_HOST=http://your-domain-or-ip:port`) if your backend
   runs somewhere else.

**Best long-term fix (no CORS at all):** for a real deployment, run
`flutter build web` and serve the resulting `build/web` folder from the
**same origin** as the Laravel API (e.g. copy it into the Laravel
project's `public/` folder, or reverse-proxy both under one domain).
Same-origin requests need no CORS whitelist and no cookie
`SameSite`/`Secure` gymnastics — this is how the production app should be
deployed, with `ApiConfig.current` set to `AppEnvironment.production`.

## iOS support (added after the initial Android-only build)

The project originally shipped with **no `ios/` folder at all** — it could
only build for Android. The following was added to make it a genuine,
universal iPhone + Android app rather than an Android app that merely
"could" support iOS:

- The full standard Flutter iOS platform folder: `ios/Runner.xcodeproj`,
  `ios/Runner.xcworkspace`, `Podfile`, `Info.plist`, `AppDelegate.swift`,
  launch/main storyboards, asset catalog (app icon + launch image
  placeholders), and the shared Xcode scheme — everything `flutter build
  ios` / `flutter run` / archiving to the App Store needs.
- `Info.plist` mirrors the two Android-manifest special cases that would
  otherwise silently break on iOS:
  - `NSPhotoLibraryUsageDescription` — the iOS equivalent of Android's
    `READ_MEDIA_IMAGES`/`READ_EXTERNAL_STORAGE` permissions, needed because
    Landlord/Admin screens call `image_picker`'s `ImageSource.gallery`
    (never `ImageSource.camera`, so no camera permission string was added
    — same "only request what's actually used" choice as the Android
    manifest already made).
  - `NSAppTransportSecurity` → `NSAllowsArbitraryLoads` — the iOS
    equivalent of `android:usesCleartextTraffic="true"`, needed ONLY so
    local development against a plain `http://` `php artisan serve` URL
    works. **Remove this block before submitting to the App Store**, exactly
    as the Android manifest's own comment says to do for
    `usesCleartextTraffic` before a production release — Apple review
    flags `NSAllowsArbitraryLoads` on submitted builds.
- `lib/core/config/api_config.dart`'s `development` URL was Android-only
  (`10.0.2.2`, which resolves to nothing on the iOS Simulator) — it now
  branches on `Platform.isAndroid` so local development actually works on
  both simulators, not just Android's.
- Bundle identifier (`com.smartrent.mobile`) matches Android's
  `applicationId` so both platforms are clearly the same app.
- `.gitignore` gained the standard iOS/Xcode/CocoaPods entries
  (`Pods/`, `Podfile.lock`, `Generated.xcconfig`, etc.) matching the
  Android-side entries that were already there.

**Honest limitation:** this was built and reference-checked (balanced
braces, valid XML/plist/JSON, no dangling or duplicate Xcode object IDs)
in a Linux sandbox with no Xcode/macOS and no access to pub.dev/CocoaPods'
registry, so it could not be literally compiled or run on a simulator here.
Treat `flutter pub get && cd ios && pod install` as the real first build
step — the same caveat the Android side of this README already carries
below for `flutter analyze`.

## Important, honest caveats

- **This could not be compiled or run in the sandbox that built it** — there
  was no Flutter SDK installed and `pub.dev` was not reachable from the
  network this was built in. Every file was written carefully by hand
  against the real API/schema, and a brace/paren/bracket balance check
  passed on all 60 files, but you should run `flutter analyze` and
  `flutter pub get` as your first step and fix anything version-specific
  (in particular double-check the `panorama` package's exact widget API
  against whatever version resolves — its constructor shape may have
  shifted between minor versions).
- `Tour360Controller`'s exact hotspot-type and viewpoint-recentre payload
  shape was inferred from its docblocks and PHP body; the request bodies
  in `lib/repositories/tour_repository.dart` match what the controller
  reads, but re-verify against your live server responses once running.
- `AdminController`'s dashboard JSON key names were inferred (the mobile
  screens try several plausible key names with `??` fallbacks) — open
  `admin_dashboard_screen.dart` / `landlord_dashboard_screen.dart` and
  match the keys exactly to what `GET /admin/dashboard` actually returns.
- `ContractRepository` and `OrderRepository` are fully implemented (list,
  create, confirm/cancel, accept) but not yet wired into a screen — the
  Order → Contract flow (requirement covered by `OrderController`/
  `ContractController`) is the natural next screen to add for Landlord/
  Admin, following the same pattern as `booking_form_screen.dart`.
- App icon/launcher assets (placeholder "SR" monogram in the app's teal
  brand color) were generated for both platforms: Android
  `mipmap-*/ic_launcher.png` at all five standard densities — these were
  actually **missing entirely** despite `AndroidManifest.xml` referencing
  `@mipmap/ic_launcher`, which would have failed the Android build too,
  not just iOS — and iOS `Assets.xcassets/AppIcon.appiconset` at all
  required sizes. Replace both with your real logo before shipping
  (`flutter_launcher_icons` can regenerate every size from one source
  image on both platforms at once).

## Architecture decisions worth knowing

- **State management:** `provider` + `ChangeNotifier`, one consistent
  approach app-wide (requirement: don't mix state solutions).
- **Every API screen** goes through the same `ViewStatus` enum
  (`initial/loading/loaded/empty/error`) and the shared `LoadingView` /
  `EmptyView` / `ErrorView` widgets, so no screen ships with a blank state.
- **Session restore:** `AuthProvider.restoreSession()` always asks the
  backend (`GET /auth/check`) whether the cookie jar loaded from disk is
  still valid — it never assumes logged-out just because the app restarted.
- **360° viewer:** `TourViewerScreen` renders the real uploaded panorama
  for the active scene and, on a navigation hotspot tap, swaps which real
  backend scene is active while staying inside the same viewer (never a
  fake dialog or demo scene). Viewpoint hotspots re-orient the same
  panorama using the real stored yaw/pitch.
- **Landlord/Admin tour manager:** one shared screen
  (`features/landlord/screens/tour_manager_screen.dart`) used by both
  roles, since they call the exact same `Tour360Controller` endpoints with
  the same permissions model — satisfying "Admin must have the same
  panorama management capability as Landlord."
