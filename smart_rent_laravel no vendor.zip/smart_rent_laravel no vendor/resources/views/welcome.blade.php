<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Smart Rent – Find Your Perfect Room in Tanzania</title>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,400;14..32,500;14..32,600;14..32,700;14..32,800&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <style>
        /* ----- CSS Variables & Reset ----- */
        :root {
            --bg-body: #f4f7fb;
            --bg-card: #ffffff;
            --bg-dark: #0f172a;
            --bg-dark-hover: #1e293b;
            --gold: #f59e0b;
            --gold-dark: #d97706;
            --text-primary: #0f172a;
            --text-secondary: #64748b;
            --text-light: #f1f5f9;
            --border-color: #eef2f6;
            --shadow-sm: 0 2px 8px rgba(0,0,0,0.04);
            --shadow-md: 0 8px 30px rgba(0,0,0,0.08);
            --shadow-lg: 0 20px 60px rgba(0,0,0,0.12);
            --gradient-gold: linear-gradient(135deg, #f59e0b, #d97706);
            --radius: 20px;
            --transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
        }
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        html {
            scroll-behavior: smooth;
        }
        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg-body);
            color: var(--text-primary);
            line-height: 1.6;
            overflow-x: hidden;
        }
        a {
            text-decoration: none;
            color: inherit;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 24px;
        }

        /* ----- Scroll-triggered animations ----- */
        .reveal {
            opacity: 0;
            transform: translateY(40px);
            transition: opacity 0.9s cubic-bezier(0.2, 0.9, 0.3, 1), transform 0.9s cubic-bezier(0.2, 0.9, 0.3, 1);
        }
        .reveal.visible {
            opacity: 1;
            transform: translateY(0);
        }
        .reveal-left {
            opacity: 0;
            transform: translateX(-60px);
            transition: opacity 0.9s cubic-bezier(0.2, 0.9, 0.3, 1), transform 0.9s cubic-bezier(0.2, 0.9, 0.3, 1);
        }
        .reveal-left.visible {
            opacity: 1;
            transform: translateX(0);
        }
        .reveal-right {
            opacity: 0;
            transform: translateX(60px);
            transition: opacity 0.9s cubic-bezier(0.2, 0.9, 0.3, 1), transform 0.9s cubic-bezier(0.2, 0.9, 0.3, 1);
        }
        .reveal-right.visible {
            opacity: 1;
            transform: translateX(0);
        }
        .reveal-scale {
            opacity: 0;
            transform: scale(0.92);
            transition: opacity 0.9s cubic-bezier(0.2, 0.9, 0.3, 1), transform 0.9s cubic-bezier(0.2, 0.9, 0.3, 1);
        }
        .reveal-scale.visible {
            opacity: 1;
            transform: scale(1);
        }

        /* ----- Navigation (sticky, glass) ----- */
        nav {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            background: rgba(15, 23, 42, 0.85);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(255,255,255,0.08);
            padding: 14px 0;
            transition: var(--transition);
        }
        nav .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 16px;
        }
        .nav-brand {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 24px;
            font-weight: 800;
            letter-spacing: -0.5px;
            color: var(--text-light);
        }
        .nav-brand .brand-icon {
            width: 40px;
            height: 40px;
            background: var(--gradient-gold);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            font-weight: 800;
            color: #0f172a;
            box-shadow: 0 4px 12px rgba(245,158,11,0.3);
        }
        .nav-brand span {
            color: var(--gold);
        }
        .nav-links {
            display: flex;
            align-items: center;
            gap: 28px;
            font-weight: 500;
            font-size: 15px;
            color: rgba(255,255,255,0.7);
        }
        .nav-links a {
            transition: var(--transition);
            position: relative;
        }
        .nav-links a::after {
            content: '';
            position: absolute;
            bottom: -4px;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--gold);
            transition: var(--transition);
        }
        .nav-links a:hover {
            color: #fff;
        }
        .nav-links a:hover::after {
            width: 100%;
        }
        .nav-actions {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .btn-outline-light {
            padding: 10px 24px;
            border: 2px solid rgba(255,255,255,0.25);
            border-radius: 12px;
            font-weight: 600;
            transition: var(--transition);
            background: transparent;
            color: var(--text-light);
            cursor: pointer;
        }
        .btn-outline-light:hover {
            background: rgba(255,255,255,0.08);
            border-color: var(--gold);
            color: var(--gold);
        }
        .nav-icon-btn {
            padding: 10px 16px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
        }
        @media (max-width: 640px) {
            .nav-icon-btn span { display: none; }
            .nav-icon-btn { padding: 10px 12px; }
        }
        .btn-gold {
            padding: 10px 28px;
            background: var(--gradient-gold);
            border: none;
            border-radius: 12px;
            font-weight: 700;
            color: #0f172a;
            cursor: pointer;
            transition: var(--transition);
            box-shadow: 0 4px 12px rgba(245,158,11,0.3);
        }
        .btn-gold:hover {
            transform: translateY(-3px) scale(1.02);
            box-shadow: 0 8px 28px rgba(245,158,11,0.4);
        }
        .mobile-toggle {
            display: none;
            font-size: 24px;
            background: none;
            border: none;
            color: var(--text-light);
            cursor: pointer;
            padding: 4px 8px;
        }
        @media (max-width: 768px) {
            .nav-links {
                display: none;
                flex-direction: column;
                width: 100%;
                gap: 12px;
                padding: 16px 0;
                border-top: 1px solid rgba(255,255,255,0.08);
                margin-top: 8px;
            }
            .nav-links.open {
                display: flex;
            }
            .mobile-toggle {
                display: block;
            }
            .nav-actions {
                flex-wrap: wrap;
                justify-content: center;
                width: 100%;
            }
        }

        /* ----- Hero Section ----- */
        .hero {
            background: var(--bg-dark);
            color: var(--text-light);
            padding: 140px 0 100px;
            position: relative;
            overflow: hidden;
            min-height: 100vh;
            display: flex;
            align-items: center;
        }
        .hero::after {
            content: '';
            position: absolute;
            right: -10%;
            bottom: -20%;
            width: 600px;
            height: 600px;
            background: radial-gradient(circle, rgba(245,158,11,0.10) 0%, transparent 70%);
            border-radius: 50%;
            pointer-events: none;
        }
        .hero .container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 60px;
            align-items: center;
            position: relative;
            z-index: 2;
        }
        .hero-content h1 {
            font-size: 52px;
            font-weight: 800;
            letter-spacing: -1.5px;
            line-height: 1.1;
        }
        .hero-content h1 span {
            background: var(--gradient-gold);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .hero-content p {
            font-size: 18px;
            color: #94a3b8;
            margin: 24px 0 36px;
            max-width: 500px;
        }
        .hero-buttons {
            display: flex;
            flex-wrap: wrap;
            gap: 16px;
        }
        .hero-image {
            display: flex;
            justify-content: center;
            align-items: center;
            animation: float 6s ease-in-out infinite;
        }
        .hero-image img {
            max-width: 100%;
            border-radius: var(--radius);
            box-shadow: var(--shadow-lg);
            border: 1px solid rgba(255,255,255,0.08);
            transition: var(--transition);
        }
        .hero-image img:hover {
            transform: scale(1.02);
        }
        @keyframes float {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-12px); }
            100% { transform: translateY(0px); }
        }
        @media (max-width: 992px) {
            .hero .container {
                grid-template-columns: 1fr;
                text-align: center;
            }
            .hero-content p {
                margin-left: auto;
                margin-right: auto;
            }
            .hero-buttons {
                justify-content: center;
            }
            .hero-content h1 {
                font-size: 40px;
            }
            .hero {
                padding: 120px 0 80px;
                min-height: auto;
            }
        }
        @media (max-width: 600px) {
            .hero-content h1 {
                font-size: 30px;
            }
            .hero {
                padding: 100px 0 60px;
            }
        }

        /* ----- Buttons (large) ----- */
        .btn-gold-large {
            padding: 16px 40px;
            font-size: 18px;
        }
        .btn-outline-light-large {
            padding: 16px 40px;
            font-size: 18px;
        }

        /* ----- Sections ----- */
        section {
            padding: 80px 0;
        }
        .section-title {
            text-align: center;
            font-size: 38px;
            font-weight: 800;
            letter-spacing: -0.5px;
            margin-bottom: 12px;
        }
        .section-title .highlight {
            background: var(--gradient-gold);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .section-subtitle {
            text-align: center;
            font-size: 18px;
            color: var(--text-secondary);
            max-width: 600px;
            margin: 0 auto 50px;
        }

        /* ----- Features ----- */
        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 30px;
        }
        .feature-card {
            background: var(--bg-card);
            padding: 32px 24px;
            border-radius: var(--radius);
            box-shadow: var(--shadow-sm);
            border: 1px solid var(--border-color);
            transition: var(--transition);
            text-align: center;
            cursor: default;
        }
        .feature-card:hover {
            transform: translateY(-8px);
            box-shadow: var(--shadow-md);
            border-color: var(--gold);
        }
        .feature-card .icon {
            width: 64px;
            height: 64px;
            background: #fef3c7;
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            color: var(--gold-dark);
            margin: 0 auto 16px;
            transition: var(--transition);
        }
        .feature-card:hover .icon {
            background: var(--gradient-gold);
            color: #0f172a;
            transform: scale(1.08) rotate(-4deg);
        }
        .feature-card h3 {
            font-size: 20px;
            font-weight: 700;
            margin-bottom: 8px;
        }
        .feature-card p {
            color: var(--text-secondary);
            font-size: 15px;
        }

        /* ----- How It Works ----- */
        .steps-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 30px;
        }
        .step-card {
            background: var(--bg-card);
            padding: 32px 24px;
            border-radius: var(--radius);
            box-shadow: var(--shadow-sm);
            border: 1px solid var(--border-color);
            text-align: center;
            position: relative;
            transition: var(--transition);
        }
        .step-card:hover {
            transform: translateY(-6px) scale(1.01);
            box-shadow: var(--shadow-md);
        }
        .step-card .step-number {
            width: 48px;
            height: 48px;
            background: var(--gradient-gold);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            font-weight: 800;
            color: #0f172a;
            margin: 0 auto 16px;
            box-shadow: 0 4px 12px rgba(245,158,11,0.2);
            transition: var(--transition);
        }
        .step-card:hover .step-number {
            transform: scale(1.1) rotate(-4deg);
        }
        .step-card h3 {
            font-size: 18px;
            font-weight: 700;
            margin-bottom: 8px;
        }
        .step-card p {
            color: var(--text-secondary);
            font-size: 14px;
        }

        /* ----- Room Previews ----- */
        .rooms-preview {
            background: var(--bg-body);
        }
        .room-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(270px, 1fr));
            gap: 28px;
        }
        .room-card {
            background: var(--bg-card);
            border-radius: var(--radius);
            overflow: hidden;
            box-shadow: var(--shadow-sm);
            border: 1px solid var(--border-color);
            transition: var(--transition);
            cursor: pointer;
        }
        .room-card:hover {
            transform: translateY(-8px);
            box-shadow: var(--shadow-md);
            border-color: var(--gold);
        }
        .room-card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            transition: var(--transition);
        }
        .room-card:hover img {
            transform: scale(1.04);
        }
        .room-card .info {
            padding: 18px 20px 20px;
        }
        .room-card .info h4 {
            font-size: 18px;
            font-weight: 700;
            margin-bottom: 4px;
        }
        .room-card .info .location {
            font-size: 13px;
            color: var(--text-secondary);
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 4px;
        }
        .room-card .info .price {
            font-size: 20px;
            font-weight: 800;
            color: var(--gold-dark);
        }
        .room-card .info .price small {
            font-weight: 400;
            font-size: 14px;
            color: var(--text-secondary);
        }

        /* ----- Stats ----- */
        .stats-section {
            background: var(--bg-dark);
            color: var(--text-light);
            padding: 80px 0;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 30px;
            text-align: center;
        }
        .stat-item .number {
            font-size: 52px;
            font-weight: 800;
            background: var(--gradient-gold);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            line-height: 1.2;
        }
        .stat-item .label {
            font-size: 16px;
            color: #94a3b8;
            font-weight: 500;
            margin-top: 4px;
        }

        /* ----- Testimonials ----- */
        .testimonials-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 30px;
        }
        .testimonial-card {
            background: var(--bg-card);
            padding: 28px 24px;
            border-radius: var(--radius);
            box-shadow: var(--shadow-sm);
            border: 1px solid var(--border-color);
            transition: var(--transition);
        }
        .testimonial-card:hover {
            box-shadow: var(--shadow-md);
            transform: translateY(-4px);
        }
        .testimonial-card .stars {
            color: var(--gold);
            margin-bottom: 12px;
            font-size: 18px;
        }
        .testimonial-card blockquote {
            font-size: 15px;
            color: var(--text-primary);
            margin-bottom: 16px;
            font-style: italic;
        }
        .testimonial-card .author {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .testimonial-card .author .avatar {
            width: 44px;
            height: 44px;
            border-radius: 50%;
            background: var(--gradient-gold);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            color: #0f172a;
            font-size: 18px;
            flex-shrink: 0;
        }
        .testimonial-card .author .name {
            font-weight: 600;
        }
        .testimonial-card .author .role {
            font-size: 13px;
            color: var(--text-secondary);
        }

        /* ----- CTA ----- */
        .cta-section {
            background: var(--bg-dark);
            color: var(--text-light);
            padding: 80px 0;
            text-align: center;
            position: relative;
            overflow: hidden;
        }
        .cta-section::before {
            content: '';
            position: absolute;
            left: -20%;
            top: -20%;
            width: 400px;
            height: 400px;
            background: radial-gradient(circle, rgba(245,158,11,0.06) 0%, transparent 70%);
            border-radius: 50%;
        }
        .cta-section h2 {
            font-size: 38px;
            font-weight: 800;
            margin-bottom: 12px;
        }
        .cta-section h2 span {
            background: var(--gradient-gold);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .cta-section p {
            font-size: 18px;
            color: #94a3b8;
            max-width: 600px;
            margin: 0 auto 36px;
        }

        /* ----- Footer ----- */
        footer {
            background: #0a0f1f;
            color: #94a3b8;
            padding: 40px 0 30px;
            border-top: 1px solid rgba(255,255,255,0.05);
        }
        footer .container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            gap: 30px;
        }
        footer .brand {
            font-size: 20px;
            font-weight: 800;
            color: var(--text-light);
        }
        footer .brand span {
            color: var(--gold);
        }
        footer .brand .tagline {
            font-weight: 400;
            font-size: 14px;
            color: #94a3b8;
            display: block;
            margin-top: 4px;
        }
        footer .links {
            display: flex;
            gap: 30px;
            flex-wrap: wrap;
        }
        footer .links a {
            transition: var(--transition);
        }
        footer .links a:hover {
            color: var(--gold);
        }
        footer .copy {
            width: 100%;
            text-align: center;
            margin-top: 30px;
            font-size: 14px;
            border-top: 1px solid rgba(255,255,255,0.05);
            padding-top: 20px;
        }
        .copy .gold {
            color: var(--gold);
        }

        /* ----- Responsive ----- */
        @media (max-width: 768px) {
            .section-title {
                font-size: 30px;
            }
            .stat-item .number {
                font-size: 40px;
            }
            footer .container {
                flex-direction: column;
                align-items: center;
                text-align: center;
            }
            footer .links {
                justify-content: center;
            }
        }
        @media (max-width: 600px) {
            .hero-content h1 {
                font-size: 28px;
            }
            .hero-buttons .btn-gold-large,
            .hero-buttons .btn-outline-light-large {
                width: 100%;
                text-align: center;
                justify-content: center;
            }
            .btn-gold-large,
            .btn-outline-light-large {
                padding: 14px 24px;
                font-size: 16px;
            }
        }
    </style>
</head>
<body>

    <!-- ===== NAVIGATION ===== -->
    <nav>
        <div class="container">
            <div class="nav-brand">
                <div class="brand-icon">SR</div>
                Smart<span>Rent</span>
            </div>
            <button class="mobile-toggle" id="mobileToggle" aria-label="Toggle navigation">
                <i class="fas fa-bars"></i>
            </button>
            <div class="nav-links" id="navLinks">
                <a href="#features">Features</a>
                <a href="#how-it-works">How It Works</a>
                <a href="#rooms">Rooms</a>
                <a href="#testimonials">Testimonials</a>
                <div class="nav-actions">
                    <a href="/app" class="btn-outline-light">Sign In</a>
                    <a href="/app" class="btn-gold">Get Started</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- ===== HERO ===== -->
    <section class="hero" id="home">
        <div class="container">
            <div class="hero-content reveal-left">
                <h1>Find Your Perfect Room<br />in <span>Tanzania</span></h1>
                <p>Discover fully verified rooms, apartments, and shared spaces. Book securely, pay easily, and move in stress‑free.</p>
                <div class="hero-buttons">
                    <a href="/app" class="btn-gold btn-gold-large"><i class="fas fa-search"></i> Browse Rooms</a>
                    <a href="/app" class="btn-outline-light btn-outline-light-large"><i class="fas fa-user-plus"></i> List Your Property</a>
                </div>
            </div>
            <div class="hero-image reveal-right">
                <img src="https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?w=600&h=400&fit=crop&crop=center" alt="Modern room" />
            </div>
        </div>
    </section>

    <!-- ===== FEATURES ===== -->
    <section id="features">
        <div class="container">
            <div class="reveal">
                <h2 class="section-title">Why Choose <span class="highlight">Smart Rent</span></h2>
                <p class="section-subtitle">We make finding and renting rooms simple, transparent, and secure.</p>
            </div>
            <div class="features-grid">
                <div class="feature-card reveal" style="transition-delay: 0.05s;">
                    <div class="icon"><i class="fas fa-shield-alt"></i></div>
                    <h3>Secure Booking</h3>
                    <p>All listings are verified and your payments are protected.</p>
                </div>
                <div class="feature-card reveal" style="transition-delay: 0.10s;">
                    <div class="icon"><i class="fas fa-headset"></i></div>
                    <h3>24/7 Support</h3>
                    <p>Our team is always ready to help you anytime, anywhere.</p>
                </div>
                <div class="feature-card reveal" style="transition-delay: 0.15s;">
                    <div class="icon"><i class="fas fa-check-circle"></i></div>
                    <h3>Verified Properties</h3>
                    <p>Every room is inspected and approved by our quality team.</p>
                </div>
                <div class="feature-card reveal" style="transition-delay: 0.20s;">
                    <div class="icon"><i class="fas fa-credit-card"></i></div>
                    <h3>Easy Payments</h3>
                    <p>Pay via M‑Pesa, Airtel, Visa, PayPal, and more.</p>
                </div>
                <div class="feature-card reveal" style="transition-delay: 0.25s;">
                    <div class="icon"><i class="fas fa-map-pin"></i></div>
                    <h3>Local Expertise</h3>
                    <p>We know Tanzania – from Dar es Salaam to Zanzibar.</p>
                </div>
                <div class="feature-card reveal" style="transition-delay: 0.30s;">
                    <div class="icon"><i class="fas fa-users"></i></div>
                    <h3>Community Driven</h3>
                    <p>Join thousands of happy tenants and landlords.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== HOW IT WORKS ===== -->
    <section id="how-it-works" style="background: var(--bg-card);">
        <div class="container">
            <div class="reveal">
                <h2 class="section-title">How It <span class="highlight">Works</span></h2>
                <p class="section-subtitle">Three simple steps to your new home.</p>
            </div>
            <div class="steps-grid">
                <div class="step-card reveal" style="transition-delay: 0.05s;">
                    <div class="step-number">1</div>
                    <h3>Browse &amp; Compare</h3>
                    <p>Search hundreds of rooms, filter by location, price, and size.</p>
                </div>
                <div class="step-card reveal" style="transition-delay: 0.10s;">
                    <div class="step-number">2</div>
                    <h3>Book or Order</h3>
                    <p>Choose your favourite room and confirm your booking or order.</p>
                </div>
                <div class="step-card reveal" style="transition-delay: 0.15s;">
                    <div class="step-number">3</div>
                    <h3>Pay &amp; Move In</h3>
                    <p>Make a secure payment and move into your new space.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== ROOM PREVIEW ===== -->
    <section id="rooms" class="rooms-preview">
        <div class="container">
            <div class="reveal">
                <h2 class="section-title">Featured <span class="highlight">Rooms</span></h2>
                <p class="section-subtitle">Some of the most popular listings in Dar es Salaam.</p>
            </div>
            <div class="room-cards">
                <div class="room-card reveal" style="transition-delay: 0.05s;">
                    <img src="https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?w=400&h=300&fit=crop&crop=center" alt="Room 1" />
                    <div class="info">
                        <h4>Modern Studio</h4>
                        <div class="location"><i class="fas fa-map-pin"></i> Kinondoni, Dar es Salaam</div>
                        <div class="price">TSh 85,000 <small>/ month</small></div>
                    </div>
                </div>
                <div class="room-card reveal" style="transition-delay: 0.10s;">
                    <img src="https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=400&h=300&fit=crop&crop=center" alt="Room 2" />
                    <div class="info">
                        <h4>Spacious Double Room</h4>
                        <div class="location"><i class="fas fa-map-pin"></i> Mikocheni, Dar es Salaam</div>
                        <div class="price">TSh 75,000 <small>/ month</small></div>
                    </div>
                </div>
                <div class="room-card reveal" style="transition-delay: 0.15s;">
                    <img src="https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=400&h=300&fit=crop&crop=center" alt="Room 3" />
                    <div class="info">
                        <h4>Cozy Shared Room</h4>
                        <div class="location"><i class="fas fa-map-pin"></i> Mbezi Beach, Dar es Salaam</div>
                        <div class="price">TSh 60,000 <small>/ month</small></div>
                    </div>
                </div>
            </div>
            <div style="text-align:center; margin-top: 40px;">
                <a href="/app" class="btn-gold btn-gold-large"><i class="fas fa-arrow-right"></i> View All Rooms</a>
            </div>
        </div>
    </section>

    <!-- ===== STATS ===== -->
    <section class="stats-section" id="stats">
        <div class="container">
            <div class="stats-grid">
                <div class="stat-item reveal-scale">
                    <div class="number" data-count="500">0</div>
                    <div class="label">Rooms Listed</div>
                </div>
                <div class="stat-item reveal-scale" style="transition-delay: 0.10s;">
                    <div class="number" data-count="1200">0</div>
                    <div class="label">Happy Tenants</div>
                </div>
                <div class="stat-item reveal-scale" style="transition-delay: 0.20s;">
                    <div class="number" data-count="98">0</div>
                    <div class="label">Satisfaction Rate %</div>
                </div>
                <div class="stat-item reveal-scale" style="transition-delay: 0.30s;">
                    <div class="number" data-count="50">0</div>
                    <div class="label">Landlords</div>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== TESTIMONIALS ===== -->
    <section id="testimonials">
        <div class="container">
            <div class="reveal">
                <h2 class="section-title">What Our <span class="highlight">Users Say</span></h2>
                <p class="section-subtitle">Real stories from real people.</p>
            </div>
            <div class="testimonials-grid">
                <div class="testimonial-card reveal" style="transition-delay: 0.05s;">
                    <div class="stars"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i></div>
                    <blockquote>“Smart Rent made finding a room so easy. I found a beautiful studio in less than a week!”</blockquote>
                    <div class="author">
                        <div class="avatar">A</div>
                        <div>
                            <div class="name">Amanda</div>
                            <div class="role">Tenant, Dar es Salaam</div>
                        </div>
                    </div>
                </div>
                <div class="testimonial-card reveal" style="transition-delay: 0.10s;">
                    <div class="stars"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i></div>
                    <blockquote>“I listed my property and got a booking within 48 hours. The platform is a game‑changer.”</blockquote>
                    <div class="author">
                        <div class="avatar">J</div>
                        <div>
                            <div class="name">Joseph</div>
                            <div class="role">Landlord, Arusha</div>
                        </div>
                    </div>
                </div>
                <div class="testimonial-card reveal" style="transition-delay: 0.15s;">
                    <div class="stars"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i></div>
                    <blockquote>“The payment process was smooth and secure. I highly recommend Smart Rent.”</blockquote>
                    <div class="author">
                        <div class="avatar">M</div>
                        <div>
                            <div class="name">Mary</div>
                            <div class="role">Student, Dodoma</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== CTA ===== -->
    <section class="cta-section">
        <div class="container">
            <div class="reveal">
                <h2>Ready to find your <span>perfect room</span>?</h2>
                <p>Join thousands of satisfied users and start your journey today.</p>
                <a href="/app" class="btn-gold btn-gold-large"><i class="fas fa-rocket"></i> Get Started Now</a>
            </div>
        </div>
    </section>

    <!-- ===== FOOTER ===== -->
    <footer>
        <div class="container">
            <div class="brand">
                Smart<span>Rent</span>
                <span class="tagline">Automated booking, trusted space and zero stress.</span>
            </div>
            <div class="links">
                <a href="#features">Features</a>
                <a href="#how-it-works">How It Works</a>
                <a href="#rooms">Rooms</a>
                <a href="#testimonials">Testimonials</a>
                <a href="/app">Sign In</a>
            </div>
            <div class="copy">&copy; 2026 Smart Rent. All rights reserved. <span class="gold">Dar es Salaam, Tanzania</span></div>
        </div>
    </footer>

    <!-- ===== JAVASCRIPT ===== -->
    <script>
        // ---------- Mobile Menu Toggle ----------
        const toggleBtn = document.getElementById('mobileToggle');
        const navLinks = document.getElementById('navLinks');
        toggleBtn.addEventListener('click', () => {
            navLinks.classList.toggle('open');
        });
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', () => {
                navLinks.classList.remove('open');
            });
        });

        // ---------- Scroll Reveal Animations ----------
        const revealElements = document.querySelectorAll('.reveal, .reveal-left, .reveal-right, .reveal-scale');

        const revealObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                }
            });
        }, {
            threshold: 0.15,
            rootMargin: '0px 0px -40px 0px'
        });

        revealElements.forEach(el => revealObserver.observe(el));

        // ---------- Animated Stats Counter ----------
        const statNumbers = document.querySelectorAll('.stat-item .number');

        const counterObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const el = entry.target;
                    const target = parseInt(el.getAttribute('data-count'));
                    if (isNaN(target)) return;
                    let current = 0;
                    const increment = Math.ceil(target / 60); // 60 steps
                    const timer = setInterval(() => {
                        current += increment;
                        if (current >= target) {
                            el.textContent = target + (target === 98 ? '%' : '');
                            clearInterval(timer);
                        } else {
                            el.textContent = current + (target === 98 ? '%' : '');
                        }
                    }, 25);
                    counterObserver.unobserve(el);
                }
            });
        }, { threshold: 0.3 });

        statNumbers.forEach(el => counterObserver.observe(el));

        // ---------- Smooth anchor scrolling (optional fallback) ----------
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                const href = this.getAttribute('href');
                if (href !== '#') {
                    e.preventDefault();
                    const target = document.querySelector(href);
                    if (target) {
                        target.scrollIntoView({ behavior: 'smooth' });
                    }
                }
            });
        });
    </script>
</body>
</html>