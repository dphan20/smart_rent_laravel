<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Property extends Model
{
    protected $table = 'properties';

    protected $fillable = [
        'landlord_id',
        'name',
        'type',
        'apartment',
        'house_no',
        'region',
        'district',
        'ward',
        'street',
        'location',
        'coords',
        'description',
        'bedrooms',
        'bathrooms',
        'amenities',
        'furnished',
        'room_size',
        'monthly_rent',
        'deposit',
        'service_charge',
        'availability',
        'images',
        'video',
        'virtual_tour',
    ];

    protected $casts = [
        'amenities' => 'array',
        'images' => 'array',
        'bedrooms' => 'integer',
        'bathrooms' => 'integer',
        'room_size' => 'integer',
        'monthly_rent' => 'decimal:2',
        'deposit' => 'decimal:2',
        'service_charge' => 'decimal:2',
    ];

    public $timestamps = true;

    /**
     * Get the landlord who owns this property
     */
    public function landlord()
    {
        return $this->belongsTo(User::class, 'landlord_id');
    }

    /**
     * Check if property is available
     */
    public function isAvailable()
    {
        return $this->availability === 'available';
    }
}
