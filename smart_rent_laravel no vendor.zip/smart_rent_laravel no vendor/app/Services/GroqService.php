<?php

namespace App\Services;

use App\Models\Room;
use App\Models\Property;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Cache;

class GroqService
{
    private $apiKey;
    private $model;
    private $endpoint;
    const RATE_LIMIT_PER_MINUTE = 20; // Per IP
    const RATE_LIMIT_PER_HOUR = 100; // Per IP

    public function __construct()
    {
        $this->apiKey = config('services.groq.api_key');
        $this->model = config('services.groq.model');
        $this->endpoint = config('services.groq.endpoint');
    }

    /**
     * Check rate limiting based on client IP
     */
    private function checkRateLimit()
    {
        $ip = request()->ip();
        
        // Per-minute limit
        $minuteKey = "chat_limit_minute_{$ip}";
        if (Cache::get($minuteKey, 0) >= self::RATE_LIMIT_PER_MINUTE) {
            return [
                'allowed' => false,
                'message' => 'Too many requests. Please wait a moment before trying again.',
            ];
        }
        
        // Per-hour limit
        $hourKey = "chat_limit_hour_{$ip}";
        if (Cache::get($hourKey, 0) >= self::RATE_LIMIT_PER_HOUR) {
            return [
                'allowed' => false,
                'message' => 'Rate limit exceeded. Please try again in an hour.',
            ];
        }
        
        return ['allowed' => true];
    }

    /**
     * Increment rate limit counters
     */
    private function incrementRateLimit()
    {
        $ip = request()->ip();
        $minuteKey = "chat_limit_minute_{$ip}";
        $hourKey = "chat_limit_hour_{$ip}";
        
        Cache::increment($minuteKey, 1, 60); // Expire after 60 seconds
        Cache::increment($hourKey, 1, 3600); // Expire after 1 hour
    }

    /**
     * Process a user message and return AI response with property recommendations.
     *
     * IMPORTANT: this method always returns a non-empty 'reply' string, no
     * matter what goes wrong (missing API key, Groq API error, network
     * failure, unexpected response shape, etc). Previously, failure paths
     * returned only ['success' => false, 'message' => ...] with no 'reply'
     * key at all, which the chat widget rendered as a blank/"undefined"
     * bubble. Now every failure path falls back to a deterministic reply
     * grounded in the real, currently-available rooms/properties already
     * looked up from the database (see buildFallbackReply()), so the
     * chatbot always "says something real" instead of going silent.
     */
    public function chat($userMessage, $sessionId = null)
    {
        $language = 'english';
        $propertyData = ['properties' => [], 'count' => 0];

        try {
            Log::info('GroqService chat started', ['message' => substr($userMessage, 0, 50)]);

            $language = $this->detectResponseLanguage($userMessage);

            // Check rate limiting
            $rateCheck = $this->checkRateLimit();
            if (!$rateCheck['allowed']) {
                Log::warning('Rate limit exceeded for IP: ' . request()->ip());
                return [
                    'success' => false,
                    'message' => $rateCheck['message'],
                    'reply' => $rateCheck['message'],
                    'properties' => [],
                ];
            }

            // Extract search criteria from user message and pull real,
            // currently-available listings from the database. This always
            // runs - even if the Groq API key is missing or the call fails
            // below - so the fallback reply is grounded in what's actually
            // in the browser/database right now, never invented.
            $searchCriteria = $this->extractSearchCriteria($userMessage);
            Log::info('Extracted criteria', $searchCriteria);

            $propertyData = $this->searchProperties($searchCriteria);
            Log::info('Search results', ['count' => $propertyData['count'] ?? 0]);

            // Validate API key - if missing, skip straight to the grounded
            // fallback reply instead of returning an empty/failed response.
            if (!$this->apiKey) {
                Log::warning('Groq API key not configured - using grounded fallback reply');
                $this->incrementRateLimit();
                return [
                    'success' => true,
                    'reply' => $this->buildFallbackReply($userMessage, $propertyData, $language),
                    'properties' => $propertyData['properties'] ?? [],
                ];
            }

            // Prepare context for Groq
            $context = $this->prepareContext($propertyData, $searchCriteria, $language);
            Log::info('Context prepared', ['context_length' => strlen($context)]);

            // Send to Groq API
            $aiResponse = $this->callGroqAPI($userMessage, $context, $language);
            Log::info('Groq API response received', ['success' => $aiResponse['success'] ?? false]);

            // Increment rate limit - we've done the work either way.
            $this->incrementRateLimit();

            if (!($aiResponse['success'] ?? false) || empty(trim((string) ($aiResponse['reply'] ?? '')))) {
                // Groq call failed or returned an empty/unexpected reply -
                // fall back to a grounded, deterministic answer instead of
                // surfacing an error or a blank message to the user.
                Log::warning('Groq call failed or returned empty reply, using grounded fallback', [
                    'groq_message' => $aiResponse['message'] ?? null,
                ]);
                return [
                    'success' => true,
                    'reply' => $this->buildFallbackReply($userMessage, $propertyData, $language),
                    'properties' => $propertyData['properties'] ?? [],
                ];
            }

            return [
                'success' => true,
                'reply' => $aiResponse['reply'],
                'properties' => $propertyData['properties'] ?? [],
            ];
        } catch (\Exception $e) {
            Log::error('GroqService error', [
                'message' => $e->getMessage(),
                'code' => $e->getCode(),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
                'trace' => $e->getTraceAsString()
            ]);
            // Even on an unexpected exception, still try to answer using
            // whatever property data we already gathered above, rather than
            // returning a bare error with no 'reply' for the widget to show.
            return [
                'success' => true,
                'reply' => $this->buildFallbackReply($userMessage, $propertyData, $language),
                'properties' => $propertyData['properties'] ?? [],
                'message' => 'Unable to process your request. Error: ' . $e->getMessage(),
            ];
        }
    }

    /**
     * Extract search criteria from user message
     */
    private function extractSearchCriteria($message)
    {
        $criteria = [
            'location' => null,
            'maxPrice' => null,
            'minPrice' => null,
            'type' => null,
            'bedrooms' => null,
            'furnished' => null,
            'amenities' => [],
        ];

        $lowerMessage = strtolower($message);

        // Extract price - supports patterns like "under 300,000", "below 800,000", "300000 to 500000"
        if (preg_match('/(?:under|below|less than|≤|max|maximum)\s*(?:tsh|tzs)?\s*([0-9,]+)/i', $message, $matches)) {
            $criteria['maxPrice'] = (int) str_replace(',', '', $matches[1]);
        }
        if (preg_match('/(?:at least|minimum|min|≥|from)\s*(?:tsh|tzs)?\s*([0-9,]+)/i', $message, $matches)) {
            $criteria['minPrice'] = (int) str_replace(',', '', $matches[1]);
        }
        if (preg_match('/([0-9,]+)\s*(?:to|–|-)\s*([0-9,]+)/i', $message, $matches)) {
            $criteria['minPrice'] = (int) str_replace(',', '', $matches[1]);
            $criteria['maxPrice'] = (int) str_replace(',', '', $matches[2]);
        }

        // Extract location
        $locations = [
            'mbezi' => 'Mbezi', 'dar es salaam' => 'Dar es Salaam', 'dar' => 'Dar es Salaam',
            'sinza' => 'Sinza', 'udsm' => 'UDSM', 'morogoro' => 'Morogoro',
            'kinondoni' => 'Kinondoni', 'temeke' => 'Temeke', 'ilala' => 'Ilala',
            'mbeya' => 'Mbeya', 'arusha' => 'Arusha', 'moshi' => 'Moshi',
        ];

        foreach ($locations as $key => $location) {
            if (strpos($lowerMessage, $key) !== false) {
                $criteria['location'] = $location;
                break;
            }
        }

        // Extract property type
        $types = ['room', 'apartment', 'house', 'bedsitter', 'chumba', 'nyumba', 'ghorofa'];
        foreach ($types as $type) {
            if (strpos($lowerMessage, $type) !== false) {
                $criteria['type'] = ucfirst($type);
                break;
            }
        }

        // Extract bedroom count - handles "2 bed", "3 bedroom", "4 rooms"
        if (preg_match('/([0-9])\s*(?:bed|bedroom|bedr|beds|chumba|chambres?)/i', $message, $matches)) {
            $criteria['bedrooms'] = (int) $matches[1];
        }

        // Extract furnished preference
        if (preg_match('/furnished|sofumishwe/i', $message)) {
            $criteria['furnished'] = 'furnished';
        } elseif (preg_match('/unfurnished|au(?:sitofumishwe|somefaa)/i', $message)) {
            $criteria['furnished'] = 'unfurnished';
        }

        return $criteria;
    }

    /**
     * Normalize a Room or Property Eloquent record into ONE shared listing
     * shape. This is the single source of truth for field names so the
     * frontend (matchmaker results, "similar properties", the chat widget)
     * never has to guess whether it's looking at a room or a property.
     *
     * IMPORTANT: keys here match what resources/views/app.blade.php already
     * expects from AI results (room_id, name, monthly_rent, bedrooms,
     * room_size, image, virtual_tour, status) - see summaryToRoomLike(),
     * renderAiMatchResults(), and fetchAndRenderSimilarProperties(). Room
     * listings previously came back as {id, title, price, beds, ...} which
     * left `monthly_rent`/`name` undefined on the frontend and crashed on
     * `s.monthly_rent.toLocaleString()`.
     */
    private function normalizeListing($record, string $sourceType): array
    {
        if ($sourceType === 'room') {
            return [
                'source_type' => 'room',
                'room_id' => $record->id,
                'name' => $record->title,
                'location' => $record->location,
                'monthly_rent' => $record->price !== null ? (float) $record->price : null,
                'bedrooms' => $record->beds,
                'room_size' => $record->size,
                'type' => $record->type,
                'furnished' => null,
                'amenities' => [],
                'image' => $record->image,
                'virtual_tour' => $record->virtual_tour,
                'status' => $record->status,
                'match_score' => null,
                'match_reasons' => [],
            ];
        }

        // property
        return [
            'source_type' => 'property',
            'room_id' => $record->id,
            'name' => $record->name,
            'location' => $record->location ?: trim(implode(', ', array_filter([
                $record->street, $record->ward, $record->district, $record->region,
            ]))),
            'monthly_rent' => $record->monthly_rent !== null ? (float) $record->monthly_rent : null,
            'bedrooms' => $record->bedrooms,
            'room_size' => $record->room_size,
            'type' => $record->type,
            'furnished' => $record->furnished,
            'amenities' => $record->amenities ?: [],
            'image' => is_array($record->images) ? ($record->images[0] ?? null) : $record->images,
            'virtual_tour' => $record->virtual_tour,
            'status' => $record->availability,
            'match_score' => null,
            'match_reasons' => [],
        ];
    }

    /**
     * Fetch ONE live listing by id for "Ask AI about this property". The
     * frontend only ever sends one numeric id (see summaryToRoomLike(),
     * which maps every listing's `room_id` back to a single `id`), so a
     * room and a property can share the same numeric id. Rooms are checked
     * first because that's what the id historically referred to; if no
     * room matches, fall back to properties. Returns null if neither table
     * has that id, so callers can say "not available" instead of guessing.
     */
    public function getListingById($id): ?array
    {
        $room = Room::find($id);
        if ($room) {
            return $this->normalizeListing($room, 'room');
        }

        $property = Property::find($id);
        if ($property) {
            return $this->normalizeListing($property, 'property');
        }

        return null;
    }

    /**
     * Answer a question about ONE specific, already-identified property.
     * Unlike chat()/match(), this never runs a fresh keyword search - it
     * builds context strictly from the single live record the frontend
     * asked about, so "where is it located" / "is it available" always
     * reflect that exact listing's current data instead of a generic
     * search result.
     */
    public function askAboutListing(array $listing, string $question, string $sessionId = null): array
    {
        $language = $this->detectResponseLanguage($question);

        $context = "You are the Smart Rent AI Assistant. Answer ONLY about this ONE specific listing using its current data below. Do not invent or assume any detail not given.\n\n";
        $context .= "Listing: {$listing['name']}\n";
        $context .= "Location: {$listing['location']}\n";
        $context .= 'Monthly rent: TZS ' . number_format((float) ($listing['monthly_rent'] ?? 0)) . "\n";
        $context .= 'Bedrooms: ' . ($listing['bedrooms'] ?? 'not specified') . "\n";
        $context .= 'Availability status: ' . ($listing['status'] ?? 'unknown') . "\n";
        if (!empty($listing['amenities'])) {
            $context .= 'Amenities: ' . implode(', ', (array) $listing['amenities']) . "\n";
        }
        $context .= "\nInstructions:\n";
        $context .= "- Base the answer only on the listing data above.\n";
        $context .= "- If asked whether it can be booked, base that on the availability status above.\n";
        $context .= "- Answer in " . ($language === 'swahili' ? 'Swahili' : 'English') . " only, 1-3 sentences.\n";

        if ($this->apiKey) {
            $aiResponse = $this->callGroqAPI($question, $context, $language);
            if (($aiResponse['success'] ?? false) && trim((string) ($aiResponse['reply'] ?? '')) !== '') {
                return ['success' => true, 'reply' => $aiResponse['reply']];
            }
        }

        // Deterministic, grounded fallback - answers directly from the
        // live listing fields rather than a generic message.
        $q = strtolower($question);
        $price = number_format((float) ($listing['monthly_rent'] ?? 0));
        $isSwahili = $language === 'swahili';

        if (preg_match('/\b(where|location|iko wapi|eneo)\b/i', $q)) {
            $reply = $isSwahili
                ? "Iko {$listing['location']}."
                : "It's located in {$listing['location']}.";
        } elseif (preg_match('/\b(how much|price|rent|bei|kiasi)\b/i', $q)) {
            $reply = $isSwahili
                ? "Kodi ni TZS {$price} kwa mwezi."
                : "The rent is TZS {$price} per month.";
        } elseif (preg_match('/\b(available|book|is it booked|inapatikana|imebook)\b/i', $q)) {
            $available = strtolower((string) $listing['status']) === 'available';
            $reply = $isSwahili
                ? ($available ? 'Ndiyo, inapatikana kwa sasa na unaweza kuiweka nafasi.' : 'Kwa sasa haipatikani.')
                : ($available ? 'Yes, it is currently available and can be booked.' : "It's not currently available.");
        } elseif (preg_match('/\b(bedroom|vyumba)\b/i', $q)) {
            $reply = $isSwahili
                ? 'Ina vyumba ' . ($listing['bedrooms'] ?? 'haijulikani') . '.'
                : 'It has ' . ($listing['bedrooms'] ?? 'an unspecified number of') . ' bedroom(s).';
        } else {
            $reply = $isSwahili
                ? "{$listing['name']} - {$listing['location']}, TZS {$price}/mwezi."
                : "{$listing['name']} — {$listing['location']}, TZS {$price}/month.";
        }

        return ['success' => true, 'reply' => $reply];
    }

    /**
     * Live "similar listings" - same rough location or price band as the
     * given listing, excluding the listing itself, available now.
     */
    public function findSimilarListings(array $listing, int $limit = 6): array
    {
        $price = (float) ($listing['monthly_rent'] ?? 0);
        $minPrice = $price > 0 ? $price * 0.6 : null;
        $maxPrice = $price > 0 ? $price * 1.4 : null;
        $location = $listing['location'] ?? null;
        $excludeId = $listing['source_type'] === 'room' ? $listing['room_id'] : null;
        $excludePropId = $listing['source_type'] === 'property' ? $listing['room_id'] : null;

        $rooms = Room::query()->where('status', 'available');
        if ($excludeId) {
            $rooms = $rooms->where('id', '!=', $excludeId);
        }
        $properties = Property::query()->where('availability', 'available');
        if ($excludePropId) {
            $properties = $properties->where('id', '!=', $excludePropId);
        }

        if ($location) {
            $like = '%' . $location . '%';
            $rooms = $rooms->where('location', 'like', $like);
            $properties = $properties->where('location', 'like', $like);
        }
        if ($minPrice && $maxPrice) {
            $rooms = $rooms->whereBetween('price', [$minPrice, $maxPrice]);
            $properties = $properties->whereBetween('monthly_rent', [$minPrice, $maxPrice]);
        }

        $results = $rooms->limit($limit)->get()->map(fn ($r) => $this->normalizeListing($r, 'room'))
            ->concat($properties->limit($limit)->get()->map(fn ($p) => $this->normalizeListing($p, 'property')))
            ->take($limit)
            ->values();

        // Widen search if a strict location+price match found nothing.
        if ($results->isEmpty() && $price > 0) {
            $rooms2 = Room::query()->where('status', 'available')->whereBetween('price', [$minPrice, $maxPrice]);
            $props2 = Property::query()->where('availability', 'available')->whereBetween('monthly_rent', [$minPrice, $maxPrice]);
            if ($excludeId) {
                $rooms2 = $rooms2->where('id', '!=', $excludeId);
            }
            if ($excludePropId) {
                $props2 = $props2->where('id', '!=', $excludePropId);
            }
            $results = $rooms2->limit($limit)->get()->map(fn ($r) => $this->normalizeListing($r, 'room'))
                ->concat($props2->limit($limit)->get()->map(fn ($p) => $this->normalizeListing($p, 'property')))
                ->take($limit)
                ->values();
        }

        return $results->toArray();
    }

    /**
     * Search properties and rooms in database based on criteria.
     *
     * Always queries LIVE data from both tables - never a cached or
     * hard-coded list - so newly added rooms/properties are discoverable
     * immediately without any code change.
     */
    private function searchProperties($criteria)
    {
        $rooms = Room::query()->where('status', 'available');
        $properties = Property::query()->where('availability', 'available');

        // Filter by location
        if ($criteria['location']) {
            $location = '%' . $criteria['location'] . '%';
            $rooms = $rooms->where('location', 'like', $location);
            $properties = $properties->where(function ($q) use ($location) {
                $q->where('location', 'like', $location)
                    ->orWhere('region', 'like', $location)
                    ->orWhere('district', 'like', $location)
                    ->orWhere('ward', 'like', $location)
                    ->orWhere('street', 'like', $location);
            });
        }

        // Filter by price
        if ($criteria['maxPrice']) {
            $rooms = $rooms->where('price', '<=', $criteria['maxPrice']);
            $properties = $properties->where('monthly_rent', '<=', $criteria['maxPrice']);
        }
        if ($criteria['minPrice']) {
            $rooms = $rooms->where('price', '>=', $criteria['minPrice']);
            $properties = $properties->where('monthly_rent', '>=', $criteria['minPrice']);
        }

        // Filter by type
        if ($criteria['type']) {
            $type = '%' . $criteria['type'] . '%';
            $rooms = $rooms->where('type', 'like', $type);
            $properties = $properties->where('type', 'like', $type);
        }

        // Filter by bedrooms - rooms use `beds`, properties use `bedrooms`
        if ($criteria['bedrooms']) {
            $rooms = $rooms->where('beds', '>=', $criteria['bedrooms']);
            $properties = $properties->where('bedrooms', '>=', $criteria['bedrooms']);
        }

        if ($criteria['furnished']) {
            $properties = $properties->where('furnished', $criteria['furnished']);
        }

        // Newest first so newly-added rooms/properties surface naturally.
        $roomResults = $rooms->orderByDesc('created_at')->limit(10)->get();
        $propertyResults = $properties->orderByDesc('created_at')->limit(10)->get();

        $listings = $roomResults->map(fn ($r) => $this->normalizeListing($r, 'room'))
            ->concat($propertyResults->map(fn ($p) => $this->normalizeListing($p, 'property')))
            ->values()
            ->toArray();

        return [
            'properties' => $listings,
            'count' => count($listings),
        ];
    }

    /**
     * Detect the language the user is asking in so the reply follows it exactly.
     */
    public function detectResponseLanguage($message)
    {
        $text = strtolower(trim((string) $message));
        if ($text === '') {
            return 'english';
        }

        $swahiliWords = [
            'nina', 'napenda', 'tafadhali', 'chumba', 'nyumba', 'gharamani', 'bei', 'kwa', 'unataka',
            'kitu', 'twende', 'mbezi', 'kiasi', 'mbili', 'moja', 'nime', 'siku', 'pesa', 'mkoa',
            'kivutio', 'kati', 'jina', 'lini', 'hivi', 'angalia', 'kama', 'na', 'kuna', 'mchango'
        ];

        $swahiliMatches = 0;
        foreach ($swahiliWords as $word) {
            if (str_contains($text, $word)) {
                $swahiliMatches++;
            }
        }

        return $swahiliMatches > 0 ? 'swahili' : 'english';
    }

    /**
     * Prepare context for Groq API
     */
    private function prepareContext($propertyData, $criteria, $language = 'english')
    {
        $languageLabel = $language === 'swahili' ? 'Swahili' : 'English';

        $context = "You are the Smart Rent AI Assistant. You help users find rental properties in Tanzania.\n\n";

        if ($propertyData['count'] > 0) {
            $context .= "Based on the user's search criteria, here are relevant, currently available listings:\n\n";
            foreach ($propertyData['properties'] as $listing) {
                $label = $listing['source_type'] === 'room' ? 'Room' : 'Property';
                $context .= "- {$label}: {$listing['name']} in {$listing['location']}, Price: TZS {$listing['monthly_rent']}, Bedrooms: {$listing['bedrooms']}\n";
            }
            $context .= "\n";
        } else {
            $context .= "No properties matched the search criteria provided.\n\n";
        }

        $context .= "Instructions:\n";
        $context .= "- Use only the provided property information. Do not invent properties, prices, or locations.\n";
        $context .= "- Answer in {$languageLabel} only. Never mix English and Swahili in the same reply.\n";
        $context .= "- Keep the answer short, direct, and specific to the exact question asked. 1-3 sentences only, unless the user explicitly asks for a list.\n";
        $context .= "- If no properties match, politely state that in the same language and ask one clarifying question only.\n";
        $context .= "- When recommending properties, include key details like location, price, and bedrooms in the same language as the question.\n";

        return $context;
    }

    /**
     * Deterministic, grounded reply used whenever the Groq API is not
     * configured, fails, times out, or returns something unusable. Never
     * invents a property, price, or location - it only ever describes the
     * real rows already fetched from the database in searchProperties(), so
     * the chatbot's answer always reflects what's actually available right
     * now instead of returning nothing.
     */
    private function buildFallbackReply($userMessage, array $propertyData, $language = 'english')
    {
        $isSwahili = $language === 'swahili';
        $properties = $propertyData['properties'] ?? [];

        if (!empty($properties)) {
            $count = count($properties);
            $lines = [];
            $lines[] = $isSwahili
                ? ("Nimepata " . $count . " zinazopatikana zinazoweza kukufaa:")
                : ("I found " . $count . " available " . ($count === 1 ? "listing" : "listings") . " that might match:");

            foreach (array_slice($properties, 0, 5) as $listing) {
                $price = number_format((float) ($listing['monthly_rent'] ?? 0));
                $name = $listing['name'] ?? ($listing['source_type'] === 'room' ? 'Room' : 'Property');
                $location = $listing['location'] ?? '';
                $bedrooms = $listing['bedrooms'] ?? '?';
                $lines[] = "- {$name} — TZS {$price}/month, {$bedrooms} bed(s), {$location}";
            }

            $lines[] = $isSwahili
                ? "Uliza swali zaidi kuhusu mojawapo, au niambie eneo, bei, na idadi ya vyumba unavyotaka."
                : "Ask me more about any of these, or tell me a location, budget, and number of bedrooms to narrow it down.";

            return implode("\n", $lines);
        }

        // No matching listings - still respond helpfully instead of blank.
        $lower = strtolower((string) $userMessage);
        if (preg_match('/\b(book|booking|how.*book)\b/i', $lower)) {
            return $isSwahili
                ? "Kuweka nafasi: chagua chumba kinachopatikana, bofya Book Now, na mwenye nyumba atakagua ombi lako. Likikubaliwa, mkataba wa kukodi utatengenezwa kwa ajili yenu wawili kukubali."
                : "To book: pick an available room, click Book Now, and the landlord will review your request. Once approved, a rental contract is generated for you both to accept.";
        }
        if (preg_match('/\b(pay|payment|mpesa|money|malipo|bei)\b/i', $lower)) {
            return $isSwahili
                ? "Malipo hufanyika kupitia jukwaa mara mkataba wako unapokuwa hai. Malipo huwekwa kama yanasubiri hadi yathibitishwe."
                : "Payments are made through the platform once your contract is active. A payment is recorded as pending until it's verified.";
        }
        if (preg_match('/\b(contract|sign|agreement|mkataba)\b/i', $lower)) {
            return $isSwahili
                ? "Mara mwenye nyumba akikubali ombi lako, mkataba wa kukodi utatengenezwa moja kwa moja. Nyote wawili mnakubali kidijitali kabla haujaanza kutumika."
                : "Once a landlord approves your booking, a rental contract is generated automatically. Both you and the landlord digitally accept it before it becomes active.";
        }

        return $isSwahili
            ? "Sikupata nyumba zinazopatikana zinazolingana na hilo kwa sasa. Niambie eneo, bei, na idadi ya vyumba - mfano \"chumba cha vyumba 2 Mbezi chini ya 300,000\"."
            : "I couldn't find any available listings matching that right now. Try telling me a location, budget, and number of bedrooms - for example \"2 bedroom apartment in Mbezi under 300,000\".";
    }

    /**
     * Call Groq API
     */
    private function callGroqAPI($userMessage, $context, $language = 'english')
    {
        try {
            Log::info('Calling Groq API', [
                'endpoint' => $this->endpoint,
                'model' => $this->model,
                'has_api_key' => !empty($this->apiKey),
                'language' => $language,
            ]);

            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->apiKey,
                'Content-Type' => 'application/json',
            ])->timeout(30)->post($this->endpoint, [
                'model' => $this->model,
                'messages' => [
                    [
                        'role' => 'system',
                        'content' => $context,
                    ],
                    [
                        'role' => 'user',
                        'content' => "Respond in " . ($language === 'swahili' ? 'Swahili' : 'English') . " only. Keep it brief and specific to this question: " . $userMessage,
                    ],
                ],
                'temperature' => 0.2,
                'max_tokens' => 512,
            ]);

            Log::info('Groq API response status', ['status' => $response->status()]);
            
            if (!$response->successful()) {
                Log::warning('Groq API error', [
                    'status' => $response->status(),
                    'body' => substr($response->body(), 0, 500)
                ]);
                return [
                    'success' => false,
                    'message' => 'Groq API error (status ' . $response->status() . '): ' . substr($response->body(), 0, 200),
                ];
            }

            $data = $response->json();
            Log::info('Groq response structure', ['keys' => array_keys($data ?? [])]);

            if (!isset($data['choices'][0]['message']['content'])) {
                Log::warning('Unexpected Groq response structure', ['data' => $data]);
                return [
                    'success' => false,
                    'message' => 'Unexpected API response structure',
                ];
            }

            return [
                'success' => true,
                'reply' => $data['choices'][0]['message']['content'],
            ];
        } catch (\Exception $e) {
            Log::error('Groq API call failed', [
                'message' => $e->getMessage(),
                'code' => $e->getCode(),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
            ]);
            return [
                'success' => false,
                'message' => 'Groq API call failed: ' . $e->getMessage(),
            ];
        }
    }
}
