<?php
require_once __DIR__ . '/../config/database.php';

class Message {
    public static function getAll() {
        global $pdo;
        $stmt = $pdo->query("SELECT * FROM messages ORDER BY created_at DESC");
        return $stmt->fetchAll();
    }

    public static function create($data) {
        global $pdo;
        $stmt = $pdo->prepare("INSERT INTO messages (name, email, phone, message) VALUES (?, ?, ?, ?)");
        $stmt->execute([$data['name'], $data['email'], $data['phone'], $data['message']]);
        return $pdo->lastInsertId();
    }
}
?>