<?php
require_once __DIR__ . '/../config/database.php';

/**
 * A "tour" here is ONE 360° panorama scene belonging to a room or a
 * property. A property/room can have several scenes (Living Room,
 * Bedroom, Kitchen, ...) linked together by navigation hotspots, which is
 * why this is (listing_type, listing_id) -> many scenes -> many hotspots,
 * not a single virtual_tour column like the existing rooms.virtual_tour /
 * properties.virtual_tour fields (which stay untouched and keep working
 * for listings that only ever had one external tour link/image).
 */
class Tour360
{
    private static function assertListingType($type)
    {
        if (!in_array($type, ['room', 'property'], true)) {
            sendJSON(['error' => 'Invalid listing_type. Must be "room" or "property".'], 400);
        }
    }

    public static function scenesForListing($listingType, $listingId)
    {
        global $pdo;
        self::assertListingType($listingType);
        $stmt = $pdo->prepare('SELECT * FROM property_360_tours WHERE listing_type = ? AND listing_id = ? ORDER BY is_primary DESC, id ASC');
        $stmt->execute([$listingType, $listingId]);
        return $stmt->fetchAll();
    }

    public static function find($id)
    {
        global $pdo;
        $stmt = $pdo->prepare('SELECT * FROM property_360_tours WHERE id = ?');
        $stmt->execute([$id]);
        $tour = $stmt->fetch();
        return $tour ?: null;
    }

    public static function hotspotsForTour($tourId)
    {
        global $pdo;
        $stmt = $pdo->prepare('SELECT * FROM property_360_hotspots WHERE tour_id = ? ORDER BY id ASC');
        $stmt->execute([$tourId]);
        return $stmt->fetchAll();
    }

    /**
     * Full payload for one listing's tour: every scene plus its hotspots,
     * in the shape the frontend's Pannellum multi-scene config expects.
     * Used both by the customer viewer and the admin/agent editor.
     */
    public static function fullTourForListing($listingType, $listingId)
    {
        $scenes = self::scenesForListing($listingType, $listingId);
        foreach ($scenes as &$scene) {
            $scene['hotspots'] = self::hotspotsForTour($scene['id']);
        }
        unset($scene);
        return $scenes;
    }

    public static function createScene($data)
    {
        global $pdo;
        self::assertListingType($data['listing_type']);
        $stmt = $pdo->prepare(
            'INSERT INTO property_360_tours (listing_type, listing_id, name, image, description, is_primary, created_by, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())'
        );
        $stmt->execute([
            $data['listing_type'],
            (int) $data['listing_id'],
            $data['name'],
            $data['image'],
            $data['description'] ?? null,
            !empty($data['is_primary']) ? 1 : 0,
            $data['created_by'] ?? null,
        ]);
        $id = $pdo->lastInsertId();

        // First scene ever uploaded for a listing becomes primary
        // automatically, so the viewer has a sensible starting point
        // without the uploader having to remember to flag one.
        $existing = self::scenesForListing($data['listing_type'], $data['listing_id']);
        if (count($existing) === 1) {
            $stmt = $pdo->prepare('UPDATE property_360_tours SET is_primary = 1 WHERE id = ?');
            $stmt->execute([$id]);
        }

        return $id;
    }

    public static function updateScene($id, $data)
    {
        global $pdo;
        $fields = [];
        $params = [];
        foreach (['name', 'description', 'image'] as $col) {
            if (array_key_exists($col, $data)) {
                $fields[] = "$col = ?";
                $params[] = $data[$col];
            }
        }
        if (array_key_exists('is_primary', $data)) {
            $fields[] = 'is_primary = ?';
            $params[] = !empty($data['is_primary']) ? 1 : 0;
        }
        if (empty($fields)) {
            return true;
        }
        $fields[] = 'updated_at = NOW()';
        $params[] = $id;
        $stmt = $pdo->prepare('UPDATE property_360_tours SET ' . implode(', ', $fields) . ' WHERE id = ?');
        return $stmt->execute($params);
    }

    /**
     * Deletes a scene and its own hotspots (DB cascade handles that), and
     * gracefully degrades any OTHER scene's navigation hotspot that
     * pointed at this one, instead of leaving a hotspot that 404s or
     * crashes the viewer when clicked.
     */
    public static function deleteScene($id)
    {
        global $pdo;
        $stmt = $pdo->prepare('UPDATE property_360_hotspots SET target_tour_id = NULL WHERE target_tour_id = ?');
        $stmt->execute([$id]);

        $stmt = $pdo->prepare('DELETE FROM property_360_tours WHERE id = ?');
        return $stmt->execute([$id]);
    }

    private static function normalizeHotspotType($type)
    {
        return in_array($type, ['navigation', 'viewpoint'], true) ? $type : 'info';
    }

    public static function createHotspot($data)
    {
        global $pdo;
        $type = self::normalizeHotspotType($data['type'] ?? null);
        $stmt = $pdo->prepare(
            'INSERT INTO property_360_hotspots (tour_id, target_tour_id, target_yaw, target_pitch, target_hfov, type, yaw, pitch, title, description, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())'
        );
        $stmt->execute([
            (int) $data['tour_id'],
            $type === 'navigation' && !empty($data['target_tour_id']) ? (int) $data['target_tour_id'] : null,
            $type === 'viewpoint' && isset($data['target_yaw']) ? (float) $data['target_yaw'] : null,
            $type === 'viewpoint' && isset($data['target_pitch']) ? (float) $data['target_pitch'] : null,
            $type === 'viewpoint' && isset($data['target_hfov']) && $data['target_hfov'] !== '' ? (float) $data['target_hfov'] : null,
            $type,
            (float) $data['yaw'],
            (float) $data['pitch'],
            $data['title'] ?? null,
            $data['description'] ?? null,
        ]);
        return $pdo->lastInsertId();
    }

    public static function findHotspot($id)
    {
        global $pdo;
        $stmt = $pdo->prepare('SELECT * FROM property_360_hotspots WHERE id = ?');
        $stmt->execute([$id]);
        $hotspot = $stmt->fetch();
        return $hotspot ?: null;
    }

    public static function updateHotspot($id, $data)
    {
        global $pdo;
        $fields = [];
        $params = [];
        foreach (['title', 'description'] as $col) {
            if (array_key_exists($col, $data)) {
                $fields[] = "$col = ?";
                $params[] = $data[$col];
            }
        }
        if (array_key_exists('type', $data)) {
            $fields[] = 'type = ?';
            $params[] = self::normalizeHotspotType($data['type']);
        }
        if (array_key_exists('target_tour_id', $data)) {
            $fields[] = 'target_tour_id = ?';
            $params[] = $data['target_tour_id'] !== null && $data['target_tour_id'] !== '' ? (int) $data['target_tour_id'] : null;
        }
        if (array_key_exists('target_yaw', $data)) {
            $fields[] = 'target_yaw = ?';
            $params[] = $data['target_yaw'] !== null && $data['target_yaw'] !== '' ? (float) $data['target_yaw'] : null;
        }
        if (array_key_exists('target_pitch', $data)) {
            $fields[] = 'target_pitch = ?';
            $params[] = $data['target_pitch'] !== null && $data['target_pitch'] !== '' ? (float) $data['target_pitch'] : null;
        }
        if (array_key_exists('target_hfov', $data)) {
            $fields[] = 'target_hfov = ?';
            $params[] = $data['target_hfov'] !== null && $data['target_hfov'] !== '' ? (float) $data['target_hfov'] : null;
        }
        if (array_key_exists('yaw', $data)) {
            $fields[] = 'yaw = ?';
            $params[] = (float) $data['yaw'];
        }
        if (array_key_exists('pitch', $data)) {
            $fields[] = 'pitch = ?';
            $params[] = (float) $data['pitch'];
        }
        if (empty($fields)) {
            return true;
        }
        $fields[] = 'updated_at = NOW()';
        $params[] = $id;
        $stmt = $pdo->prepare('UPDATE property_360_hotspots SET ' . implode(', ', $fields) . ' WHERE id = ?');
        return $stmt->execute($params);
    }

    public static function deleteHotspot($id)
    {
        global $pdo;
        $stmt = $pdo->prepare('DELETE FROM property_360_hotspots WHERE id = ?');
        return $stmt->execute([$id]);
    }

    /**
     * Resolves whether $user is allowed to manage tours for the given
     * listing: Admins can manage any listing; Landlords only their own
     * room/property. Never trusts a landlord_id supplied by the browser -
     * always looks up the listing's actual owner from the database.
     */
    public static function userCanManageListing($user, $listingType, $listingId)
    {
        if (!$user) {
            return false;
        }
        $role = normalizeRole($user['type']);
        if ($role === 'Admin') {
            return true;
        }
        if ($role !== 'Landlord') {
            return false;
        }

        global $pdo;
        $table = $listingType === 'room' ? 'rooms' : 'properties';
        $stmt = $pdo->prepare("SELECT landlord_id FROM {$table} WHERE id = ?");
        $stmt->execute([$listingId]);
        $row = $stmt->fetch();
        return $row && (int) $row['landlord_id'] === (int) $user['id'];
    }
}
