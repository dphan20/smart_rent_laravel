<?php
/**
 * SMART RENT - database migration runner.
 *
 * Run once from the command line after pulling this update:
 *   php backend/migrate.php
 *
 * Safe to run multiple times: every step checks whether it has already been
 * applied (via information_schema) before doing anything, so re-running this
 * on a database that already has the changes is a no-op, not an error.
 *
 * This does NOT touch: payments (business columns), or anything the
 * payment-gateway/SMS layers own. It only adds integrity/security structure
 * around the existing tables, plus (as of 2026-08-26) the permanent
 * house_id identifier on properties/rooms - see the last step below.
 */

require_once __DIR__ . '/config/env.php';
// backend/ now lives inside public/ - project root is 2 levels up.
loadEnvFile(__DIR__ . '/../../.env');

$host = getenv('SMART_RENT_DB_HOST') ?: 'localhost';
$dbname = getenv('SMART_RENT_DB_NAME') ?: 'smartrent';
$username = getenv('SMART_RENT_DB_USER') ?: 'root';
$password = getenv('SMART_RENT_DB_PASS') ?: '';

$pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
]);

function columnExists(PDO $pdo, string $table, string $column): bool {
    $stmt = $pdo->prepare(
        "SELECT COUNT(*) FROM information_schema.columns
         WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ?"
    );
    $stmt->execute([$table, $column]);
    return (int) $stmt->fetchColumn() > 0;
}

function tableExists(PDO $pdo, string $table): bool {
    $stmt = $pdo->prepare(
        "SELECT COUNT(*) FROM information_schema.tables
         WHERE table_schema = DATABASE() AND table_name = ?"
    );
    $stmt->execute([$table]);
    return (int) $stmt->fetchColumn() > 0;
}

function indexExists(PDO $pdo, string $table, string $indexName): bool {
    $stmt = $pdo->prepare(
        "SELECT COUNT(*) FROM information_schema.statistics
         WHERE table_schema = DATABASE() AND table_name = ? AND index_name = ?"
    );
    $stmt->execute([$table, $indexName]);
    return (int) $stmt->fetchColumn() > 0;
}

function fkExists(PDO $pdo, string $constraintName): bool {
    $stmt = $pdo->prepare(
        "SELECT COUNT(*) FROM information_schema.table_constraints
         WHERE table_schema = DATABASE() AND constraint_name = ? AND constraint_type = 'FOREIGN KEY'"
    );
    $stmt->execute([$constraintName]);
    return (int) $stmt->fetchColumn() > 0;
}

function step(string $label, callable $fn): void {
    echo "-> $label ... ";
    try {
        $result = $fn();
        echo ($result === false ? "skipped (already applied)" : "done") . "\n";
    } catch (Throwable $e) {
        echo "FAILED: " . $e->getMessage() . "\n";
    }
}

// ---------------------------------------------------------------------
// 1. Auth-hardening columns on users
// ---------------------------------------------------------------------
step('users.email_verified_at', function () use ($pdo) {
    if (columnExists($pdo, 'users', 'email_verified_at')) return false;
    $pdo->exec("ALTER TABLE users ADD COLUMN email_verified_at DATETIME NULL AFTER role");
});

step('users.failed_login_attempts / locked_until', function () use ($pdo) {
    $changed = false;
    if (!columnExists($pdo, 'users', 'failed_login_attempts')) {
        $pdo->exec("ALTER TABLE users ADD COLUMN failed_login_attempts INT NOT NULL DEFAULT 0");
        $changed = true;
    }
    if (!columnExists($pdo, 'users', 'locked_until')) {
        $pdo->exec("ALTER TABLE users ADD COLUMN locked_until DATETIME NULL");
        $changed = true;
    }
    return $changed;
});

// ---------------------------------------------------------------------
// 2. New tables: login attempts (IP-level throttling + audit trail),
//    password resets, remember-me tokens, email verification tokens
// ---------------------------------------------------------------------
step('login_attempts table', function () use ($pdo) {
    if (tableExists($pdo, 'login_attempts')) return false;
    $pdo->exec("CREATE TABLE login_attempts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        email VARCHAR(191) NOT NULL,
        ip_address VARCHAR(45) NOT NULL,
        success TINYINT(1) NOT NULL DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_login_attempts_ip_time (ip_address, created_at),
        INDEX idx_login_attempts_email_time (email, created_at)
    ) ENGINE=InnoDB");
});

step('password_resets table', function () use ($pdo) {
    if (tableExists($pdo, 'password_resets')) return false;
    $pdo->exec("CREATE TABLE password_resets (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        token_hash CHAR(64) NOT NULL,
        expires_at DATETIME NOT NULL,
        used_at DATETIME NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_password_resets_token_hash (token_hash),
        INDEX idx_password_resets_user (user_id),
        CONSTRAINT fk_password_resets_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB");
});

step('remember_tokens table', function () use ($pdo) {
    if (tableExists($pdo, 'remember_tokens')) return false;
    $pdo->exec("CREATE TABLE remember_tokens (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        selector CHAR(24) NOT NULL,
        token_hash CHAR(64) NOT NULL,
        expires_at DATETIME NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_remember_tokens_selector (selector),
        INDEX idx_remember_tokens_user (user_id),
        CONSTRAINT fk_remember_tokens_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB");
});

step('email_verifications table', function () use ($pdo) {
    if (tableExists($pdo, 'email_verifications')) return false;
    $pdo->exec("CREATE TABLE email_verifications (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        token_hash CHAR(64) NOT NULL,
        expires_at DATETIME NOT NULL,
        verified_at DATETIME NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_email_verifications_token_hash (token_hash),
        INDEX idx_email_verifications_user (user_id),
        CONSTRAINT fk_email_verifications_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB");
});

// ---------------------------------------------------------------------
// 3. Referential integrity on the existing business tables.
//    Nullable FKs (ON DELETE SET NULL) so removing a room/user doesn't
//    destroy financial history - it just detaches the reference.
// ---------------------------------------------------------------------
$foreignKeys = [
    ['fk_bookings_room',      'bookings',  'room_id',     'rooms',  'id', 'SET NULL'],
    ['fk_bookings_user',      'bookings',  'user_id',     'users',  'id', 'SET NULL'],
    ['fk_bookings_landlord',  'bookings',  'landlord_id', 'users',  'id', 'SET NULL'],
    ['fk_orders_room',        'orders',    'room_id',     'rooms',  'id', 'SET NULL'],
    ['fk_orders_user',        'orders',    'user_id',     'users',  'id', 'SET NULL'],
    ['fk_orders_landlord',    'orders',    'landlord_id', 'users',  'id', 'SET NULL'],
    ['fk_payments_room',      'payments',  'room_id',     'rooms',  'id', 'SET NULL'],
    ['fk_payments_user',      'payments',  'user_id',     'users',  'id', 'SET NULL'],
    ['fk_payments_landlord',  'payments',  'landlord_id', 'users',  'id', 'SET NULL'],
    ['fk_receipts_booking',   'receipts',  'booking_id',  'bookings', 'id', 'SET NULL'],
    ['fk_receipts_payment',   'receipts',  'payment_id',  'payments', 'id', 'SET NULL'],
    ['fk_properties_landlord','properties','landlord_id', 'users',  'id', 'CASCADE'],
];

foreach ($foreignKeys as [$name, $table, $column, $refTable, $refColumn, $onDelete]) {
    step("FK $name ($table.$column -> $refTable.$refColumn)", function () use ($pdo, $name, $table, $column, $refTable, $refColumn, $onDelete) {
        if (!tableExists($pdo, $table) || !tableExists($pdo, $refTable)) return false;
        if (fkExists($pdo, $name)) return false;

        // Orphaned rows would make the FK creation fail outright. Null them
        // out first so existing (pre-migration) data doesn't block this.
        $pdo->exec("UPDATE `$table` t LEFT JOIN `$refTable` r ON t.`$column` = r.`$refColumn`
                     SET t.`$column` = NULL
                     WHERE t.`$column` IS NOT NULL AND r.`$refColumn` IS NULL");

        $pdo->exec("ALTER TABLE `$table`
                     ADD CONSTRAINT `$name` FOREIGN KEY (`$column`) REFERENCES `$refTable`(`$refColumn`)
                     ON DELETE $onDelete ON UPDATE CASCADE");
    });
}

// ---------------------------------------------------------------------
// 4. Indexes for the query patterns the controllers actually use, and a
//    uniqueness constraint that prevents the same payment reference from
//    ever being recorded twice (double-submit / duplicate callback safety).
// ---------------------------------------------------------------------
$indexes = [
    ['idx_rooms_status',        'rooms',    'status'],
    ['idx_rooms_landlord',      'rooms',    'landlord_id'],
    ['idx_bookings_room',       'bookings', 'room_id'],
    ['idx_bookings_user',       'bookings', 'user_id'],
    ['idx_bookings_status',     'bookings', 'status'],
    ['idx_orders_room',         'orders',   'room_id'],
    ['idx_orders_user',         'orders',   'user_id'],
    ['idx_orders_status',       'orders',   'status'],
    ['idx_payments_user',       'payments', 'user_id'],
    ['idx_payments_status',     'payments', 'status'],
];
foreach ($indexes as [$name, $table, $column]) {
    step("index $name ($table.$column)", function () use ($pdo, $name, $table, $column) {
        if (!tableExists($pdo, $table)) return false;
        if (indexExists($pdo, $table, $name)) return false;
        $pdo->exec("ALTER TABLE `$table` ADD INDEX `$name` (`$column`)");
    });
}

step('UNIQUE payments.reference (prevents duplicate payment processing)', function () use ($pdo) {
    if (!tableExists($pdo, 'payments')) return false;
    if (indexExists($pdo, 'payments', 'uq_payments_reference')) return false;

    // If historical duplicate references already exist, a plain UNIQUE
    // index would fail to create. Report them instead of silently dropping
    // financial data.
    $dupes = $pdo->query("SELECT reference, COUNT(*) c FROM payments GROUP BY reference HAVING c > 1")->fetchAll();
    if ($dupes) {
        echo "\n   WARNING: duplicate payment references already exist, skipping unique index:\n";
        foreach ($dupes as $d) {
            echo "     - {$d['reference']} appears {$d['c']} times\n";
        }
        echo "   Resolve these manually, then re-run this migration.\n";
        return false;
    }
    $pdo->exec("ALTER TABLE `payments` ADD UNIQUE INDEX `uq_payments_reference` (`reference`)");
});

step('payments.commission_rate / commission_amount / landlord_amount', function () use ($pdo) {
    if (!tableExists($pdo, 'payments')) return false;
    $changed = false;
    if (!columnExists($pdo, 'payments', 'commission_rate')) {
        $pdo->exec("ALTER TABLE payments ADD COLUMN commission_rate DECIMAL(5,2) NULL AFTER amount");
        $changed = true;
    }
    if (!columnExists($pdo, 'payments', 'commission_amount')) {
        $pdo->exec("ALTER TABLE payments ADD COLUMN commission_amount DECIMAL(10,2) NULL AFTER commission_rate");
        $changed = true;
    }
    if (!columnExists($pdo, 'payments', 'landlord_amount')) {
        $pdo->exec("ALTER TABLE payments ADD COLUMN landlord_amount DECIMAL(10,2) NULL AFTER commission_amount");
        $changed = true;
    }
    return $changed;
});

step('payments.room_id / landlord_id / booking_id / order_id (needed by the create/verify/webhook payment flow)', function () use ($pdo) {
    if (!tableExists($pdo, 'payments')) return false;
    $changed = false;
    if (!columnExists($pdo, 'payments', 'room_id')) {
        $pdo->exec("ALTER TABLE payments ADD COLUMN room_id INT NULL AFTER id");
        $changed = true;
    }
    if (!columnExists($pdo, 'payments', 'landlord_id')) {
        $pdo->exec("ALTER TABLE payments ADD COLUMN landlord_id INT NULL AFTER user_id");
        $changed = true;
    }
    if (!columnExists($pdo, 'payments', 'booking_id')) {
        $pdo->exec("ALTER TABLE payments ADD COLUMN booking_id INT NULL AFTER landlord_id");
        $changed = true;
    }
    if (!columnExists($pdo, 'payments', 'order_id')) {
        $pdo->exec("ALTER TABLE payments ADD COLUMN order_id INT NULL AFTER booking_id");
        $changed = true;
    }
    return $changed;
});

step('receipts.booking_id / room_id / user_id / landlord_id / recipient_number / status / payment_status (needed by the receipt-issuing flow)', function () use ($pdo) {
    if (!tableExists($pdo, 'receipts')) return false;
    $changed = false;
    $additions = [
        ['booking_id', 'INT NULL', 'AFTER id'],
        ['room_id', 'INT NULL', 'AFTER payment_id'],
        ['user_id', 'INT NULL', 'AFTER room_id'],
        ['landlord_id', 'INT NULL', 'AFTER user_id'],
        ['recipient_number', "VARCHAR(30) NULL", 'AFTER customer_phone'],
        ['reference', "VARCHAR(100) NULL", 'AFTER transaction_ref'],
        ['status', "VARCHAR(30) NOT NULL DEFAULT 'issued'", 'AFTER recipient_number'],
        ['payment_status', "VARCHAR(30) NOT NULL DEFAULT 'pending'", 'AFTER status'],
    ];
    foreach ($additions as [$col, $def, $after]) {
        if (!columnExists($pdo, 'receipts', $col)) {
            $pdo->exec("ALTER TABLE receipts ADD COLUMN `$col` $def $after");
            $changed = true;
        }
    }
    // room_name/transaction_ref predate the room_id/reference columns above
    // and are still populated for old rows - but the current write path
    // (Receipt::create) no longer supplies them, so they must allow NULL
    // for new rows instead of blocking every future receipt.
    $stmt = $pdo->query("SELECT IS_NULLABLE FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'receipts' AND column_name = 'room_name'");
    if ($stmt && $stmt->fetchColumn() === 'NO') {
        $pdo->exec("ALTER TABLE receipts MODIFY room_name VARCHAR(255) NULL");
        $changed = true;
    }
    $stmt = $pdo->query("SELECT IS_NULLABLE FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'receipts' AND column_name = 'transaction_ref'");
    if ($stmt && $stmt->fetchColumn() === 'NO') {
        $pdo->exec("ALTER TABLE receipts MODIFY transaction_ref VARCHAR(100) NULL");
        $changed = true;
    }
    return $changed;
});

step('properties.house_id / rooms.house_id (permanent listing ID) + backfill', function () use ($pdo) {
    require_once __DIR__ . '/helpers/ListingIdGenerator.php';
    $changed = false;

    if (tableExists($pdo, 'properties') && !columnExists($pdo, 'properties', 'house_id')) {
        $pdo->exec("ALTER TABLE properties ADD COLUMN house_id VARCHAR(40) NULL AFTER id");
        $changed = true;
    }
    if (tableExists($pdo, 'rooms') && !columnExists($pdo, 'rooms', 'house_id')) {
        $pdo->exec("ALTER TABLE rooms ADD COLUMN house_id VARCHAR(40) NULL AFTER id");
        $changed = true;
    }

    // Backfill: every existing property/room without a house_id gets one,
    // generated from its own existing location data. Rows that already
    // have a valid house_id are left completely untouched.
    if (tableExists($pdo, 'properties')) {
        $rows = $pdo->query("SELECT id, region, district FROM properties WHERE house_id IS NULL OR house_id = ''")->fetchAll();
        foreach ($rows as $row) {
            $houseId = ListingIdGenerator::generate($pdo, 'properties', $row['region'] ?? '', $row['district'] ?? '');
            $upd = $pdo->prepare("UPDATE properties SET house_id = ? WHERE id = ?");
            $upd->execute([$houseId, $row['id']]);
            $changed = true;
        }
    }
    if (tableExists($pdo, 'rooms')) {
        $rows = $pdo->query("SELECT id, location, area FROM rooms WHERE house_id IS NULL OR house_id = ''")->fetchAll();
        foreach ($rows as $row) {
            $houseId = ListingIdGenerator::generate($pdo, 'rooms', $row['location'] ?? '', $row['area'] ?? '');
            $upd = $pdo->prepare("UPDATE rooms SET house_id = ? WHERE id = ?");
            $upd->execute([$houseId, $row['id']]);
            $changed = true;
        }
    }

    // Unique index added only after backfill, so it can never fail due to
    // NULL/blank collisions on old rows.
    if (tableExists($pdo, 'properties') && !indexExists($pdo, 'properties', 'uq_properties_house_id')) {
        $pdo->exec("ALTER TABLE properties ADD UNIQUE INDEX uq_properties_house_id (house_id)");
        $changed = true;
    }
    if (tableExists($pdo, 'rooms') && !indexExists($pdo, 'rooms', 'uq_rooms_house_id')) {
        $pdo->exec("ALTER TABLE rooms ADD UNIQUE INDEX uq_rooms_house_id (house_id)");
        $changed = true;
    }

    return $changed;
});

echo "\nMigration complete.\n";
