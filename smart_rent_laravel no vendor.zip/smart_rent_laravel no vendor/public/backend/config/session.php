<?php
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.use_strict_mode', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_secure', (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 1 : 0);
    ini_set('session.cookie_httponly', 1);
    ini_set('session.cookie_samesite', 'Lax');
    ini_set('session.gc_maxlifetime', 3600);
    ini_set('session.cookie_lifetime', 0);
    ini_set('session.name', 'SMART_RENT_SESSID');
    session_start();
}

// Requested behavior: a logged-in user stays logged in until they
// explicitly click Logout (POST /api/auth/logout). There is intentionally
// no automatic idle/inactivity logout here - a session must never be
// destroyed merely because time passed between requests. last_activity is
// still recorded (useful for diagnostics/future features) but nothing
// reads it to force a logout.
$_SESSION['last_activity'] = time();

if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

function getCsrfToken() {
    return trim((string) ($_SESSION['csrf_token'] ?? ''));
}

function verifyCsrfToken($token) {
    $sessionToken = getCsrfToken();
    $providedToken = is_string($token) ? trim($token) : '';
    if ($sessionToken === '' || $providedToken === '') {
        return false;
    }
    return hash_equals($sessionToken, $providedToken);
}
?>