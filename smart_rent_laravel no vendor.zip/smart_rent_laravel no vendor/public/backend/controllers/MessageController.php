<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../helpers/functions.php';
require_once __DIR__ . '/../models/Message.php';

class MessageController {
    public static function getAll() {
        requireAuth();
        requireRole('Admin');
        $messages = Message::getAll();
        sendJSON($messages);
    }

    public static function create() {
        $data = json_decode(file_get_contents('php://input'), true);
        if (empty($data['name']) || empty($data['email']) || empty($data['phone']) || empty($data['message'])) {
            sendJSON(['error' => 'All fields required'], 400);
        }
        $id = Message::create($data);
        sendJSON(['success' => true, 'id' => $id]);
    }
}
?>