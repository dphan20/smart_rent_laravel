<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../helpers/functions.php';
require_once __DIR__ . '/../helpers/UploadSecurity.php';
require_once __DIR__ . '/../models/Property.php';
require_once __DIR__ . '/../models/Room.php';
require_once __DIR__ . '/../helpers/ListingIdGenerator.php';

class PropertyController {
    public static function getAll() {
        $user = getCurrentUser();
        $landlordId = $_GET['landlord_id'] ?? null;
        if ($user && normalizeRole($user['type']) === 'Landlord') {
            $landlordId = $user['id'];
        }
        $houseId = $_GET['house_id'] ?? null;
        $props = Property::getAll($landlordId, $houseId);
        sendJSON($props);
    }

    public static function create() {
        requireAuth();
        requireRole('Landlord');

        // --- 1. Get form data ---
        $data = $_POST;
        $data['landlord_id'] = $_SESSION['user_id'];

        // --- 2. Handle image uploads ---
        // backend/ and public/ are siblings under the same project root -
        // see RoomController::create() for the full explanation.
        $uploadsDir = getenv('SMART_RENT_UPLOADS_DIR') ?: (__DIR__ . '/../../uploads');
        // Ensure the directory exists and is writable
        if (!is_dir($uploadsDir)) {
            if (!mkdir($uploadsDir, 0755, true)) {
                sendJSON(['error' => 'Failed to create uploads directory.'], 500);
            }
        }
        if (!is_writable($uploadsDir)) {
            sendJSON(['error' => 'Uploads directory is not writable. Please chmod 755 on "' . $uploadsDir . '".'], 500);
        }

        // Check if any files were uploaded
        if (!isset($_FILES['images']) || empty($_FILES['images']['tmp_name'][0])) {
            sendJSON(['error' => 'No images were uploaded.'], 400);
        }

        $imageFilenames = [];
        foreach ($_FILES['images']['tmp_name'] as $index => $tmp) {
            $fileEntry = [
                'tmp_name' => $tmp,
                'error'    => $_FILES['images']['error'][$index] ?? UPLOAD_ERR_NO_FILE,
                'size'     => $_FILES['images']['size'][$index] ?? 0,
            ];
            $result = UploadSecurity::validateAndStore($fileEntry, $uploadsDir, 'property');
            if (!$result['ok']) {
                // Roll back anything already saved earlier in this same
                // request before rejecting, so a bad file later in the
                // batch doesn't leave earlier ones orphaned on disk.
                foreach ($imageFilenames as $rel) {
                    $abs = __DIR__ . '/../../' . $rel;
                    if (is_file($abs)) @unlink($abs);
                }
                sendJSON(['error' => $result['error']], 400);
            }
            $imageFilenames[] = $result['path'];
        }

        if (empty($imageFilenames)) {
            sendJSON(['error' => 'No images were successfully saved.'], 500);
        }

        // --- 3. Save property ---
        $data['images'] = json_encode($imageFilenames);

        // Automatic, permanent House ID - generated once here so the same
        // value can be shared with the room this property spawns below
        // (see Part 4/25/27 in the brief: gallery + room must resolve to
        // the same identified "house"). Never accepted from the request.
        global $pdo;
        $houseId = ListingIdGenerator::generate($pdo, 'properties', $data['region'] ?? '', $data['district'] ?? '');
        $data['house_id'] = $houseId;

        // Optional 360° virtual tour: either an uploaded panorama image
        // (preferred - validated exactly like property photos) or a pasted
        // external tour URL (e.g. a Matterport/Kuula link) typed into the
        // virtualTour text field. An uploaded file always takes priority
        // over a pasted URL if both are somehow provided.
        if (isset($_FILES['virtualTourImage']) && ($_FILES['virtualTourImage']['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_OK) {
            $tourResult = UploadSecurity::validateAndStore($_FILES['virtualTourImage'], $uploadsDir, 'tour');
            if (!$tourResult['ok']) {
                foreach ($imageFilenames as $rel) {
                    $abs = __DIR__ . '/../../' . $rel;
                    if (is_file($abs)) @unlink($abs);
                }
                sendJSON(['error' => '360° tour image: ' . $tourResult['error']], 400);
            }
            $data['virtualTour'] = $tourResult['path'];
        } elseif (!empty($data['virtualTour'])) {
            $url = trim((string) $data['virtualTour']);
            // A pasted URL must actually be an absolute http(s) URL - reject
            // anything else rather than silently storing garbage that would
            // later render as a broken tour button.
            $data['virtualTour'] = (filter_var($url, FILTER_VALIDATE_URL) && preg_match('/^https?:\/\//i', $url)) ? $url : null;
        }
        // NOTE: 'amenities' arrives from the frontend as a JSON string
        // (fd.append('amenities', JSON.stringify({...}))) and the DB column
        // is TEXT, so it must stay a string. Do NOT json_decode it here —
        // binding a PHP array as a single PDO parameter throws an uncaught
        // PDOException (PDO::ATTR_ERRMODE = ERRMODE_EXCEPTION), which used
        // to kill the request AFTER the image was already saved to disk but
        // BEFORE the property/room rows were inserted. That's why images
        // showed up in the uploads/ folder but never in the DB or frontend.
        if (!isset($data['amenities']) || $data['amenities'] === '') {
            $data['amenities'] = json_encode([]);
        }

        try {
            $propertyId = Property::create($data);
        } catch (Throwable $e) {
            // Roll back the files we just saved so we don't leave orphaned
            // uploads behind when the DB insert fails.
            foreach ($imageFilenames as $rel) {
                $abs = __DIR__ . '/../../' . $rel;
                if (is_file($abs)) {
                    @unlink($abs);
                }
            }
            error_log('Property::create failed: ' . $e->getMessage());
            sendJSON(['error' => 'Failed to save property: ' . $e->getMessage()], 500);
        }

        // --- 4. Create corresponding room ---
        $roomData = [
            'title'       => $data['name'],
            'location'    => $data['region'] . ', ' . $data['district'] . (isset($data['ward']) ? ', ' . $data['ward'] : '') . (isset($data['street']) ? ', ' . $data['street'] : ''),
            'area'        => $data['district'],
            'price'       => $data['monthlyRent'],
            'size'        => $data['roomSize'],
            'type'        => $data['type'] ?? 'Apartment',
            'beds'        => $data['bedrooms'] ?? 1,
            'badge'       => '',
            'status'      => $data['availability'] ?? 'available',
            // Full gallery, not just the first image - so the room (the
            // entity customers actually browse/book) carries every photo,
            // not only a single cover shot. Stored as a JSON array, same
            // convention properties.images already uses.
            'image'       => json_encode($imageFilenames),
            'landlord_id' => $_SESSION['user_id'],
            'virtual_tour' => $data['virtualTour'] ?? null,
            // Same House ID as the parent property, so the gallery/tour/
            // booking/payment for this listing all resolve to one identity.
            'house_id'    => $houseId,
        ];

        // Log the image paths for debugging
        error_log("Saving room images: " . $roomData['image']);

        try {
            $roomId = Room::create($roomData);
        } catch (Throwable $e) {
            // The property row was already saved successfully at this point,
            // so we don't roll back the files/property — just report the
            // room-creation failure clearly instead of a blank 500.
            error_log('Room::create failed: ' . $e->getMessage());
            sendJSON(['error' => 'Property saved, but failed to create the room listing: ' . $e->getMessage()], 500);
        }

        sendJSON(['success' => true, 'property_id' => $propertyId, 'room_id' => $roomId, 'house_id' => $houseId, 'image' => $roomData['image']]);
    }

    public static function delete($id) {
        requireAuth();
        requireRole('Landlord');
        $user = getCurrentUser();
        $property = Property::find($id);
        if (!$property || (int)$property['landlord_id'] !== (int)$user['id']) {
            sendJSON(['error' => 'You can only delete your own properties'], 403);
        }
        if (Property::delete($id)) {
            sendJSON(['success' => true]);
        } else {
            sendJSON(['error' => 'Delete failed'], 500);
        }
    }
}