<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../helpers/functions.php';
require_once __DIR__ . '/../helpers/UploadSecurity.php';
require_once __DIR__ . '/../models/Room.php';

class RoomController {
    public static function getAll() {
        $filters = $_GET;
        $user = getCurrentUser();
        if ($user && normalizeRole($user['type']) === 'Landlord') {
            $filters['landlord_id'] = $user['id'];
        }
        $rooms = Room::getAll($filters);
        sendJSON($rooms);
    }

    public static function getOne($id) {
        $user = getCurrentUser();
        $room = Room::find($id);
        if (!$room) sendJSON(['error' => 'Not found'], 404);
        if ($user && normalizeRole($user['type']) === 'Landlord' && (int) $room['landlord_id'] !== (int) $user['id']) {
            sendJSON(['error' => 'Forbidden'], 403);
        }
        sendJSON($room);
    }

    public static function create() {
        requireAuth();
        $user = getCurrentUser();
        if (!$user || !in_array(normalizeRole($user['type']), ['Admin', 'Landlord'])) {
            sendJSON(['error' => 'Forbidden – only Admin or Landlord can create rooms'], 403);
        }

        $isMultipart = isset($_FILES) && !empty($_FILES);
        if ($isMultipart) {
            $data = $_POST;

            $required = ['title', 'location', 'area', 'price', 'size', 'type', 'beds'];
            foreach ($required as $field) {
                if (empty($data[$field])) {
                    sendJSON(['error' => "Missing field: $field"], 400);
                }
            }

            // In this merged project, backend/ and public/ are siblings
            // under the same project root, so images saved here land
            // directly in Laravel's public/uploads folder and are
            // immediately visible to the Laravel frontend - no copying
            // or symlinking needed. SMART_RENT_UPLOADS_DIR (.env) can
            // still override this if you ever split the projects again.
            $uploadsDir = getenv('SMART_RENT_UPLOADS_DIR') ?: (__DIR__ . '/../../uploads');
            if (!is_dir($uploadsDir)) {
                mkdir($uploadsDir, 0755, true);
            }

            // Accepts either the legacy single 'image' file field, or a
            // new multi-file 'images[]' field (multiple images for one
            // room's gallery) - whichever the caller actually sent.
            $savedPaths = [];
            $multiFiles = $_FILES['images'] ?? null;
            if ($multiFiles && !empty($multiFiles['tmp_name'][0])) {
                foreach ($multiFiles['tmp_name'] as $index => $tmp) {
                    $fileEntry = [
                        'tmp_name' => $tmp,
                        'error'    => $multiFiles['error'][$index] ?? UPLOAD_ERR_NO_FILE,
                        'size'     => $multiFiles['size'][$index] ?? 0,
                    ];
                    $result = UploadSecurity::validateAndStore($fileEntry, $uploadsDir, 'room');
                    if (!$result['ok']) {
                        foreach ($savedPaths as $rel) {
                            $abs = __DIR__ . '/../../' . $rel;
                            if (is_file($abs)) @unlink($abs);
                        }
                        sendJSON(['error' => $result['error']], 400);
                    }
                    $savedPaths[] = $result['path'];
                }
            } elseif (isset($_FILES['image']) && ($_FILES['image']['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_OK) {
                $result = UploadSecurity::validateAndStore($_FILES['image'], $uploadsDir, 'room');
                if (!$result['ok']) {
                    sendJSON(['error' => $result['error']], 400);
                }
                $savedPaths[] = $result['path'];
            } else {
                sendJSON(['error' => 'Image upload failed'], 400);
            }

            // Stored as a JSON array so this room can carry a full photo
            // gallery, not just one cover shot - same convention already
            // used by properties.images.
            $data['image'] = json_encode($savedPaths);

            // Optional 360° virtual tour: either an uploaded panorama image
            // (preferred - validated exactly like the room's own photos) or
            // a pasted external tour URL (e.g. a Matterport/Kuula link).
            // Mirrors PropertyController::create() so Admin gets the exact
            // same "Single 360° Photo (optional)" behaviour the Landlord
            // upload form already has. An uploaded file always takes
            // priority over a pasted URL if both are somehow provided.
            if (isset($_FILES['virtualTourImage']) && ($_FILES['virtualTourImage']['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_OK) {
                $tourResult = UploadSecurity::validateAndStore($_FILES['virtualTourImage'], $uploadsDir, 'tour');
                if (!$tourResult['ok']) {
                    foreach ($savedPaths as $rel) {
                        $abs = __DIR__ . '/../../' . $rel;
                        if (is_file($abs)) @unlink($abs);
                    }
                    sendJSON(['error' => '360° tour image: ' . $tourResult['error']], 400);
                }
                $data['virtual_tour'] = $tourResult['path'];
            } elseif (!empty($data['virtualTour'])) {
                $url = trim((string) $data['virtualTour']);
                // A pasted URL must actually be an absolute http(s) URL -
                // reject anything else rather than silently storing garbage
                // that would later render as a broken tour button.
                $data['virtual_tour'] = (filter_var($url, FILTER_VALIDATE_URL) && preg_match('/^https?:\/\//i', $url)) ? $url : null;
            }

            $data['status'] = $data['status'] ?? 'available';
            if (normalizeRole($user['type']) === 'Landlord') {
                $data['landlord_id'] = $_SESSION['user_id'];
            } else {
                $data['landlord_id'] = $data['landlord_id'] ?? null;
            }

            $id = Room::create($data);
            sendJSON(['success' => true, 'id' => $id]);
        } else {
            $data = json_decode(file_get_contents('php://input'), true);
            if (!$data) {
                sendJSON(['error' => 'Invalid JSON'], 400);
            }
            $required = ['title', 'location', 'area', 'price', 'size', 'type', 'beds'];
            foreach ($required as $field) {
                if (empty($data[$field])) {
                    sendJSON(['error' => "Missing field: $field"], 400);
                }
            }
            $data['status'] = $data['status'] ?? 'available';
            if (normalizeRole($user['type']) === 'Landlord') {
                $data['landlord_id'] = $_SESSION['user_id'];
            } else {
                $data['landlord_id'] = $data['landlord_id'] ?? null;
            }
            $id = Room::create($data);
            sendJSON(['success' => true, 'id' => $id]);
        }
    }

    // NEW: Update room
    public static function update($id) {
        requireAuth();
        $user = getCurrentUser();
        if (!$user || !in_array(normalizeRole($user['type']), ['Admin', 'Landlord'])) {
            sendJSON(['error' => 'Forbidden'], 403);
        }
        if (normalizeRole($user['type']) === 'Landlord') {
            $room = Room::find($id);
            if (!$room || $room['landlord_id'] != $user['id']) {
                sendJSON(['error' => 'You can only update your own rooms'], 403);
            }
        }
        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data) {
            sendJSON(['error' => 'Invalid JSON'], 400);
        }
        // The House ID is permanent once generated (Part 23/46 of the
        // brief) - never regenerated or overwritten by an edit, no matter
        // what a client sends.
        unset($data['id'], $data['house_id']);
        if (Room::update($id, $data)) {
            sendJSON(['success' => true]);
        } else {
            sendJSON(['error' => 'Update failed'], 500);
        }
    }

    public static function delete($id) {
        requireAuth();
        $user = getCurrentUser();
        if (!$user || !in_array(normalizeRole($user['type']), ['Admin', 'Landlord'])) {
            sendJSON(['error' => 'Forbidden'], 403);
        }
        if (normalizeRole($user['type']) === 'Landlord') {
            $room = Room::find($id);
            if (!$room || $room['landlord_id'] != $user['id']) {
                sendJSON(['error' => 'You can only delete your own rooms'], 403);
            }
        }
        if (Room::delete($id)) {
            sendJSON(['success' => true]);
        } else {
            sendJSON(['error' => 'Delete failed'], 500);
        }
    }

    /** Admin, or the Landlord who owns this room - never anyone else. */
    private static function authorizeRoomManagement($id) {
        requireAuth();
        $user = getCurrentUser();
        $room = Room::find($id);
        if (!$room) {
            sendJSON(['error' => 'Not found'], 404);
        }
        $role = normalizeRole($user['type'] ?? '');
        if ($role === 'Admin') {
            return $room;
        }
        if ($role === 'Landlord' && (int) $room['landlord_id'] === (int) $user['id']) {
            return $room;
        }
        sendJSON(['error' => 'Forbidden - only Admin or the owning Landlord can manage this room\'s images'], 403);
    }

    /**
     * POST /rooms/{id}/images (multipart, field name "images[]" or
     * "images") - appends one or more new photos to this room's existing
     * gallery without disturbing the images already there.
     */
    public static function addImages($id) {
        $room = self::authorizeRoomManagement($id);

        $files = $_FILES['images'] ?? null;
        if (!$files || empty($files['tmp_name'][0])) {
            // Also accept a single-file field name for convenience.
            $files = isset($_FILES['image']) ? [
                'tmp_name' => [$_FILES['image']['tmp_name'] ?? null],
                'error'    => [$_FILES['image']['error'] ?? UPLOAD_ERR_NO_FILE],
                'size'     => [$_FILES['image']['size'] ?? 0],
            ] : null;
        }
        if (!$files || empty($files['tmp_name'][0])) {
            sendJSON(['error' => 'No images were uploaded.'], 400);
        }

        $uploadsDir = getenv('SMART_RENT_UPLOADS_DIR') ?: (__DIR__ . '/../../uploads');
        if (!is_dir($uploadsDir)) {
            mkdir($uploadsDir, 0755, true);
        }

        $newPaths = [];
        foreach ($files['tmp_name'] as $index => $tmp) {
            $fileEntry = [
                'tmp_name' => $tmp,
                'error'    => $files['error'][$index] ?? UPLOAD_ERR_NO_FILE,
                'size'     => $files['size'][$index] ?? 0,
            ];
            $result = UploadSecurity::validateAndStore($fileEntry, $uploadsDir, 'room');
            if (!$result['ok']) {
                foreach ($newPaths as $rel) {
                    $abs = __DIR__ . '/../../' . $rel;
                    if (is_file($abs)) @unlink($abs);
                }
                sendJSON(['error' => $result['error']], 400);
            }
            $newPaths[] = $result['path'];
        }

        $existing = Room::parseImageList($room['image']);
        $merged = array_merge($existing, $newPaths);
        Room::saveImageList($id, $merged);

        sendJSON(['success' => true, 'images' => $merged]);
    }

    /**
     * DELETE /rooms/{id}/images/{index} - removes exactly one image (by
     * its position in the gallery) from this room. Never deletes the room
     * itself, and never touches any other image.
     */
    public static function deleteImage($id, $index) {
        $room = self::authorizeRoomManagement($id);

        $images = Room::parseImageList($room['image']);
        $index = (int) $index;
        if ($index < 0 || $index >= count($images)) {
            sendJSON(['error' => 'Image index out of range'], 404);
        }

        $removed = $images[$index];
        array_splice($images, $index, 1);
        Room::saveImageList($id, $images);

        // Best-effort physical file cleanup - a missing/already-gone file
        // must never block the (already-persisted) database update above.
        $abs = __DIR__ . '/../../' . ltrim($removed, '/');
        if (is_file($abs)) {
            @unlink($abs);
        }

        sendJSON(['success' => true, 'images' => $images]);
    }
}