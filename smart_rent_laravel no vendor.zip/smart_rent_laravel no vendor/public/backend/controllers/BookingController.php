<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../helpers/functions.php';
require_once __DIR__ . '/../models/Booking.php';

class BookingController {
    public static function getAll() {
        $user = getCurrentUser();
        $bookings = [];
        if (!$user) {
            sendJSON([]);
            return;
        }
        if (normalizeRole($user['type']) === 'Admin') {
            $bookings = Booking::getAll();
        } elseif (normalizeRole($user['type']) === 'Landlord') {
            $all = Booking::getAll();
            $bookings = array_filter($all, function($b) use ($user) {
                return $b['landlord_id'] == $user['id'];
            });
            $bookings = array_values($bookings);
        } else {
            $all = Booking::getAll();
            $bookings = array_filter($all, function($b) use ($user) {
                return $b['user_id'] == $user['id'];
            });
            $bookings = array_values($bookings);
        }
        sendJSON($bookings);
    }

    /**
     * Canonical field => accepted aliases. Lets the booking endpoint accept
     * payloads whose keys don't exactly match the `bookings`/`payments`
     * column names (e.g. an older frontend build, a form post, or a
     * differently-cased field) without silently dropping data.
     */
    private static function fieldAliases(): array {
        return [
            'room_id'          => ['room_id', 'roomId', 'room'],
            'landlord_id'      => ['landlord_id', 'landlordId'],
            'user_id'          => ['user_id', 'userId'],
            'customer_name'    => ['customer_name', 'customerName', 'full_name', 'fullName', 'name'],
            'customer_email'   => ['customer_email', 'customerEmail', 'email'],
            'customer_phone'   => ['customer_phone', 'customerPhone', 'phone', 'mobile', 'msisdn'],
            'amount'           => ['amount', 'total', 'totalAmount', 'total_amount', 'price'],
            'payment_method'   => ['payment_method', 'paymentMethod', 'method'],
            'reference'        => ['reference', 'ref', 'payment_ref', 'paymentRef', 'txn_ref', 'transactionReference'],
            'recipient_number' => ['recipient_number', 'recipientNumber', 'recipient'],
            'arrival_date'     => ['arrival_date', 'arrivalDate'],
        ];
    }

    /** Map any accepted alias onto its canonical column name. */
    private static function normalizeFields(array $data): array {
        $normalized = $data;
        foreach (self::fieldAliases() as $canonical => $aliases) {
            $hasCanonical = isset($normalized[$canonical]) && $normalized[$canonical] !== '';
            if ($hasCanonical) {
                continue;
            }
            foreach ($aliases as $alias) {
                if (isset($data[$alias]) && $data[$alias] !== '') {
                    $normalized[$canonical] = $data[$alias];
                    break;
                }
            }
        }
        return $normalized;
    }

    /**
     * Reads the request body exactly once and supports:
     *  - application/json (and any Content-Type containing "json")
     *  - application/x-www-form-urlencoded
     *  - multipart/form-data (via $_POST, populated by PHP itself)
     * Returns [$data, $parseError]. $parseError is non-null only when the
     * client explicitly declared JSON but sent syntactically invalid JSON,
     * so that case is reported distinctly from "fields were left empty".
     */
    private static function parseIncomingData(): array {
        $rawBody = file_get_contents('php://input');
        $contentType = $_SERVER['CONTENT_TYPE'] ?? ($_SERVER['HTTP_CONTENT_TYPE'] ?? '');
        $trimmed = trim((string) $rawBody);
        $data = [];
        $parseError = null;

        if ($trimmed !== '') {
            $decoded = json_decode($trimmed, true);
            if (is_array($decoded)) {
                $data = $decoded;
            } elseif (stripos($contentType, 'json') !== false) {
                // Client said JSON but it didn't parse - don't silently
                // treat this as "no fields provided".
                $parseError = 'Invalid JSON payload: ' . json_last_error_msg();
            } else {
                parse_str($trimmed, $parsed);
                if (is_array($parsed) && !empty($parsed)) {
                    $data = $parsed;
                }
            }
        }

        if (empty($data) && !empty($_POST)) {
            // multipart/form-data ends up here; php://input is empty for it.
            $data = $_POST;
        }

        error_log('Booking raw body: ' . $rawBody);
        error_log('Booking content-type: ' . $contentType);

        return [$data, $parseError];
    }

    public static function create() {
        requireAuth();

        [$data, $parseError] = self::parseIncomingData();
        if ($parseError !== null) {
            sendJSON(['error' => $parseError], 400);
            return;
        }

        if (!is_array($data)) {
            $data = [];
        }
        $data = array_map(function ($value) {
            return is_string($value) ? trim($value) : $value;
        }, $data);
        $data = self::normalizeFields($data);

        error_log('Booking parsed data: ' . json_encode($data));

        $requiredFields = ['room_id', 'customer_name', 'customer_email', 'customer_phone'];
        $missing = [];
        foreach ($requiredFields as $field) {
            $value = $data[$field] ?? null;
            if ($value === null || $value === '' || (is_string($value) && trim($value) === '')) {
                $missing[] = $field;
            }
        }
        if (!empty($missing)) {
            sendJSON([
                'error' => 'Missing required fields',
                'missing_fields' => $missing,
                'received_fields' => array_keys($data),
            ], 400);
            return;
        }
        if (!empty($data['customer_email']) && !filter_var($data['customer_email'], FILTER_VALIDATE_EMAIL)) {
            sendJSON(['error' => 'Invalid customer_email format', 'field' => 'customer_email'], 400);
            return;
        }
        if (!is_numeric($data['room_id'])) {
            sendJSON(['error' => 'room_id must be numeric', 'field' => 'room_id'], 400);
            return;
        }

        // A booking only exists in this app as the result of a completed
        // payment, so the payment details are required here too. This lets us
        // create the booking, the payment record, AND the room status update
        // as a single atomic transaction: they all succeed together, or none
        // of them happen at all. The room can never end up "taken" while the
        // payment that was supposed to pay for it failed or never happened.
        $missingPayment = [];
        foreach (['payment_method', 'reference'] as $field) {
            if (empty($data[$field])) {
                $missingPayment[] = $field;
            }
        }
        if (!isset($data['amount']) || $data['amount'] === '' || !is_numeric($data['amount'])) {
            $missingPayment[] = 'amount';
        }
        if (!empty($missingPayment)) {
            sendJSON([
                'error' => 'Missing payment details for this booking',
                'missing_fields' => $missingPayment,
            ], 400);
            return;
        }
        require_once __DIR__ . '/../models/Payment.php';
        require_once __DIR__ . '/../models/Receipt.php';

        $user = getCurrentUser();
        if ($user) {
            $data['user_id'] = $user['id'];
        }

        global $pdo;
        // Lock the room row for the duration of this transaction so two
        // simultaneous booking attempts on the same room can't both succeed.
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare("SELECT * FROM rooms WHERE id = ? FOR UPDATE");
            $stmt->execute([$data['room_id']]);
            $room = $stmt->fetch();

            if (!$room) {
                $pdo->rollBack();
                sendJSON(['error' => 'Room not found'], 404);
                return;
            }
            if ($room['status'] !== 'available') {
                $pdo->rollBack();
                sendJSON(['error' => 'This room is no longer available. It may already be booked or ordered.'], 409);
                return;
            }

            if (empty($data['landlord_id'])) {
                $data['landlord_id'] = $room['landlord_id'];
            }

            // 1. Create the booking record. Its status is ALWAYS 'pending'
            //    here, no matter what the client sent - clicking Pay Now
            //    does not, by itself, prove a payment happened. A booking
            //    only becomes 'confirmed' once PaymentController::verify()
            //    (admin, checking the real mobile-money/bank statement) or
            //    PaymentController::webhook() (a signed provider callback)
            //    genuinely confirms the matching payment - see
            //    Booking::syncFromPaymentStatus().
            $data['status'] = 'pending';
            $bookingId = Booking::create($data);

            // 2. Record the payment that's meant to pay for this booking.
            //    Commission is computed here, server-side, from the
            //    admin-configured rate - a client can never supply its own
            //    commission/landlord_amount values; any such fields in the
            //    request body are ignored. The payment itself is recorded
            //    as 'pending': the customer has only just submitted a
            //    reference/confirmation code, and nothing here has actually
            //    verified with a payment gateway or bank/mobile-money
            //    statement yet, so it must never be stored as 'successful'.
            require_once __DIR__ . '/../helpers/CommissionService.php';
            $commission = CommissionService::calculate((float) $data['amount']);

            $paymentId = Payment::create([
                'room_id' => $data['room_id'],
                'user_id' => $data['user_id'] ?? null,
                'landlord_id' => $data['landlord_id'],
                'booking_id' => $bookingId,
                'order_id' => null,
                'amount' => $data['amount'],
                'commission_rate' => $commission['rate'],
                'commission_amount' => $commission['commission'],
                'landlord_amount' => $commission['landlord_amount'],
                'payment_method' => $data['payment_method'],
                'reference' => $data['reference'],
                'status' => 'pending',
                'recipient_number' => $data['recipient_number'] ?? null,
                'customer_name' => $data['customer_name'],
                'customer_email' => $data['customer_email'],
                'customer_phone' => $data['customer_phone'],
            ]);

            // No payout is created here. A payout is only ever created once
            // the payment is genuinely confirmed (PaymentController::verify()
            // / webhook(), via Booking::syncFromPaymentStatus() below in the
            // future) - never at the moment the customer merely submits a
            // reference number.

            // 3. Create a receipt record acknowledging the submission. Its
            //    payment_status honestly reflects that verification is
            //    still pending - it is updated in place once verified (see
            //    Booking::syncFromPaymentStatus()).
            Receipt::create([
                'booking_id' => $bookingId,
                'payment_id' => $paymentId,
                'room_id' => $data['room_id'],
                'user_id' => $data['user_id'] ?? null,
                'landlord_id' => $data['landlord_id'],
                'receipt_number' => 'RCP-' . date('Ymd') . '-' . substr(strtoupper(bin2hex(random_bytes(3))), 0, 6),
                'amount' => $data['amount'],
                'payment_method' => $data['payment_method'],
                'reference' => $data['reference'],
                'customer_name' => $data['customer_name'],
                'customer_email' => $data['customer_email'],
                'customer_phone' => $data['customer_phone'],
                'recipient_number' => $data['recipient_number'] ?? null,
                'status' => 'issued',
                'payment_status' => 'pending',
            ]);

            // 4. Hold the room (not "taken") so nobody else can book it while
            //    this payment is being verified, without pretending it has
            //    already been paid for. It only becomes 'taken' once the
            //    payment is genuinely verified successful.
            $upd = $pdo->prepare("UPDATE rooms SET status = 'booked' WHERE id = ?");
            $upd->execute([$data['room_id']]);

            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log('Booking transaction failed: ' . $e->getMessage());
            sendJSON(['error' => 'The transaction could not be completed, so the room remains available: ' . $e->getMessage()], 500);
            return;
        }

        // status: 'pending' here is honest, not a placeholder - the caller
        // (frontend) must show a "payment pending verification" state, not
        // a success screen, until an admin/webhook actually verifies it.
        sendJSON([
            'success' => true,
            'id' => $bookingId,
            'payment_id' => $paymentId,
            'status' => 'pending',
            'message' => 'Your payment reference has been recorded and is pending verification. The room is held for you while this is confirmed.',
        ]);
    }

    public static function update($id) {
        requireAuth();
        $data = json_decode(file_get_contents('php://input'), true);
        if (empty($data)) {
            sendJSON(['error' => 'No data provided'], 400);
        }
        $user = getCurrentUser();
        if (normalizeRole($user['type'] ?? '') === 'Landlord') {
            $booking = Booking::getAll();
            $booking = current(array_filter($booking, function($item) use ($id) { return (int)$item['id'] === (int)$id; }));
            if (!$booking || (int)$booking['landlord_id'] !== (int)$user['id']) {
                sendJSON(['error' => 'You can only update your own bookings'], 403);
            }
        }
        if (Booking::update($id, $data)) {
            sendJSON(['success' => true]);
        } else {
            sendJSON(['error' => 'Update failed'], 500);
        }
    }

    public static function delete($id) {
        requireAuth();
        $user = getCurrentUser();
        if (normalizeRole($user['type'] ?? '') === 'Landlord') {
            $booking = Booking::getAll();
            $booking = current(array_filter($booking, function($item) use ($id) { return (int)$item['id'] === (int)$id; }));
            if (!$booking || (int)$booking['landlord_id'] !== (int)$user['id']) {
                sendJSON(['error' => 'You can only delete your own bookings'], 403);
            }
        }
        if (Booking::delete($id)) {
            sendJSON(['success' => true]);
        } else {
            sendJSON(['error' => 'Delete failed'], 500);
        }
    }
}