<?php
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../helpers/functions.php';
require_once __DIR__ . '/../models/Order.php';

class OrderController {
    public static function getAll() {
        $user = getCurrentUser();
        $orders = [];
        if (!$user) {
            sendJSON([]);
            return;
        }
        if (normalizeRole($user['type']) === 'Admin') {
            $orders = Order::getAll();
        } elseif (normalizeRole($user['type']) === 'Landlord') {
            $all = Order::getAll();
            $orders = array_filter($all, function($o) use ($user) {
                return $o['landlord_id'] == $user['id'];
            });
            $orders = array_values($orders);
        } else {
            $all = Order::getAll();
            $orders = array_filter($all, function($o) use ($user) {
                return $o['user_id'] == $user['id'];
            });
            $orders = array_values($orders);
        }
        sendJSON($orders);
    }

    public static function create() {
        requireAuth();
        $data = json_decode(file_get_contents('php://input'), true);
        if (empty($data['room_id']) || empty($data['customer_name']) || empty($data['customer_email']) || empty($data['customer_phone'])) {
            sendJSON(['error' => 'Missing required fields'], 400);
        }
        $user = getCurrentUser();
        if ($user) {
            $data['user_id'] = $user['id'];
        }

        global $pdo;
        // Lock the room row and re-check its availability inside a transaction so
        // two simultaneous requests (same customer double-clicking, or two
        // different customers) can never both succeed for the same room.
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare("SELECT * FROM rooms WHERE id = ? FOR UPDATE");
            $stmt->execute([$data['room_id']]);
            $room = $stmt->fetch();

            if (!$room) {
                $pdo->rollBack();
                sendJSON(['error' => 'Room not found'], 404);
                return;
            }
            if ($room['status'] !== 'available') {
                $pdo->rollBack();
                sendJSON(['error' => 'This room is no longer available. It may already be booked or ordered.'], 409);
                return;
            }

            if (empty($data['landlord_id'])) {
                $data['landlord_id'] = $room['landlord_id'];
            }
            $data['status'] = 'ordered';

            $id = Order::create($data);

            $upd = $pdo->prepare("UPDATE rooms SET status = 'ordered' WHERE id = ?");
            $upd->execute([$data['room_id']]);

            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log('Order::create failed: ' . $e->getMessage());
            sendJSON(['error' => 'Failed to place order: ' . $e->getMessage()], 500);
            return;
        }

        sendJSON(['success' => true, 'id' => $id]);
    }

    public static function update($id) {
        requireAuth();
        $data = json_decode(file_get_contents('php://input'), true);
        if (empty($data)) {
            sendJSON(['error' => 'No data provided'], 400);
        }
        $user = getCurrentUser();
        $role = normalizeRole($user['type'] ?? '');

        $order = Order::getAll();
        $order = current(array_filter($order, function($item) use ($id) { return (int)$item['id'] === (int)$id; }));

        if ($role === 'Landlord') {
            if (!$order || (int)$order['landlord_id'] !== (int)$user['id']) {
                sendJSON(['error' => 'You can only update your own orders'], 403);
            }
        } elseif ($role !== 'Admin') {
            // Any non-Landlord, non-Admin role (i.e. Customer) may only
            // touch an order that actually belongs to them.
            if (!$order || (int)($order['user_id'] ?? 0) !== (int)$user['id']) {
                sendJSON(['error' => 'You can only update your own orders'], 403);
            }
        }

        // Only Admin/Landlord may confirm or cancel an order; a customer editing
        // their own order (e.g. arrival date) cannot self-confirm it.
        if (isset($data['status']) && in_array($data['status'], ['confirmed', 'cancelled'], true) && $role !== 'Admin' && $role !== 'Landlord') {
            sendJSON(['error' => 'Only the landlord or an admin can confirm or cancel an order'], 403);
        }

        if (Order::update($id, $data)) {
            // If the order was cancelled, free up the room again so it can be
            // booked/ordered by someone else.
            if (isset($data['status']) && $data['status'] === 'cancelled' && $order) {
                global $pdo;
                $stmt = $pdo->prepare("SELECT status FROM rooms WHERE id = ?");
                $stmt->execute([$order['room_id']]);
                $room = $stmt->fetch();
                if ($room && $room['status'] === 'ordered') {
                    $pdo->prepare("UPDATE rooms SET status = 'available' WHERE id = ?")->execute([$order['room_id']]);
                }
            }
            // Landlord/Admin confirming an order is the trigger for the
            // rental contract: generate it automatically here so the
            // customer finds it waiting on their next "My Contracts" view,
            // rather than requiring landlords to remember a second step.
            if (isset($data['status']) && $data['status'] === 'confirmed') {
                require_once __DIR__ . '/ContractController.php';
                try {
                    ContractController::generateForOrder($id);
                } catch (Throwable $e) {
                    // The order is still confirmed even if contract
                    // generation hits an error - log it rather than fail
                    // the whole request; it can be created manually via
                    // POST contracts afterwards.
                    error_log('Auto contract generation failed for order ' . $id . ': ' . $e->getMessage());
                }
            }
            sendJSON(['success' => true]);
        } else {
            sendJSON(['error' => 'Update failed'], 500);
        }
    }

    public static function delete($id) {
        requireAuth();
        $user = getCurrentUser();
        $order = Order::getAll();
        $order = current(array_filter($order, function($item) use ($id) { return (int)$item['id'] === (int)$id; }));
        $role = normalizeRole($user['type'] ?? '');
        if ($role === 'Landlord') {
            if (!$order || (int)$order['landlord_id'] !== (int)$user['id']) {
                sendJSON(['error' => 'You can only delete your own orders'], 403);
            }
        } elseif ($role !== 'Admin') {
            if (!$order || (int)($order['user_id'] ?? 0) !== (int)$user['id']) {
                sendJSON(['error' => 'You can only delete your own orders'], 403);
            }
        }
        if (Order::delete($id)) {
            // Free up the room again if it was reserved for this order.
            if ($order && !empty($order['room_id'])) {
                global $pdo;
                $stmt = $pdo->prepare("SELECT status FROM rooms WHERE id = ?");
                $stmt->execute([$order['room_id']]);
                $room = $stmt->fetch();
                if ($room && $room['status'] === 'ordered') {
                    $pdo->prepare("UPDATE rooms SET status = 'available' WHERE id = ?")->execute([$order['room_id']]);
                }
            }
            sendJSON(['success' => true]);
        } else {
            sendJSON(['error' => 'Delete failed'], 500);
        }
    }
}